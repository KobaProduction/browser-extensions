// packages/adapters/src/installation-popup.ts
function attachChromeInstallationToggle(host, allowedHost) {
  const button = document.createElement("button");
  button.type = "button";
  button.textContent = "Состояние установки";
  button.setAttribute("aria-label", "Включить или выключить эту версию расширения");
  const feedback = document.createElement("p");
  feedback.setAttribute("role", "status");
  host.append(button, feedback);
  async function currentTab() {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab?.id || !allowedHost.test(tab.url ?? ""))
      throw Error("Open the supported page");
    return tab.id;
  }
  async function refresh() {
    try {
      const id = await currentTab();
      const response = await chrome.tabs.sendMessage(id, {
        type: "koba:installation-status"
      });
      if (typeof response?.enabled !== "boolean")
        throw Error("No active runtime");
      button.textContent = response.enabled ? "Выключить эту версию" : "Включить эту версию";
      button.dataset.enabled = String(response.enabled);
      feedback.textContent = "";
      button.disabled = false;
    } catch {
      feedback.textContent = "Откройте поддерживаемую страницу. Если скрипт ещё не загрузился, обновите её один раз.";
      button.disabled = true;
    }
  }
  button.addEventListener("click", async () => {
    button.disabled = true;
    try {
      const id = await currentTab();
      const enabled = button.dataset.enabled !== "true";
      const answer = await chrome.tabs.sendMessage(id, {
        type: "koba:installation-set-running",
        enabled
      });
      if (!answer?.ok)
        throw Error("Toggle failed");
      await refresh();
    } catch {
      feedback.textContent = "Не удалось переключить установку";
      button.disabled = false;
    }
  });
  refresh();
}
// apps/extension/src/all-in-one-popup.ts
var button = document.getElementById("open");
var status = document.getElementById("status");
button.onclick = async () => {
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab?.id || !/^https:\/\/(?:(?:vk\.ru|vk\.com)\/im|chatgpt\.com\/)/.test(tab.url || "")) {
      status.textContent = "Откройте VK или ChatGPT";
      return;
    }
    await chrome.tabs.sendMessage(tab.id, { type: "koba:open" });
    window.close();
  } catch {
    status.textContent = "Откройте поддерживаемый сайт и обновите вкладку";
  }
};
attachChromeInstallationToggle(document.body, /^https:\/\/(?:vk\.ru\/im|vk\.com\/im|chatgpt\.com\/)/);
