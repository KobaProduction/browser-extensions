function instanceScope() {
  return "all-in-one:dev";
}
function scopedIdentity(base, scope, legacyOwner) {
  if (legacyOwner && scope === legacyOwner)
    return base;
  if (!/^(vk-booster|chatgpt-booster|all-in-one):(dev|prod)$/.test(scope))
    throw new Error("Unsupported Booster instance scope");
  return `${base}:${scope}`;
}
function instanceKey(base, legacyOwner) {
  return scopedIdentity(base, instanceScope(), legacyOwner);
}
function scopedShellIdentity(base, scope, target) {
  const identity = scopedIdentity(base, scope);
  return `${identity}:${target}`;
}
function shellInstanceKey(base) {
  const target = "chromium";
  return scopedShellIdentity(base, instanceScope(), target);
}
var DEFAULT_REMOTE_SESSION_CONFIG = Object.freeze({
  enabled: false,
  mode: "local-only",
  endpoint: "",
  rawEvents: false,
  allowedCommands: Object.freeze([]),
  queueLimit: 1e4,
  inFlightLimit: 8,
  maxAttempts: 8,
  commandTtlMs: 6e4
});
var DEFAULT_AUTOMATION_CONFIGURATION = Object.freeze({
  enabled: false,
  domEvents: false,
  rules: Object.freeze([]),
  remote: DEFAULT_REMOTE_SESSION_CONFIG
});
var object = (value) => !!value && typeof value === "object" && !Array.isArray(value);
var REMOTE_COMMAND_KINDS = Object.freeze([
  "send-message",
  "stop",
  "continue",
  "new-chat",
  "triggers-set",
  "triggers-reset",
  "archive-sync",
  "triggers-list",
  "triggers-get-config",
  "triggers-get",
  "triggers-get-unsaved",
  "triggers-draft-set",
  "triggers-draft-upsert",
  "triggers-draft-remove",
  "triggers-draft-reset",
  "triggers-draft-save",
  "triggers-draft-discard"
]);
var remoteKinds = REMOTE_COMMAND_KINDS;
var eventTypes = [
  "message",
  "api",
  "dom",
  "limit",
  "conflict",
  "completion"
];
var outcomes = [
  "complete",
  "failed",
  "cancelled",
  "context-exhausted"
];
function shape(value, keys2) {
  if (!object(value) || Object.keys(value).some((key) => !keys2.includes(key)))
    throw Error("Invalid automation configuration");
  return value;
}
function text(value, max = 8192, empty = false) {
  if (typeof value !== "string" || value.length > max || !empty && !value.trim())
    throw Error("Invalid automation text");
  return value;
}
function id(value) {
  const result = text(value, 256);
  for (const character of result)
    if (character.charCodeAt(0) < 32)
      throw Error("Invalid automation identity");
  return result;
}
function bool(value, fallback) {
  if (value === void 0)
    return fallback;
  if (typeof value !== "boolean")
    throw Error("Invalid automation flag");
  return value;
}
function integer(value, fallback, min, max) {
  if (value === void 0)
    return fallback;
  if (typeof value !== "number" || !Number.isSafeInteger(value) || value < min || value > max)
    throw Error("Invalid automation limit");
  return value;
}
function normalizeRemoteSessionConfig(input = DEFAULT_REMOTE_SESSION_CONFIG) {
  const value = shape(input, [
    "enabled",
    "mode",
    "endpoint",
    "rawEvents",
    "allowedCommands",
    "queueLimit",
    "inFlightLimit",
    "maxAttempts",
    "commandTtlMs"
  ]);
  const mode = value.mode ?? "local-only";
  if (typeof mode !== "string" || !["local-only", "local-and-remote", "remote-only"].includes(mode))
    throw Error("Invalid remote session mode");
  const endpoint = value.endpoint === void 0 ? "" : text(value.endpoint, 2048, true);
  if (endpoint) {
    const url = new URL(endpoint);
    const loopback = ["localhost", "127.0.0.1", "[::1]"].includes(url.hostname);
    if (url.protocol !== "wss:" && !(url.protocol === "ws:" && loopback) || url.username || url.password || url.search || url.hash)
      throw Error("Invalid remote WebSocket endpoint");
  }
  const commands = value.allowedCommands ?? [];
  if (!Array.isArray(commands) || commands.length > remoteKinds.length || commands.some((kind) => !remoteKinds.includes(kind)) || new Set(commands).size !== commands.length)
    throw Error("Invalid remote command capabilities");
  const enabled = bool(value.enabled, false);
  if (enabled && mode !== "local-only" && !endpoint)
    throw Error("Remote session endpoint is required");
  return {
    enabled,
    mode,
    endpoint,
    rawEvents: bool(value.rawEvents, false),
    allowedCommands: [...commands],
    queueLimit: integer(value.queueLimit, 1e4, 1, 1e5),
    inFlightLimit: integer(value.inFlightLimit, 8, 1, 32),
    maxAttempts: integer(value.maxAttempts, 8, 1, 32),
    commandTtlMs: integer(value.commandTtlMs, 6e4, 1e3, 864e5)
  };
}
function triggerOf(input) {
  const value = shape(input, ["type", "name", "role", "outcome", "pattern"]);
  if (!eventTypes.includes(value.type))
    throw Error("Invalid automation trigger");
  const result = { type: value.type };
  if (value.name !== void 0) {
    if (!["api", "dom", "limit", "conflict"].includes(result.type))
      throw Error("Trigger name is unsupported");
    result.name = text(value.name, 128);
  }
  if (value.role !== void 0) {
    if (result.type !== "message" || typeof value.role !== "string" || !["user", "assistant", "tool"].includes(value.role))
      throw Error("Invalid trigger role");
    result.role = value.role;
  }
  if (value.outcome !== void 0) {
    if (result.type !== "completion" || !outcomes.includes(value.outcome))
      throw Error("Invalid completion trigger");
    result.outcome = value.outcome;
  }
  if (value.pattern !== void 0) {
    const pattern = shape(value.pattern, ["kind", "value", "caseSensitive"]);
    if (result.type !== "message" || pattern.kind !== "contains" && pattern.kind !== "exact")
      throw Error("Invalid message pattern");
    result.pattern = {
      kind: pattern.kind,
      value: text(pattern.value, 512),
      caseSensitive: bool(pattern.caseSensitive, false)
    };
  }
  return result;
}
function actionOf(input) {
  if (!object(input) || typeof input.type !== "string")
    throw Error("Invalid automation action");
  if (input.type === "send-message") {
    const value = shape(input, ["type", "text"]);
    return { type: "send-message", text: text(value.text) };
  }
  if (input.type === "stop") {
    shape(input, ["type"]);
    return { type: "stop" };
  }
  if (input.type === "continue" || input.type === "new-chat") {
    const value = shape(input, input.type === "new-chat" ? ["type", "text", "projectId"] : ["type", "text"]);
    return {
      type: input.type,
      ...value.text !== void 0 ? { text: text(value.text) } : {},
      ...value.projectId !== void 0 ? { projectId: id(value.projectId) } : {}
    };
  }
  if (input.type === "remote-event") {
    const value = shape(input, ["type", "name"]);
    return { type: "remote-event", name: text(value.name, 128) };
  }
  if (input.type === "play-sound") {
    const value = shape(input, ["type", "tone"]);
    if (value.tone !== "soft" && value.tone !== "chime" && value.tone !== "pulse")
      throw Error("Invalid automation sound tone");
    return { type: "play-sound", tone: value.tone };
  }
  throw Error("Unsupported automation action");
}
function validateAutomationRule(input) {
  const value = shape(input, ["id", "label", "enabled", "trigger", "actions", "cooldownMs"]);
  if (!Array.isArray(value.actions) || !value.actions.length || value.actions.length > 8)
    throw Error("Invalid automation action count");
  const ruleId = text(value.id, 64);
  if (!/^[a-zA-Z0-9][a-zA-Z0-9_-]*$/.test(ruleId))
    throw Error("Invalid automation rule identity");
  return {
    id: ruleId,
    label: text(value.label, 128),
    enabled: bool(value.enabled, false),
    trigger: triggerOf(value.trigger),
    actions: value.actions.map(actionOf),
    cooldownMs: integer(value.cooldownMs, 1e3, 0, 864e5)
  };
}
function validateAutomationRules(input) {
  if (!Array.isArray(input) || input.length > 64)
    throw Error("Invalid automation rule count");
  const rules = input.map(validateAutomationRule);
  if (new Set(rules.map((rule) => rule.id)).size !== rules.length)
    throw Error("Duplicate automation rules");
  return rules;
}
var rulesOf = validateAutomationRules;
function normalizeAutomationConfiguration(input = DEFAULT_AUTOMATION_CONFIGURATION) {
  const value = shape(input, ["enabled", "domEvents", "rules", "remote"]);
  return {
    enabled: bool(value.enabled, false),
    domEvents: bool(value.domEvents, false),
    rules: rulesOf(value.rules ?? []),
    remote: normalizeRemoteSessionConfig(value.remote)
  };
}
var APPROVED_SIGNALS = /* @__PURE__ */ new Set([
  "feature.started",
  "feature.stopped",
  "feature.failed",
  "application.notification",
  "application.error",
  "archive.capture.started",
  "archive.capture.completed",
  "archive.capture.failed",
  "archive.export.completed",
  "archive.export.failed",
  "archive.audit.completed",
  "archive.backup.completed",
  "archive.restore.completed"
]);
var SCOPED_TELEMETRY_SCHEMA_VERSION = 1;
function isScopedTelemetryName(name) {
  return APPROVED_SIGNALS.has(name);
}
function isTelemetryProviderId(value) {
  return value === "application" || value === "vk-booster" || value === "chatgpt-booster";
}
function isTelemetryErrorClass(value) {
  return typeof value === "string" && ["network", "permission", "storage", "validation", "cancelled", "internal"].includes(value);
}
class ScopedTelemetry {
  service;
  scope;
  sink;
  enabled = false;
  constructor(service, scope, sink) {
    this.service = service;
    this.scope = scope;
    this.sink = sink;
    if (!/^[a-zA-Z][\w -]{2,64}$/.test(service) || !/^[a-z][a-z0-9-]*:(dev|prod)$/.test(scope))
      throw Error("Invalid telemetry service scope");
  }
  available() {
    return Boolean(this.sink);
  }
  isEnabled() {
    return this.enabled && this.available();
  }
  setEnabled(value) {
    this.enabled = value && this.available();
  }
  async record(name, count, durationMs, context) {
    if (!this.isEnabled() || !this.sink || !isScopedTelemetryName(name))
      return;
    const event = {
      service: this.service,
      serviceId: this.service,
      scope: this.scope,
      productId: this.scope.split(":")[0] ?? "",
      channel: this.scope.endsWith(":dev") ? "dev" : "prod",
      schemaVersion: SCOPED_TELEMETRY_SCHEMA_VERSION,
      name,
      timestamp: Date.now(),
      ...isTelemetryProviderId(context?.providerId) ? { providerId: context.providerId } : {},
      ...isTelemetryErrorClass(context?.errorClass) ? { errorClass: context.errorClass } : {},
      ...Number.isFinite(count) && count !== void 0 && count >= 0 && count <= 1e6 ? { count: Math.floor(count) } : {},
      ...Number.isFinite(durationMs) && durationMs !== void 0 && durationMs >= 0 && durationMs <= 864e5 ? { durationMs: Math.round(durationMs) } : {}
    };
    try {
      await this.sink.send(event);
    } catch {
    }
  }
}
shellInstanceKey("koba:open-feature");
shellInstanceKey("koba:close-shell");
shellInstanceKey("koba:restore-ui");
function normalizeExportOverride(value) {
  if (!value || typeof value !== "object" || Array.isArray(value)) return {};
  const input = value;
  const result = {};
  if (typeof input.format === "string" && /^[a-z0-9][a-z0-9._-]{0,63}$/i.test(input.format.trim()))
    result.format = input.format.trim();
  if (input.level === "conversation" || input.level === "custom" || input.level === "full")
    result.level = input.level;
  if (input.packaging === "none" || input.packaging === "zip" || input.packaging === "gzip")
    result.packaging = input.packaging;
  for (const field of [
    "reasoning",
    "tools",
    "internal",
    "reasoningRecap",
    "reasoningFull",
    "toolCalls",
    "toolResults",
    "toolSourceContent",
    "modelEvidence",
    "dictationEditEvidence",
    "sourceRevisions",
    "attachmentMetadata",
    "images",
    "files"
  ])
    if (typeof input[field] === "boolean") result[field] = input[field];
  return result;
}
function normalizeExportOverrides(value) {
  const incoming = value && typeof value === "object" && !Array.isArray(value) ? value : {};
  const parse = (source) => {
    if (!source || typeof source !== "object" || Array.isArray(source)) return {};
    const accepted = [];
    for (const [key, override2] of Object.entries(source)) {
      try {
        const identity = JSON.parse(key);
        if (!Array.isArray(identity) || identity.length !== 2 || identity.some((part) => typeof part !== "string" || !part || part.trim() !== part))
          continue;
        const normalized = normalizeExportOverride(override2);
        if (Object.keys(normalized).length) accepted.push([key, normalized]);
      } catch {
      }
    }
    return Object.fromEntries(accepted);
  };
  return { projects: parse(incoming.projects), conversations: parse(incoming.conversations) };
}
const DEFAULT_CAPTURE_RULE = {
  enabled: true,
  reasoning: true,
  tools: true,
  internal: true
};
const DEFAULT_EXPORT_OPTIONS = {
  format: "markdown",
  packaging: "none",
  level: "conversation",
  reasoning: true,
  tools: true,
  internal: false,
  reasoningRecap: true,
  reasoningFull: true,
  toolCalls: true,
  toolResults: true,
  toolSourceContent: false,
  modelEvidence: true,
  dictationEditEvidence: false,
  sourceRevisions: false,
  attachmentMetadata: false,
  images: false,
  files: false
};
instanceKey(
  "chatgpt-booster:archive-updated",
  "chatgpt-booster:prod"
);
instanceKey(
  "chatgpt-booster:archive-contract-error",
  "chatgpt-booster:prod"
);
instanceKey("chatgpt-booster:open-archive", "chatgpt-booster:prod");
instanceKey(
  "chatgpt-booster:open-capture-settings",
  "chatgpt-booster:prod"
);
instanceKey(
  "chatgpt-booster:history-loader-state",
  "chatgpt-booster:prod"
);
instanceKey(
  "chatgpt-booster:history-loader-start",
  "chatgpt-booster:prod"
);
instanceKey(
  "chatgpt-booster:history-loader-stop",
  "chatgpt-booster:prod"
);
function normalizeCaptureRule(value) {
  return {
    enabled: value?.enabled === void 0 ? DEFAULT_CAPTURE_RULE.enabled : value.enabled === true,
    reasoning: typeof value?.reasoning === "boolean" ? value.reasoning : true,
    tools: typeof value?.tools === "boolean" ? value.tools : true,
    internal: typeof value?.internal === "boolean" ? value.internal : true
  };
}
function normalizeExportOptions(value) {
  return {
    format: typeof value?.format === "string" && /^[a-z0-9][a-z0-9._-]{0,63}$/i.test(value.format.trim()) ? value.format.trim() : DEFAULT_EXPORT_OPTIONS.format,
    level: value?.level === "custom" || value?.level === "full" ? value.level : "conversation",
    packaging: value?.packaging === "zip" || value?.packaging === "gzip" ? value.packaging : "none",
    reasoning: typeof value?.reasoning === "boolean" ? value.reasoning : true,
    tools: typeof value?.tools === "boolean" ? value.tools : true,
    internal: value?.internal === true,
    reasoningRecap: value?.reasoningRecap !== false,
    reasoningFull: value?.reasoningFull !== false,
    toolCalls: value?.toolCalls !== false,
    toolResults: value?.toolResults !== false,
    toolSourceContent: value?.toolSourceContent === true,
    modelEvidence: value?.modelEvidence !== false,
    dictationEditEvidence: value?.dictationEditEvidence === true,
    sourceRevisions: value?.sourceRevisions === true,
    attachmentMetadata: value?.attachmentMetadata === true,
    images: value?.images === true,
    files: value?.files === true
  };
}
const EMPTY_TRANSPORT_COUNTERS = {
  requestsSent: 0,
  responsesReceived: 0,
  messagesSent: 0,
  messagesReceived: 0,
  errors: 0,
  lastEventAt: null
};
function applyTransportCounterEvent(current, event) {
  const next = { ...current, lastEventAt: event.timestamp };
  if (event.phase === "error" && event.errorClass !== "aborted") next.errors += 1;
  if (event.phase === "request") next.requestsSent += 1;
  if (event.phase === "response") next.responsesReceived += 1;
  if (event.phase === "message" && event.direction === "outbound") next.messagesSent += 1;
  if (event.phase === "message" && event.direction === "inbound") next.messagesReceived += 1;
  return next;
}
function clampRatio(value, fallback = 0.65) {
  return typeof value === "number" && Number.isFinite(value) ? Math.max(0, Math.min(1, value)) : fallback;
}
const SETTINGS_SCHEMA_VERSION = 9;
function clampWindowRatio(value, fallback, min, max) {
  return typeof value === "number" && Number.isFinite(value) ? Math.max(min, Math.min(max, value)) : fallback;
}
function normalizeTone(value, fallback) {
  return value === "soft" || value === "chime" || value === "pulse" ? value : fallback;
}
const DEFAULT_SETTINGS = {
  schemaVersion: SETTINGS_SCHEMA_VERSION,
  enabled: true,
  language: "auto",
  features: {
    messageMetadata: true,
    activityIndicator: true,
    toolInspector: true,
    requestTimer: true
  },
  historyLoader: {
    speedPxPerSecond: 2600,
    burstDurationMs: 650,
    pauseMs: 90
  },
  alerts: {
    enabled: true,
    userSendSound: true,
    responseCompleteSound: true,
    conversationEndSound: true,
    sendTone: "soft",
    completeTone: "chime",
    endTone: "pulse",
    longRunningSound: false,
    longRunningThresholdMs: 12e4
  },
  monitoring: {
    intervalMs: 500
  },
  launcher: {
    x: null,
    y: null,
    side: "right",
    heightRatio: 0.65
  },
  observer: {
    enabled: true,
    captureBodies: false,
    maxBodyChars: 2048
  },
  telemetry: {
    enabled: false,
    endpoint: ""
  },
  automation: {
    ...DEFAULT_AUTOMATION_CONFIGURATION,
    rules: [],
    remote: { ...DEFAULT_AUTOMATION_CONFIGURATION.remote }
  },
  archive: { defaultRule: { ...DEFAULT_CAPTURE_RULE }, projects: {}, conversations: {} },
  export: { ...DEFAULT_EXPORT_OPTIONS },
  exportOverrides: { projects: {}, conversations: {} },
  ui: {
    archiveStart: "latest",
    activeSection: "modules",
    telemetryExpanded: true,
    archiveWindow: {
      xRatio: 0.08,
      yRatio: 0.08,
      widthRatio: 0.72,
      heightRatio: 0.82,
      minimizedSide: "right",
      minimizedHeightRatio: 0.45
    }
  }
};
function normalizeChatGptAutomationConfiguration(value) {
  const normalized = normalizeAutomationConfiguration(value);
  return {
    ...normalized,
    domEvents: false,
    rules: normalized.rules.map(
      (rule) => rule.trigger.type === "dom" ? { ...rule, enabled: false } : rule
    )
  };
}
function normalizeSettings(value) {
  const incomingSchema = value?.schemaVersion ?? 0;
  return {
    ...DEFAULT_SETTINGS,
    ...value,
    schemaVersion: SETTINGS_SCHEMA_VERSION,
    language: value?.language ?? DEFAULT_SETTINGS.language,
    features: {
      ...DEFAULT_SETTINGS.features,
      ...value?.features
    },
    historyLoader: {
      speedPxPerSecond: clampWindowRatio(
        value?.historyLoader?.speedPxPerSecond,
        DEFAULT_SETTINGS.historyLoader.speedPxPerSecond,
        600,
        6e3
      ),
      burstDurationMs: clampWindowRatio(
        value?.historyLoader?.burstDurationMs,
        DEFAULT_SETTINGS.historyLoader.burstDurationMs,
        180,
        1600
      ),
      pauseMs: clampWindowRatio(
        value?.historyLoader?.pauseMs,
        DEFAULT_SETTINGS.historyLoader.pauseMs,
        20,
        1200
      )
    },
    alerts: {
      enabled: value?.alerts?.enabled ?? DEFAULT_SETTINGS.alerts.enabled,
      userSendSound: value?.alerts?.userSendSound ?? DEFAULT_SETTINGS.alerts.userSendSound,
      conversationEndSound: value?.alerts?.conversationEndSound ?? DEFAULT_SETTINGS.alerts.conversationEndSound,
      sendTone: normalizeTone(value?.alerts?.sendTone, DEFAULT_SETTINGS.alerts.sendTone),
      completeTone: normalizeTone(value?.alerts?.completeTone, DEFAULT_SETTINGS.alerts.completeTone),
      endTone: normalizeTone(value?.alerts?.endTone, DEFAULT_SETTINGS.alerts.endTone),
      responseCompleteSound: value?.alerts?.responseCompleteSound ?? DEFAULT_SETTINGS.alerts.responseCompleteSound,
      longRunningSound: value?.alerts?.longRunningSound ?? DEFAULT_SETTINGS.alerts.longRunningSound,
      longRunningThresholdMs: clampWindowRatio(
        value?.alerts?.longRunningThresholdMs,
        DEFAULT_SETTINGS.alerts.longRunningThresholdMs,
        15e3,
        30 * 6e4
      )
    },
    monitoring: {
      intervalMs: clampWindowRatio(
        value?.monitoring?.intervalMs,
        DEFAULT_SETTINGS.monitoring.intervalMs,
        100,
        1e4
      )
    },
    launcher: {
      ...DEFAULT_SETTINGS.launcher,
      // Schema < 3 stored absolute viewport pixels. They are resolution-specific,
      // so migration intentionally discards them instead of pretending they are portable.
      x: null,
      y: null,
      side: incomingSchema >= 3 && value?.launcher?.side === "left" ? "left" : DEFAULT_SETTINGS.launcher.side,
      heightRatio: incomingSchema >= 3 ? clampRatio(value?.launcher?.heightRatio) : DEFAULT_SETTINGS.launcher.heightRatio
    },
    observer: {
      ...DEFAULT_SETTINGS.observer,
      ...value?.observer,
      enabled: value?.observer?.enabled ?? DEFAULT_SETTINGS.observer.enabled
    },
    telemetry: {
      ...DEFAULT_SETTINGS.telemetry,
      ...value?.telemetry,
      endpoint: incomingSchema < 2 ? DEFAULT_SETTINGS.telemetry.endpoint : value?.telemetry?.endpoint ?? DEFAULT_SETTINGS.telemetry.endpoint
    },
    automation: normalizeChatGptAutomationConfiguration(value?.automation),
    archive: {
      defaultRule: normalizeCaptureRule(value?.archive?.defaultRule),
      projects: mergeCaptureRules({}, value?.archive?.projects),
      conversations: mergeCaptureRules({}, value?.archive?.conversations)
    },
    export: normalizeExportOptions(value?.export),
    exportOverrides: normalizeExportOverrides(value?.exportOverrides),
    ui: {
      ...DEFAULT_SETTINGS.ui,
      ...value?.ui,
      activeSection: ["modules", "archive", "sounds", "analytics", "other", "triggers", "remote"].find(
        (section) => section === value?.ui?.activeSection
      ) ?? DEFAULT_SETTINGS.ui.activeSection,
      archiveStart: value?.ui?.archiveStart === "first" ? "first" : "latest",
      archiveWindow: {
        ...DEFAULT_SETTINGS.ui.archiveWindow,
        ...value?.ui?.archiveWindow,
        xRatio: clampWindowRatio(
          value?.ui?.archiveWindow?.xRatio,
          DEFAULT_SETTINGS.ui.archiveWindow.xRatio,
          0,
          0.95
        ),
        yRatio: clampWindowRatio(
          value?.ui?.archiveWindow?.yRatio,
          DEFAULT_SETTINGS.ui.archiveWindow.yRatio,
          0,
          0.95
        ),
        widthRatio: clampWindowRatio(
          value?.ui?.archiveWindow?.widthRatio,
          DEFAULT_SETTINGS.ui.archiveWindow.widthRatio,
          0.32,
          0.96
        ),
        heightRatio: clampWindowRatio(
          value?.ui?.archiveWindow?.heightRatio,
          DEFAULT_SETTINGS.ui.archiveWindow.heightRatio,
          0.4,
          0.96
        ),
        minimizedSide: value?.ui?.archiveWindow?.minimizedSide === "left" ? "left" : "right",
        minimizedHeightRatio: clampRatio(value?.ui?.archiveWindow?.minimizedHeightRatio)
      }
    }
  };
}
function mergeExportOverrides(current, patch) {
  if (!patch) return current;
  const merge = (previous, incoming) => {
    const result = { ...previous };
    for (const [key, update] of Object.entries(incoming ?? {})) {
      if (update === null) delete result[key];
      else result[key] = { ...previous[key], ...update };
    }
    return result;
  };
  return normalizeExportOverrides({
    projects: merge(current.projects, patch.projects),
    conversations: merge(current.conversations, patch.conversations)
  });
}
function mergeSettings(current, patch) {
  const normalized = normalizeSettings(current);
  return normalizeSettings({
    ...normalized,
    ...patch,
    features: {
      ...normalized.features,
      ...patch.features
    },
    historyLoader: {
      ...normalized.historyLoader,
      ...patch.historyLoader
    },
    alerts: {
      ...normalized.alerts,
      ...patch.alerts
    },
    monitoring: {
      ...normalized.monitoring,
      ...patch.monitoring
    },
    launcher: {
      ...normalized.launcher,
      ...patch.launcher
    },
    observer: {
      ...normalized.observer,
      ...patch.observer
    },
    telemetry: {
      ...normalized.telemetry,
      ...patch.telemetry
    },
    automation: {
      ...normalized.automation,
      ...patch.automation,
      remote: { ...normalized.automation.remote, ...patch.automation?.remote }
    },
    archive: {
      defaultRule: { ...normalized.archive.defaultRule, ...patch.archive?.defaultRule },
      projects: mergeCaptureRules(normalized.archive.projects, patch.archive?.projects),
      conversations: mergeCaptureRules(normalized.archive.conversations, patch.archive?.conversations)
    },
    export: { ...normalized.export, ...patch.export },
    exportOverrides: mergeExportOverrides(normalized.exportOverrides, patch.exportOverrides),
    ui: {
      ...normalized.ui,
      ...patch.ui,
      archiveWindow: {
        ...normalized.ui.archiveWindow,
        ...patch.ui?.archiveWindow
      }
    }
  });
}
instanceKey("chatgpt-booster:open-settings", "chatgpt-booster:prod");
function mergeCaptureRules(current, patch) {
  const entries = new Map(Object.entries(current));
  for (const [id2, rule] of Object.entries(patch ?? {})) {
    if (rule === null) entries.delete(id2);
    else if (rule && typeof rule === "object") entries.set(id2, normalizeCaptureRule(rule));
  }
  return Object.fromEntries(entries);
}
var extendStatics = function(d, b) {
  extendStatics = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(d2, b2) {
    d2.__proto__ = b2;
  } || function(d2, b2) {
    for (var p in b2) if (Object.prototype.hasOwnProperty.call(b2, p)) d2[p] = b2[p];
  };
  return extendStatics(d, b);
};
function __extends(d, b) {
  if (typeof b !== "function" && b !== null)
    throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
  extendStatics(d, b);
  function __() {
    this.constructor = d;
  }
  d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
}
var __assign = function() {
  __assign = Object.assign || function __assign2(t) {
    for (var s, i = 1, n = arguments.length; i < n; i++) {
      s = arguments[i];
      for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
    }
    return t;
  };
  return __assign.apply(this, arguments);
};
function __spreadArray(to, from, pack) {
  for (var i = 0, l = from.length, ar; i < l; i++) {
    if (ar || !(i in from)) {
      if (!ar) ar = Array.prototype.slice.call(from, 0, i);
      ar[i] = from[i];
    }
  }
  return to.concat(ar || Array.prototype.slice.call(from));
}
typeof SuppressedError === "function" ? SuppressedError : function(error, suppressed, message) {
  var e = new Error(message);
  return e.name = "SuppressedError", e.error = error, e.suppressed = suppressed, e;
};
var _global = typeof globalThis !== "undefined" ? globalThis : typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : global;
var keys = Object.keys;
var isArray = Array.isArray;
if (typeof Promise !== "undefined" && !_global.Promise) {
  _global.Promise = Promise;
}
function extend(obj, extension) {
  if (typeof extension !== "object")
    return obj;
  keys(extension).forEach(function(key) {
    obj[key] = extension[key];
  });
  return obj;
}
var getProto = Object.getPrototypeOf;
var _hasOwn = {}.hasOwnProperty;
function hasOwn(obj, prop) {
  return _hasOwn.call(obj, prop);
}
function props(proto, extension) {
  if (typeof extension === "function")
    extension = extension(getProto(proto));
  (typeof Reflect === "undefined" ? keys : Reflect.ownKeys)(extension).forEach(function(key) {
    setProp(proto, key, extension[key]);
  });
}
var defineProperty = Object.defineProperty;
function setProp(obj, prop, functionOrGetSet, options) {
  defineProperty(obj, prop, extend(functionOrGetSet && hasOwn(functionOrGetSet, "get") && typeof functionOrGetSet.get === "function" ? {
    get: functionOrGetSet.get,
    set: functionOrGetSet.set,
    configurable: true
  } : { value: functionOrGetSet, configurable: true, writable: true }, options));
}
function derive(Child) {
  return {
    from: function(Parent) {
      Child.prototype = Object.create(Parent.prototype);
      setProp(Child.prototype, "constructor", Child);
      return {
        extend: props.bind(null, Child.prototype)
      };
    }
  };
}
var getOwnPropertyDescriptor = Object.getOwnPropertyDescriptor;
function getPropertyDescriptor(obj, prop) {
  var pd = getOwnPropertyDescriptor(obj, prop);
  var proto;
  return pd || (proto = getProto(obj)) && getPropertyDescriptor(proto, prop);
}
var _slice = [].slice;
function slice(args, start, end) {
  return _slice.call(args, start, end);
}
function override(origFunc, overridedFactory) {
  return overridedFactory(origFunc);
}
function assert(b) {
  if (!b)
    throw new Error("Assertion Failed");
}
function asap$1(fn) {
  if (_global.setImmediate)
    setImmediate(fn);
  else
    setTimeout(fn, 0);
}
function arrayToObject(array, extractor) {
  return array.reduce(function(result, item, i) {
    var nameAndValue = extractor(item, i);
    if (nameAndValue)
      result[nameAndValue[0]] = nameAndValue[1];
    return result;
  }, {});
}
function getByKeyPath(obj, keyPath) {
  if (typeof keyPath === "string" && hasOwn(obj, keyPath))
    return obj[keyPath];
  if (!keyPath)
    return obj;
  if (typeof keyPath !== "string") {
    var rv = [];
    for (var i = 0, l = keyPath.length; i < l; ++i) {
      var val = getByKeyPath(obj, keyPath[i]);
      rv.push(val);
    }
    return rv;
  }
  var period = keyPath.indexOf(".");
  if (period !== -1) {
    var innerObj = obj[keyPath.substr(0, period)];
    return innerObj == null ? void 0 : getByKeyPath(innerObj, keyPath.substr(period + 1));
  }
  return void 0;
}
function setByKeyPath(obj, keyPath, value) {
  if (!obj || keyPath === void 0)
    return;
  if ("isFrozen" in Object && Object.isFrozen(obj))
    return;
  if (typeof keyPath !== "string" && "length" in keyPath) {
    assert(typeof value !== "string" && "length" in value);
    for (var i = 0, l = keyPath.length; i < l; ++i) {
      setByKeyPath(obj, keyPath[i], value[i]);
    }
  } else {
    var period = keyPath.indexOf(".");
    if (period !== -1) {
      var currentKeyPath = keyPath.substr(0, period);
      var remainingKeyPath = keyPath.substr(period + 1);
      if (remainingKeyPath === "")
        if (value === void 0) {
          if (isArray(obj) && !isNaN(parseInt(currentKeyPath)))
            obj.splice(currentKeyPath, 1);
          else
            delete obj[currentKeyPath];
        } else
          obj[currentKeyPath] = value;
      else {
        var innerObj = obj[currentKeyPath];
        if (!innerObj || !hasOwn(obj, currentKeyPath)) {
          if (value === void 0)
            return;
          innerObj = obj[currentKeyPath] = {};
        }
        setByKeyPath(innerObj, remainingKeyPath, value);
      }
    } else {
      if (value === void 0) {
        if (isArray(obj) && !isNaN(parseInt(keyPath)))
          obj.splice(keyPath, 1);
        else
          delete obj[keyPath];
      } else
        obj[keyPath] = value;
    }
  }
}
function delByKeyPath(obj, keyPath) {
  if (typeof keyPath === "string")
    setByKeyPath(obj, keyPath, void 0);
  else if ("length" in keyPath)
    [].map.call(keyPath, function(kp) {
      setByKeyPath(obj, kp, void 0);
    });
}
function shallowClone(obj) {
  var rv = {};
  for (var m in obj) {
    if (hasOwn(obj, m))
      rv[m] = obj[m];
  }
  return rv;
}
var concat = [].concat;
function flatten(a) {
  return concat.apply([], a);
}
var intrinsicTypeNames = "BigUint64Array,BigInt64Array,Array,Boolean,String,Date,RegExp,Blob,File,FileList,FileSystemFileHandle,FileSystemDirectoryHandle,ArrayBuffer,DataView,Uint8ClampedArray,ImageBitmap,ImageData,Map,Set,CryptoKey".split(",").concat(flatten([8, 16, 32, 64].map(function(num) {
  return ["Int", "Uint", "Float"].map(function(t) {
    return t + num + "Array";
  });
}))).filter(function(t) {
  return _global[t];
});
var intrinsicTypes = new Set(intrinsicTypeNames.map(function(t) {
  return _global[t];
}));
function cloneSimpleObjectTree(o) {
  var rv = {};
  for (var k in o)
    if (hasOwn(o, k)) {
      var v = o[k];
      rv[k] = !v || typeof v !== "object" || intrinsicTypes.has(v.constructor) ? v : cloneSimpleObjectTree(v);
    }
  return rv;
}
var circularRefs = null;
function deepClone(any) {
  circularRefs = /* @__PURE__ */ new WeakMap();
  var rv = innerDeepClone(any);
  circularRefs = null;
  return rv;
}
function innerDeepClone(x) {
  if (!x || typeof x !== "object")
    return x;
  var rv = circularRefs.get(x);
  if (rv)
    return rv;
  if (isArray(x)) {
    rv = [];
    circularRefs.set(x, rv);
    for (var i = 0, l = x.length; i < l; ++i) {
      rv.push(innerDeepClone(x[i]));
    }
  } else if (intrinsicTypes.has(x.constructor)) {
    rv = x;
  } else {
    var proto = getProto(x);
    rv = proto === Object.prototype ? {} : Object.create(proto);
    circularRefs.set(x, rv);
    for (var prop in x) {
      if (hasOwn(x, prop)) {
        rv[prop] = innerDeepClone(x[prop]);
      }
    }
  }
  return rv;
}
var toString = {}.toString;
function toStringTag(o) {
  return toString.call(o).slice(8, -1);
}
var iteratorSymbol = typeof Symbol !== "undefined" ? Symbol.iterator : "@@iterator";
var getIteratorOf = typeof iteratorSymbol === "symbol" ? function(x) {
  var i;
  return x != null && (i = x[iteratorSymbol]) && i.apply(x);
} : function() {
  return null;
};
function delArrayItem(a, x) {
  var i = a.indexOf(x);
  if (i >= 0)
    a.splice(i, 1);
  return i >= 0;
}
var NO_CHAR_ARRAY = {};
function getArrayOf(arrayLike) {
  var i, a, x, it;
  if (arguments.length === 1) {
    if (isArray(arrayLike))
      return arrayLike.slice();
    if (this === NO_CHAR_ARRAY && typeof arrayLike === "string")
      return [arrayLike];
    if (it = getIteratorOf(arrayLike)) {
      a = [];
      while (x = it.next(), !x.done)
        a.push(x.value);
      return a;
    }
    if (arrayLike == null)
      return [arrayLike];
    i = arrayLike.length;
    if (typeof i === "number") {
      a = new Array(i);
      while (i--)
        a[i] = arrayLike[i];
      return a;
    }
    return [arrayLike];
  }
  i = arguments.length;
  a = new Array(i);
  while (i--)
    a[i] = arguments[i];
  return a;
}
var isAsyncFunction = typeof Symbol !== "undefined" ? function(fn) {
  return fn[Symbol.toStringTag] === "AsyncFunction";
} : function() {
  return false;
};
var dexieErrorNames = [
  "Modify",
  "Bulk",
  "OpenFailed",
  "VersionChange",
  "Schema",
  "Upgrade",
  "InvalidTable",
  "MissingAPI",
  "NoSuchDatabase",
  "InvalidArgument",
  "SubTransaction",
  "Unsupported",
  "Internal",
  "DatabaseClosed",
  "PrematureCommit",
  "ForeignAwait"
];
var idbDomErrorNames = [
  "Unknown",
  "Constraint",
  "Data",
  "TransactionInactive",
  "ReadOnly",
  "Version",
  "NotFound",
  "InvalidState",
  "InvalidAccess",
  "Abort",
  "Timeout",
  "QuotaExceeded",
  "Syntax",
  "DataClone"
];
var errorList = dexieErrorNames.concat(idbDomErrorNames);
var defaultTexts = {
  VersionChanged: "Database version changed by other database connection",
  DatabaseClosed: "Database has been closed",
  Abort: "Transaction aborted",
  TransactionInactive: "Transaction has already completed or failed",
  MissingAPI: "IndexedDB API missing. Please visit https://tinyurl.com/y2uuvskb"
};
function DexieError(name, msg) {
  this.name = name;
  this.message = msg;
}
derive(DexieError).from(Error).extend({
  toString: function() {
    return this.name + ": " + this.message;
  }
});
function getMultiErrorMessage(msg, failures) {
  return msg + ". Errors: " + Object.keys(failures).map(function(key) {
    return failures[key].toString();
  }).filter(function(v, i, s) {
    return s.indexOf(v) === i;
  }).join("\n");
}
function ModifyError(msg, failures, successCount, failedKeys) {
  this.failures = failures;
  this.failedKeys = failedKeys;
  this.successCount = successCount;
  this.message = getMultiErrorMessage(msg, failures);
}
derive(ModifyError).from(DexieError);
function BulkError(msg, failures) {
  this.name = "BulkError";
  this.failures = Object.keys(failures).map(function(pos) {
    return failures[pos];
  });
  this.failuresByPos = failures;
  this.message = getMultiErrorMessage(msg, this.failures);
}
derive(BulkError).from(DexieError);
var errnames = errorList.reduce(function(obj, name) {
  return obj[name] = name + "Error", obj;
}, {});
var BaseException = DexieError;
var exceptions = errorList.reduce(function(obj, name) {
  var fullName = name + "Error";
  function DexieError2(msgOrInner, inner) {
    this.name = fullName;
    if (!msgOrInner) {
      this.message = defaultTexts[name] || fullName;
      this.inner = null;
    } else if (typeof msgOrInner === "string") {
      this.message = "".concat(msgOrInner).concat(!inner ? "" : "\n " + inner);
      this.inner = inner || null;
    } else if (typeof msgOrInner === "object") {
      this.message = "".concat(msgOrInner.name, " ").concat(msgOrInner.message);
      this.inner = msgOrInner;
    }
  }
  derive(DexieError2).from(BaseException);
  obj[name] = DexieError2;
  return obj;
}, {});
exceptions.Syntax = SyntaxError;
exceptions.Type = TypeError;
exceptions.Range = RangeError;
var exceptionMap = idbDomErrorNames.reduce(function(obj, name) {
  obj[name + "Error"] = exceptions[name];
  return obj;
}, {});
function mapError(domError, message) {
  if (!domError || domError instanceof DexieError || domError instanceof TypeError || domError instanceof SyntaxError || !domError.name || !exceptionMap[domError.name])
    return domError;
  var rv = new exceptionMap[domError.name](message || domError.message, domError);
  if ("stack" in domError) {
    setProp(rv, "stack", {
      get: function() {
        return this.inner.stack;
      }
    });
  }
  return rv;
}
var fullNameExceptions = errorList.reduce(function(obj, name) {
  if (["Syntax", "Type", "Range"].indexOf(name) === -1)
    obj[name + "Error"] = exceptions[name];
  return obj;
}, {});
fullNameExceptions.ModifyError = ModifyError;
fullNameExceptions.DexieError = DexieError;
fullNameExceptions.BulkError = BulkError;
function nop() {
}
function mirror(val) {
  return val;
}
function pureFunctionChain(f1, f2) {
  if (f1 == null || f1 === mirror)
    return f2;
  return function(val) {
    return f2(f1(val));
  };
}
function callBoth(on1, on2) {
  return function() {
    on1.apply(this, arguments);
    on2.apply(this, arguments);
  };
}
function hookCreatingChain(f1, f2) {
  if (f1 === nop)
    return f2;
  return function() {
    var res = f1.apply(this, arguments);
    if (res !== void 0)
      arguments[0] = res;
    var onsuccess = this.onsuccess, onerror = this.onerror;
    this.onsuccess = null;
    this.onerror = null;
    var res2 = f2.apply(this, arguments);
    if (onsuccess)
      this.onsuccess = this.onsuccess ? callBoth(onsuccess, this.onsuccess) : onsuccess;
    if (onerror)
      this.onerror = this.onerror ? callBoth(onerror, this.onerror) : onerror;
    return res2 !== void 0 ? res2 : res;
  };
}
function hookDeletingChain(f1, f2) {
  if (f1 === nop)
    return f2;
  return function() {
    f1.apply(this, arguments);
    var onsuccess = this.onsuccess, onerror = this.onerror;
    this.onsuccess = this.onerror = null;
    f2.apply(this, arguments);
    if (onsuccess)
      this.onsuccess = this.onsuccess ? callBoth(onsuccess, this.onsuccess) : onsuccess;
    if (onerror)
      this.onerror = this.onerror ? callBoth(onerror, this.onerror) : onerror;
  };
}
function hookUpdatingChain(f1, f2) {
  if (f1 === nop)
    return f2;
  return function() {
    var res = f1.apply(this, arguments);
    var modifications = arguments[0];
    extend(modifications, res);
    var onsuccess = this.onsuccess, onerror = this.onerror;
    this.onsuccess = null;
    this.onerror = null;
    var res2 = f2.apply(this, arguments);
    if (onsuccess)
      this.onsuccess = this.onsuccess ? callBoth(onsuccess, this.onsuccess) : onsuccess;
    if (onerror)
      this.onerror = this.onerror ? callBoth(onerror, this.onerror) : onerror;
    return res === void 0 ? res2 === void 0 ? void 0 : res2 : extend(res, res2);
  };
}
function reverseStoppableEventChain(f1, f2) {
  if (f1 === nop)
    return f2;
  return function() {
    if (f2.apply(this, arguments) === false)
      return false;
    return f1.apply(this, arguments);
  };
}
function promisableChain(f1, f2) {
  if (f1 === nop)
    return f2;
  return function() {
    var res = f1.apply(this, arguments);
    if (res && typeof res.then === "function") {
      var thiz = this, i = arguments.length, args = new Array(i);
      while (i--)
        args[i] = arguments[i];
      return res.then(function() {
        return f2.apply(thiz, args);
      });
    }
    return f2.apply(this, arguments);
  };
}
var debug = typeof location !== "undefined" && /^(http|https):\/\/(localhost|127\.0\.0\.1)/.test(location.href);
function setDebug(value, filter) {
  debug = value;
}
var INTERNAL = {};
var ZONE_ECHO_LIMIT = 100, _a$1 = typeof Promise === "undefined" ? [] : (function() {
  var globalP = Promise.resolve();
  if (typeof crypto === "undefined" || !crypto.subtle)
    return [globalP, getProto(globalP), globalP];
  var nativeP = crypto.subtle.digest("SHA-512", new Uint8Array([0]));
  return [nativeP, getProto(nativeP), globalP];
})(), resolvedNativePromise = _a$1[0], nativePromiseProto = _a$1[1], resolvedGlobalPromise = _a$1[2], nativePromiseThen = nativePromiseProto && nativePromiseProto.then;
var NativePromise = resolvedNativePromise && resolvedNativePromise.constructor;
var patchGlobalPromise = !!resolvedGlobalPromise;
function schedulePhysicalTick() {
  queueMicrotask(physicalTick);
}
var asap = function(callback, args) {
  microtickQueue.push([callback, args]);
  if (needsNewPhysicalTick) {
    schedulePhysicalTick();
    needsNewPhysicalTick = false;
  }
};
var isOutsideMicroTick = true, needsNewPhysicalTick = true, unhandledErrors = [], rejectingErrors = [], rejectionMapper = mirror;
var globalPSD = {
  id: "global",
  global: true,
  ref: 0,
  unhandleds: [],
  onunhandled: nop,
  pgp: false,
  env: {},
  finalize: nop
};
var PSD = globalPSD;
var microtickQueue = [];
var numScheduledCalls = 0;
var tickFinalizers = [];
function DexiePromise(fn) {
  if (typeof this !== "object")
    throw new TypeError("Promises must be constructed via new");
  this._listeners = [];
  this._lib = false;
  var psd = this._PSD = PSD;
  if (typeof fn !== "function") {
    if (fn !== INTERNAL)
      throw new TypeError("Not a function");
    this._state = arguments[1];
    this._value = arguments[2];
    if (this._state === false)
      handleRejection(this, this._value);
    return;
  }
  this._state = null;
  this._value = null;
  ++psd.ref;
  executePromiseTask(this, fn);
}
var thenProp = {
  get: function() {
    var psd = PSD, microTaskId = totalEchoes;
    function then(onFulfilled, onRejected) {
      var _this = this;
      var possibleAwait = !psd.global && (psd !== PSD || microTaskId !== totalEchoes);
      var cleanup = possibleAwait && !decrementExpectedAwaits();
      var rv = new DexiePromise(function(resolve, reject) {
        propagateToListener(_this, new Listener(nativeAwaitCompatibleWrap(onFulfilled, psd, possibleAwait, cleanup), nativeAwaitCompatibleWrap(onRejected, psd, possibleAwait, cleanup), resolve, reject, psd));
      });
      if (this._consoleTask)
        rv._consoleTask = this._consoleTask;
      return rv;
    }
    then.prototype = INTERNAL;
    return then;
  },
  set: function(value) {
    setProp(this, "then", value && value.prototype === INTERNAL ? thenProp : {
      get: function() {
        return value;
      },
      set: thenProp.set
    });
  }
};
props(DexiePromise.prototype, {
  then: thenProp,
  _then: function(onFulfilled, onRejected) {
    propagateToListener(this, new Listener(null, null, onFulfilled, onRejected, PSD));
  },
  catch: function(onRejected) {
    if (arguments.length === 1)
      return this.then(null, onRejected);
    var type2 = arguments[0], handler = arguments[1];
    return typeof type2 === "function" ? this.then(null, function(err) {
      return err instanceof type2 ? handler(err) : PromiseReject(err);
    }) : this.then(null, function(err) {
      return err && err.name === type2 ? handler(err) : PromiseReject(err);
    });
  },
  finally: function(onFinally) {
    return this.then(function(value) {
      return DexiePromise.resolve(onFinally()).then(function() {
        return value;
      });
    }, function(err) {
      return DexiePromise.resolve(onFinally()).then(function() {
        return PromiseReject(err);
      });
    });
  },
  timeout: function(ms, msg) {
    var _this = this;
    return ms < Infinity ? new DexiePromise(function(resolve, reject) {
      var handle = setTimeout(function() {
        return reject(new exceptions.Timeout(msg));
      }, ms);
      _this.then(resolve, reject).finally(clearTimeout.bind(null, handle));
    }) : this;
  }
});
if (typeof Symbol !== "undefined" && Symbol.toStringTag)
  setProp(DexiePromise.prototype, Symbol.toStringTag, "Dexie.Promise");
globalPSD.env = snapShot();
function Listener(onFulfilled, onRejected, resolve, reject, zone) {
  this.onFulfilled = typeof onFulfilled === "function" ? onFulfilled : null;
  this.onRejected = typeof onRejected === "function" ? onRejected : null;
  this.resolve = resolve;
  this.reject = reject;
  this.psd = zone;
}
props(DexiePromise, {
  all: function() {
    var values = getArrayOf.apply(null, arguments).map(onPossibleParallellAsync);
    return new DexiePromise(function(resolve, reject) {
      if (values.length === 0)
        resolve([]);
      var remaining = values.length;
      values.forEach(function(a, i) {
        return DexiePromise.resolve(a).then(function(x) {
          values[i] = x;
          if (!--remaining)
            resolve(values);
        }, reject);
      });
    });
  },
  resolve: function(value) {
    if (value instanceof DexiePromise)
      return value;
    if (value && typeof value.then === "function")
      return new DexiePromise(function(resolve, reject) {
        value.then(resolve, reject);
      });
    var rv = new DexiePromise(INTERNAL, true, value);
    return rv;
  },
  reject: PromiseReject,
  race: function() {
    var values = getArrayOf.apply(null, arguments).map(onPossibleParallellAsync);
    return new DexiePromise(function(resolve, reject) {
      values.map(function(value) {
        return DexiePromise.resolve(value).then(resolve, reject);
      });
    });
  },
  PSD: {
    get: function() {
      return PSD;
    },
    set: function(value) {
      return PSD = value;
    }
  },
  totalEchoes: { get: function() {
    return totalEchoes;
  } },
  newPSD: newScope,
  usePSD,
  scheduler: {
    get: function() {
      return asap;
    },
    set: function(value) {
      asap = value;
    }
  },
  rejectionMapper: {
    get: function() {
      return rejectionMapper;
    },
    set: function(value) {
      rejectionMapper = value;
    }
  },
  follow: function(fn, zoneProps) {
    return new DexiePromise(function(resolve, reject) {
      return newScope(function(resolve2, reject2) {
        var psd = PSD;
        psd.unhandleds = [];
        psd.onunhandled = reject2;
        psd.finalize = callBoth(function() {
          var _this = this;
          run_at_end_of_this_or_next_physical_tick(function() {
            _this.unhandleds.length === 0 ? resolve2() : reject2(_this.unhandleds[0]);
          });
        }, psd.finalize);
        fn();
      }, zoneProps, resolve, reject);
    });
  }
});
if (NativePromise) {
  if (NativePromise.allSettled)
    setProp(DexiePromise, "allSettled", function() {
      var possiblePromises = getArrayOf.apply(null, arguments).map(onPossibleParallellAsync);
      return new DexiePromise(function(resolve) {
        if (possiblePromises.length === 0)
          resolve([]);
        var remaining = possiblePromises.length;
        var results = new Array(remaining);
        possiblePromises.forEach(function(p, i) {
          return DexiePromise.resolve(p).then(function(value) {
            return results[i] = { status: "fulfilled", value };
          }, function(reason) {
            return results[i] = { status: "rejected", reason };
          }).then(function() {
            return --remaining || resolve(results);
          });
        });
      });
    });
  if (NativePromise.any && typeof AggregateError !== "undefined")
    setProp(DexiePromise, "any", function() {
      var possiblePromises = getArrayOf.apply(null, arguments).map(onPossibleParallellAsync);
      return new DexiePromise(function(resolve, reject) {
        if (possiblePromises.length === 0)
          reject(new AggregateError([]));
        var remaining = possiblePromises.length;
        var failures = new Array(remaining);
        possiblePromises.forEach(function(p, i) {
          return DexiePromise.resolve(p).then(function(value) {
            return resolve(value);
          }, function(failure) {
            failures[i] = failure;
            if (!--remaining)
              reject(new AggregateError(failures));
          });
        });
      });
    });
  if (NativePromise.withResolvers)
    DexiePromise.withResolvers = NativePromise.withResolvers;
}
function executePromiseTask(promise, fn) {
  try {
    fn(function(value) {
      if (promise._state !== null)
        return;
      if (value === promise)
        throw new TypeError("A promise cannot be resolved with itself.");
      var shouldExecuteTick = promise._lib && beginMicroTickScope();
      if (value && typeof value.then === "function") {
        executePromiseTask(promise, function(resolve, reject) {
          value instanceof DexiePromise ? value._then(resolve, reject) : value.then(resolve, reject);
        });
      } else {
        promise._state = true;
        promise._value = value;
        propagateAllListeners(promise);
      }
      if (shouldExecuteTick)
        endMicroTickScope();
    }, handleRejection.bind(null, promise));
  } catch (ex) {
    handleRejection(promise, ex);
  }
}
function handleRejection(promise, reason) {
  rejectingErrors.push(reason);
  if (promise._state !== null)
    return;
  var shouldExecuteTick = promise._lib && beginMicroTickScope();
  reason = rejectionMapper(reason);
  promise._state = false;
  promise._value = reason;
  addPossiblyUnhandledError(promise);
  propagateAllListeners(promise);
  if (shouldExecuteTick)
    endMicroTickScope();
}
function propagateAllListeners(promise) {
  var listeners = promise._listeners;
  promise._listeners = [];
  for (var i = 0, len = listeners.length; i < len; ++i) {
    propagateToListener(promise, listeners[i]);
  }
  var psd = promise._PSD;
  --psd.ref || psd.finalize();
  if (numScheduledCalls === 0) {
    ++numScheduledCalls;
    asap(function() {
      if (--numScheduledCalls === 0)
        finalizePhysicalTick();
    }, []);
  }
}
function propagateToListener(promise, listener) {
  if (promise._state === null) {
    promise._listeners.push(listener);
    return;
  }
  var cb = promise._state ? listener.onFulfilled : listener.onRejected;
  if (cb === null) {
    return (promise._state ? listener.resolve : listener.reject)(promise._value);
  }
  ++listener.psd.ref;
  ++numScheduledCalls;
  asap(callListener, [cb, promise, listener]);
}
function callListener(cb, promise, listener) {
  try {
    var ret, value = promise._value;
    if (!promise._state && rejectingErrors.length)
      rejectingErrors = [];
    ret = debug && promise._consoleTask ? promise._consoleTask.run(function() {
      return cb(value);
    }) : cb(value);
    if (!promise._state && rejectingErrors.indexOf(value) === -1) {
      markErrorAsHandled(promise);
    }
    listener.resolve(ret);
  } catch (e) {
    listener.reject(e);
  } finally {
    if (--numScheduledCalls === 0)
      finalizePhysicalTick();
    --listener.psd.ref || listener.psd.finalize();
  }
}
function physicalTick() {
  usePSD(globalPSD, function() {
    beginMicroTickScope() && endMicroTickScope();
  });
}
function beginMicroTickScope() {
  var wasRootExec = isOutsideMicroTick;
  isOutsideMicroTick = false;
  needsNewPhysicalTick = false;
  return wasRootExec;
}
function endMicroTickScope() {
  var callbacks, i, l;
  do {
    while (microtickQueue.length > 0) {
      callbacks = microtickQueue;
      microtickQueue = [];
      l = callbacks.length;
      for (i = 0; i < l; ++i) {
        var item = callbacks[i];
        item[0].apply(null, item[1]);
      }
    }
  } while (microtickQueue.length > 0);
  isOutsideMicroTick = true;
  needsNewPhysicalTick = true;
}
function finalizePhysicalTick() {
  var unhandledErrs = unhandledErrors;
  unhandledErrors = [];
  unhandledErrs.forEach(function(p) {
    p._PSD.onunhandled.call(null, p._value, p);
  });
  var finalizers = tickFinalizers.slice(0);
  var i = finalizers.length;
  while (i)
    finalizers[--i]();
}
function run_at_end_of_this_or_next_physical_tick(fn) {
  function finalizer() {
    fn();
    tickFinalizers.splice(tickFinalizers.indexOf(finalizer), 1);
  }
  tickFinalizers.push(finalizer);
  ++numScheduledCalls;
  asap(function() {
    if (--numScheduledCalls === 0)
      finalizePhysicalTick();
  }, []);
}
function addPossiblyUnhandledError(promise) {
  if (!unhandledErrors.some(function(p) {
    return p._value === promise._value;
  }))
    unhandledErrors.push(promise);
}
function markErrorAsHandled(promise) {
  var i = unhandledErrors.length;
  while (i)
    if (unhandledErrors[--i]._value === promise._value) {
      unhandledErrors.splice(i, 1);
      return;
    }
}
function PromiseReject(reason) {
  return new DexiePromise(INTERNAL, false, reason);
}
function wrap(fn, errorCatcher) {
  var psd = PSD;
  return function() {
    var wasRootExec = beginMicroTickScope(), outerScope = PSD;
    try {
      switchToZone(psd, true);
      return fn.apply(this, arguments);
    } catch (e) {
      errorCatcher && errorCatcher(e);
    } finally {
      switchToZone(outerScope, false);
      if (wasRootExec)
        endMicroTickScope();
    }
  };
}
var task = { awaits: 0, echoes: 0, id: 0 };
var taskCounter = 0;
var zoneStack = [];
var zoneEchoes = 0;
var totalEchoes = 0;
var zone_id_counter = 0;
function newScope(fn, props2, a1, a2) {
  var parent = PSD, psd = Object.create(parent);
  psd.parent = parent;
  psd.ref = 0;
  psd.global = false;
  psd.id = ++zone_id_counter;
  globalPSD.env;
  psd.env = patchGlobalPromise ? {
    Promise: DexiePromise,
    PromiseProp: {
      value: DexiePromise,
      configurable: true,
      writable: true
    },
    all: DexiePromise.all,
    race: DexiePromise.race,
    allSettled: DexiePromise.allSettled,
    any: DexiePromise.any,
    resolve: DexiePromise.resolve,
    reject: DexiePromise.reject
  } : {};
  if (props2)
    extend(psd, props2);
  ++parent.ref;
  psd.finalize = function() {
    --this.parent.ref || this.parent.finalize();
  };
  var rv = usePSD(psd, fn, a1, a2);
  if (psd.ref === 0)
    psd.finalize();
  return rv;
}
function incrementExpectedAwaits() {
  if (!task.id)
    task.id = ++taskCounter;
  ++task.awaits;
  task.echoes += ZONE_ECHO_LIMIT;
  return task.id;
}
function decrementExpectedAwaits() {
  if (!task.awaits)
    return false;
  if (--task.awaits === 0)
    task.id = 0;
  task.echoes = task.awaits * ZONE_ECHO_LIMIT;
  return true;
}
if (("" + nativePromiseThen).indexOf("[native code]") === -1) {
  incrementExpectedAwaits = decrementExpectedAwaits = nop;
}
function onPossibleParallellAsync(possiblePromise) {
  if (task.echoes && possiblePromise && possiblePromise.constructor === NativePromise) {
    incrementExpectedAwaits();
    return possiblePromise.then(function(x) {
      decrementExpectedAwaits();
      return x;
    }, function(e) {
      decrementExpectedAwaits();
      return rejection(e);
    });
  }
  return possiblePromise;
}
function zoneEnterEcho(targetZone) {
  ++totalEchoes;
  if (!task.echoes || --task.echoes === 0) {
    task.echoes = task.awaits = task.id = 0;
  }
  zoneStack.push(PSD);
  switchToZone(targetZone, true);
}
function zoneLeaveEcho() {
  var zone = zoneStack[zoneStack.length - 1];
  zoneStack.pop();
  switchToZone(zone, false);
}
function switchToZone(targetZone, bEnteringZone) {
  var currentZone = PSD;
  if (bEnteringZone ? task.echoes && (!zoneEchoes++ || targetZone !== PSD) : zoneEchoes && (!--zoneEchoes || targetZone !== PSD)) {
    queueMicrotask(bEnteringZone ? zoneEnterEcho.bind(null, targetZone) : zoneLeaveEcho);
  }
  if (targetZone === PSD)
    return;
  PSD = targetZone;
  if (currentZone === globalPSD)
    globalPSD.env = snapShot();
  if (patchGlobalPromise) {
    var GlobalPromise = globalPSD.env.Promise;
    var targetEnv = targetZone.env;
    if (currentZone.global || targetZone.global) {
      Object.defineProperty(_global, "Promise", targetEnv.PromiseProp);
      GlobalPromise.all = targetEnv.all;
      GlobalPromise.race = targetEnv.race;
      GlobalPromise.resolve = targetEnv.resolve;
      GlobalPromise.reject = targetEnv.reject;
      if (targetEnv.allSettled)
        GlobalPromise.allSettled = targetEnv.allSettled;
      if (targetEnv.any)
        GlobalPromise.any = targetEnv.any;
    }
  }
}
function snapShot() {
  var GlobalPromise = _global.Promise;
  return patchGlobalPromise ? {
    Promise: GlobalPromise,
    PromiseProp: Object.getOwnPropertyDescriptor(_global, "Promise"),
    all: GlobalPromise.all,
    race: GlobalPromise.race,
    allSettled: GlobalPromise.allSettled,
    any: GlobalPromise.any,
    resolve: GlobalPromise.resolve,
    reject: GlobalPromise.reject
  } : {};
}
function usePSD(psd, fn, a1, a2, a3) {
  var outerScope = PSD;
  try {
    switchToZone(psd, true);
    return fn(a1, a2, a3);
  } finally {
    switchToZone(outerScope, false);
  }
}
function nativeAwaitCompatibleWrap(fn, zone, possibleAwait, cleanup) {
  return typeof fn !== "function" ? fn : function() {
    var outerZone = PSD;
    if (possibleAwait)
      incrementExpectedAwaits();
    switchToZone(zone, true);
    try {
      return fn.apply(this, arguments);
    } finally {
      switchToZone(outerZone, false);
      if (cleanup)
        queueMicrotask(decrementExpectedAwaits);
    }
  };
}
function execInGlobalContext(cb) {
  if (Promise === NativePromise && task.echoes === 0) {
    if (zoneEchoes === 0) {
      cb();
    } else {
      enqueueNativeMicroTask(cb);
    }
  } else {
    setTimeout(cb, 0);
  }
}
var rejection = DexiePromise.reject;
function tempTransaction(db, mode, storeNames, fn) {
  if (!db.idbdb || !db._state.openComplete && !PSD.letThrough && !db._vip) {
    if (db._state.openComplete) {
      return rejection(new exceptions.DatabaseClosed(db._state.dbOpenError));
    }
    if (!db._state.isBeingOpened) {
      if (!db._state.autoOpen)
        return rejection(new exceptions.DatabaseClosed());
      db.open().catch(nop);
    }
    return db._state.dbReadyPromise.then(function() {
      return tempTransaction(db, mode, storeNames, fn);
    });
  } else {
    var trans = db._createTransaction(mode, storeNames, db._dbSchema);
    try {
      trans.create();
      db._state.PR1398_maxLoop = 3;
    } catch (ex) {
      if (ex.name === errnames.InvalidState && db.isOpen() && --db._state.PR1398_maxLoop > 0) {
        console.warn("Dexie: Need to reopen db");
        db.close({ disableAutoOpen: false });
        return db.open().then(function() {
          return tempTransaction(db, mode, storeNames, fn);
        });
      }
      return rejection(ex);
    }
    return trans._promise(mode, function(resolve, reject) {
      return newScope(function() {
        PSD.trans = trans;
        return fn(resolve, reject, trans);
      });
    }).then(function(result) {
      if (mode === "readwrite")
        try {
          trans.idbtrans.commit();
        } catch (_a2) {
        }
      return mode === "readonly" ? result : trans._completion.then(function() {
        return result;
      });
    });
  }
}
var DEXIE_VERSION = "4.4.6";
var maxString = String.fromCharCode(65535);
var minKey = -Infinity;
var INVALID_KEY_ARGUMENT = "Invalid key provided. Keys must be of type string, number, Date or Array<string | number | Date>.";
var STRING_EXPECTED = "String expected.";
var DEFAULT_MAX_CONNECTIONS = 1e3;
var DBNAMES_DB = "__dbnames";
var READONLY = "readonly";
var READWRITE = "readwrite";
function combine(filter1, filter2) {
  return filter1 ? filter2 ? function() {
    return filter1.apply(this, arguments) && filter2.apply(this, arguments);
  } : filter1 : filter2;
}
var AnyRange = {
  type: 3,
  lower: -Infinity,
  lowerOpen: false,
  upper: [[]],
  upperOpen: false
};
function workaroundForUndefinedPrimKey(keyPath) {
  return typeof keyPath === "string" && !/\./.test(keyPath) ? function(obj) {
    if (obj[keyPath] === void 0 && keyPath in obj) {
      obj = deepClone(obj);
      delete obj[keyPath];
    }
    return obj;
  } : function(obj) {
    return obj;
  };
}
function Entity() {
  throw exceptions.Type("Entity instances must never be new:ed. Instances are generated by the framework bypassing the constructor.");
}
function cmp(a, b) {
  try {
    var ta = type(a);
    var tb = type(b);
    if (ta !== tb) {
      if (ta === "Array")
        return 1;
      if (tb === "Array")
        return -1;
      if (ta === "binary")
        return 1;
      if (tb === "binary")
        return -1;
      if (ta === "string")
        return 1;
      if (tb === "string")
        return -1;
      if (ta === "Date")
        return 1;
      if (tb !== "Date")
        return NaN;
      return -1;
    }
    switch (ta) {
      case "number":
      case "Date":
      case "string":
        return a > b ? 1 : a < b ? -1 : 0;
      case "binary": {
        return compareUint8Arrays(getUint8Array(a), getUint8Array(b));
      }
      case "Array":
        return compareArrays(a, b);
    }
  } catch (_a2) {
  }
  return NaN;
}
function compareArrays(a, b) {
  var al = a.length;
  var bl = b.length;
  var l = al < bl ? al : bl;
  for (var i = 0; i < l; ++i) {
    var res = cmp(a[i], b[i]);
    if (res !== 0)
      return res;
  }
  return al === bl ? 0 : al < bl ? -1 : 1;
}
function compareUint8Arrays(a, b) {
  var al = a.length;
  var bl = b.length;
  var l = al < bl ? al : bl;
  for (var i = 0; i < l; ++i) {
    if (a[i] !== b[i])
      return a[i] < b[i] ? -1 : 1;
  }
  return al === bl ? 0 : al < bl ? -1 : 1;
}
function type(x) {
  var t = typeof x;
  if (t !== "object")
    return t;
  if (ArrayBuffer.isView(x))
    return "binary";
  var tsTag = toStringTag(x);
  return tsTag === "ArrayBuffer" ? "binary" : tsTag;
}
function getUint8Array(a) {
  if (a instanceof Uint8Array)
    return a;
  if (ArrayBuffer.isView(a))
    return new Uint8Array(a.buffer, a.byteOffset, a.byteLength);
  return new Uint8Array(a);
}
function builtInDeletionTrigger(table, keys2, res) {
  var yProps = table.schema.yProps;
  if (!yProps)
    return res;
  if (keys2 && res.numFailures > 0)
    keys2 = keys2.filter(function(_, i) {
      return !res.failures[i];
    });
  return Promise.all(yProps.map(function(_a2) {
    var updatesTable = _a2.updatesTable;
    return keys2 ? table.db.table(updatesTable).where("k").anyOf(keys2).delete() : table.db.table(updatesTable).clear();
  })).then(function() {
    return res;
  });
}
var PropModification = (function() {
  function PropModification2(spec) {
    this["@@propmod"] = spec;
  }
  PropModification2.prototype.execute = function(value) {
    var _a2;
    var spec = this["@@propmod"];
    if (spec.add !== void 0) {
      var term = spec.add;
      if (isArray(term)) {
        return __spreadArray(__spreadArray([], isArray(value) ? value : [], true), term).sort();
      }
      if (typeof term === "number")
        return (Number(value) || 0) + term;
      if (typeof term === "bigint") {
        try {
          return BigInt(value) + term;
        } catch (_b) {
          return BigInt(0) + term;
        }
      }
      throw new TypeError("Invalid term ".concat(term));
    }
    if (spec.remove !== void 0) {
      var subtrahend_1 = spec.remove;
      if (isArray(subtrahend_1)) {
        return isArray(value) ? value.filter(function(item) {
          return !subtrahend_1.includes(item);
        }).sort() : [];
      }
      if (typeof subtrahend_1 === "number")
        return Number(value) - subtrahend_1;
      if (typeof subtrahend_1 === "bigint") {
        try {
          return BigInt(value) - subtrahend_1;
        } catch (_c) {
          return BigInt(0) - subtrahend_1;
        }
      }
      throw new TypeError("Invalid subtrahend ".concat(subtrahend_1));
    }
    var prefixToReplace = (_a2 = spec.replacePrefix) === null || _a2 === void 0 ? void 0 : _a2[0];
    if (prefixToReplace && typeof value === "string" && value.startsWith(prefixToReplace)) {
      return spec.replacePrefix[1] + value.substring(prefixToReplace.length);
    }
    return value;
  };
  return PropModification2;
})();
function applyUpdateSpec(obj, changes) {
  var keyPaths = keys(changes);
  var numKeys = keyPaths.length;
  var anythingModified = false;
  for (var i = 0; i < numKeys; ++i) {
    var keyPath = keyPaths[i];
    var value = changes[keyPath];
    var origValue = getByKeyPath(obj, keyPath);
    if (value instanceof PropModification) {
      setByKeyPath(obj, keyPath, value.execute(origValue));
      anythingModified = true;
    } else if (origValue !== value) {
      setByKeyPath(obj, keyPath, value);
      anythingModified = true;
    }
  }
  return anythingModified;
}
var Table = (function() {
  function Table2() {
  }
  Table2.prototype._trans = function(mode, fn, writeLocked) {
    var trans = this._tx || PSD.trans;
    var tableName = this.name;
    var task2 = debug && typeof console !== "undefined" && console.createTask && console.createTask("Dexie: ".concat(mode === "readonly" ? "read" : "write", " ").concat(this.name));
    function checkTableInTransaction(resolve, reject, trans2) {
      if (!trans2.schema[tableName])
        throw new exceptions.NotFound("Table " + tableName + " not part of transaction");
      return fn(trans2.idbtrans, trans2);
    }
    var wasRootExec = beginMicroTickScope();
    try {
      var p = trans && trans.db._novip === this.db._novip ? trans === PSD.trans ? trans._promise(mode, checkTableInTransaction, writeLocked) : newScope(function() {
        return trans._promise(mode, checkTableInTransaction, writeLocked);
      }, { trans, transless: PSD.transless || PSD }) : tempTransaction(this.db, mode, [this.name], checkTableInTransaction);
      if (task2) {
        p._consoleTask = task2;
        p = p.catch(function(err) {
          console.trace(err);
          return rejection(err);
        });
      }
      return p;
    } finally {
      if (wasRootExec)
        endMicroTickScope();
    }
  };
  Table2.prototype.get = function(keyOrCrit, cb) {
    var _this = this;
    if (keyOrCrit && keyOrCrit.constructor === Object)
      return this.where(keyOrCrit).first(cb);
    if (keyOrCrit == null)
      return rejection(new exceptions.Type("Invalid argument to Table.get()"));
    return this._trans("readonly", function(trans) {
      return _this.core.get({ trans, key: keyOrCrit }).then(function(res) {
        return _this.hook.reading.fire(res);
      });
    }).then(cb);
  };
  Table2.prototype.where = function(indexOrCrit) {
    if (typeof indexOrCrit === "string")
      return new this.db.WhereClause(this, indexOrCrit);
    if (isArray(indexOrCrit))
      return new this.db.WhereClause(this, "[".concat(indexOrCrit.join("+"), "]"));
    var keyPaths = keys(indexOrCrit);
    if (keyPaths.length === 1)
      return this.where(keyPaths[0]).equals(indexOrCrit[keyPaths[0]]);
    var compoundIndex = this.schema.indexes.concat(this.schema.primKey).filter(function(ix) {
      if (ix.compound && keyPaths.every(function(keyPath) {
        return ix.keyPath.indexOf(keyPath) >= 0;
      })) {
        for (var i = 0; i < keyPaths.length; ++i) {
          if (keyPaths.indexOf(ix.keyPath[i]) === -1)
            return false;
        }
        return true;
      }
      return false;
    }).sort(function(a, b) {
      return a.keyPath.length - b.keyPath.length;
    })[0];
    if (compoundIndex && this.db._maxKey !== maxString) {
      var keyPathsInValidOrder = compoundIndex.keyPath.slice(0, keyPaths.length);
      return this.where(keyPathsInValidOrder).equals(keyPathsInValidOrder.map(function(kp) {
        return indexOrCrit[kp];
      }));
    }
    if (!compoundIndex && debug)
      console.warn("The query ".concat(JSON.stringify(indexOrCrit), " on ").concat(this.name, " would benefit from a ") + "compound index [".concat(keyPaths.join("+"), "]"));
    var idxByName = this.schema.idxByName;
    function equals(a, b) {
      return cmp(a, b) === 0;
    }
    var _a2 = keyPaths.reduce(function(_a3, keyPath) {
      var prevIndex = _a3[0], prevFilterFn = _a3[1];
      var index = idxByName[keyPath];
      var value = indexOrCrit[keyPath];
      return [
        prevIndex || index,
        prevIndex || !index ? combine(prevFilterFn, index && index.multi ? function(x) {
          var prop = getByKeyPath(x, keyPath);
          return isArray(prop) && prop.some(function(item) {
            return equals(value, item);
          });
        } : function(x) {
          return equals(value, getByKeyPath(x, keyPath));
        }) : prevFilterFn
      ];
    }, [null, null]), idx = _a2[0], filterFunction = _a2[1];
    return idx ? this.where(idx.name).equals(indexOrCrit[idx.keyPath]).filter(filterFunction) : compoundIndex ? this.filter(filterFunction) : this.where(keyPaths).equals("");
  };
  Table2.prototype.filter = function(filterFunction) {
    return this.toCollection().and(filterFunction);
  };
  Table2.prototype.count = function(thenShortcut) {
    return this.toCollection().count(thenShortcut);
  };
  Table2.prototype.offset = function(offset) {
    return this.toCollection().offset(offset);
  };
  Table2.prototype.limit = function(numRows) {
    return this.toCollection().limit(numRows);
  };
  Table2.prototype.each = function(callback) {
    return this.toCollection().each(callback);
  };
  Table2.prototype.toArray = function(thenShortcut) {
    return this.toCollection().toArray(thenShortcut);
  };
  Table2.prototype.toCollection = function() {
    return new this.db.Collection(new this.db.WhereClause(this));
  };
  Table2.prototype.orderBy = function(index) {
    return new this.db.Collection(new this.db.WhereClause(this, isArray(index) ? "[".concat(index.join("+"), "]") : index));
  };
  Table2.prototype.reverse = function() {
    return this.toCollection().reverse();
  };
  Table2.prototype.mapToClass = function(constructor) {
    var _a2 = this, db = _a2.db, tableName = _a2.name;
    this.schema.mappedClass = constructor;
    if (constructor.prototype instanceof Entity) {
      constructor = (function(_super) {
        __extends(class_1, _super);
        function class_1() {
          return _super !== null && _super.apply(this, arguments) || this;
        }
        Object.defineProperty(class_1.prototype, "db", {
          get: function() {
            return db;
          },
          enumerable: false,
          configurable: true
        });
        class_1.prototype.table = function() {
          return tableName;
        };
        return class_1;
      })(constructor);
    }
    var inheritedProps = /* @__PURE__ */ new Set();
    for (var proto = constructor.prototype; proto; proto = getProto(proto)) {
      Object.getOwnPropertyNames(proto).forEach(function(propName) {
        return inheritedProps.add(propName);
      });
    }
    var readHook = function(obj) {
      if (!obj)
        return obj;
      var res = Object.create(constructor.prototype);
      for (var m in obj)
        if (!inheritedProps.has(m))
          try {
            res[m] = obj[m];
          } catch (_) {
          }
      return res;
    };
    if (this.schema.readHook) {
      this.hook.reading.unsubscribe(this.schema.readHook);
    }
    this.schema.readHook = readHook;
    this.hook("reading", readHook);
    return constructor;
  };
  Table2.prototype.defineClass = function() {
    function Class(content) {
      extend(this, content);
    }
    return this.mapToClass(Class);
  };
  Table2.prototype.add = function(obj, key) {
    var _this = this;
    var _a2 = this.schema.primKey, auto = _a2.auto, keyPath = _a2.keyPath;
    var objToAdd = obj;
    if (keyPath && auto) {
      objToAdd = workaroundForUndefinedPrimKey(keyPath)(obj);
    }
    return this._trans("readwrite", function(trans) {
      return _this.core.mutate({
        trans,
        type: "add",
        keys: key != null ? [key] : null,
        values: [objToAdd]
      });
    }).then(function(res) {
      return res.numFailures ? DexiePromise.reject(res.failures[0]) : res.lastResult;
    }).then(function(lastResult) {
      if (keyPath) {
        try {
          setByKeyPath(obj, keyPath, lastResult);
        } catch (_) {
        }
      }
      return lastResult;
    });
  };
  Table2.prototype.upsert = function(key, modifications) {
    var _this = this;
    var keyPath = this.schema.primKey.keyPath;
    return this._trans("readwrite", function(trans) {
      return _this.core.get({ trans, key }).then(function(existing) {
        var obj = existing !== null && existing !== void 0 ? existing : {};
        applyUpdateSpec(obj, modifications);
        if (keyPath)
          setByKeyPath(obj, keyPath, key);
        return _this.core.mutate({
          trans,
          type: "put",
          values: [obj],
          keys: [key],
          upsert: true,
          updates: { keys: [key], changeSpecs: [modifications] }
        }).then(function(res) {
          return res.numFailures ? DexiePromise.reject(res.failures[0]) : !!existing;
        });
      });
    });
  };
  Table2.prototype.update = function(keyOrObject, modifications) {
    if (typeof keyOrObject === "object" && !isArray(keyOrObject)) {
      var key = getByKeyPath(keyOrObject, this.schema.primKey.keyPath);
      if (key === void 0)
        return rejection(new exceptions.InvalidArgument("Given object does not contain its primary key"));
      return this.where(":id").equals(key).modify(modifications);
    } else {
      return this.where(":id").equals(keyOrObject).modify(modifications);
    }
  };
  Table2.prototype.put = function(obj, key) {
    var _this = this;
    var _a2 = this.schema.primKey, auto = _a2.auto, keyPath = _a2.keyPath;
    var objToAdd = obj;
    if (keyPath && auto) {
      objToAdd = workaroundForUndefinedPrimKey(keyPath)(obj);
    }
    return this._trans("readwrite", function(trans) {
      return _this.core.mutate({
        trans,
        type: "put",
        values: [objToAdd],
        keys: key != null ? [key] : null
      });
    }).then(function(res) {
      return res.numFailures ? DexiePromise.reject(res.failures[0]) : res.lastResult;
    }).then(function(lastResult) {
      if (keyPath) {
        try {
          setByKeyPath(obj, keyPath, lastResult);
        } catch (_) {
        }
      }
      return lastResult;
    });
  };
  Table2.prototype.delete = function(key) {
    var _this = this;
    return this._trans("readwrite", function(trans) {
      return _this.core.mutate({ trans, type: "delete", keys: [key] }).then(function(res) {
        return builtInDeletionTrigger(_this, [key], res);
      }).then(function(res) {
        return res.numFailures ? DexiePromise.reject(res.failures[0]) : void 0;
      });
    });
  };
  Table2.prototype.clear = function() {
    var _this = this;
    return this._trans("readwrite", function(trans) {
      return _this.core.mutate({ trans, type: "deleteRange", range: AnyRange }).then(function(res) {
        return builtInDeletionTrigger(_this, null, res);
      });
    }).then(function(res) {
      return res.numFailures ? DexiePromise.reject(res.failures[0]) : void 0;
    });
  };
  Table2.prototype.bulkGet = function(keys2) {
    var _this = this;
    return this._trans("readonly", function(trans) {
      return _this.core.getMany({
        keys: keys2,
        trans
      }).then(function(result) {
        return result.map(function(res) {
          return _this.hook.reading.fire(res);
        });
      });
    });
  };
  Table2.prototype.bulkAdd = function(objects, keysOrOptions, options) {
    var _this = this;
    var keys2 = Array.isArray(keysOrOptions) ? keysOrOptions : void 0;
    options = options || (keys2 ? void 0 : keysOrOptions);
    var wantResults = options ? options.allKeys : void 0;
    return this._trans("readwrite", function(trans) {
      var _a2 = _this.schema.primKey, auto = _a2.auto, keyPath = _a2.keyPath;
      if (keyPath && keys2)
        throw new exceptions.InvalidArgument("bulkAdd(): keys argument invalid on tables with inbound keys");
      if (keys2 && keys2.length !== objects.length)
        throw new exceptions.InvalidArgument("Arguments objects and keys must have the same length");
      var numObjects = objects.length;
      var objectsToAdd = keyPath && auto ? objects.map(workaroundForUndefinedPrimKey(keyPath)) : objects;
      return _this.core.mutate({
        trans,
        type: "add",
        keys: keys2,
        values: objectsToAdd,
        wantResults
      }).then(function(_a3) {
        var numFailures = _a3.numFailures, results = _a3.results, lastResult = _a3.lastResult, failures = _a3.failures;
        var result = wantResults ? results : lastResult;
        if (numFailures === 0)
          return result;
        throw new BulkError("".concat(_this.name, ".bulkAdd(): ").concat(numFailures, " of ").concat(numObjects, " operations failed"), failures);
      });
    });
  };
  Table2.prototype.bulkPut = function(objects, keysOrOptions, options) {
    var _this = this;
    var keys2 = Array.isArray(keysOrOptions) ? keysOrOptions : void 0;
    options = options || (keys2 ? void 0 : keysOrOptions);
    var wantResults = options ? options.allKeys : void 0;
    return this._trans("readwrite", function(trans) {
      var _a2 = _this.schema.primKey, auto = _a2.auto, keyPath = _a2.keyPath;
      if (keyPath && keys2)
        throw new exceptions.InvalidArgument("bulkPut(): keys argument invalid on tables with inbound keys");
      if (keys2 && keys2.length !== objects.length)
        throw new exceptions.InvalidArgument("Arguments objects and keys must have the same length");
      var numObjects = objects.length;
      var objectsToPut = keyPath && auto ? objects.map(workaroundForUndefinedPrimKey(keyPath)) : objects;
      return _this.core.mutate({
        trans,
        type: "put",
        keys: keys2,
        values: objectsToPut,
        wantResults
      }).then(function(_a3) {
        var numFailures = _a3.numFailures, results = _a3.results, lastResult = _a3.lastResult, failures = _a3.failures;
        var result = wantResults ? results : lastResult;
        if (numFailures === 0)
          return result;
        throw new BulkError("".concat(_this.name, ".bulkPut(): ").concat(numFailures, " of ").concat(numObjects, " operations failed"), failures);
      });
    });
  };
  Table2.prototype.bulkUpdate = function(keysAndChanges) {
    var _this = this;
    var coreTable = this.core;
    var keys2 = keysAndChanges.map(function(entry) {
      return entry.key;
    });
    var changeSpecs = keysAndChanges.map(function(entry) {
      return entry.changes;
    });
    var offsetMap = [];
    return this._trans("readwrite", function(trans) {
      return coreTable.getMany({ trans, keys: keys2, cache: "clone" }).then(function(objs) {
        var resultKeys = [];
        var resultObjs = [];
        keysAndChanges.forEach(function(_a2, idx) {
          var key = _a2.key, changes = _a2.changes;
          var obj = objs[idx];
          if (obj) {
            for (var _i = 0, _b = Object.keys(changes); _i < _b.length; _i++) {
              var keyPath = _b[_i];
              var value = changes[keyPath];
              if (keyPath === _this.schema.primKey.keyPath) {
                if (cmp(value, key) !== 0) {
                  throw new exceptions.Constraint("Cannot update primary key in bulkUpdate()");
                }
              } else {
                setByKeyPath(obj, keyPath, value);
              }
            }
            offsetMap.push(idx);
            resultKeys.push(key);
            resultObjs.push(obj);
          }
        });
        var numEntries = resultKeys.length;
        return coreTable.mutate({
          trans,
          type: "put",
          keys: resultKeys,
          values: resultObjs,
          updates: {
            keys: keys2,
            changeSpecs
          }
        }).then(function(_a2) {
          var numFailures = _a2.numFailures, failures = _a2.failures;
          if (numFailures === 0)
            return numEntries;
          for (var _i = 0, _b = Object.keys(failures); _i < _b.length; _i++) {
            var offset = _b[_i];
            var mappedOffset = offsetMap[Number(offset)];
            if (mappedOffset != null) {
              var failure = failures[offset];
              delete failures[offset];
              failures[mappedOffset] = failure;
            }
          }
          throw new BulkError("".concat(_this.name, ".bulkUpdate(): ").concat(numFailures, " of ").concat(numEntries, " operations failed"), failures);
        });
      });
    });
  };
  Table2.prototype.bulkDelete = function(keys2) {
    var _this = this;
    var numKeys = keys2.length;
    return this._trans("readwrite", function(trans) {
      return _this.core.mutate({ trans, type: "delete", keys: keys2 }).then(function(res) {
        return builtInDeletionTrigger(_this, keys2, res);
      });
    }).then(function(_a2) {
      var numFailures = _a2.numFailures, lastResult = _a2.lastResult, failures = _a2.failures;
      if (numFailures === 0)
        return lastResult;
      throw new BulkError("".concat(_this.name, ".bulkDelete(): ").concat(numFailures, " of ").concat(numKeys, " operations failed"), failures);
    });
  };
  return Table2;
})();
function Events(ctx) {
  var evs = {};
  var rv = function(eventName, subscriber) {
    if (subscriber) {
      var i2 = arguments.length, args = new Array(i2 - 1);
      while (--i2)
        args[i2 - 1] = arguments[i2];
      evs[eventName].subscribe.apply(null, args);
      return ctx;
    } else if (typeof eventName === "string") {
      return evs[eventName];
    }
  };
  rv.addEventType = add;
  for (var i = 1, l = arguments.length; i < l; ++i) {
    add(arguments[i]);
  }
  return rv;
  function add(eventName, chainFunction, defaultFunction) {
    if (typeof eventName === "object")
      return addConfiguredEvents(eventName);
    if (!chainFunction)
      chainFunction = reverseStoppableEventChain;
    if (!defaultFunction)
      defaultFunction = nop;
    var context = {
      subscribers: [],
      fire: defaultFunction,
      subscribe: function(cb) {
        if (context.subscribers.indexOf(cb) === -1) {
          context.subscribers.push(cb);
          context.fire = chainFunction(context.fire, cb);
        }
      },
      unsubscribe: function(cb) {
        context.subscribers = context.subscribers.filter(function(fn) {
          return fn !== cb;
        });
        context.fire = context.subscribers.reduce(chainFunction, defaultFunction);
      }
    };
    evs[eventName] = rv[eventName] = context;
    return context;
  }
  function addConfiguredEvents(cfg) {
    keys(cfg).forEach(function(eventName) {
      var args = cfg[eventName];
      if (isArray(args)) {
        add(eventName, cfg[eventName][0], cfg[eventName][1]);
      } else if (args === "asap") {
        var context = add(eventName, mirror, function fire() {
          var i2 = arguments.length, args2 = new Array(i2);
          while (i2--)
            args2[i2] = arguments[i2];
          context.subscribers.forEach(function(fn) {
            asap$1(function fireEvent() {
              fn.apply(null, args2);
            });
          });
        });
      } else
        throw new exceptions.InvalidArgument("Invalid event config");
    });
  }
}
function makeClassConstructor(prototype, constructor) {
  derive(constructor).from({ prototype });
  return constructor;
}
function createTableConstructor(db) {
  return makeClassConstructor(Table.prototype, function Table2(name, tableSchema, trans) {
    this.db = db;
    this._tx = trans;
    this.name = name;
    this.schema = tableSchema;
    this.hook = db._allTables[name] ? db._allTables[name].hook : Events(null, {
      creating: [hookCreatingChain, nop],
      reading: [pureFunctionChain, mirror],
      updating: [hookUpdatingChain, nop],
      deleting: [hookDeletingChain, nop]
    });
  });
}
function isPlainKeyRange(ctx, ignoreLimitFilter) {
  return !(ctx.filter || ctx.algorithm || ctx.or) && (ignoreLimitFilter ? ctx.justLimit : !ctx.replayFilter);
}
function addFilter(ctx, fn) {
  ctx.filter = combine(ctx.filter, fn);
}
function addReplayFilter(ctx, factory, isLimitFilter) {
  var curr = ctx.replayFilter;
  ctx.replayFilter = curr ? function() {
    return combine(curr(), factory());
  } : factory;
  ctx.justLimit = isLimitFilter && !curr;
}
function addMatchFilter(ctx, fn) {
  ctx.isMatch = combine(ctx.isMatch, fn);
}
function getIndexOrStore(ctx, coreSchema) {
  if (ctx.isPrimKey)
    return coreSchema.primaryKey;
  var index = coreSchema.getIndexByKeyPath(ctx.index);
  if (!index)
    throw new exceptions.Schema("KeyPath " + ctx.index + " on object store " + coreSchema.name + " is not indexed");
  return index;
}
function openCursor(ctx, coreTable, trans) {
  var index = getIndexOrStore(ctx, coreTable.schema);
  return coreTable.openCursor({
    trans,
    values: !ctx.keysOnly,
    reverse: ctx.dir === "prev",
    unique: !!ctx.unique,
    query: {
      index,
      range: ctx.range
    }
  });
}
function iter(ctx, fn, coreTrans, coreTable) {
  var filter = ctx.replayFilter ? combine(ctx.filter, ctx.replayFilter()) : ctx.filter;
  if (!ctx.or) {
    return iterate(openCursor(ctx, coreTable, coreTrans), combine(ctx.algorithm, filter), fn, !ctx.keysOnly && ctx.valueMapper);
  } else {
    var set_1 = {};
    var union = function(item, cursor, advance) {
      if (!filter || filter(cursor, advance, function(result) {
        return cursor.stop(result);
      }, function(err) {
        return cursor.fail(err);
      })) {
        var primaryKey = cursor.primaryKey;
        var key = "" + primaryKey;
        if (key === "[object ArrayBuffer]")
          key = "" + new Uint8Array(primaryKey);
        if (!hasOwn(set_1, key)) {
          set_1[key] = true;
          fn(item, cursor, advance);
        }
      }
    };
    return Promise.all([
      ctx.or._iterate(union, coreTrans),
      iterate(openCursor(ctx, coreTable, coreTrans), ctx.algorithm, union, !ctx.keysOnly && ctx.valueMapper)
    ]);
  }
}
function iterate(cursorPromise, filter, fn, valueMapper) {
  var mappedFn = valueMapper ? function(x, c, a) {
    return fn(valueMapper(x), c, a);
  } : fn;
  var wrappedFn = wrap(mappedFn);
  return cursorPromise.then(function(cursor) {
    if (cursor) {
      return cursor.start(function() {
        var c = function() {
          return cursor.continue();
        };
        if (!filter || filter(cursor, function(advancer) {
          return c = advancer;
        }, function(val) {
          cursor.stop(val);
          c = nop;
        }, function(e) {
          cursor.fail(e);
          c = nop;
        }))
          wrappedFn(cursor.value, cursor, function(advancer) {
            return c = advancer;
          });
        c();
      });
    }
  });
}
var Collection = (function() {
  function Collection2() {
  }
  Collection2.prototype._read = function(fn, cb) {
    var ctx = this._ctx;
    return ctx.error ? ctx.table._trans(null, rejection.bind(null, ctx.error)) : ctx.table._trans("readonly", fn).then(cb);
  };
  Collection2.prototype._write = function(fn) {
    var ctx = this._ctx;
    return ctx.error ? ctx.table._trans(null, rejection.bind(null, ctx.error)) : ctx.table._trans("readwrite", fn, "locked");
  };
  Collection2.prototype._addAlgorithm = function(fn) {
    var ctx = this._ctx;
    ctx.algorithm = combine(ctx.algorithm, fn);
  };
  Collection2.prototype._iterate = function(fn, coreTrans) {
    return iter(this._ctx, fn, coreTrans, this._ctx.table.core);
  };
  Collection2.prototype.clone = function(props2) {
    var rv = Object.create(this.constructor.prototype), ctx = Object.create(this._ctx);
    if (props2)
      extend(ctx, props2);
    rv._ctx = ctx;
    return rv;
  };
  Collection2.prototype.raw = function() {
    this._ctx.valueMapper = null;
    return this;
  };
  Collection2.prototype.each = function(fn) {
    var ctx = this._ctx;
    return this._read(function(trans) {
      return iter(ctx, fn, trans, ctx.table.core);
    });
  };
  Collection2.prototype.count = function(cb) {
    var _this = this;
    return this._read(function(trans) {
      var ctx = _this._ctx;
      var coreTable = ctx.table.core;
      if (isPlainKeyRange(ctx, true)) {
        return coreTable.count({
          trans,
          query: {
            index: getIndexOrStore(ctx, coreTable.schema),
            range: ctx.range
          }
        }).then(function(count2) {
          return Math.min(count2, ctx.limit);
        });
      } else {
        var count = 0;
        return iter(ctx, function() {
          ++count;
          return false;
        }, trans, coreTable).then(function() {
          return count;
        });
      }
    }).then(cb);
  };
  Collection2.prototype.sortBy = function(keyPath, cb) {
    var parts = keyPath.split(".").reverse(), lastPart = parts[0], lastIndex = parts.length - 1;
    function getval(obj, i) {
      if (i)
        return getval(obj[parts[i]], i - 1);
      return obj[lastPart];
    }
    var order = this._ctx.dir === "next" ? 1 : -1;
    function sorter(a, b) {
      var aVal = getval(a, lastIndex), bVal = getval(b, lastIndex);
      return cmp(aVal, bVal) * order;
    }
    return this.toArray(function(a) {
      return a.slice().sort(sorter);
    }).then(cb);
  };
  Collection2.prototype.toArray = function(cb) {
    var _this = this;
    return this._read(function(trans) {
      var ctx = _this._ctx;
      if (isPlainKeyRange(ctx, true) && ctx.limit > 0) {
        var valueMapper_1 = ctx.valueMapper;
        var index = getIndexOrStore(ctx, ctx.table.core.schema);
        return ctx.table.core.query({
          trans,
          limit: ctx.limit,
          values: true,
          direction: ctx.dir === "prev" ? "prev" : void 0,
          query: {
            index,
            range: ctx.range
          }
        }).then(function(_a2) {
          var result = _a2.result;
          return valueMapper_1 ? result.map(valueMapper_1) : result;
        });
      } else {
        var a_1 = [];
        return iter(ctx, function(item) {
          return a_1.push(item);
        }, trans, ctx.table.core).then(function() {
          return a_1;
        });
      }
    }, cb);
  };
  Collection2.prototype.offset = function(offset) {
    var ctx = this._ctx;
    if (offset <= 0)
      return this;
    ctx.offset += offset;
    if (isPlainKeyRange(ctx)) {
      addReplayFilter(ctx, function() {
        var offsetLeft = offset;
        return function(cursor, advance) {
          if (offsetLeft === 0)
            return true;
          if (offsetLeft === 1) {
            --offsetLeft;
            return false;
          }
          advance(function() {
            cursor.advance(offsetLeft);
            offsetLeft = 0;
          });
          return false;
        };
      });
    } else {
      addReplayFilter(ctx, function() {
        var offsetLeft = offset;
        return function() {
          return --offsetLeft < 0;
        };
      });
    }
    return this;
  };
  Collection2.prototype.limit = function(numRows) {
    this._ctx.limit = Math.min(this._ctx.limit, numRows);
    addReplayFilter(this._ctx, function() {
      var rowsLeft = numRows;
      return function(cursor, advance, resolve) {
        if (--rowsLeft <= 0)
          advance(resolve);
        return rowsLeft >= 0;
      };
    }, true);
    return this;
  };
  Collection2.prototype.until = function(filterFunction, bIncludeStopEntry) {
    addFilter(this._ctx, function(cursor, advance, resolve) {
      if (filterFunction(cursor.value)) {
        advance(resolve);
        return bIncludeStopEntry;
      } else {
        return true;
      }
    });
    return this;
  };
  Collection2.prototype.first = function(cb) {
    return this.limit(1).toArray(function(a) {
      return a[0];
    }).then(cb);
  };
  Collection2.prototype.last = function(cb) {
    return this.reverse().first(cb);
  };
  Collection2.prototype.filter = function(filterFunction) {
    addFilter(this._ctx, function(cursor) {
      return filterFunction(cursor.value);
    });
    addMatchFilter(this._ctx, filterFunction);
    return this;
  };
  Collection2.prototype.and = function(filter) {
    return this.filter(filter);
  };
  Collection2.prototype.or = function(indexName) {
    return new this.db.WhereClause(this._ctx.table, indexName, this);
  };
  Collection2.prototype.reverse = function() {
    this._ctx.dir = this._ctx.dir === "prev" ? "next" : "prev";
    if (this._ondirectionchange)
      this._ondirectionchange(this._ctx.dir);
    return this;
  };
  Collection2.prototype.desc = function() {
    return this.reverse();
  };
  Collection2.prototype.eachKey = function(cb) {
    var ctx = this._ctx;
    ctx.keysOnly = !ctx.isMatch;
    return this.each(function(val, cursor) {
      cb(cursor.key, cursor);
    });
  };
  Collection2.prototype.eachUniqueKey = function(cb) {
    this._ctx.unique = "unique";
    return this.eachKey(cb);
  };
  Collection2.prototype.eachPrimaryKey = function(cb) {
    var ctx = this._ctx;
    ctx.keysOnly = !ctx.isMatch;
    return this.each(function(val, cursor) {
      cb(cursor.primaryKey, cursor);
    });
  };
  Collection2.prototype.keys = function(cb) {
    var ctx = this._ctx;
    ctx.keysOnly = !ctx.isMatch;
    var a = [];
    return this.each(function(item, cursor) {
      a.push(cursor.key);
    }).then(function() {
      return a;
    }).then(cb);
  };
  Collection2.prototype.primaryKeys = function(cb) {
    var ctx = this._ctx;
    if (isPlainKeyRange(ctx, true) && ctx.limit > 0) {
      return this._read(function(trans) {
        var index = getIndexOrStore(ctx, ctx.table.core.schema);
        return ctx.table.core.query({
          trans,
          values: false,
          limit: ctx.limit,
          direction: ctx.dir === "prev" ? "prev" : void 0,
          query: {
            index,
            range: ctx.range
          }
        });
      }).then(function(_a2) {
        var result = _a2.result;
        return result;
      }).then(cb);
    }
    ctx.keysOnly = !ctx.isMatch;
    var a = [];
    return this.each(function(item, cursor) {
      a.push(cursor.primaryKey);
    }).then(function() {
      return a;
    }).then(cb);
  };
  Collection2.prototype.uniqueKeys = function(cb) {
    this._ctx.unique = "unique";
    return this.keys(cb);
  };
  Collection2.prototype.firstKey = function(cb) {
    return this.limit(1).keys(function(a) {
      return a[0];
    }).then(cb);
  };
  Collection2.prototype.lastKey = function(cb) {
    return this.reverse().firstKey(cb);
  };
  Collection2.prototype.distinct = function() {
    var ctx = this._ctx, idx = ctx.index && ctx.table.schema.idxByName[ctx.index];
    if (!idx || !idx.multi)
      return this;
    var set = {};
    addFilter(this._ctx, function(cursor) {
      var strKey = cursor.primaryKey.toString();
      var found = hasOwn(set, strKey);
      set[strKey] = true;
      return !found;
    });
    return this;
  };
  Collection2.prototype.modify = function(changes) {
    var _this = this;
    var ctx = this._ctx;
    return this._write(function(trans) {
      var modifyer;
      if (typeof changes === "function") {
        modifyer = changes;
      } else {
        modifyer = function(item) {
          return applyUpdateSpec(item, changes);
        };
      }
      var coreTable = ctx.table.core;
      var _a2 = coreTable.schema.primaryKey, outbound = _a2.outbound, extractKey = _a2.extractKey;
      var limit = 200;
      var modifyChunkSize = _this.db._options.modifyChunkSize;
      if (modifyChunkSize) {
        if (typeof modifyChunkSize == "object") {
          limit = modifyChunkSize[coreTable.name] || modifyChunkSize["*"] || 200;
        } else {
          limit = modifyChunkSize;
        }
      }
      var totalFailures = [];
      var successCount = 0;
      var failedKeys = [];
      var applyMutateResult = function(expectedCount, res) {
        var failures = res.failures, numFailures = res.numFailures;
        successCount += expectedCount - numFailures;
        for (var _i = 0, _a3 = keys(failures); _i < _a3.length; _i++) {
          var pos = _a3[_i];
          totalFailures.push(failures[pos]);
        }
      };
      var isUnconditionalDelete = changes === deleteCallback;
      return _this.clone().primaryKeys().then(function(keys2) {
        var criteria = isPlainKeyRange(ctx) && ctx.limit === Infinity && (typeof changes !== "function" || isUnconditionalDelete) && {
          index: ctx.index,
          range: ctx.range
        };
        var nextChunk = function(offset) {
          var count = Math.min(limit, keys2.length - offset);
          var keysInChunk = keys2.slice(offset, offset + count);
          return (isUnconditionalDelete ? Promise.resolve([]) : coreTable.getMany({
            trans,
            keys: keysInChunk,
            cache: "immutable"
          })).then(function(values) {
            var addValues = [];
            var putValues = [];
            var putKeys = outbound ? [] : null;
            var deleteKeys = isUnconditionalDelete ? keysInChunk : [];
            if (!isUnconditionalDelete)
              for (var i = 0; i < count; ++i) {
                var origValue = values[i];
                var ctx_1 = {
                  value: deepClone(origValue),
                  primKey: keys2[offset + i]
                };
                if (modifyer.call(ctx_1, ctx_1.value, ctx_1) !== false) {
                  if (ctx_1.value == null) {
                    deleteKeys.push(keys2[offset + i]);
                  } else if (!outbound && cmp(extractKey(origValue), extractKey(ctx_1.value)) !== 0) {
                    deleteKeys.push(keys2[offset + i]);
                    addValues.push(ctx_1.value);
                  } else {
                    putValues.push(ctx_1.value);
                    if (outbound)
                      putKeys.push(keys2[offset + i]);
                  }
                }
              }
            return Promise.resolve(addValues.length > 0 && coreTable.mutate({ trans, type: "add", values: addValues }).then(function(res) {
              for (var pos in res.failures) {
                deleteKeys.splice(parseInt(pos), 1);
              }
              applyMutateResult(addValues.length, res);
            })).then(function() {
              return (putValues.length > 0 || criteria && typeof changes === "object") && coreTable.mutate({
                trans,
                type: "put",
                keys: putKeys,
                values: putValues,
                criteria,
                changeSpec: typeof changes !== "function" && changes,
                isAdditionalChunk: offset > 0
              }).then(function(res) {
                return applyMutateResult(putValues.length, res);
              });
            }).then(function() {
              return (deleteKeys.length > 0 || criteria && isUnconditionalDelete) && coreTable.mutate({
                trans,
                type: "delete",
                keys: deleteKeys,
                criteria,
                isAdditionalChunk: offset > 0
              }).then(function(res) {
                return builtInDeletionTrigger(ctx.table, deleteKeys, res);
              }).then(function(res) {
                return applyMutateResult(deleteKeys.length, res);
              });
            }).then(function() {
              return keys2.length > offset + count && nextChunk(offset + limit);
            });
          });
        };
        return nextChunk(0).then(function() {
          if (totalFailures.length > 0)
            throw new ModifyError("Error modifying one or more objects", totalFailures, successCount, failedKeys);
          return keys2.length;
        });
      });
    });
  };
  Collection2.prototype.delete = function() {
    var ctx = this._ctx, range = ctx.range;
    if (isPlainKeyRange(ctx) && !ctx.table.schema.yProps && (ctx.isPrimKey || range.type === 3)) {
      return this._write(function(trans) {
        var primaryKey = ctx.table.core.schema.primaryKey;
        var coreRange = range;
        return ctx.table.core.count({ trans, query: { index: primaryKey, range: coreRange } }).then(function(count) {
          return ctx.table.core.mutate({ trans, type: "deleteRange", range: coreRange }).then(function(_a2) {
            var failures = _a2.failures, numFailures = _a2.numFailures;
            if (numFailures)
              throw new ModifyError("Could not delete some values", Object.keys(failures).map(function(pos) {
                return failures[pos];
              }), count - numFailures);
            return count - numFailures;
          });
        });
      });
    }
    return this.modify(deleteCallback);
  };
  return Collection2;
})();
var deleteCallback = function(value, ctx) {
  return ctx.value = null;
};
function createCollectionConstructor(db) {
  return makeClassConstructor(Collection.prototype, function Collection2(whereClause, keyRangeGenerator) {
    this.db = db;
    var keyRange = AnyRange, error = null;
    if (keyRangeGenerator)
      try {
        keyRange = keyRangeGenerator();
      } catch (ex) {
        error = ex;
      }
    var whereCtx = whereClause._ctx;
    var table = whereCtx.table;
    var readingHook = table.hook.reading.fire;
    this._ctx = {
      table,
      index: whereCtx.index,
      isPrimKey: !whereCtx.index || table.schema.primKey.keyPath && whereCtx.index === table.schema.primKey.name,
      range: keyRange,
      keysOnly: false,
      dir: "next",
      unique: "",
      algorithm: null,
      filter: null,
      replayFilter: null,
      justLimit: true,
      isMatch: null,
      offset: 0,
      limit: Infinity,
      error,
      or: whereCtx.or,
      valueMapper: readingHook !== mirror ? readingHook : null
    };
  });
}
function simpleCompare(a, b) {
  return a < b ? -1 : a === b ? 0 : 1;
}
function simpleCompareReverse(a, b) {
  return a > b ? -1 : a === b ? 0 : 1;
}
function fail(collectionOrWhereClause, err, T) {
  var collection = collectionOrWhereClause instanceof WhereClause ? new collectionOrWhereClause.Collection(collectionOrWhereClause) : collectionOrWhereClause;
  collection._ctx.error = T ? new T(err) : new TypeError(err);
  return collection;
}
function emptyCollection(whereClause) {
  return new whereClause.Collection(whereClause, function() {
    return rangeEqual("");
  }).limit(0);
}
function upperFactory(dir) {
  return dir === "next" ? function(s) {
    return s.toUpperCase();
  } : function(s) {
    return s.toLowerCase();
  };
}
function lowerFactory(dir) {
  return dir === "next" ? function(s) {
    return s.toLowerCase();
  } : function(s) {
    return s.toUpperCase();
  };
}
function nextCasing(key, lowerKey, upperNeedle, lowerNeedle, cmp2, dir) {
  var length = Math.min(key.length, lowerNeedle.length);
  var llp = -1;
  for (var i = 0; i < length; ++i) {
    var lwrKeyChar = lowerKey[i];
    if (lwrKeyChar !== lowerNeedle[i]) {
      if (cmp2(key[i], upperNeedle[i]) < 0)
        return key.substr(0, i) + upperNeedle[i] + upperNeedle.substr(i + 1);
      if (cmp2(key[i], lowerNeedle[i]) < 0)
        return key.substr(0, i) + lowerNeedle[i] + upperNeedle.substr(i + 1);
      if (llp >= 0)
        return key.substr(0, llp) + lowerKey[llp] + upperNeedle.substr(llp + 1);
      return null;
    }
    if (cmp2(key[i], lwrKeyChar) < 0)
      llp = i;
  }
  if (length < lowerNeedle.length && dir === "next")
    return key + upperNeedle.substr(key.length);
  if (length < key.length && dir === "prev")
    return key.substr(0, upperNeedle.length);
  return llp < 0 ? null : key.substr(0, llp) + lowerNeedle[llp] + upperNeedle.substr(llp + 1);
}
function addIgnoreCaseAlgorithm(whereClause, match, needles, suffix) {
  var upper, lower, compare, upperNeedles, lowerNeedles, direction, nextKeySuffix, needlesLen = needles.length;
  if (!needles.every(function(s) {
    return typeof s === "string";
  })) {
    return fail(whereClause, STRING_EXPECTED);
  }
  function initDirection(dir) {
    upper = upperFactory(dir);
    lower = lowerFactory(dir);
    compare = dir === "next" ? simpleCompare : simpleCompareReverse;
    var needleBounds = needles.map(function(needle) {
      return { lower: lower(needle), upper: upper(needle) };
    }).sort(function(a, b) {
      return compare(a.lower, b.lower);
    });
    upperNeedles = needleBounds.map(function(nb) {
      return nb.upper;
    });
    lowerNeedles = needleBounds.map(function(nb) {
      return nb.lower;
    });
    direction = dir;
    nextKeySuffix = dir === "next" ? "" : suffix;
  }
  initDirection("next");
  var c = new whereClause.Collection(whereClause, function() {
    return createRange(upperNeedles[0], lowerNeedles[needlesLen - 1] + suffix);
  });
  c._ondirectionchange = function(direction2) {
    initDirection(direction2);
  };
  var firstPossibleNeedle = 0;
  c._addAlgorithm(function(cursor, advance, resolve) {
    var key = cursor.key;
    if (typeof key !== "string")
      return false;
    var lowerKey = lower(key);
    if (match(lowerKey, lowerNeedles, firstPossibleNeedle)) {
      return true;
    } else {
      var lowestPossibleCasing = null;
      for (var i = firstPossibleNeedle; i < needlesLen; ++i) {
        var casing = nextCasing(key, lowerKey, upperNeedles[i], lowerNeedles[i], compare, direction);
        if (casing === null && lowestPossibleCasing === null)
          firstPossibleNeedle = i + 1;
        else if (lowestPossibleCasing === null || compare(lowestPossibleCasing, casing) > 0) {
          lowestPossibleCasing = casing;
        }
      }
      if (lowestPossibleCasing !== null) {
        advance(function() {
          cursor.continue(lowestPossibleCasing + nextKeySuffix);
        });
      } else {
        advance(resolve);
      }
      return false;
    }
  });
  return c;
}
function createRange(lower, upper, lowerOpen, upperOpen) {
  return {
    type: 2,
    lower,
    upper,
    lowerOpen,
    upperOpen
  };
}
function rangeEqual(value) {
  return {
    type: 1,
    lower: value,
    upper: value
  };
}
var WhereClause = (function() {
  function WhereClause2() {
  }
  Object.defineProperty(WhereClause2.prototype, "Collection", {
    get: function() {
      return this._ctx.table.db.Collection;
    },
    enumerable: false,
    configurable: true
  });
  WhereClause2.prototype.between = function(lower, upper, includeLower, includeUpper) {
    includeLower = includeLower !== false;
    includeUpper = includeUpper === true;
    try {
      if (this._cmp(lower, upper) > 0 || this._cmp(lower, upper) === 0 && (includeLower || includeUpper) && !(includeLower && includeUpper))
        return emptyCollection(this);
      return new this.Collection(this, function() {
        return createRange(lower, upper, !includeLower, !includeUpper);
      });
    } catch (e) {
      return fail(this, INVALID_KEY_ARGUMENT);
    }
  };
  WhereClause2.prototype.equals = function(value) {
    if (value == null)
      return fail(this, INVALID_KEY_ARGUMENT);
    return new this.Collection(this, function() {
      return rangeEqual(value);
    });
  };
  WhereClause2.prototype.above = function(value) {
    if (value == null)
      return fail(this, INVALID_KEY_ARGUMENT);
    return new this.Collection(this, function() {
      return createRange(value, void 0, true);
    });
  };
  WhereClause2.prototype.aboveOrEqual = function(value) {
    if (value == null)
      return fail(this, INVALID_KEY_ARGUMENT);
    return new this.Collection(this, function() {
      return createRange(value, void 0, false);
    });
  };
  WhereClause2.prototype.below = function(value) {
    if (value == null)
      return fail(this, INVALID_KEY_ARGUMENT);
    return new this.Collection(this, function() {
      return createRange(void 0, value, false, true);
    });
  };
  WhereClause2.prototype.belowOrEqual = function(value) {
    if (value == null)
      return fail(this, INVALID_KEY_ARGUMENT);
    return new this.Collection(this, function() {
      return createRange(void 0, value);
    });
  };
  WhereClause2.prototype.startsWith = function(str) {
    if (typeof str !== "string")
      return fail(this, STRING_EXPECTED);
    return this.between(str, str + maxString, true, true);
  };
  WhereClause2.prototype.startsWithIgnoreCase = function(str) {
    if (str === "")
      return this.startsWith(str);
    return addIgnoreCaseAlgorithm(this, function(x, a) {
      return x.indexOf(a[0]) === 0;
    }, [str], maxString);
  };
  WhereClause2.prototype.equalsIgnoreCase = function(str) {
    return addIgnoreCaseAlgorithm(this, function(x, a) {
      return x === a[0];
    }, [str], "");
  };
  WhereClause2.prototype.anyOfIgnoreCase = function() {
    var set = getArrayOf.apply(NO_CHAR_ARRAY, arguments);
    if (set.length === 0)
      return emptyCollection(this);
    return addIgnoreCaseAlgorithm(this, function(x, a) {
      return a.indexOf(x) !== -1;
    }, set, "");
  };
  WhereClause2.prototype.startsWithAnyOfIgnoreCase = function() {
    var set = getArrayOf.apply(NO_CHAR_ARRAY, arguments);
    if (set.length === 0)
      return emptyCollection(this);
    return addIgnoreCaseAlgorithm(this, function(x, a) {
      return a.some(function(n) {
        return x.indexOf(n) === 0;
      });
    }, set, maxString);
  };
  WhereClause2.prototype.anyOf = function() {
    var _this = this;
    var set = getArrayOf.apply(NO_CHAR_ARRAY, arguments);
    var compare = this._cmp;
    try {
      set.sort(compare);
    } catch (e) {
      return fail(this, INVALID_KEY_ARGUMENT);
    }
    if (set.length === 0)
      return emptyCollection(this);
    var c = new this.Collection(this, function() {
      return createRange(set[0], set[set.length - 1]);
    });
    c._ondirectionchange = function(direction) {
      compare = direction === "next" ? _this._ascending : _this._descending;
      set.sort(compare);
    };
    var i = 0;
    c._addAlgorithm(function(cursor, advance, resolve) {
      var key = cursor.key;
      while (compare(key, set[i]) > 0) {
        ++i;
        if (i === set.length) {
          advance(resolve);
          return false;
        }
      }
      if (compare(key, set[i]) === 0) {
        return true;
      } else {
        advance(function() {
          cursor.continue(set[i]);
        });
        return false;
      }
    });
    return c;
  };
  WhereClause2.prototype.notEqual = function(value) {
    return this.inAnyRange([
      [minKey, value],
      [value, this.db._maxKey]
    ], { includeLowers: false, includeUppers: false });
  };
  WhereClause2.prototype.noneOf = function() {
    var set = getArrayOf.apply(NO_CHAR_ARRAY, arguments);
    if (set.length === 0)
      return new this.Collection(this);
    try {
      set.sort(this._ascending);
    } catch (e) {
      return fail(this, INVALID_KEY_ARGUMENT);
    }
    var ranges = set.reduce(function(res, val) {
      return res ? res.concat([[res[res.length - 1][1], val]]) : [[minKey, val]];
    }, null);
    ranges.push([set[set.length - 1], this.db._maxKey]);
    return this.inAnyRange(ranges, {
      includeLowers: false,
      includeUppers: false
    });
  };
  WhereClause2.prototype.inAnyRange = function(ranges, options) {
    var _this = this;
    var cmp2 = this._cmp, ascending = this._ascending, descending = this._descending, min = this._min, max = this._max;
    if (ranges.length === 0)
      return emptyCollection(this);
    if (!ranges.every(function(range) {
      return range[0] !== void 0 && range[1] !== void 0 && ascending(range[0], range[1]) <= 0;
    })) {
      return fail(this, "First argument to inAnyRange() must be an Array of two-value Arrays [lower,upper] where upper must not be lower than lower", exceptions.InvalidArgument);
    }
    var includeLowers = !options || options.includeLowers !== false;
    var includeUppers = options && options.includeUppers === true;
    function addRange2(ranges2, newRange) {
      var i = 0, l = ranges2.length;
      for (; i < l; ++i) {
        var range = ranges2[i];
        if (cmp2(newRange[0], range[1]) < 0 && cmp2(newRange[1], range[0]) > 0) {
          range[0] = min(range[0], newRange[0]);
          range[1] = max(range[1], newRange[1]);
          break;
        }
      }
      if (i === l)
        ranges2.push(newRange);
      return ranges2;
    }
    var sortDirection = ascending;
    function rangeSorter(a, b) {
      return sortDirection(a[0], b[0]);
    }
    var set;
    try {
      set = ranges.reduce(addRange2, []);
      set.sort(rangeSorter);
    } catch (ex) {
      return fail(this, INVALID_KEY_ARGUMENT);
    }
    var rangePos = 0;
    var keyIsBeyondCurrentEntry = includeUppers ? function(key) {
      return ascending(key, set[rangePos][1]) > 0;
    } : function(key) {
      return ascending(key, set[rangePos][1]) >= 0;
    };
    var keyIsBeforeCurrentEntry = includeLowers ? function(key) {
      return descending(key, set[rangePos][0]) > 0;
    } : function(key) {
      return descending(key, set[rangePos][0]) >= 0;
    };
    function keyWithinCurrentRange(key) {
      return !keyIsBeyondCurrentEntry(key) && !keyIsBeforeCurrentEntry(key);
    }
    var checkKey = keyIsBeyondCurrentEntry;
    var c = new this.Collection(this, function() {
      return createRange(set[0][0], set[set.length - 1][1], !includeLowers, !includeUppers);
    });
    c._ondirectionchange = function(direction) {
      if (direction === "next") {
        checkKey = keyIsBeyondCurrentEntry;
        sortDirection = ascending;
      } else {
        checkKey = keyIsBeforeCurrentEntry;
        sortDirection = descending;
      }
      set.sort(rangeSorter);
    };
    c._addAlgorithm(function(cursor, advance, resolve) {
      var key = cursor.key;
      while (checkKey(key)) {
        ++rangePos;
        if (rangePos === set.length) {
          advance(resolve);
          return false;
        }
      }
      if (keyWithinCurrentRange(key)) {
        return true;
      } else if (_this._cmp(key, set[rangePos][1]) === 0 || _this._cmp(key, set[rangePos][0]) === 0) {
        return false;
      } else {
        advance(function() {
          if (sortDirection === ascending)
            cursor.continue(set[rangePos][0]);
          else
            cursor.continue(set[rangePos][1]);
        });
        return false;
      }
    });
    return c;
  };
  WhereClause2.prototype.startsWithAnyOf = function() {
    var set = getArrayOf.apply(NO_CHAR_ARRAY, arguments);
    if (!set.every(function(s) {
      return typeof s === "string";
    })) {
      return fail(this, "startsWithAnyOf() only works with strings");
    }
    if (set.length === 0)
      return emptyCollection(this);
    return this.inAnyRange(set.map(function(str) {
      return [str, str + maxString];
    }));
  };
  return WhereClause2;
})();
function createWhereClauseConstructor(db) {
  return makeClassConstructor(WhereClause.prototype, function WhereClause2(table, index, orCollection) {
    this.db = db;
    this._ctx = {
      table,
      index: index === ":id" ? null : index,
      or: orCollection
    };
    this._cmp = this._ascending = cmp;
    this._descending = function(a, b) {
      return cmp(b, a);
    };
    this._max = function(a, b) {
      return cmp(a, b) > 0 ? a : b;
    };
    this._min = function(a, b) {
      return cmp(a, b) < 0 ? a : b;
    };
    this._IDBKeyRange = db._deps.IDBKeyRange;
    if (!this._IDBKeyRange)
      throw new exceptions.MissingAPI();
  });
}
function eventRejectHandler(reject) {
  return wrap(function(event) {
    preventDefault(event);
    reject(event.target.error);
    return false;
  });
}
function preventDefault(event) {
  if (event.stopPropagation)
    event.stopPropagation();
  if (event.preventDefault)
    event.preventDefault();
}
var DEXIE_STORAGE_MUTATED_EVENT_NAME = "storagemutated";
var STORAGE_MUTATED_DOM_EVENT_NAME = "x-storagemutated-1";
var globalEvents = Events(null, DEXIE_STORAGE_MUTATED_EVENT_NAME);
var Transaction = (function() {
  function Transaction2() {
  }
  Transaction2.prototype._lock = function() {
    assert(!PSD.global);
    ++this._reculock;
    if (this._reculock === 1 && !PSD.global)
      PSD.lockOwnerFor = this;
    return this;
  };
  Transaction2.prototype._unlock = function() {
    assert(!PSD.global);
    if (--this._reculock === 0) {
      if (!PSD.global)
        PSD.lockOwnerFor = null;
      while (this._blockedFuncs.length > 0 && !this._locked()) {
        var fnAndPSD = this._blockedFuncs.shift();
        try {
          usePSD(fnAndPSD[1], fnAndPSD[0]);
        } catch (e) {
        }
      }
    }
    return this;
  };
  Transaction2.prototype._locked = function() {
    return this._reculock && PSD.lockOwnerFor !== this;
  };
  Transaction2.prototype.create = function(idbtrans) {
    var _this = this;
    if (!this.mode)
      return this;
    var idbdb = this.db.idbdb;
    var dbOpenError = this.db._state.dbOpenError;
    assert(!this.idbtrans);
    if (!idbtrans && !idbdb) {
      switch (dbOpenError && dbOpenError.name) {
        case "DatabaseClosedError":
          throw new exceptions.DatabaseClosed(dbOpenError);
        case "MissingAPIError":
          throw new exceptions.MissingAPI(dbOpenError.message, dbOpenError);
        default:
          throw new exceptions.OpenFailed(dbOpenError);
      }
    }
    if (!this.active)
      throw new exceptions.TransactionInactive();
    assert(this._completion._state === null);
    idbtrans = this.idbtrans = idbtrans || (this.db.core ? this.db.core.transaction(this.storeNames, this.mode, { durability: this.chromeTransactionDurability }) : idbdb.transaction(this.storeNames, this.mode, {
      durability: this.chromeTransactionDurability
    }));
    idbtrans.onerror = wrap(function(ev) {
      preventDefault(ev);
      _this._reject(idbtrans.error);
    });
    idbtrans.onabort = wrap(function(ev) {
      preventDefault(ev);
      _this.active && _this._reject(new exceptions.Abort(idbtrans.error));
      _this.active = false;
      _this.on("abort").fire(ev);
    });
    idbtrans.oncomplete = wrap(function() {
      _this.active = false;
      _this._resolve();
      if ("mutatedParts" in idbtrans) {
        globalEvents.storagemutated.fire(idbtrans["mutatedParts"]);
      }
    });
    return this;
  };
  Transaction2.prototype._promise = function(mode, fn, bWriteLock) {
    var _this = this;
    if (mode === "readwrite" && this.mode !== "readwrite")
      return rejection(new exceptions.ReadOnly("Transaction is readonly"));
    if (!this.active)
      return rejection(new exceptions.TransactionInactive());
    if (this._locked()) {
      return new DexiePromise(function(resolve, reject) {
        _this._blockedFuncs.push([
          function() {
            _this._promise(mode, fn, bWriteLock).then(resolve, reject);
          },
          PSD
        ]);
      });
    } else if (bWriteLock) {
      return newScope(function() {
        var p2 = new DexiePromise(function(resolve, reject) {
          _this._lock();
          var rv = fn(resolve, reject, _this);
          if (rv && rv.then)
            rv.then(resolve, reject);
        });
        p2.finally(function() {
          return _this._unlock();
        });
        p2._lib = true;
        return p2;
      });
    } else {
      var p = new DexiePromise(function(resolve, reject) {
        var rv = fn(resolve, reject, _this);
        if (rv && rv.then)
          rv.then(resolve, reject);
      });
      p._lib = true;
      return p;
    }
  };
  Transaction2.prototype._root = function() {
    return this.parent ? this.parent._root() : this;
  };
  Transaction2.prototype.waitFor = function(promiseLike) {
    var root = this._root();
    var promise = DexiePromise.resolve(promiseLike);
    if (root._waitingFor) {
      root._waitingFor = root._waitingFor.then(function() {
        return promise;
      });
    } else {
      root._waitingFor = promise;
      root._waitingQueue = [];
      var store = root.idbtrans.objectStore(root.storeNames[0]);
      (function spin() {
        ++root._spinCount;
        while (root._waitingQueue.length)
          root._waitingQueue.shift()();
        if (root._waitingFor)
          store.get(-Infinity).onsuccess = spin;
      })();
    }
    var currentWaitPromise = root._waitingFor;
    return new DexiePromise(function(resolve, reject) {
      promise.then(function(res) {
        return root._waitingQueue.push(wrap(resolve.bind(null, res)));
      }, function(err) {
        return root._waitingQueue.push(wrap(reject.bind(null, err)));
      }).finally(function() {
        if (root._waitingFor === currentWaitPromise) {
          root._waitingFor = null;
        }
      });
    });
  };
  Transaction2.prototype.abort = function() {
    if (this.active) {
      this.active = false;
      if (this.idbtrans)
        this.idbtrans.abort();
      this._reject(new exceptions.Abort());
    }
  };
  Transaction2.prototype.table = function(tableName) {
    var memoizedTables = this._memoizedTables || (this._memoizedTables = {});
    if (hasOwn(memoizedTables, tableName))
      return memoizedTables[tableName];
    var tableSchema = this.schema[tableName];
    if (!tableSchema) {
      throw new exceptions.NotFound("Table " + tableName + " not part of transaction");
    }
    var transactionBoundTable = new this.db.Table(tableName, tableSchema, this);
    transactionBoundTable.core = this.db.core.table(tableName);
    memoizedTables[tableName] = transactionBoundTable;
    return transactionBoundTable;
  };
  return Transaction2;
})();
function createTransactionConstructor(db) {
  return makeClassConstructor(Transaction.prototype, function Transaction2(mode, storeNames, dbschema, chromeTransactionDurability, parent) {
    var _this = this;
    if (mode !== "readonly")
      storeNames.forEach(function(storeName) {
        var _a2;
        var yProps = (_a2 = dbschema[storeName]) === null || _a2 === void 0 ? void 0 : _a2.yProps;
        if (yProps)
          storeNames = storeNames.concat(yProps.map(function(p) {
            return p.updatesTable;
          }));
      });
    this.db = db;
    this.mode = mode;
    this.storeNames = storeNames;
    this.schema = dbschema;
    this.chromeTransactionDurability = chromeTransactionDurability;
    this.idbtrans = null;
    this.on = Events(this, "complete", "error", "abort");
    this.parent = parent || null;
    this.active = true;
    this._reculock = 0;
    this._blockedFuncs = [];
    this._resolve = null;
    this._reject = null;
    this._waitingFor = null;
    this._waitingQueue = null;
    this._spinCount = 0;
    this._completion = new DexiePromise(function(resolve, reject) {
      _this._resolve = resolve;
      _this._reject = reject;
    });
    this._completion.then(function() {
      _this.active = false;
      _this.on.complete.fire();
    }, function(e) {
      var wasActive = _this.active;
      _this.active = false;
      _this.on.error.fire(e);
      _this.parent ? _this.parent._reject(e) : wasActive && _this.idbtrans && _this.idbtrans.abort();
      return rejection(e);
    });
  });
}
function createIndexSpec(name, keyPath, unique, multi, auto, compound, isPrimKey, type2) {
  return {
    name,
    keyPath,
    unique,
    multi,
    auto,
    compound,
    src: (unique && !isPrimKey ? "&" : "") + (multi ? "*" : "") + (auto ? "++" : "") + nameFromKeyPath(keyPath),
    type: type2
  };
}
function nameFromKeyPath(keyPath) {
  return typeof keyPath === "string" ? keyPath : keyPath ? "[" + [].join.call(keyPath, "+") + "]" : "";
}
function createTableSchema(name, primKey, indexes) {
  return {
    name,
    primKey,
    indexes,
    mappedClass: null,
    idxByName: arrayToObject(indexes, function(index) {
      return [index.name, index];
    })
  };
}
function safariMultiStoreFix(storeNames) {
  return storeNames.length === 1 ? storeNames[0] : storeNames;
}
var getMaxKey = function(IdbKeyRange) {
  try {
    IdbKeyRange.only([[]]);
    getMaxKey = function() {
      return [[]];
    };
    return [[]];
  } catch (e) {
    getMaxKey = function() {
      return maxString;
    };
    return maxString;
  }
};
function getKeyExtractor(keyPath) {
  if (keyPath == null) {
    return function() {
      return void 0;
    };
  } else if (typeof keyPath === "string") {
    return getSinglePathKeyExtractor(keyPath);
  } else {
    return function(obj) {
      return getByKeyPath(obj, keyPath);
    };
  }
}
function getSinglePathKeyExtractor(keyPath) {
  var split = keyPath.split(".");
  if (split.length === 1) {
    return function(obj) {
      return obj[keyPath];
    };
  } else {
    return function(obj) {
      return getByKeyPath(obj, keyPath);
    };
  }
}
function arrayify(arrayLike) {
  return [].slice.call(arrayLike);
}
var _id_counter = 0;
function getKeyPathAlias(keyPath) {
  return keyPath == null ? ":id" : typeof keyPath === "string" ? keyPath : "[".concat(keyPath.join("+"), "]");
}
function createDBCore(db, IdbKeyRange, tmpTrans) {
  function extractSchema(db2, trans) {
    var tables2 = arrayify(db2.objectStoreNames);
    var tempStore = tables2.length > 0 ? trans.objectStore(tables2[0]) : {};
    return {
      schema: {
        name: db2.name,
        tables: tables2.map(function(table) {
          return trans.objectStore(table);
        }).map(function(store) {
          var keyPath = store.keyPath, autoIncrement = store.autoIncrement;
          var compound = isArray(keyPath);
          var outbound = keyPath == null;
          var indexByKeyPath = {};
          var result = {
            name: store.name,
            primaryKey: {
              name: null,
              isPrimaryKey: true,
              outbound,
              compound,
              keyPath,
              autoIncrement,
              unique: true,
              extractKey: getKeyExtractor(keyPath)
            },
            indexes: arrayify(store.indexNames).map(function(indexName) {
              return store.index(indexName);
            }).map(function(index) {
              var name = index.name, unique = index.unique, multiEntry = index.multiEntry, keyPath2 = index.keyPath;
              var compound2 = isArray(keyPath2);
              var result2 = {
                name,
                compound: compound2,
                keyPath: keyPath2,
                unique,
                multiEntry,
                extractKey: getKeyExtractor(keyPath2)
              };
              indexByKeyPath[getKeyPathAlias(keyPath2)] = result2;
              return result2;
            }),
            getIndexByKeyPath: function(keyPath2) {
              return indexByKeyPath[getKeyPathAlias(keyPath2)];
            }
          };
          indexByKeyPath[":id"] = result.primaryKey;
          if (keyPath != null) {
            indexByKeyPath[getKeyPathAlias(keyPath)] = result.primaryKey;
          }
          return result;
        })
      },
      hasGetAll: tables2.length > 0 && "getAll" in tempStore && !(typeof navigator !== "undefined" && /Safari/.test(navigator.userAgent) && !/(Chrome\/|Edge\/)/.test(navigator.userAgent) && [].concat(navigator.userAgent.match(/Safari\/(\d*)/))[1] < 604),
      hasIdb3Features: "getAllRecords" in tempStore
    };
  }
  function makeIDBKeyRange(range) {
    if (range.type === 3)
      return null;
    if (range.type === 4)
      throw new Error("Cannot convert never type to IDBKeyRange");
    var lower = range.lower, upper = range.upper, lowerOpen = range.lowerOpen, upperOpen = range.upperOpen;
    var idbRange = lower === void 0 ? upper === void 0 ? null : IdbKeyRange.upperBound(upper, !!upperOpen) : upper === void 0 ? IdbKeyRange.lowerBound(lower, !!lowerOpen) : IdbKeyRange.bound(lower, upper, !!lowerOpen, !!upperOpen);
    return idbRange;
  }
  function createDbCoreTable(tableSchema) {
    var tableName = tableSchema.name;
    function mutate(_a3) {
      var trans = _a3.trans, type2 = _a3.type, keys2 = _a3.keys, values = _a3.values, range = _a3.range;
      return new Promise(function(resolve, reject) {
        resolve = wrap(resolve);
        var store = trans.objectStore(tableName);
        var outbound = store.keyPath == null;
        var isAddOrPut = type2 === "put" || type2 === "add";
        if (!isAddOrPut && type2 !== "delete" && type2 !== "deleteRange")
          throw new Error("Invalid operation type: " + type2);
        var length = (keys2 || values || { length: 1 }).length;
        if (keys2 && values && keys2.length !== values.length) {
          throw new Error("Given keys array must have same length as given values array.");
        }
        if (length === 0)
          return resolve({
            numFailures: 0,
            failures: {},
            results: [],
            lastResult: void 0
          });
        var req;
        var reqs = [];
        var failures = [];
        var numFailures = 0;
        var errorHandler = function(event) {
          ++numFailures;
          preventDefault(event);
        };
        if (type2 === "deleteRange") {
          if (range.type === 4)
            return resolve({
              numFailures,
              failures,
              results: [],
              lastResult: void 0
            });
          if (range.type === 3)
            reqs.push(req = store.clear());
          else
            reqs.push(req = store.delete(makeIDBKeyRange(range)));
        } else {
          var _a4 = isAddOrPut ? outbound ? [values, keys2] : [values, null] : [keys2, null], args1 = _a4[0], args2 = _a4[1];
          if (isAddOrPut) {
            for (var i = 0; i < length; ++i) {
              reqs.push(req = args2 && args2[i] !== void 0 ? store[type2](args1[i], args2[i]) : store[type2](args1[i]));
              req.onerror = errorHandler;
            }
          } else {
            for (var i = 0; i < length; ++i) {
              reqs.push(req = store[type2](args1[i]));
              req.onerror = errorHandler;
            }
          }
        }
        var done = function(event) {
          var lastResult = event.target.result;
          reqs.forEach(function(req2, i2) {
            return req2.error != null && (failures[i2] = req2.error);
          });
          resolve({
            numFailures,
            failures,
            results: type2 === "delete" ? keys2 : reqs.map(function(req2) {
              return req2.result;
            }),
            lastResult
          });
        };
        req.onerror = function(event) {
          errorHandler(event);
          done(event);
        };
        req.onsuccess = done;
      });
    }
    function openCursor2(_a3) {
      var trans = _a3.trans, values = _a3.values, query2 = _a3.query, reverse = _a3.reverse, unique = _a3.unique;
      return new Promise(function(resolve, reject) {
        resolve = wrap(resolve);
        var index = query2.index, range = query2.range;
        var store = trans.objectStore(tableName);
        var source = index.isPrimaryKey ? store : store.index(index.name);
        var direction = reverse ? unique ? "prevunique" : "prev" : unique ? "nextunique" : "next";
        var req = values || !("openKeyCursor" in source) ? source.openCursor(makeIDBKeyRange(range), direction) : source.openKeyCursor(makeIDBKeyRange(range), direction);
        req.onerror = eventRejectHandler(reject);
        req.onsuccess = wrap(function(ev) {
          var cursor = req.result;
          if (!cursor) {
            resolve(null);
            return;
          }
          cursor.___id = ++_id_counter;
          cursor.done = false;
          var _cursorContinue = cursor.continue.bind(cursor);
          var _cursorContinuePrimaryKey = cursor.continuePrimaryKey;
          if (_cursorContinuePrimaryKey)
            _cursorContinuePrimaryKey = _cursorContinuePrimaryKey.bind(cursor);
          var _cursorAdvance = cursor.advance.bind(cursor);
          var doThrowCursorIsNotStarted = function() {
            throw new Error("Cursor not started");
          };
          var doThrowCursorIsStopped = function() {
            throw new Error("Cursor not stopped");
          };
          cursor.trans = trans;
          cursor.stop = cursor.continue = cursor.continuePrimaryKey = cursor.advance = doThrowCursorIsNotStarted;
          cursor.fail = wrap(reject);
          cursor.next = function() {
            var _this = this;
            var gotOne = 1;
            return this.start(function() {
              return gotOne-- ? _this.continue() : _this.stop();
            }).then(function() {
              return _this;
            });
          };
          cursor.start = function(callback) {
            var iterationPromise = new Promise(function(resolveIteration, rejectIteration) {
              resolveIteration = wrap(resolveIteration);
              req.onerror = eventRejectHandler(rejectIteration);
              cursor.fail = rejectIteration;
              cursor.stop = function(value) {
                cursor.stop = cursor.continue = cursor.continuePrimaryKey = cursor.advance = doThrowCursorIsStopped;
                resolveIteration(value);
              };
            });
            var guardedCallback = function() {
              if (req.result) {
                try {
                  callback();
                } catch (err) {
                  cursor.fail(err);
                }
              } else {
                cursor.done = true;
                cursor.start = function() {
                  throw new Error("Cursor behind last entry");
                };
                cursor.stop();
              }
            };
            req.onsuccess = wrap(function(ev2) {
              req.onsuccess = guardedCallback;
              guardedCallback();
            });
            cursor.continue = _cursorContinue;
            cursor.continuePrimaryKey = _cursorContinuePrimaryKey;
            cursor.advance = _cursorAdvance;
            guardedCallback();
            return iterationPromise;
          };
          resolve(cursor);
        }, reject);
      });
    }
    function query(hasGetAll2, hasIdb3Features2) {
      return function(request) {
        return new Promise(function(resolve, reject) {
          var _a3;
          resolve = wrap(resolve);
          var trans = request.trans, values = request.values, limit = request.limit, query2 = request.query;
          var direction = (_a3 = request.direction) !== null && _a3 !== void 0 ? _a3 : "next";
          var nonInfinitLimit = limit === Infinity ? void 0 : limit;
          var index = query2.index, range = query2.range;
          var store = trans.objectStore(tableName);
          var source = index.isPrimaryKey ? store : store.index(index.name);
          var idbKeyRange = makeIDBKeyRange(range);
          if (limit === 0)
            return resolve({ result: [] });
          if (hasIdb3Features2) {
            var options = {
              query: idbKeyRange,
              count: nonInfinitLimit,
              direction
            };
            var req = values ? source.getAll(options) : source.getAllKeys(options);
            req.onsuccess = function(event) {
              return resolve({ result: event.target.result });
            };
            req.onerror = eventRejectHandler(reject);
          } else if (hasGetAll2 && direction === "next") {
            var req = values ? source.getAll(idbKeyRange, nonInfinitLimit) : source.getAllKeys(idbKeyRange, nonInfinitLimit);
            req.onsuccess = function(event) {
              return resolve({ result: event.target.result });
            };
            req.onerror = eventRejectHandler(reject);
          } else {
            var count_1 = 0;
            var req_1 = values || !("openKeyCursor" in source) ? source.openCursor(idbKeyRange, direction) : source.openKeyCursor(idbKeyRange, direction);
            var result_1 = [];
            req_1.onsuccess = function() {
              var cursor = req_1.result;
              if (!cursor)
                return resolve({ result: result_1 });
              result_1.push(values ? cursor.value : cursor.primaryKey);
              if (++count_1 === limit)
                return resolve({ result: result_1 });
              cursor.continue();
            };
            req_1.onerror = eventRejectHandler(reject);
          }
        });
      };
    }
    return {
      name: tableName,
      schema: tableSchema,
      mutate,
      getMany: function(_a3) {
        var trans = _a3.trans, keys2 = _a3.keys;
        return new Promise(function(resolve, reject) {
          resolve = wrap(resolve);
          var store = trans.objectStore(tableName);
          var length = keys2.length;
          var result = new Array(length);
          var keyCount = 0;
          var callbackCount = 0;
          var req;
          var successHandler = function(event) {
            var req2 = event.target;
            if ((result[req2._pos] = req2.result) != null)
              ;
            if (++callbackCount === keyCount)
              resolve(result);
          };
          var errorHandler = eventRejectHandler(reject);
          for (var i = 0; i < length; ++i) {
            var key = keys2[i];
            if (key != null) {
              req = store.get(keys2[i]);
              req._pos = i;
              req.onsuccess = successHandler;
              req.onerror = errorHandler;
              ++keyCount;
            }
          }
          if (keyCount === 0)
            resolve(result);
        });
      },
      get: function(_a3) {
        var trans = _a3.trans, key = _a3.key;
        return new Promise(function(resolve, reject) {
          resolve = wrap(resolve);
          var store = trans.objectStore(tableName);
          var req = store.get(key);
          req.onsuccess = function(event) {
            return resolve(event.target.result);
          };
          req.onerror = eventRejectHandler(reject);
        });
      },
      query: query(hasGetAll, hasIdb3Features),
      openCursor: openCursor2,
      count: function(_a3) {
        var query2 = _a3.query, trans = _a3.trans;
        var index = query2.index, range = query2.range;
        return new Promise(function(resolve, reject) {
          var store = trans.objectStore(tableName);
          var source = index.isPrimaryKey ? store : store.index(index.name);
          var idbKeyRange = makeIDBKeyRange(range);
          var req = idbKeyRange ? source.count(idbKeyRange) : source.count();
          req.onsuccess = wrap(function(ev) {
            return resolve(ev.target.result);
          });
          req.onerror = eventRejectHandler(reject);
        });
      }
    };
  }
  var _a2 = extractSchema(db, tmpTrans), schema = _a2.schema, hasGetAll = _a2.hasGetAll, hasIdb3Features = _a2.hasIdb3Features;
  var tables = schema.tables.map(function(tableSchema) {
    return createDbCoreTable(tableSchema);
  });
  var tableMap = {};
  tables.forEach(function(table) {
    return tableMap[table.name] = table;
  });
  return {
    stack: "dbcore",
    transaction: db.transaction.bind(db),
    table: function(name) {
      var result = tableMap[name];
      if (!result)
        throw new Error("Table '".concat(name, "' not found"));
      return tableMap[name];
    },
    MIN_KEY: -Infinity,
    MAX_KEY: getMaxKey(IdbKeyRange),
    schema
  };
}
function createMiddlewareStack(stackImpl, middlewares) {
  return middlewares.reduce(function(down, _a2) {
    var create = _a2.create;
    return __assign(__assign({}, down), create(down));
  }, stackImpl);
}
function createMiddlewareStacks(middlewares, idbdb, _a2, tmpTrans) {
  var IDBKeyRange = _a2.IDBKeyRange;
  _a2.indexedDB;
  var dbcore = createMiddlewareStack(createDBCore(idbdb, IDBKeyRange, tmpTrans), middlewares.dbcore);
  return {
    dbcore
  };
}
function generateMiddlewareStacks(db, tmpTrans) {
  var idbdb = tmpTrans.db;
  var stacks = createMiddlewareStacks(db._middlewares, idbdb, db._deps, tmpTrans);
  db.core = stacks.dbcore;
  db.tables.forEach(function(table) {
    var tableName = table.name;
    if (db.core.schema.tables.some(function(tbl) {
      return tbl.name === tableName;
    })) {
      table.core = db.core.table(tableName);
      if (db[tableName] instanceof db.Table) {
        db[tableName].core = table.core;
      }
    }
  });
}
function setApiOnPlace(db, objs, tableNames, dbschema) {
  tableNames.forEach(function(tableName) {
    var schema = dbschema[tableName];
    objs.forEach(function(obj) {
      var propDesc = getPropertyDescriptor(obj, tableName);
      if (!propDesc || "value" in propDesc && propDesc.value === void 0) {
        if (obj === db.Transaction.prototype || obj instanceof db.Transaction) {
          setProp(obj, tableName, {
            get: function() {
              return this.table(tableName);
            },
            set: function(value) {
              defineProperty(this, tableName, {
                value,
                writable: true,
                configurable: true,
                enumerable: true
              });
            }
          });
        } else {
          obj[tableName] = new db.Table(tableName, schema);
        }
      }
    });
  });
}
function removeTablesApi(db, objs) {
  objs.forEach(function(obj) {
    for (var key in obj) {
      if (obj[key] instanceof db.Table)
        delete obj[key];
    }
  });
}
function lowerVersionFirst(a, b) {
  return a._cfg.version - b._cfg.version;
}
function runUpgraders(db, oldVersion, idbUpgradeTrans, reject) {
  var globalSchema = db._dbSchema;
  if (idbUpgradeTrans.objectStoreNames.contains("$meta") && !globalSchema.$meta) {
    globalSchema.$meta = createTableSchema("$meta", parseIndexSyntax("")[0], []);
    db._storeNames.push("$meta");
  }
  var trans = db._createTransaction("readwrite", db._storeNames, globalSchema);
  trans.create(idbUpgradeTrans);
  trans._completion.catch(reject);
  var rejectTransaction = trans._reject.bind(trans);
  var transless = PSD.transless || PSD;
  newScope(function() {
    PSD.trans = trans;
    PSD.transless = transless;
    if (oldVersion === 0) {
      keys(globalSchema).forEach(function(tableName) {
        createTable(idbUpgradeTrans, tableName, globalSchema[tableName].primKey, globalSchema[tableName].indexes);
      });
      generateMiddlewareStacks(db, idbUpgradeTrans);
      DexiePromise.follow(function() {
        return db.on.populate.fire(trans);
      }).catch(rejectTransaction);
    } else {
      generateMiddlewareStacks(db, idbUpgradeTrans);
      return getExistingVersion(db, trans, oldVersion).then(function(oldVersion2) {
        return updateTablesAndIndexes(db, oldVersion2, trans, idbUpgradeTrans);
      }).catch(rejectTransaction);
    }
  });
}
function patchCurrentVersion(db, idbUpgradeTrans) {
  createMissingTables(db._dbSchema, idbUpgradeTrans);
  if (idbUpgradeTrans.db.version % 10 === 0 && !idbUpgradeTrans.objectStoreNames.contains("$meta")) {
    idbUpgradeTrans.db.createObjectStore("$meta").add(Math.ceil(idbUpgradeTrans.db.version / 10 - 1), "version");
  }
  var globalSchema = buildGlobalSchema(db, db.idbdb, idbUpgradeTrans);
  adjustToExistingIndexNames(db, db._dbSchema, idbUpgradeTrans);
  var diff = getSchemaDiff(globalSchema, db._dbSchema);
  var _loop_1 = function(tableChange2) {
    if (tableChange2.change.length || tableChange2.recreate) {
      console.warn("Unable to patch indexes of table ".concat(tableChange2.name, " because it has changes on the type of index or primary key."));
      return { value: void 0 };
    }
    var store = idbUpgradeTrans.objectStore(tableChange2.name);
    tableChange2.add.forEach(function(idx) {
      if (debug)
        console.debug("Dexie upgrade patch: Creating missing index ".concat(tableChange2.name, ".").concat(idx.src));
      addIndex(store, idx);
    });
  };
  for (var _i = 0, _a2 = diff.change; _i < _a2.length; _i++) {
    var tableChange = _a2[_i];
    var state_1 = _loop_1(tableChange);
    if (typeof state_1 === "object")
      return state_1.value;
  }
}
function getExistingVersion(db, trans, oldVersion) {
  if (trans.storeNames.includes("$meta")) {
    return trans.table("$meta").get("version").then(function(metaVersion) {
      return metaVersion != null ? metaVersion : oldVersion;
    });
  } else {
    return DexiePromise.resolve(oldVersion);
  }
}
function updateTablesAndIndexes(db, oldVersion, trans, idbUpgradeTrans) {
  var queue = [];
  var versions = db._versions;
  var globalSchema = db._dbSchema = buildGlobalSchema(db, db.idbdb, idbUpgradeTrans);
  var versToRun = versions.filter(function(v) {
    return v._cfg.version >= oldVersion;
  });
  if (versToRun.length === 0) {
    return DexiePromise.resolve();
  }
  versToRun.forEach(function(version) {
    queue.push(function() {
      var oldSchema = globalSchema;
      var newSchema = version._cfg.dbschema;
      adjustToExistingIndexNames(db, oldSchema, idbUpgradeTrans);
      adjustToExistingIndexNames(db, newSchema, idbUpgradeTrans);
      globalSchema = db._dbSchema = newSchema;
      var diff = getSchemaDiff(oldSchema, newSchema);
      diff.add.forEach(function(tuple) {
        createTable(idbUpgradeTrans, tuple[0], tuple[1].primKey, tuple[1].indexes);
      });
      diff.change.forEach(function(change) {
        if (change.recreate) {
          throw new exceptions.Upgrade("Not yet support for changing primary key");
        } else {
          var store_1 = idbUpgradeTrans.objectStore(change.name);
          change.add.forEach(function(idx) {
            return addIndex(store_1, idx);
          });
          change.change.forEach(function(idx) {
            store_1.deleteIndex(idx.name);
            addIndex(store_1, idx);
          });
          change.del.forEach(function(idxName) {
            return store_1.deleteIndex(idxName);
          });
        }
      });
      var contentUpgrade = version._cfg.contentUpgrade;
      if (contentUpgrade && version._cfg.version > oldVersion) {
        generateMiddlewareStacks(db, idbUpgradeTrans);
        trans._memoizedTables = {};
        var upgradeSchema_1 = shallowClone(newSchema);
        diff.del.forEach(function(table) {
          upgradeSchema_1[table] = oldSchema[table];
        });
        removeTablesApi(db, [db.Transaction.prototype]);
        setApiOnPlace(db, [db.Transaction.prototype], keys(upgradeSchema_1), upgradeSchema_1);
        trans.schema = upgradeSchema_1;
        var contentUpgradeIsAsync_1 = isAsyncFunction(contentUpgrade);
        if (contentUpgradeIsAsync_1) {
          incrementExpectedAwaits();
        }
        var returnValue_1;
        var promiseFollowed = DexiePromise.follow(function() {
          returnValue_1 = contentUpgrade(trans);
          if (returnValue_1) {
            if (contentUpgradeIsAsync_1) {
              var decrementor = decrementExpectedAwaits.bind(null, null);
              returnValue_1.then(decrementor, decrementor);
            }
          }
        });
        return returnValue_1 && typeof returnValue_1.then === "function" ? DexiePromise.resolve(returnValue_1) : promiseFollowed.then(function() {
          return returnValue_1;
        });
      }
    });
    queue.push(function(idbtrans) {
      var newSchema = version._cfg.dbschema;
      deleteRemovedTables(newSchema, idbtrans);
      removeTablesApi(db, [db.Transaction.prototype]);
      setApiOnPlace(db, [db.Transaction.prototype], db._storeNames, db._dbSchema);
      trans.schema = db._dbSchema;
    });
    queue.push(function(idbtrans) {
      if (db.idbdb.objectStoreNames.contains("$meta")) {
        if (Math.ceil(db.idbdb.version / 10) === version._cfg.version) {
          db.idbdb.deleteObjectStore("$meta");
          delete db._dbSchema.$meta;
          db._storeNames = db._storeNames.filter(function(name) {
            return name !== "$meta";
          });
        } else {
          idbtrans.objectStore("$meta").put(version._cfg.version, "version");
        }
      }
    });
  });
  function runQueue() {
    return queue.length ? DexiePromise.resolve(queue.shift()(trans.idbtrans)).then(runQueue) : DexiePromise.resolve();
  }
  return runQueue().then(function() {
    createMissingTables(globalSchema, idbUpgradeTrans);
  });
}
function getSchemaDiff(oldSchema, newSchema) {
  var diff = {
    del: [],
    add: [],
    change: []
  };
  var table;
  for (table in oldSchema) {
    if (!newSchema[table])
      diff.del.push(table);
  }
  for (table in newSchema) {
    var oldDef = oldSchema[table], newDef = newSchema[table];
    if (!oldDef) {
      diff.add.push([table, newDef]);
    } else {
      var change = {
        name: table,
        def: newDef,
        recreate: false,
        del: [],
        add: [],
        change: []
      };
      if ("" + (oldDef.primKey.keyPath || "") !== "" + (newDef.primKey.keyPath || "") || oldDef.primKey.auto !== newDef.primKey.auto) {
        change.recreate = true;
        diff.change.push(change);
      } else {
        var oldIndexes = oldDef.idxByName;
        var newIndexes = newDef.idxByName;
        var idxName = void 0;
        for (idxName in oldIndexes) {
          if (!newIndexes[idxName])
            change.del.push(idxName);
        }
        for (idxName in newIndexes) {
          var oldIdx = oldIndexes[idxName], newIdx = newIndexes[idxName];
          if (!oldIdx)
            change.add.push(newIdx);
          else if (oldIdx.src !== newIdx.src)
            change.change.push(newIdx);
        }
        if (change.del.length > 0 || change.add.length > 0 || change.change.length > 0) {
          diff.change.push(change);
        }
      }
    }
  }
  return diff;
}
function createTable(idbtrans, tableName, primKey, indexes) {
  var store = idbtrans.db.createObjectStore(tableName, primKey.keyPath ? { keyPath: primKey.keyPath, autoIncrement: primKey.auto } : { autoIncrement: primKey.auto });
  indexes.forEach(function(idx) {
    return addIndex(store, idx);
  });
  return store;
}
function createMissingTables(newSchema, idbtrans) {
  keys(newSchema).forEach(function(tableName) {
    if (!idbtrans.db.objectStoreNames.contains(tableName)) {
      if (debug)
        console.debug("Dexie: Creating missing table", tableName);
      createTable(idbtrans, tableName, newSchema[tableName].primKey, newSchema[tableName].indexes);
    }
  });
}
function deleteRemovedTables(newSchema, idbtrans) {
  [].slice.call(idbtrans.db.objectStoreNames).forEach(function(storeName) {
    return newSchema[storeName] == null && idbtrans.db.deleteObjectStore(storeName);
  });
}
function addIndex(store, idx) {
  store.createIndex(idx.name, idx.keyPath, {
    unique: idx.unique,
    multiEntry: idx.multi
  });
}
function buildGlobalSchema(db, idbdb, tmpTrans) {
  var globalSchema = {};
  var dbStoreNames = slice(idbdb.objectStoreNames, 0);
  dbStoreNames.forEach(function(storeName) {
    var store = tmpTrans.objectStore(storeName);
    var keyPath = store.keyPath;
    var primKey = createIndexSpec(nameFromKeyPath(keyPath), keyPath || "", true, false, !!store.autoIncrement, keyPath && typeof keyPath !== "string", true);
    var indexes = [];
    for (var j = 0; j < store.indexNames.length; ++j) {
      var idbindex = store.index(store.indexNames[j]);
      keyPath = idbindex.keyPath;
      var index = createIndexSpec(idbindex.name, keyPath, !!idbindex.unique, !!idbindex.multiEntry, false, keyPath && typeof keyPath !== "string", false);
      indexes.push(index);
    }
    globalSchema[storeName] = createTableSchema(storeName, primKey, indexes);
  });
  return globalSchema;
}
function readGlobalSchema(db, idbdb, tmpTrans) {
  db.verno = idbdb.version / 10;
  var globalSchema = db._dbSchema = buildGlobalSchema(db, idbdb, tmpTrans);
  db._storeNames = slice(idbdb.objectStoreNames, 0);
  setApiOnPlace(db, [db._allTables], keys(globalSchema), globalSchema);
}
function verifyInstalledSchema(db, tmpTrans) {
  var installedSchema = buildGlobalSchema(db, db.idbdb, tmpTrans);
  var diff = getSchemaDiff(installedSchema, db._dbSchema);
  return !(diff.add.length || diff.change.some(function(ch) {
    return ch.add.length || ch.change.length;
  }));
}
function adjustToExistingIndexNames(db, schema, idbtrans) {
  var storeNames = idbtrans.db.objectStoreNames;
  for (var i = 0; i < storeNames.length; ++i) {
    var storeName = storeNames[i];
    var store = idbtrans.objectStore(storeName);
    db._hasGetAll = "getAll" in store;
    for (var j = 0; j < store.indexNames.length; ++j) {
      var indexName = store.indexNames[j];
      var keyPath = store.index(indexName).keyPath;
      var dexieName = typeof keyPath === "string" ? keyPath : "[" + slice(keyPath).join("+") + "]";
      if (schema[storeName]) {
        var indexSpec = schema[storeName].idxByName[dexieName];
        if (indexSpec) {
          indexSpec.name = indexName;
          delete schema[storeName].idxByName[dexieName];
          schema[storeName].idxByName[indexName] = indexSpec;
        }
      }
    }
  }
  if (typeof navigator !== "undefined" && /Safari/.test(navigator.userAgent) && !/(Chrome\/|Edge\/)/.test(navigator.userAgent) && _global.WorkerGlobalScope && _global instanceof _global.WorkerGlobalScope && [].concat(navigator.userAgent.match(/Safari\/(\d*)/))[1] < 604) {
    db._hasGetAll = false;
  }
}
function parseIndexSyntax(primKeyAndIndexes) {
  return primKeyAndIndexes.split(",").map(function(index, indexNum) {
    var _a2;
    var typeSplit = index.split(":");
    var type2 = (_a2 = typeSplit[1]) === null || _a2 === void 0 ? void 0 : _a2.trim();
    index = typeSplit[0].trim();
    var name = index.replace(/([&*]|\+\+)/g, "");
    var keyPath = /^\[/.test(name) ? name.match(/^\[(.*)\]$/)[1].split("+") : name;
    return createIndexSpec(name, keyPath || null, /\&/.test(index), /\*/.test(index), /\+\+/.test(index), isArray(keyPath), indexNum === 0, type2);
  });
}
var Version = (function() {
  function Version2() {
  }
  Version2.prototype._createTableSchema = function(name, primKey, indexes) {
    return createTableSchema(name, primKey, indexes);
  };
  Version2.prototype._parseIndexSyntax = function(primKeyAndIndexes) {
    return parseIndexSyntax(primKeyAndIndexes);
  };
  Version2.prototype._parseStoresSpec = function(stores, outSchema) {
    var _this = this;
    keys(stores).forEach(function(tableName) {
      if (stores[tableName] !== null) {
        var indexes = _this._parseIndexSyntax(stores[tableName]);
        var primKey = indexes.shift();
        if (!primKey) {
          throw new exceptions.Schema("Invalid schema for table " + tableName + ": " + stores[tableName]);
        }
        primKey.unique = true;
        if (primKey.multi)
          throw new exceptions.Schema("Primary key cannot be multiEntry*");
        indexes.forEach(function(idx) {
          if (idx.auto)
            throw new exceptions.Schema("Only primary key can be marked as autoIncrement (++)");
          if (!idx.keyPath)
            throw new exceptions.Schema("Index must have a name and cannot be an empty string");
        });
        var tblSchema = _this._createTableSchema(tableName, primKey, indexes);
        outSchema[tableName] = tblSchema;
      }
    });
  };
  Version2.prototype.stores = function(stores) {
    var db = this.db;
    this._cfg.storesSource = this._cfg.storesSource ? extend(this._cfg.storesSource, stores) : stores;
    var versions = db._versions;
    var storesSpec = {};
    var dbschema = {};
    versions.forEach(function(version) {
      extend(storesSpec, version._cfg.storesSource);
      dbschema = version._cfg.dbschema = {};
      version._parseStoresSpec(storesSpec, dbschema);
    });
    db._dbSchema = dbschema;
    removeTablesApi(db, [db._allTables, db, db.Transaction.prototype]);
    setApiOnPlace(db, [db._allTables, db, db.Transaction.prototype, this._cfg.tables], keys(dbschema), dbschema);
    db._storeNames = keys(dbschema);
    return this;
  };
  Version2.prototype.upgrade = function(upgradeFunction) {
    this._cfg.contentUpgrade = promisableChain(this._cfg.contentUpgrade || nop, upgradeFunction);
    return this;
  };
  return Version2;
})();
function createVersionConstructor(db) {
  return makeClassConstructor(Version.prototype, function Version2(versionNumber) {
    this.db = db;
    this._cfg = {
      version: versionNumber,
      storesSource: null,
      dbschema: {},
      tables: {},
      contentUpgrade: null
    };
  });
}
var connections = createConnectionsManager();
function createConnectionsManager() {
  if (typeof FinalizationRegistry !== "undefined" && typeof WeakRef !== "undefined") {
    var _refs_1 = /* @__PURE__ */ new Set();
    var _registry_1 = new FinalizationRegistry(function(ref) {
      _refs_1.delete(ref);
    });
    var toArray = function() {
      return Array.from(_refs_1).map(function(ref) {
        return ref.deref();
      }).filter(function(db) {
        return db !== void 0;
      });
    };
    var add = function(db) {
      var ref = new WeakRef(db._novip);
      _refs_1.add(ref);
      _registry_1.register(db._novip, ref, ref);
      if (_refs_1.size > db._options.maxConnections) {
        var oldestRef = _refs_1.values().next().value;
        _refs_1.delete(oldestRef);
        _registry_1.unregister(oldestRef);
      }
    };
    var remove = function(db) {
      if (!db)
        return;
      var iterator = _refs_1.values();
      var result = iterator.next();
      while (!result.done) {
        var ref = result.value;
        if (ref.deref() === db._novip) {
          _refs_1.delete(ref);
          _registry_1.unregister(ref);
          return;
        }
        result = iterator.next();
      }
    };
    return { toArray, add, remove };
  } else {
    var connections_1 = [];
    var toArray = function() {
      return connections_1;
    };
    var add = function(db) {
      connections_1.push(db._novip);
    };
    var remove = function(db) {
      if (!db)
        return;
      var index = connections_1.indexOf(db._novip);
      if (index !== -1) {
        connections_1.splice(index, 1);
      }
    };
    return { toArray, add, remove };
  }
}
function getDbNamesTable(indexedDB2, IDBKeyRange) {
  var dbNamesDB = indexedDB2["_dbNamesDB"];
  if (!dbNamesDB) {
    dbNamesDB = indexedDB2["_dbNamesDB"] = new Dexie$1(DBNAMES_DB, {
      addons: [],
      indexedDB: indexedDB2,
      IDBKeyRange
    });
    dbNamesDB.version(1).stores({ dbnames: "name" });
  }
  return dbNamesDB.table("dbnames");
}
function hasDatabasesNative(indexedDB2) {
  return indexedDB2 && typeof indexedDB2.databases === "function";
}
function getDatabaseNames(_a2) {
  var indexedDB2 = _a2.indexedDB, IDBKeyRange = _a2.IDBKeyRange;
  return hasDatabasesNative(indexedDB2) ? Promise.resolve(indexedDB2.databases()).then(function(infos) {
    return infos.map(function(info) {
      return info.name;
    }).filter(function(name) {
      return name !== DBNAMES_DB;
    });
  }) : getDbNamesTable(indexedDB2, IDBKeyRange).toCollection().primaryKeys();
}
function _onDatabaseCreated(_a2, name) {
  var indexedDB2 = _a2.indexedDB, IDBKeyRange = _a2.IDBKeyRange;
  !hasDatabasesNative(indexedDB2) && name !== DBNAMES_DB && getDbNamesTable(indexedDB2, IDBKeyRange).put({ name }).catch(nop);
}
function _onDatabaseDeleted(_a2, name) {
  var indexedDB2 = _a2.indexedDB, IDBKeyRange = _a2.IDBKeyRange;
  !hasDatabasesNative(indexedDB2) && name !== DBNAMES_DB && getDbNamesTable(indexedDB2, IDBKeyRange).delete(name).catch(nop);
}
function vip(fn) {
  return newScope(function() {
    PSD.letThrough = true;
    return fn();
  });
}
function idbReady() {
  var isSafari = !navigator.userAgentData && /Safari\//.test(navigator.userAgent) && !/Chrom(e|ium)\//.test(navigator.userAgent);
  if (!isSafari || !indexedDB.databases)
    return Promise.resolve();
  var intervalId;
  return new Promise(function(resolve) {
    var tryIdb = function() {
      return indexedDB.databases().finally(resolve);
    };
    intervalId = setInterval(tryIdb, 100);
    tryIdb();
  }).finally(function() {
    return clearInterval(intervalId);
  });
}
var _a;
function isEmptyRange(node) {
  return !("from" in node);
}
var RangeSet = function(fromOrTree, to) {
  if (this) {
    extend(this, arguments.length ? { d: 1, from: fromOrTree, to: arguments.length > 1 ? to : fromOrTree } : { d: 0 });
  } else {
    var rv = new RangeSet();
    if (fromOrTree && "d" in fromOrTree) {
      extend(rv, fromOrTree);
    }
    return rv;
  }
};
props(RangeSet.prototype, (_a = {
  add: function(rangeSet) {
    mergeRanges(this, rangeSet);
    return this;
  },
  addKey: function(key) {
    addRange(this, key, key);
    return this;
  },
  addKeys: function(keys2) {
    var _this = this;
    keys2.forEach(function(key) {
      return addRange(_this, key, key);
    });
    return this;
  },
  hasKey: function(key) {
    var node = getRangeSetIterator(this).next(key).value;
    return node && cmp(node.from, key) <= 0 && cmp(node.to, key) >= 0;
  }
}, _a[iteratorSymbol] = function() {
  return getRangeSetIterator(this);
}, _a));
function addRange(target, from, to) {
  var diff = cmp(from, to);
  if (isNaN(diff))
    return;
  if (diff > 0)
    throw RangeError();
  if (isEmptyRange(target))
    return extend(target, { from, to, d: 1 });
  var left = target.l;
  var right = target.r;
  if (cmp(to, target.from) < 0) {
    left ? addRange(left, from, to) : target.l = { from, to, d: 1, l: null, r: null };
    return rebalance(target);
  }
  if (cmp(from, target.to) > 0) {
    right ? addRange(right, from, to) : target.r = { from, to, d: 1, l: null, r: null };
    return rebalance(target);
  }
  if (cmp(from, target.from) < 0) {
    target.from = from;
    target.l = null;
    target.d = right ? right.d + 1 : 1;
  }
  if (cmp(to, target.to) > 0) {
    target.to = to;
    target.r = null;
    target.d = target.l ? target.l.d + 1 : 1;
  }
  var rightWasCutOff = !target.r;
  if (left && !target.l) {
    mergeRanges(target, left);
  }
  if (right && rightWasCutOff) {
    mergeRanges(target, right);
  }
}
function mergeRanges(target, newSet) {
  function _addRangeSet(target2, _a2) {
    var from = _a2.from, to = _a2.to, l = _a2.l, r = _a2.r;
    addRange(target2, from, to);
    if (l)
      _addRangeSet(target2, l);
    if (r)
      _addRangeSet(target2, r);
  }
  if (!isEmptyRange(newSet))
    _addRangeSet(target, newSet);
}
function rangesOverlap(rangeSet1, rangeSet2) {
  var i1 = getRangeSetIterator(rangeSet2);
  var nextResult1 = i1.next();
  if (nextResult1.done)
    return false;
  var a = nextResult1.value;
  var i2 = getRangeSetIterator(rangeSet1);
  var nextResult2 = i2.next(a.from);
  var b = nextResult2.value;
  while (!nextResult1.done && !nextResult2.done) {
    if (cmp(b.from, a.to) <= 0 && cmp(b.to, a.from) >= 0)
      return true;
    cmp(a.from, b.from) < 0 ? a = (nextResult1 = i1.next(b.from)).value : b = (nextResult2 = i2.next(a.from)).value;
  }
  return false;
}
function getRangeSetIterator(node) {
  var state = isEmptyRange(node) ? null : { s: 0, n: node };
  return {
    next: function(key) {
      var keyProvided = arguments.length > 0;
      while (state) {
        switch (state.s) {
          case 0:
            state.s = 1;
            if (keyProvided) {
              while (state.n.l && cmp(key, state.n.from) < 0)
                state = { up: state, n: state.n.l, s: 1 };
            } else {
              while (state.n.l)
                state = { up: state, n: state.n.l, s: 1 };
            }
          case 1:
            state.s = 2;
            if (!keyProvided || cmp(key, state.n.to) <= 0)
              return { value: state.n, done: false };
          case 2:
            if (state.n.r) {
              state.s = 3;
              state = { up: state, n: state.n.r, s: 0 };
              continue;
            }
          case 3:
            state = state.up;
        }
      }
      return { done: true };
    }
  };
}
function rebalance(target) {
  var _a2, _b;
  var diff = (((_a2 = target.r) === null || _a2 === void 0 ? void 0 : _a2.d) || 0) - (((_b = target.l) === null || _b === void 0 ? void 0 : _b.d) || 0);
  var r = diff > 1 ? "r" : diff < -1 ? "l" : "";
  if (r) {
    var l = r === "r" ? "l" : "r";
    var rootClone = __assign({}, target);
    var oldRootRight = target[r];
    target.from = oldRootRight.from;
    target.to = oldRootRight.to;
    target[r] = oldRootRight[r];
    rootClone[r] = oldRootRight[l];
    target[l] = rootClone;
    rootClone.d = computeDepth(rootClone);
  }
  target.d = computeDepth(target);
}
function computeDepth(_a2) {
  var r = _a2.r, l = _a2.l;
  return (r ? l ? Math.max(r.d, l.d) : r.d : l ? l.d : 0) + 1;
}
function extendObservabilitySet(target, newSet) {
  keys(newSet).forEach(function(part) {
    if (target[part])
      mergeRanges(target[part], newSet[part]);
    else
      target[part] = cloneSimpleObjectTree(newSet[part]);
  });
  return target;
}
function obsSetsOverlap(os1, os2) {
  return os1.all || os2.all || Object.keys(os1).some(function(key) {
    return os2[key] && rangesOverlap(os2[key], os1[key]);
  });
}
var cache = {};
var unsignaledParts = {};
var isTaskEnqueued = false;
function signalSubscribersLazily(part, optimistic) {
  extendObservabilitySet(unsignaledParts, part);
  if (!isTaskEnqueued) {
    isTaskEnqueued = true;
    setTimeout(function() {
      isTaskEnqueued = false;
      var parts = unsignaledParts;
      unsignaledParts = {};
      signalSubscribersNow(parts, false);
    }, 0);
  }
}
function signalSubscribersNow(updatedParts, deleteAffectedCacheEntries) {
  if (deleteAffectedCacheEntries === void 0) {
    deleteAffectedCacheEntries = false;
  }
  var queriesToSignal = /* @__PURE__ */ new Set();
  if (updatedParts.all) {
    for (var _i = 0, _a2 = Object.values(cache); _i < _a2.length; _i++) {
      var tblCache = _a2[_i];
      collectTableSubscribers(tblCache, updatedParts, queriesToSignal, deleteAffectedCacheEntries);
    }
  } else {
    for (var key in updatedParts) {
      var parts = /^idb\:\/\/(.*)\/(.*)\//.exec(key);
      if (parts) {
        var dbName = parts[1], tableName = parts[2];
        var tblCache = cache["idb://".concat(dbName, "/").concat(tableName)];
        if (tblCache)
          collectTableSubscribers(tblCache, updatedParts, queriesToSignal, deleteAffectedCacheEntries);
      }
    }
  }
  queriesToSignal.forEach(function(requery) {
    return requery();
  });
}
function collectTableSubscribers(tblCache, updatedParts, outQueriesToSignal, deleteAffectedCacheEntries) {
  var updatedEntryLists = [];
  for (var _i = 0, _a2 = Object.entries(tblCache.queries.query); _i < _a2.length; _i++) {
    var _b = _a2[_i], indexName = _b[0], entries = _b[1];
    var filteredEntries = [];
    for (var _c = 0, entries_1 = entries; _c < entries_1.length; _c++) {
      var entry = entries_1[_c];
      if (obsSetsOverlap(updatedParts, entry.obsSet)) {
        entry.subscribers.forEach(function(requery) {
          return outQueriesToSignal.add(requery);
        });
      } else if (deleteAffectedCacheEntries) {
        filteredEntries.push(entry);
      }
    }
    if (deleteAffectedCacheEntries)
      updatedEntryLists.push([indexName, filteredEntries]);
  }
  if (deleteAffectedCacheEntries) {
    for (var _d = 0, updatedEntryLists_1 = updatedEntryLists; _d < updatedEntryLists_1.length; _d++) {
      var _e = updatedEntryLists_1[_d], indexName = _e[0], filteredEntries = _e[1];
      tblCache.queries.query[indexName] = filteredEntries;
    }
  }
}
function dexieOpen(db) {
  var state = db._state;
  var indexedDB2 = db._deps.indexedDB;
  if (state.isBeingOpened || db.idbdb)
    return state.dbReadyPromise.then(function() {
      return state.dbOpenError ? rejection(state.dbOpenError) : db;
    });
  state.isBeingOpened = true;
  state.dbOpenError = null;
  state.openComplete = false;
  var openCanceller = state.openCanceller;
  var nativeVerToOpen = Math.round(db.verno * 10);
  var schemaPatchMode = false;
  function throwIfCancelled() {
    if (state.openCanceller !== openCanceller)
      throw new exceptions.DatabaseClosed("db.open() was cancelled");
  }
  var resolveDbReady = state.dbReadyResolve, upgradeTransaction = null, wasCreated = false;
  var tryOpenDB = function() {
    return new DexiePromise(function(resolve, reject) {
      throwIfCancelled();
      if (!indexedDB2)
        throw new exceptions.MissingAPI();
      var dbName = db.name;
      var req = state.autoSchema || !nativeVerToOpen ? indexedDB2.open(dbName) : indexedDB2.open(dbName, nativeVerToOpen);
      if (!req)
        throw new exceptions.MissingAPI();
      req.onerror = eventRejectHandler(reject);
      req.onblocked = wrap(db._fireOnBlocked);
      req.onupgradeneeded = wrap(function(e) {
        upgradeTransaction = req.transaction;
        if (state.autoSchema && !db._options.allowEmptyDB) {
          req.onerror = preventDefault;
          upgradeTransaction.abort();
          req.result.close();
          var delreq = indexedDB2.deleteDatabase(dbName);
          delreq.onsuccess = delreq.onerror = wrap(function() {
            reject(new exceptions.NoSuchDatabase("Database ".concat(dbName, " doesnt exist")));
          });
        } else {
          upgradeTransaction.onerror = eventRejectHandler(reject);
          var oldVer = e.oldVersion > Math.pow(2, 62) ? 0 : e.oldVersion;
          wasCreated = oldVer < 1;
          db.idbdb = req.result;
          if (schemaPatchMode) {
            patchCurrentVersion(db, upgradeTransaction);
          }
          runUpgraders(db, oldVer / 10, upgradeTransaction, reject);
        }
      }, reject);
      req.onsuccess = wrap(function() {
        upgradeTransaction = null;
        var idbdb = db.idbdb = req.result;
        var objectStoreNames = slice(idbdb.objectStoreNames);
        if (objectStoreNames.length > 0)
          try {
            var tmpTrans = idbdb.transaction(safariMultiStoreFix(objectStoreNames), "readonly");
            if (state.autoSchema)
              readGlobalSchema(db, idbdb, tmpTrans);
            else {
              adjustToExistingIndexNames(db, db._dbSchema, tmpTrans);
              if (!verifyInstalledSchema(db, tmpTrans) && !schemaPatchMode) {
                console.warn("Dexie SchemaDiff: Schema was extended without increasing the number passed to db.version(). Dexie will add missing parts and increment native version number to workaround this.");
                idbdb.close();
                nativeVerToOpen = idbdb.version + 1;
                schemaPatchMode = true;
                return resolve(tryOpenDB());
              }
            }
            generateMiddlewareStacks(db, tmpTrans);
          } catch (e) {
          }
        connections.add(db);
        idbdb.onversionchange = wrap(function(ev) {
          state.vcFired = true;
          db.on("versionchange").fire(ev);
        });
        idbdb.onclose = wrap(function() {
          db.close({ disableAutoOpen: false });
        });
        if (wasCreated)
          _onDatabaseCreated(db._deps, dbName);
        resolve();
      }, reject);
    }).catch(function(err) {
      switch (err === null || err === void 0 ? void 0 : err.name) {
        case "UnknownError":
          if (state.PR1398_maxLoop > 0) {
            state.PR1398_maxLoop--;
            console.warn("Dexie: Workaround for Chrome UnknownError on open()");
            return tryOpenDB();
          }
          break;
        case "VersionError":
          if (nativeVerToOpen > 0) {
            nativeVerToOpen = 0;
            return tryOpenDB();
          }
          break;
      }
      return DexiePromise.reject(err);
    });
  };
  return DexiePromise.race([
    openCanceller,
    (typeof navigator === "undefined" ? DexiePromise.resolve() : idbReady()).then(tryOpenDB)
  ]).then(function() {
    throwIfCancelled();
    state.onReadyBeingFired = [];
    return DexiePromise.resolve(vip(function() {
      return db.on.ready.fire(db.vip);
    })).then(function fireRemainders() {
      if (state.onReadyBeingFired.length > 0) {
        var remainders_1 = state.onReadyBeingFired.reduce(promisableChain, nop);
        state.onReadyBeingFired = [];
        return DexiePromise.resolve(vip(function() {
          return remainders_1(db.vip);
        })).then(fireRemainders);
      }
    });
  }).finally(function() {
    if (state.openCanceller === openCanceller) {
      state.onReadyBeingFired = null;
      state.isBeingOpened = false;
    }
  }).catch(function(err) {
    state.dbOpenError = err;
    try {
      upgradeTransaction && upgradeTransaction.abort();
    } catch (_a2) {
    }
    if (openCanceller === state.openCanceller) {
      db._close();
    }
    return rejection(err);
  }).finally(function() {
    state.openComplete = true;
    resolveDbReady();
  }).then(function() {
    if (wasCreated) {
      var everything_1 = {};
      db.tables.forEach(function(table) {
        table.schema.indexes.forEach(function(idx) {
          if (idx.name)
            everything_1["idb://".concat(db.name, "/").concat(table.name, "/").concat(idx.name)] = new RangeSet(-Infinity, [[[]]]);
        });
        everything_1["idb://".concat(db.name, "/").concat(table.name, "/")] = everything_1["idb://".concat(db.name, "/").concat(table.name, "/:dels")] = new RangeSet(-Infinity, [[[]]]);
      });
      globalEvents(DEXIE_STORAGE_MUTATED_EVENT_NAME).fire(everything_1);
      signalSubscribersNow(everything_1, true);
    }
    return db;
  });
}
function awaitIterator(iterator) {
  var callNext = function(result) {
    return iterator.next(result);
  }, doThrow = function(error) {
    return iterator.throw(error);
  }, onSuccess = step(callNext), onError = step(doThrow);
  function step(getNext) {
    return function(val) {
      var next = getNext(val), value = next.value;
      return next.done ? value : !value || typeof value.then !== "function" ? isArray(value) ? Promise.all(value).then(onSuccess, onError) : onSuccess(value) : value.then(onSuccess, onError);
    };
  }
  return step(callNext)();
}
function extractTransactionArgs(mode, _tableArgs_, scopeFunc) {
  var i = arguments.length;
  if (i < 2)
    throw new exceptions.InvalidArgument("Too few arguments");
  var args = new Array(i - 1);
  while (--i)
    args[i - 1] = arguments[i];
  scopeFunc = args.pop();
  var tables = flatten(args);
  return [mode, tables, scopeFunc];
}
function enterTransactionScope(db, mode, storeNames, parentTransaction, scopeFunc) {
  return DexiePromise.resolve().then(function() {
    var transless = PSD.transless || PSD;
    var trans = db._createTransaction(mode, storeNames, db._dbSchema, parentTransaction);
    trans.explicit = true;
    var zoneProps = {
      trans,
      transless
    };
    if (parentTransaction) {
      trans.idbtrans = parentTransaction.idbtrans;
    } else {
      try {
        trans.create();
        trans.idbtrans._explicit = true;
        db._state.PR1398_maxLoop = 3;
      } catch (ex) {
        if (ex.name === errnames.InvalidState && db.isOpen() && --db._state.PR1398_maxLoop > 0) {
          console.warn("Dexie: Need to reopen db");
          db.close({ disableAutoOpen: false });
          return db.open().then(function() {
            return enterTransactionScope(db, mode, storeNames, null, scopeFunc);
          });
        }
        return rejection(ex);
      }
    }
    var scopeFuncIsAsync = isAsyncFunction(scopeFunc);
    if (scopeFuncIsAsync) {
      incrementExpectedAwaits();
    }
    var returnValue;
    var promiseFollowed = DexiePromise.follow(function() {
      returnValue = scopeFunc.call(trans, trans);
      if (returnValue) {
        if (scopeFuncIsAsync) {
          var decrementor = decrementExpectedAwaits.bind(null, null);
          returnValue.then(decrementor, decrementor);
        } else if (typeof returnValue.next === "function" && typeof returnValue.throw === "function") {
          returnValue = awaitIterator(returnValue);
        }
      }
    }, zoneProps);
    return (returnValue && typeof returnValue.then === "function" ? DexiePromise.resolve(returnValue).then(function(x) {
      return trans.active ? x : rejection(new exceptions.PrematureCommit("Transaction committed too early. See http://bit.ly/2kdckMn"));
    }) : promiseFollowed.then(function() {
      return returnValue;
    })).then(function(x) {
      if (parentTransaction)
        trans._resolve();
      return trans._completion.then(function() {
        return x;
      });
    }).catch(function(e) {
      trans._reject(e);
      return rejection(e);
    });
  });
}
function pad(a, value, count) {
  var result = isArray(a) ? a.slice() : [a];
  for (var i = 0; i < count; ++i)
    result.push(value);
  return result;
}
function createVirtualIndexMiddleware(down) {
  return __assign(__assign({}, down), { table: function(tableName) {
    var table = down.table(tableName);
    var schema = table.schema;
    var indexLookup = /* @__PURE__ */ Object.create(null);
    var allVirtualIndexes = [];
    function addVirtualIndexes(keyPath, keyTail, lowLevelIndex) {
      var keyPathAlias = getKeyPathAlias(keyPath);
      var indexList = indexLookup[keyPathAlias] = indexLookup[keyPathAlias] || [];
      var keyLength = keyPath == null ? 0 : typeof keyPath === "string" ? 1 : keyPath.length;
      var isVirtual = keyTail > 0;
      var virtualIndex = __assign(__assign({}, lowLevelIndex), { name: isVirtual ? "".concat(keyPathAlias, "(virtual-from:").concat(lowLevelIndex.name, ")") : lowLevelIndex.name, lowLevelIndex, isVirtual, keyTail, keyLength, extractKey: getKeyExtractor(keyPath), unique: !isVirtual && lowLevelIndex.unique });
      indexList.push(virtualIndex);
      if (!virtualIndex.isPrimaryKey) {
        allVirtualIndexes.push(virtualIndex);
      }
      if (keyLength > 1) {
        var virtualKeyPath = keyLength === 2 ? keyPath[0] : keyPath.slice(0, keyLength - 1);
        addVirtualIndexes(virtualKeyPath, keyTail + 1, lowLevelIndex);
      }
      indexList.sort(function(a, b) {
        return a.keyTail - b.keyTail;
      });
      return virtualIndex;
    }
    var primaryKey = addVirtualIndexes(schema.primaryKey.keyPath, 0, schema.primaryKey);
    indexLookup[":id"] = [primaryKey];
    for (var _i = 0, _a2 = schema.indexes; _i < _a2.length; _i++) {
      var index = _a2[_i];
      addVirtualIndexes(index.keyPath, 0, index);
    }
    function findBestIndex(keyPath) {
      var result2 = indexLookup[getKeyPathAlias(keyPath)];
      return result2 && result2[0];
    }
    function translateRange(range, keyTail) {
      return {
        type: range.type === 1 ? 2 : range.type,
        lower: pad(range.lower, range.lowerOpen ? down.MAX_KEY : down.MIN_KEY, keyTail),
        lowerOpen: true,
        upper: pad(range.upper, range.upperOpen ? down.MIN_KEY : down.MAX_KEY, keyTail),
        upperOpen: true
      };
    }
    function translateRequest(req) {
      var index2 = req.query.index;
      return index2.isVirtual ? __assign(__assign({}, req), { query: {
        index: index2.lowLevelIndex,
        range: translateRange(req.query.range, index2.keyTail)
      } }) : req;
    }
    var result = __assign(__assign({}, table), { schema: __assign(__assign({}, schema), { primaryKey, indexes: allVirtualIndexes, getIndexByKeyPath: findBestIndex }), count: function(req) {
      return table.count(translateRequest(req));
    }, query: function(req) {
      return table.query(translateRequest(req));
    }, openCursor: function(req) {
      var _a3 = req.query.index, keyTail = _a3.keyTail, isVirtual = _a3.isVirtual, keyLength = _a3.keyLength;
      if (!isVirtual)
        return table.openCursor(req);
      function createVirtualCursor(cursor) {
        function _continue(key) {
          key != null ? cursor.continue(pad(key, req.reverse ? down.MAX_KEY : down.MIN_KEY, keyTail)) : req.unique ? cursor.continue(cursor.key.slice(0, keyLength).concat(req.reverse ? down.MIN_KEY : down.MAX_KEY, keyTail)) : cursor.continue();
        }
        var virtualCursor = Object.create(cursor, {
          continue: { value: _continue },
          continuePrimaryKey: {
            value: function(key, primaryKey2) {
              cursor.continuePrimaryKey(pad(key, down.MAX_KEY, keyTail), primaryKey2);
            }
          },
          primaryKey: {
            get: function() {
              return cursor.primaryKey;
            }
          },
          key: {
            get: function() {
              var key = cursor.key;
              return keyLength === 1 ? key[0] : key.slice(0, keyLength);
            }
          },
          value: {
            get: function() {
              return cursor.value;
            }
          }
        });
        return virtualCursor;
      }
      return table.openCursor(translateRequest(req)).then(function(cursor) {
        return cursor && createVirtualCursor(cursor);
      });
    } });
    return result;
  } });
}
var virtualIndexMiddleware = {
  stack: "dbcore",
  name: "VirtualIndexMiddleware",
  level: 1,
  create: createVirtualIndexMiddleware
};
function getObjectDiff(a, b, rv, prfx) {
  rv = rv || {};
  prfx = prfx || "";
  keys(a).forEach(function(prop) {
    if (!hasOwn(b, prop)) {
      rv[prfx + prop] = void 0;
    } else {
      var ap = a[prop], bp = b[prop];
      if (typeof ap === "object" && typeof bp === "object" && ap && bp) {
        var apTypeName = toStringTag(ap);
        var bpTypeName = toStringTag(bp);
        if (apTypeName !== bpTypeName) {
          rv[prfx + prop] = b[prop];
        } else if (apTypeName === "Object") {
          getObjectDiff(ap, bp, rv, prfx + prop + ".");
        } else if (ap !== bp) {
          rv[prfx + prop] = b[prop];
        }
      } else if (ap !== bp)
        rv[prfx + prop] = b[prop];
    }
  });
  keys(b).forEach(function(prop) {
    if (!hasOwn(a, prop)) {
      rv[prfx + prop] = b[prop];
    }
  });
  return rv;
}
function getEffectiveKeys(primaryKey, req) {
  if (req.type === "delete")
    return req.keys;
  return req.keys || req.values.map(primaryKey.extractKey);
}
var hooksMiddleware = {
  stack: "dbcore",
  name: "HooksMiddleware",
  level: 2,
  create: function(downCore) {
    return __assign(__assign({}, downCore), { table: function(tableName) {
      var downTable = downCore.table(tableName);
      var primaryKey = downTable.schema.primaryKey;
      var tableMiddleware = __assign(__assign({}, downTable), { mutate: function(req) {
        var dxTrans = PSD.trans;
        var _a2 = dxTrans.table(tableName).hook, deleting = _a2.deleting, creating = _a2.creating, updating = _a2.updating;
        switch (req.type) {
          case "add":
            if (creating.fire === nop)
              break;
            return dxTrans._promise("readwrite", function() {
              return addPutOrDelete(req);
            }, true);
          case "put":
            if (creating.fire === nop && updating.fire === nop)
              break;
            return dxTrans._promise("readwrite", function() {
              return addPutOrDelete(req);
            }, true);
          case "delete":
            if (deleting.fire === nop)
              break;
            return dxTrans._promise("readwrite", function() {
              return addPutOrDelete(req);
            }, true);
          case "deleteRange":
            if (deleting.fire === nop)
              break;
            return dxTrans._promise("readwrite", function() {
              return deleteRange(req);
            }, true);
        }
        return downTable.mutate(req);
        function addPutOrDelete(req2) {
          var dxTrans2 = PSD.trans;
          var keys2 = req2.keys || getEffectiveKeys(primaryKey, req2);
          if (!keys2)
            throw new Error("Keys missing");
          req2 = req2.type === "add" || req2.type === "put" ? __assign(__assign({}, req2), { keys: keys2 }) : __assign({}, req2);
          if (req2.type !== "delete")
            req2.values = __spreadArray([], req2.values);
          if (req2.keys)
            req2.keys = __spreadArray([], req2.keys);
          return getExistingValues(downTable, req2, keys2).then(function(existingValues) {
            var contexts = keys2.map(function(key, i) {
              var existingValue = existingValues[i];
              var ctx = { onerror: null, onsuccess: null };
              if (req2.type === "delete") {
                deleting.fire.call(ctx, key, existingValue, dxTrans2);
              } else if (req2.type === "add" || existingValue === void 0) {
                var generatedPrimaryKey = creating.fire.call(ctx, key, req2.values[i], dxTrans2);
                if (key == null && generatedPrimaryKey != null) {
                  key = generatedPrimaryKey;
                  req2.keys[i] = key;
                  if (!primaryKey.outbound) {
                    setByKeyPath(req2.values[i], primaryKey.keyPath, key);
                  }
                }
              } else {
                var objectDiff = getObjectDiff(existingValue, req2.values[i]);
                var additionalChanges_1 = updating.fire.call(ctx, objectDiff, key, existingValue, dxTrans2);
                if (additionalChanges_1) {
                  var requestedValue_1 = req2.values[i];
                  Object.keys(additionalChanges_1).forEach(function(keyPath) {
                    if (hasOwn(requestedValue_1, keyPath)) {
                      requestedValue_1[keyPath] = additionalChanges_1[keyPath];
                    } else {
                      setByKeyPath(requestedValue_1, keyPath, additionalChanges_1[keyPath]);
                    }
                  });
                }
              }
              return ctx;
            });
            return downTable.mutate(req2).then(function(_a3) {
              var failures = _a3.failures, results = _a3.results, numFailures = _a3.numFailures, lastResult = _a3.lastResult;
              for (var i = 0; i < keys2.length; ++i) {
                var primKey = results ? results[i] : keys2[i];
                var ctx = contexts[i];
                if (primKey == null) {
                  ctx.onerror && ctx.onerror(failures[i]);
                } else {
                  ctx.onsuccess && ctx.onsuccess(
                    req2.type === "put" && existingValues[i] ? req2.values[i] : primKey
                  );
                }
              }
              return { failures, results, numFailures, lastResult };
            }).catch(function(error) {
              contexts.forEach(function(ctx) {
                return ctx.onerror && ctx.onerror(error);
              });
              return Promise.reject(error);
            });
          });
        }
        function deleteRange(req2) {
          return deleteNextChunk(req2.trans, req2.range, 1e4);
        }
        function deleteNextChunk(trans, range, limit) {
          return downTable.query({
            trans,
            values: false,
            query: { index: primaryKey, range },
            limit
          }).then(function(_a3) {
            var result = _a3.result;
            return addPutOrDelete({
              type: "delete",
              keys: result,
              trans
            }).then(function(res) {
              if (res.numFailures > 0)
                return Promise.reject(res.failures[0]);
              if (result.length < limit) {
                return {
                  failures: [],
                  numFailures: 0,
                  lastResult: void 0
                };
              } else {
                return deleteNextChunk(trans, __assign(__assign({}, range), { lower: result[result.length - 1], lowerOpen: true }), limit);
              }
            });
          });
        }
      } });
      return tableMiddleware;
    } });
  }
};
function getExistingValues(table, req, effectiveKeys) {
  return req.type === "add" ? Promise.resolve([]) : table.getMany({
    trans: req.trans,
    keys: effectiveKeys,
    cache: "immutable"
  });
}
function getFromTransactionCache(keys2, cache2, clone) {
  try {
    if (!cache2)
      return null;
    if (cache2.keys.length < keys2.length)
      return null;
    var result = [];
    for (var i = 0, j = 0; i < cache2.keys.length && j < keys2.length; ++i) {
      if (cmp(cache2.keys[i], keys2[j]) !== 0)
        continue;
      result.push(clone ? deepClone(cache2.values[i]) : cache2.values[i]);
      ++j;
    }
    return result.length === keys2.length ? result : null;
  } catch (_a2) {
    return null;
  }
}
var cacheExistingValuesMiddleware = {
  stack: "dbcore",
  level: -1,
  create: function(core) {
    return {
      table: function(tableName) {
        var table = core.table(tableName);
        return __assign(__assign({}, table), { getMany: function(req) {
          if (!req.cache) {
            return table.getMany(req);
          }
          var cachedResult = getFromTransactionCache(req.keys, req.trans["_cache"], req.cache === "clone");
          if (cachedResult) {
            return DexiePromise.resolve(cachedResult);
          }
          return table.getMany(req).then(function(res) {
            req.trans["_cache"] = {
              keys: req.keys,
              values: req.cache === "clone" ? deepClone(res) : res
            };
            return res;
          });
        }, mutate: function(req) {
          if (req.type !== "add")
            req.trans["_cache"] = null;
          return table.mutate(req);
        } });
      }
    };
  }
};
function isCachableContext(ctx, table) {
  return ctx.trans.mode === "readonly" && !!ctx.subscr && !ctx.trans.explicit && ctx.trans.db._options.cache !== "disabled" && !table.schema.primaryKey.outbound;
}
function isCachableRequest(type2, req) {
  switch (type2) {
    case "query":
      return req.values && !req.unique;
    case "get":
      return false;
    case "getMany":
      return false;
    case "count":
      return false;
    case "openCursor":
      return false;
  }
}
var observabilityMiddleware = {
  stack: "dbcore",
  level: 0,
  name: "Observability",
  create: function(core) {
    var dbName = core.schema.name;
    var FULL_RANGE = new RangeSet(core.MIN_KEY, core.MAX_KEY);
    return __assign(__assign({}, core), { transaction: function(stores, mode, options) {
      if (PSD.subscr && mode !== "readonly") {
        throw new exceptions.ReadOnly("Readwrite transaction in liveQuery context. Querier source: ".concat(PSD.querier));
      }
      return core.transaction(stores, mode, options);
    }, table: function(tableName) {
      var table = core.table(tableName);
      var schema = table.schema;
      var primaryKey = schema.primaryKey, indexes = schema.indexes;
      var extractKey = primaryKey.extractKey, outbound = primaryKey.outbound;
      var indexesWithAutoIncPK = primaryKey.autoIncrement && indexes.filter(function(index) {
        return index.compound && index.keyPath.includes(primaryKey.keyPath);
      });
      var tableClone = __assign(__assign({}, table), { mutate: function(req) {
        var _a2, _b;
        var trans = req.trans;
        var mutatedParts = req.mutatedParts || (req.mutatedParts = {});
        var getRangeSet = function(indexName) {
          var part = "idb://".concat(dbName, "/").concat(tableName, "/").concat(indexName);
          return mutatedParts[part] || (mutatedParts[part] = new RangeSet());
        };
        var pkRangeSet = getRangeSet("");
        var delsRangeSet = getRangeSet(":dels");
        var type2 = req.type;
        var _c = req.type === "deleteRange" ? [req.range] : req.type === "delete" ? [req.keys] : req.values.length < 50 ? [
          getEffectiveKeys(primaryKey, req).filter(function(id2) {
            return id2;
          }),
          req.values
        ] : [], keys2 = _c[0], newObjs = _c[1];
        var oldCache = req.trans["_cache"];
        if (isArray(keys2)) {
          pkRangeSet.addKeys(keys2);
          var oldObjs = type2 === "delete" || keys2.length === newObjs.length ? getFromTransactionCache(keys2, oldCache) : null;
          if (!oldObjs) {
            delsRangeSet.addKeys(keys2);
          }
          if (oldObjs || newObjs) {
            trackAffectedIndexes(getRangeSet, schema, oldObjs, newObjs);
          }
        } else if (keys2) {
          var range = {
            from: (_a2 = keys2.lower) !== null && _a2 !== void 0 ? _a2 : core.MIN_KEY,
            to: (_b = keys2.upper) !== null && _b !== void 0 ? _b : core.MAX_KEY
          };
          delsRangeSet.add(range);
          pkRangeSet.add(range);
        } else {
          pkRangeSet.add(FULL_RANGE);
          delsRangeSet.add(FULL_RANGE);
          schema.indexes.forEach(function(idx) {
            return getRangeSet(idx.name).add(FULL_RANGE);
          });
        }
        return table.mutate(req).then(function(res) {
          if (keys2 && (req.type === "add" || req.type === "put")) {
            pkRangeSet.addKeys(res.results);
            if (indexesWithAutoIncPK) {
              indexesWithAutoIncPK.forEach(function(idx) {
                var idxVals = req.values.map(function(v) {
                  return idx.extractKey(v);
                });
                var pkPos = idx.keyPath.findIndex(function(prop) {
                  return prop === primaryKey.keyPath;
                });
                for (var i = 0, len = res.results.length; i < len; ++i) {
                  idxVals[i][pkPos] = res.results[i];
                }
                getRangeSet(idx.name).addKeys(idxVals);
              });
            }
          }
          trans.mutatedParts = extendObservabilitySet(trans.mutatedParts || {}, mutatedParts);
          return res;
        });
      } });
      var getRange = function(_a2) {
        var _b, _c;
        var _d = _a2.query, index = _d.index, range = _d.range;
        return [
          index,
          new RangeSet((_b = range.lower) !== null && _b !== void 0 ? _b : core.MIN_KEY, (_c = range.upper) !== null && _c !== void 0 ? _c : core.MAX_KEY)
        ];
      };
      var readSubscribers = {
        get: function(req) {
          return [primaryKey, new RangeSet(req.key)];
        },
        getMany: function(req) {
          return [primaryKey, new RangeSet().addKeys(req.keys)];
        },
        count: getRange,
        query: getRange,
        openCursor: getRange
      };
      keys(readSubscribers).forEach(function(method) {
        tableClone[method] = function(req) {
          var subscr = PSD.subscr;
          var isLiveQuery = !!subscr;
          var cachable = isCachableContext(PSD, table) && isCachableRequest(method, req);
          var obsSet = cachable ? req.obsSet = {} : subscr;
          if (isLiveQuery) {
            var getRangeSet = function(indexName) {
              var part = "idb://".concat(dbName, "/").concat(tableName, "/").concat(indexName);
              return obsSet[part] || (obsSet[part] = new RangeSet());
            };
            var pkRangeSet_1 = getRangeSet("");
            var delsRangeSet_1 = getRangeSet(":dels");
            var _a2 = readSubscribers[method](req), queriedIndex = _a2[0], queriedRanges = _a2[1];
            if (method === "query" && queriedIndex.isPrimaryKey && !req.values) {
              delsRangeSet_1.add(queriedRanges);
            } else {
              getRangeSet(queriedIndex.name || "").add(queriedRanges);
            }
            if (!queriedIndex.isPrimaryKey) {
              if (method === "count") {
                delsRangeSet_1.add(FULL_RANGE);
              } else {
                var keysPromise_1 = method === "query" && outbound && req.values && table.query(__assign(__assign({}, req), { values: false }));
                return table[method].apply(this, arguments).then(function(res) {
                  if (method === "query") {
                    if (outbound && req.values) {
                      return keysPromise_1.then(function(_a3) {
                        var resultingKeys = _a3.result;
                        pkRangeSet_1.addKeys(resultingKeys);
                        return res;
                      });
                    }
                    var pKeys = req.values ? res.result.map(extractKey) : res.result;
                    if (req.values) {
                      pkRangeSet_1.addKeys(pKeys);
                    } else {
                      delsRangeSet_1.addKeys(pKeys);
                    }
                  } else if (method === "openCursor") {
                    var cursor_1 = res;
                    var wantValues_1 = req.values;
                    return cursor_1 && Object.create(cursor_1, {
                      key: {
                        get: function() {
                          delsRangeSet_1.addKey(cursor_1.primaryKey);
                          return cursor_1.key;
                        }
                      },
                      primaryKey: {
                        get: function() {
                          var pkey = cursor_1.primaryKey;
                          delsRangeSet_1.addKey(pkey);
                          return pkey;
                        }
                      },
                      value: {
                        get: function() {
                          wantValues_1 && pkRangeSet_1.addKey(cursor_1.primaryKey);
                          return cursor_1.value;
                        }
                      }
                    });
                  }
                  return res;
                });
              }
            }
          }
          return table[method].apply(this, arguments);
        };
      });
      return tableClone;
    } });
  }
};
function trackAffectedIndexes(getRangeSet, schema, oldObjs, newObjs) {
  function addAffectedIndex(ix) {
    var rangeSet = getRangeSet(ix.name || "");
    function extractKey(obj) {
      return obj != null ? ix.extractKey(obj) : null;
    }
    var addKeyOrKeys = function(key) {
      return ix.multiEntry && isArray(key) ? key.forEach(function(key2) {
        return rangeSet.addKey(key2);
      }) : rangeSet.addKey(key);
    };
    (oldObjs || newObjs).forEach(function(_, i) {
      var oldKey = oldObjs && extractKey(oldObjs[i]);
      var newKey = newObjs && extractKey(newObjs[i]);
      if (cmp(oldKey, newKey) !== 0) {
        if (oldKey != null)
          addKeyOrKeys(oldKey);
        if (newKey != null)
          addKeyOrKeys(newKey);
      }
    });
  }
  schema.indexes.forEach(addAffectedIndex);
}
function adjustOptimisticFromFailures(tblCache, req, res) {
  if (res.numFailures === 0)
    return req;
  if (req.type === "deleteRange") {
    return null;
  }
  var numBulkOps = req.keys ? req.keys.length : "values" in req && req.values ? req.values.length : 1;
  if (res.numFailures === numBulkOps) {
    return null;
  }
  var clone = __assign({}, req);
  if (isArray(clone.keys)) {
    clone.keys = clone.keys.filter(function(_, i) {
      return !(i in res.failures);
    });
  }
  if ("values" in clone && isArray(clone.values)) {
    clone.values = clone.values.filter(function(_, i) {
      return !(i in res.failures);
    });
  }
  return clone;
}
function isAboveLower(key, range) {
  return range.lower === void 0 ? true : range.lowerOpen ? cmp(key, range.lower) > 0 : cmp(key, range.lower) >= 0;
}
function isBelowUpper(key, range) {
  return range.upper === void 0 ? true : range.upperOpen ? cmp(key, range.upper) < 0 : cmp(key, range.upper) <= 0;
}
function isWithinRange(key, range) {
  return isAboveLower(key, range) && isBelowUpper(key, range);
}
function applyOptimisticOps(result, req, ops, table, cacheEntry, immutable) {
  if (!ops || ops.length === 0)
    return result;
  var index = req.query.index;
  var multiEntry = index.multiEntry;
  var queryRange = req.query.range;
  var primaryKey = table.schema.primaryKey;
  var extractPrimKey = primaryKey.extractKey;
  var extractIndex = index.extractKey;
  var extractLowLevelIndex = (index.lowLevelIndex || index).extractKey;
  var finalResult = ops.reduce(function(result2, op) {
    var modifedResult = result2;
    var includedValues = [];
    if (op.type === "add" || op.type === "put") {
      var includedPKs = new RangeSet();
      for (var i = op.values.length - 1; i >= 0; --i) {
        var value = op.values[i];
        var pk = extractPrimKey(value);
        if (includedPKs.hasKey(pk))
          continue;
        var key = extractIndex(value);
        if (multiEntry && isArray(key) ? key.some(function(k) {
          return isWithinRange(k, queryRange);
        }) : isWithinRange(key, queryRange)) {
          includedPKs.addKey(pk);
          includedValues.push(value);
        }
      }
    }
    switch (op.type) {
      case "add": {
        var existingKeys_1 = new RangeSet().addKeys(req.values ? result2.map(function(v) {
          return extractPrimKey(v);
        }) : result2);
        modifedResult = result2.concat(req.values ? includedValues.filter(function(v) {
          var key2 = extractPrimKey(v);
          if (existingKeys_1.hasKey(key2))
            return false;
          existingKeys_1.addKey(key2);
          return true;
        }) : includedValues.map(function(v) {
          return extractPrimKey(v);
        }).filter(function(k) {
          if (existingKeys_1.hasKey(k))
            return false;
          existingKeys_1.addKey(k);
          return true;
        }));
        break;
      }
      case "put": {
        var keySet_1 = new RangeSet().addKeys(op.values.map(function(v) {
          return extractPrimKey(v);
        }));
        modifedResult = result2.filter(
          function(item) {
            return !keySet_1.hasKey(req.values ? extractPrimKey(item) : item);
          }
        ).concat(
          req.values ? includedValues : includedValues.map(function(v) {
            return extractPrimKey(v);
          })
        );
        break;
      }
      case "delete":
        var keysToDelete_1 = new RangeSet().addKeys(op.keys);
        modifedResult = result2.filter(function(item) {
          return !keysToDelete_1.hasKey(req.values ? extractPrimKey(item) : item);
        });
        break;
      case "deleteRange":
        var range_1 = op.range;
        modifedResult = result2.filter(function(item) {
          return !isWithinRange(extractPrimKey(item), range_1);
        });
        break;
    }
    return modifedResult;
  }, result);
  if (finalResult === result)
    return result;
  var sorter = function(a, b) {
    return cmp(extractLowLevelIndex(a), extractLowLevelIndex(b)) || cmp(extractPrimKey(a), extractPrimKey(b));
  };
  finalResult.sort(req.direction === "prev" || req.direction === "prevunique" ? function(a, b) {
    return sorter(b, a);
  } : sorter);
  if (req.limit && req.limit < Infinity) {
    if (finalResult.length > req.limit) {
      finalResult.length = req.limit;
    } else if (result.length === req.limit && finalResult.length < req.limit) {
      cacheEntry.dirty = true;
    }
  }
  return immutable ? Object.freeze(finalResult) : finalResult;
}
function areRangesEqual(r1, r2) {
  return cmp(r1.lower, r2.lower) === 0 && cmp(r1.upper, r2.upper) === 0 && !!r1.lowerOpen === !!r2.lowerOpen && !!r1.upperOpen === !!r2.upperOpen;
}
function compareLowers(lower1, lower2, lowerOpen1, lowerOpen2) {
  if (lower1 === void 0)
    return lower2 !== void 0 ? -1 : 0;
  if (lower2 === void 0)
    return 1;
  var c = cmp(lower1, lower2);
  if (c === 0) {
    if (lowerOpen1 && lowerOpen2)
      return 0;
    if (lowerOpen1)
      return 1;
    if (lowerOpen2)
      return -1;
  }
  return c;
}
function compareUppers(upper1, upper2, upperOpen1, upperOpen2) {
  if (upper1 === void 0)
    return upper2 !== void 0 ? 1 : 0;
  if (upper2 === void 0)
    return -1;
  var c = cmp(upper1, upper2);
  if (c === 0) {
    if (upperOpen1 && upperOpen2)
      return 0;
    if (upperOpen1)
      return -1;
    if (upperOpen2)
      return 1;
  }
  return c;
}
function isSuperRange(r1, r2) {
  return compareLowers(r1.lower, r2.lower, r1.lowerOpen, r2.lowerOpen) <= 0 && compareUppers(r1.upper, r2.upper, r1.upperOpen, r2.upperOpen) >= 0;
}
function findCompatibleQuery(dbName, tableName, type2, req) {
  var _a2;
  var tblCache = cache["idb://".concat(dbName, "/").concat(tableName)];
  if (!tblCache)
    return [];
  var queries = tblCache.queries[type2];
  if (!queries)
    return [null, false, tblCache, null];
  var indexName = req.query ? req.query.index.name : null;
  var entries = queries[indexName || ""];
  if (!entries)
    return [null, false, tblCache, null];
  switch (type2) {
    case "query":
      var reqDirection_1 = (_a2 = req.direction) !== null && _a2 !== void 0 ? _a2 : "next";
      var equalEntry = entries.find(function(entry) {
        var _a3;
        return entry.req.limit === req.limit && entry.req.values === req.values && ((_a3 = entry.req.direction) !== null && _a3 !== void 0 ? _a3 : "next") === reqDirection_1 && areRangesEqual(entry.req.query.range, req.query.range);
      });
      if (equalEntry)
        return [
          equalEntry,
          true,
          tblCache,
          entries
        ];
      var superEntry = entries.find(function(entry) {
        var _a3;
        var limit = "limit" in entry.req ? entry.req.limit : Infinity;
        return limit >= req.limit && ((_a3 = entry.req.direction) !== null && _a3 !== void 0 ? _a3 : "next") === reqDirection_1 && (req.values ? entry.req.values : true) && isSuperRange(entry.req.query.range, req.query.range);
      });
      return [superEntry, false, tblCache, entries];
    case "count":
      var countQuery = entries.find(function(entry) {
        return areRangesEqual(entry.req.query.range, req.query.range);
      });
      return [countQuery, !!countQuery, tblCache, entries];
  }
}
function subscribeToCacheEntry(cacheEntry, container, requery, signal) {
  cacheEntry.subscribers.add(requery);
  signal.addEventListener("abort", function() {
    cacheEntry.subscribers.delete(requery);
    if (cacheEntry.subscribers.size === 0) {
      enqueForDeletion(cacheEntry, container);
    }
  });
}
function enqueForDeletion(cacheEntry, container) {
  setTimeout(function() {
    if (cacheEntry.subscribers.size === 0) {
      delArrayItem(container, cacheEntry);
    }
  }, 3e3);
}
var cacheMiddleware = {
  stack: "dbcore",
  level: 0,
  name: "Cache",
  create: function(core) {
    var dbName = core.schema.name;
    var coreMW = __assign(__assign({}, core), { transaction: function(stores, mode, options) {
      var idbtrans = core.transaction(stores, mode, options);
      if (mode === "readwrite") {
        var ac_1 = new AbortController();
        var signal = ac_1.signal;
        var endTransaction = function(wasCommitted) {
          return function() {
            ac_1.abort();
            if (mode === "readwrite") {
              var affectedSubscribers_1 = /* @__PURE__ */ new Set();
              for (var _i = 0, stores_1 = stores; _i < stores_1.length; _i++) {
                var storeName = stores_1[_i];
                var tblCache = cache["idb://".concat(dbName, "/").concat(storeName)];
                if (tblCache) {
                  var table = core.table(storeName);
                  var ops = tblCache.optimisticOps.filter(function(op) {
                    return op.trans === idbtrans;
                  });
                  if (idbtrans._explicit && wasCommitted && idbtrans.mutatedParts) {
                    for (var _a2 = 0, _b = Object.values(tblCache.queries.query); _a2 < _b.length; _a2++) {
                      var entries = _b[_a2];
                      for (var _c = 0, _d = entries.slice(); _c < _d.length; _c++) {
                        var entry = _d[_c];
                        if (obsSetsOverlap(entry.obsSet, idbtrans.mutatedParts)) {
                          delArrayItem(entries, entry);
                          entry.subscribers.forEach(function(requery) {
                            return affectedSubscribers_1.add(requery);
                          });
                        }
                      }
                    }
                  } else if (ops.length > 0) {
                    tblCache.optimisticOps = tblCache.optimisticOps.filter(function(op) {
                      return op.trans !== idbtrans;
                    });
                    for (var _e = 0, _f = Object.values(tblCache.queries.query); _e < _f.length; _e++) {
                      var entries = _f[_e];
                      for (var _g = 0, _h = entries.slice(); _g < _h.length; _g++) {
                        var entry = _h[_g];
                        if (entry.res != null && idbtrans.mutatedParts) {
                          if (wasCommitted && !entry.dirty) {
                            var freezeResults = Object.isFrozen(entry.res);
                            var modRes = applyOptimisticOps(entry.res, entry.req, ops, table, entry, freezeResults);
                            if (entry.dirty) {
                              delArrayItem(entries, entry);
                              entry.subscribers.forEach(function(requery) {
                                return affectedSubscribers_1.add(requery);
                              });
                            } else if (modRes !== entry.res) {
                              entry.res = modRes;
                              entry.promise = DexiePromise.resolve({
                                result: modRes
                              });
                            }
                          } else {
                            if (entry.dirty) {
                              delArrayItem(entries, entry);
                            }
                            entry.subscribers.forEach(function(requery) {
                              return affectedSubscribers_1.add(requery);
                            });
                          }
                        }
                      }
                    }
                  }
                }
              }
              affectedSubscribers_1.forEach(function(requery) {
                return requery();
              });
            }
          };
        };
        idbtrans.addEventListener("abort", endTransaction(false), {
          signal
        });
        idbtrans.addEventListener("error", endTransaction(false), {
          signal
        });
        idbtrans.addEventListener("complete", endTransaction(true), {
          signal
        });
      }
      return idbtrans;
    }, table: function(tableName) {
      var downTable = core.table(tableName);
      var primKey = downTable.schema.primaryKey;
      var tableMW = __assign(__assign({}, downTable), { mutate: function(req) {
        var trans = PSD.trans;
        if (primKey.outbound || trans.db._options.cache === "disabled" || trans.explicit || trans.idbtrans.mode !== "readwrite") {
          return downTable.mutate(req);
        }
        var tblCache = cache["idb://".concat(dbName, "/").concat(tableName)];
        if (!tblCache)
          return downTable.mutate(req);
        var promise = downTable.mutate(req);
        if ((req.type === "add" || req.type === "put") && (req.values.length >= 50 || getEffectiveKeys(primKey, req).some(function(key) {
          return key == null;
        }))) {
          promise.then(function(res) {
            var reqWithResolvedKeys = __assign(__assign({}, req), { values: req.values.map(function(value, i) {
              var _a2;
              if (res.failures[i])
                return value;
              var valueWithKey = ((_a2 = primKey.keyPath) === null || _a2 === void 0 ? void 0 : _a2.includes(".")) ? deepClone(value) : __assign({}, value);
              setByKeyPath(valueWithKey, primKey.keyPath, res.results[i]);
              return valueWithKey;
            }) });
            var adjustedReq = adjustOptimisticFromFailures(tblCache, reqWithResolvedKeys, res);
            tblCache.optimisticOps.push(adjustedReq);
            queueMicrotask(function() {
              return req.mutatedParts && signalSubscribersLazily(req.mutatedParts);
            });
          });
        } else {
          tblCache.optimisticOps.push(req);
          req.mutatedParts && signalSubscribersLazily(req.mutatedParts);
          promise.then(function(res) {
            if (res.numFailures > 0) {
              delArrayItem(tblCache.optimisticOps, req);
              var adjustedReq = adjustOptimisticFromFailures(tblCache, req, res);
              if (adjustedReq) {
                tblCache.optimisticOps.push(adjustedReq);
              }
              req.mutatedParts && signalSubscribersLazily(req.mutatedParts);
            }
          });
          promise.catch(function() {
            delArrayItem(tblCache.optimisticOps, req);
            req.mutatedParts && signalSubscribersLazily(req.mutatedParts);
          });
        }
        return promise;
      }, query: function(req) {
        var _a2;
        if (!isCachableContext(PSD, downTable) || !isCachableRequest("query", req))
          return downTable.query(req);
        var freezeResults = ((_a2 = PSD.trans) === null || _a2 === void 0 ? void 0 : _a2.db._options.cache) === "immutable";
        var _b = PSD, requery = _b.requery, signal = _b.signal;
        var _c = findCompatibleQuery(dbName, tableName, "query", req), cacheEntry = _c[0], exactMatch = _c[1], tblCache = _c[2], container = _c[3];
        if (cacheEntry && exactMatch) {
          cacheEntry.obsSet = req.obsSet;
        } else {
          var promise = downTable.query(req).then(function(res) {
            var result = res.result;
            if (cacheEntry)
              cacheEntry.res = result;
            if (freezeResults) {
              for (var i = 0, l = result.length; i < l; ++i) {
                Object.freeze(result[i]);
              }
              Object.freeze(result);
            }
            return res;
          }).catch(function(error) {
            if (container && cacheEntry)
              delArrayItem(container, cacheEntry);
            return Promise.reject(error);
          });
          cacheEntry = {
            obsSet: req.obsSet,
            promise,
            subscribers: /* @__PURE__ */ new Set(),
            type: "query",
            req,
            dirty: false
          };
          if (container) {
            container.push(cacheEntry);
          } else {
            container = [cacheEntry];
            if (!tblCache) {
              tblCache = cache["idb://".concat(dbName, "/").concat(tableName)] = {
                queries: {
                  query: {},
                  count: {}
                },
                objs: /* @__PURE__ */ new Map(),
                optimisticOps: [],
                unsignaledParts: {}
              };
            }
            tblCache.queries.query[req.query.index.name || ""] = container;
          }
        }
        subscribeToCacheEntry(cacheEntry, container, requery, signal);
        return cacheEntry.promise.then(function(res) {
          var result = applyOptimisticOps(res.result, req, tblCache === null || tblCache === void 0 ? void 0 : tblCache.optimisticOps, downTable, cacheEntry, freezeResults);
          return {
            result: freezeResults ? result : deepClone(result)
          };
        });
      } });
      return tableMW;
    } });
    return coreMW;
  }
};
function vipify(target, vipDb) {
  return new Proxy(target, {
    get: function(target2, prop, receiver) {
      if (prop === "db")
        return vipDb;
      return Reflect.get(target2, prop, receiver);
    }
  });
}
var Dexie$1 = (function() {
  function Dexie2(name, options) {
    var _this = this;
    this._middlewares = {};
    this.verno = 0;
    var deps = Dexie2.dependencies;
    this._options = options = __assign({
      addons: Dexie2.addons,
      autoOpen: true,
      indexedDB: deps.indexedDB,
      IDBKeyRange: deps.IDBKeyRange,
      cache: "cloned",
      maxConnections: DEFAULT_MAX_CONNECTIONS
    }, options);
    this._deps = {
      indexedDB: options.indexedDB,
      IDBKeyRange: options.IDBKeyRange
    };
    var addons = options.addons;
    this._dbSchema = {};
    this._versions = [];
    this._storeNames = [];
    this._allTables = {};
    this.idbdb = null;
    this._novip = this;
    var state = {
      dbOpenError: null,
      isBeingOpened: false,
      onReadyBeingFired: null,
      openComplete: false,
      dbReadyResolve: nop,
      dbReadyPromise: null,
      cancelOpen: nop,
      openCanceller: null,
      autoSchema: true,
      PR1398_maxLoop: 3,
      autoOpen: options.autoOpen
    };
    state.dbReadyPromise = new DexiePromise(function(resolve) {
      state.dbReadyResolve = resolve;
    });
    state.openCanceller = new DexiePromise(function(_, reject) {
      state.cancelOpen = reject;
    });
    this._state = state;
    this.name = name;
    this.on = Events(this, "populate", "blocked", "versionchange", "close", {
      ready: [promisableChain, nop]
    });
    this.once = function(event, callback) {
      var fn = function() {
        var args = [];
        for (var _i = 0; _i < arguments.length; _i++) {
          args[_i] = arguments[_i];
        }
        _this.on(event).unsubscribe(fn);
        callback.apply(_this, args);
      };
      return _this.on(event, fn);
    };
    this.on.ready.subscribe = override(this.on.ready.subscribe, function(subscribe) {
      return function(subscriber, bSticky) {
        Dexie2.vip(function() {
          var state2 = _this._state;
          if (state2.openComplete) {
            if (!state2.dbOpenError)
              DexiePromise.resolve().then(subscriber);
            if (bSticky)
              subscribe(subscriber);
          } else if (state2.onReadyBeingFired) {
            state2.onReadyBeingFired.push(subscriber);
            if (bSticky)
              subscribe(subscriber);
          } else {
            subscribe(subscriber);
            var db_1 = _this;
            if (!bSticky)
              subscribe(function unsubscribe() {
                db_1.on.ready.unsubscribe(subscriber);
                db_1.on.ready.unsubscribe(unsubscribe);
              });
          }
        });
      };
    });
    this.Collection = createCollectionConstructor(this);
    this.Table = createTableConstructor(this);
    this.Transaction = createTransactionConstructor(this);
    this.Version = createVersionConstructor(this);
    this.WhereClause = createWhereClauseConstructor(this);
    this.on("versionchange", function(ev) {
      if (ev.newVersion > 0)
        console.warn("Another connection wants to upgrade database '".concat(_this.name, "'. Closing db now to resume the upgrade."));
      else
        console.warn("Another connection wants to delete database '".concat(_this.name, "'. Closing db now to resume the delete request."));
      _this.close({ disableAutoOpen: false });
    });
    this.on("blocked", function(ev) {
      if (!ev.newVersion || ev.newVersion < ev.oldVersion)
        console.warn("Dexie.delete('".concat(_this.name, "') was blocked"));
      else
        console.warn("Upgrade '".concat(_this.name, "' blocked by other connection holding version ").concat(ev.oldVersion / 10));
    });
    this._maxKey = getMaxKey(options.IDBKeyRange);
    this._createTransaction = function(mode, storeNames, dbschema, parentTransaction) {
      return new _this.Transaction(mode, storeNames, dbschema, _this._options.chromeTransactionDurability, parentTransaction);
    };
    this._fireOnBlocked = function(ev) {
      _this.on("blocked").fire(ev);
      connections.toArray().filter(function(c) {
        return c.name === _this.name && c !== _this && !c._state.vcFired;
      }).map(function(c) {
        return c.on("versionchange").fire(ev);
      });
    };
    this.use(cacheExistingValuesMiddleware);
    this.use(cacheMiddleware);
    this.use(observabilityMiddleware);
    this.use(virtualIndexMiddleware);
    this.use(hooksMiddleware);
    var vipDB = new Proxy(this, {
      get: function(_, prop, receiver) {
        if (prop === "_vip")
          return true;
        if (prop === "table")
          return function(tableName) {
            return vipify(_this.table(tableName), vipDB);
          };
        var rv = Reflect.get(_, prop, receiver);
        if (rv instanceof Table)
          return vipify(rv, vipDB);
        if (prop === "tables")
          return rv.map(function(t) {
            return vipify(t, vipDB);
          });
        if (prop === "_createTransaction")
          return function() {
            var tx = rv.apply(this, arguments);
            return vipify(tx, vipDB);
          };
        return rv;
      }
    });
    this.vip = vipDB;
    addons.forEach(function(addon) {
      return addon(_this);
    });
  }
  Dexie2.prototype.version = function(versionNumber) {
    if (isNaN(versionNumber) || versionNumber < 0.1)
      throw new exceptions.Type("Given version is not a positive number");
    versionNumber = Math.round(versionNumber * 10) / 10;
    if (this.idbdb || this._state.isBeingOpened)
      throw new exceptions.Schema("Cannot add version when database is open");
    this.verno = Math.max(this.verno, versionNumber);
    var versions = this._versions;
    var versionInstance = versions.filter(function(v) {
      return v._cfg.version === versionNumber;
    })[0];
    if (versionInstance)
      return versionInstance;
    versionInstance = new this.Version(versionNumber);
    versions.push(versionInstance);
    versions.sort(lowerVersionFirst);
    versionInstance.stores({});
    this._state.autoSchema = false;
    return versionInstance;
  };
  Dexie2.prototype._whenReady = function(fn) {
    var _this = this;
    return this.idbdb && (this._state.openComplete || PSD.letThrough || this._vip) ? fn() : new DexiePromise(function(resolve, reject) {
      if (_this._state.openComplete) {
        return reject(new exceptions.DatabaseClosed(_this._state.dbOpenError));
      }
      if (!_this._state.isBeingOpened) {
        if (!_this._state.autoOpen) {
          reject(new exceptions.DatabaseClosed());
          return;
        }
        _this.open().catch(nop);
      }
      _this._state.dbReadyPromise.then(resolve, reject);
    }).then(fn);
  };
  Dexie2.prototype.use = function(_a2) {
    var stack = _a2.stack, create = _a2.create, level = _a2.level, name = _a2.name;
    if (name)
      this.unuse({ stack, name });
    var middlewares = this._middlewares[stack] || (this._middlewares[stack] = []);
    middlewares.push({
      stack,
      create,
      level: level == null ? 10 : level,
      name
    });
    middlewares.sort(function(a, b) {
      return a.level - b.level;
    });
    return this;
  };
  Dexie2.prototype.unuse = function(_a2) {
    var stack = _a2.stack, name = _a2.name, create = _a2.create;
    if (stack && this._middlewares[stack]) {
      this._middlewares[stack] = this._middlewares[stack].filter(function(mw) {
        return create ? mw.create !== create : name ? mw.name !== name : false;
      });
    }
    return this;
  };
  Dexie2.prototype.open = function() {
    var _this = this;
    return usePSD(
      globalPSD,
      function() {
        return dexieOpen(_this);
      }
    );
  };
  Dexie2.prototype._close = function() {
    this.on.close.fire(new CustomEvent("close"));
    var state = this._state;
    connections.remove(this);
    if (this.idbdb) {
      try {
        this.idbdb.close();
      } catch (e) {
      }
      this.idbdb = null;
    }
    if (!state.isBeingOpened) {
      state.dbReadyPromise = new DexiePromise(function(resolve) {
        state.dbReadyResolve = resolve;
      });
      state.openCanceller = new DexiePromise(function(_, reject) {
        state.cancelOpen = reject;
      });
    }
  };
  Dexie2.prototype.close = function(_a2) {
    var _b = _a2 === void 0 ? { disableAutoOpen: true } : _a2, disableAutoOpen = _b.disableAutoOpen;
    var state = this._state;
    if (disableAutoOpen) {
      if (state.isBeingOpened) {
        state.cancelOpen(new exceptions.DatabaseClosed());
      }
      this._close();
      state.autoOpen = false;
      state.dbOpenError = new exceptions.DatabaseClosed();
    } else {
      this._close();
      state.autoOpen = this._options.autoOpen || state.isBeingOpened;
      state.openComplete = false;
      state.dbOpenError = null;
    }
  };
  Dexie2.prototype.delete = function(closeOptions) {
    var _this = this;
    if (closeOptions === void 0) {
      closeOptions = { disableAutoOpen: true };
    }
    var hasInvalidArguments = arguments.length > 0 && typeof arguments[0] !== "object";
    var state = this._state;
    return new DexiePromise(function(resolve, reject) {
      var doDelete = function() {
        _this.close(closeOptions);
        var req = _this._deps.indexedDB.deleteDatabase(_this.name);
        req.onsuccess = wrap(function() {
          _onDatabaseDeleted(_this._deps, _this.name);
          resolve();
        });
        req.onerror = eventRejectHandler(reject);
        req.onblocked = _this._fireOnBlocked;
      };
      if (hasInvalidArguments)
        throw new exceptions.InvalidArgument("Invalid closeOptions argument to db.delete()");
      if (state.isBeingOpened) {
        state.dbReadyPromise.then(doDelete);
      } else {
        doDelete();
      }
    });
  };
  Dexie2.prototype.backendDB = function() {
    return this.idbdb;
  };
  Dexie2.prototype.isOpen = function() {
    return this.idbdb !== null;
  };
  Dexie2.prototype.hasBeenClosed = function() {
    var dbOpenError = this._state.dbOpenError;
    return dbOpenError && dbOpenError.name === "DatabaseClosed";
  };
  Dexie2.prototype.hasFailed = function() {
    return this._state.dbOpenError !== null;
  };
  Dexie2.prototype.dynamicallyOpened = function() {
    return this._state.autoSchema;
  };
  Object.defineProperty(Dexie2.prototype, "tables", {
    get: function() {
      var _this = this;
      return keys(this._allTables).map(function(name) {
        return _this._allTables[name];
      });
    },
    enumerable: false,
    configurable: true
  });
  Dexie2.prototype.transaction = function() {
    var args = extractTransactionArgs.apply(this, arguments);
    return this._transaction.apply(this, args);
  };
  Dexie2.prototype._transaction = function(mode, tables, scopeFunc) {
    var _this = this;
    var parentTransaction = PSD.trans;
    if (!parentTransaction || parentTransaction.db !== this || mode.indexOf("!") !== -1)
      parentTransaction = null;
    var onlyIfCompatible = mode.indexOf("?") !== -1;
    mode = mode.replace("!", "").replace("?", "");
    var idbMode, storeNames;
    try {
      storeNames = tables.map(function(table) {
        var storeName = table instanceof _this.Table ? table.name : table;
        if (typeof storeName !== "string")
          throw new TypeError("Invalid table argument to Dexie.transaction(). Only Table or String are allowed");
        return storeName;
      });
      if (mode == "r" || mode === READONLY)
        idbMode = READONLY;
      else if (mode == "rw" || mode == READWRITE)
        idbMode = READWRITE;
      else
        throw new exceptions.InvalidArgument("Invalid transaction mode: " + mode);
      if (parentTransaction) {
        if (parentTransaction.mode === READONLY && idbMode === READWRITE) {
          if (onlyIfCompatible) {
            parentTransaction = null;
          } else
            throw new exceptions.SubTransaction("Cannot enter a sub-transaction with READWRITE mode when parent transaction is READONLY");
        }
        if (parentTransaction) {
          storeNames.forEach(function(storeName) {
            if (parentTransaction && parentTransaction.storeNames.indexOf(storeName) === -1) {
              if (onlyIfCompatible) {
                parentTransaction = null;
              } else
                throw new exceptions.SubTransaction("Table " + storeName + " not included in parent transaction.");
            }
          });
        }
        if (onlyIfCompatible && parentTransaction && !parentTransaction.active) {
          parentTransaction = null;
        }
      }
    } catch (e) {
      return parentTransaction ? parentTransaction._promise(null, function(_, reject) {
        reject(e);
      }) : rejection(e);
    }
    var enterTransaction = enterTransactionScope.bind(null, this, idbMode, storeNames, parentTransaction, scopeFunc);
    return parentTransaction ? parentTransaction._promise(idbMode, enterTransaction, "lock") : PSD.trans ? usePSD(PSD.transless, function() {
      return _this._whenReady(enterTransaction);
    }) : this._whenReady(enterTransaction);
  };
  Dexie2.prototype.table = function(tableName) {
    if (!hasOwn(this._allTables, tableName)) {
      throw new exceptions.InvalidTable("Table ".concat(tableName, " does not exist"));
    }
    return this._allTables[tableName];
  };
  return Dexie2;
})();
var symbolObservable = typeof Symbol !== "undefined" && "observable" in Symbol ? Symbol.observable : "@@observable";
var Observable = (function() {
  function Observable2(subscribe) {
    this._subscribe = subscribe;
  }
  Observable2.prototype.subscribe = function(x, error, complete) {
    return this._subscribe(!x || typeof x === "function" ? { next: x, error, complete } : x);
  };
  Observable2.prototype[symbolObservable] = function() {
    return this;
  };
  return Observable2;
})();
var domDeps;
try {
  domDeps = {
    indexedDB: _global.indexedDB || _global.mozIndexedDB || _global.webkitIndexedDB || _global.msIndexedDB,
    IDBKeyRange: _global.IDBKeyRange || _global.webkitIDBKeyRange
  };
} catch (e) {
  domDeps = { indexedDB: null, IDBKeyRange: null };
}
function liveQuery(querier) {
  var hasValue = false;
  var currentValue;
  var observable = new Observable(function(observer) {
    var scopeFuncIsAsync = isAsyncFunction(querier);
    function execute(ctx) {
      var wasRootExec = beginMicroTickScope();
      try {
        if (scopeFuncIsAsync) {
          incrementExpectedAwaits();
        }
        var rv = newScope(querier, ctx);
        if (scopeFuncIsAsync) {
          rv = rv.finally(decrementExpectedAwaits);
        }
        return rv;
      } finally {
        wasRootExec && endMicroTickScope();
      }
    }
    var closed = false;
    var abortController;
    var accumMuts = {};
    var currentObs = {};
    var subscription = {
      get closed() {
        return closed;
      },
      unsubscribe: function() {
        if (closed)
          return;
        closed = true;
        if (abortController)
          abortController.abort();
        if (startedListening)
          globalEvents.storagemutated.unsubscribe(mutationListener);
      }
    };
    observer.start && observer.start(subscription);
    var startedListening = false;
    var doQuery = function() {
      return execInGlobalContext(_doQuery);
    };
    function shouldNotify() {
      return obsSetsOverlap(currentObs, accumMuts);
    }
    var mutationListener = function(parts) {
      extendObservabilitySet(accumMuts, parts);
      if (shouldNotify()) {
        doQuery();
      }
    };
    var _doQuery = function() {
      if (closed || !domDeps.indexedDB) {
        return;
      }
      accumMuts = {};
      var subscr = {};
      if (abortController)
        abortController.abort();
      abortController = new AbortController();
      var ctx = {
        subscr,
        signal: abortController.signal,
        requery: doQuery,
        querier,
        trans: null
      };
      var ret = execute(ctx);
      if (!startedListening) {
        globalEvents.storagemutated.subscribe(mutationListener);
        startedListening = true;
      }
      Promise.resolve(ret).then(function(result) {
        hasValue = true;
        currentValue = result;
        if (closed || ctx.signal.aborted) {
          return;
        }
        if (shouldNotify()) {
          doQuery();
        } else {
          currentObs = subscr;
          if (shouldNotify()) {
            doQuery();
          } else {
            accumMuts = {};
            execInGlobalContext(function() {
              return !closed && observer.next && observer.next(result);
            });
          }
        }
      }, function(err) {
        hasValue = false;
        if (!["DatabaseClosedError", "AbortError"].includes(err === null || err === void 0 ? void 0 : err.name)) {
          if (!closed)
            execInGlobalContext(function() {
              if (closed)
                return;
              observer.error && observer.error(err);
            });
        }
      });
    };
    setTimeout(doQuery, 0);
    return subscription;
  });
  observable.hasValue = function() {
    return hasValue;
  };
  observable.getValue = function() {
    return currentValue;
  };
  return observable;
}
var Dexie = Dexie$1;
props(Dexie, __assign(__assign({}, fullNameExceptions), {
  delete: function(databaseName) {
    var db = new Dexie(databaseName, { addons: [] });
    return db.delete();
  },
  exists: function(name) {
    return new Dexie(name, { addons: [] }).open().then(function(db) {
      db.close();
      return true;
    }).catch("NoSuchDatabaseError", function() {
      return false;
    });
  },
  getDatabaseNames: function(cb) {
    try {
      return getDatabaseNames(Dexie.dependencies).then(cb);
    } catch (_a2) {
      return rejection(new exceptions.MissingAPI());
    }
  },
  defineClass: function() {
    function Class(content) {
      extend(this, content);
    }
    return Class;
  },
  ignoreTransaction: function(scopeFunc) {
    return PSD.trans ? usePSD(PSD.transless || globalPSD, scopeFunc) : scopeFunc();
  },
  vip,
  async: function(generatorFn) {
    return function() {
      try {
        var rv = awaitIterator(generatorFn.apply(this, arguments));
        if (!rv || typeof rv.then !== "function")
          return DexiePromise.resolve(rv);
        return rv;
      } catch (e) {
        return rejection(e);
      }
    };
  },
  spawn: function(generatorFn, args, thiz) {
    try {
      var rv = awaitIterator(generatorFn.apply(thiz, args || []));
      if (!rv || typeof rv.then !== "function")
        return DexiePromise.resolve(rv);
      return rv;
    } catch (e) {
      return rejection(e);
    }
  },
  currentTransaction: {
    get: function() {
      return PSD.trans || null;
    }
  },
  waitFor: function(promiseOrFunction, optionalTimeout) {
    var promise = DexiePromise.resolve(typeof promiseOrFunction === "function" ? Dexie.ignoreTransaction(promiseOrFunction) : promiseOrFunction).timeout(optionalTimeout || 6e4);
    return PSD.trans ? PSD.trans.waitFor(promise) : promise;
  },
  Promise: DexiePromise,
  debug: {
    get: function() {
      return debug;
    },
    set: function(value) {
      setDebug(value);
    }
  },
  derive,
  extend,
  props,
  override,
  Events,
  on: globalEvents,
  liveQuery,
  extendObservabilitySet,
  getByKeyPath,
  setByKeyPath,
  delByKeyPath,
  shallowClone,
  deepClone,
  getObjectDiff,
  cmp,
  asap: asap$1,
  minKey,
  addons: [],
  connections: {
    get: connections.toArray
  },
  errnames,
  dependencies: domDeps,
  cache,
  semVer: DEXIE_VERSION,
  version: DEXIE_VERSION.split(".").map(function(n) {
    return parseInt(n);
  }).reduce(function(p, c, i) {
    return p + c / Math.pow(10, i * 2);
  })
}));
Dexie.maxKey = getMaxKey(Dexie.dependencies.IDBKeyRange);
if (typeof dispatchEvent !== "undefined" && typeof addEventListener !== "undefined") {
  globalEvents(DEXIE_STORAGE_MUTATED_EVENT_NAME, function(updatedParts) {
    if (!propagatingLocally) {
      var event_1;
      event_1 = new CustomEvent(STORAGE_MUTATED_DOM_EVENT_NAME, {
        detail: updatedParts
      });
      propagatingLocally = true;
      dispatchEvent(event_1);
      propagatingLocally = false;
    }
  });
  addEventListener(STORAGE_MUTATED_DOM_EVENT_NAME, function(_a2) {
    var detail = _a2.detail;
    if (!propagatingLocally) {
      propagateLocally(detail);
    }
  });
}
function propagateLocally(updateParts) {
  var wasMe = propagatingLocally;
  try {
    propagatingLocally = true;
    globalEvents.storagemutated.fire(updateParts);
    signalSubscribersNow(updateParts, true);
  } finally {
    propagatingLocally = wasMe;
  }
}
var propagatingLocally = false;
var bc;
var createBC = function() {
};
if (typeof BroadcastChannel !== "undefined") {
  createBC = function() {
    bc = new BroadcastChannel(STORAGE_MUTATED_DOM_EVENT_NAME);
    bc.onmessage = function(ev) {
      return ev.data && propagateLocally(ev.data);
    };
  };
  createBC();
  if (typeof bc.unref === "function") {
    bc.unref();
  }
  globalEvents(DEXIE_STORAGE_MUTATED_EVENT_NAME, function(changedParts) {
    if (!propagatingLocally) {
      bc.postMessage(changedParts);
    }
  });
}
if (typeof addEventListener !== "undefined") {
  addEventListener("pagehide", function(event) {
    if (!Dexie$1.disableBfCache && event.persisted) {
      if (debug)
        console.debug("Dexie: handling persisted pagehide");
      bc === null || bc === void 0 ? void 0 : bc.close();
      for (var _i = 0, _a2 = connections.toArray(); _i < _a2.length; _i++) {
        var db = _a2[_i];
        db.close({ disableAutoOpen: false });
      }
    }
  });
  addEventListener("pageshow", function(event) {
    if (!Dexie$1.disableBfCache && event.persisted) {
      if (debug)
        console.debug("Dexie: handling persisted pageshow");
      createBC();
      propagateLocally({ all: new RangeSet(-Infinity, [[]]) });
    }
  });
}
DexiePromise.rejectionMapper = mapError;
setDebug(debug);
function isDevelopmentContextAllowed(_target, scope = instanceScope()) {
  return /^(vk-booster|chatgpt-booster|all-in-one):(dev|prod)$/.test(scope);
}
function assertServiceScope(scope) {
  if (!scope || typeof scope !== "object" || Array.isArray(scope) || typeof scope.productId !== "string" || !/^[a-z][a-z0-9-]{1,63}$/.test(scope.productId) || scope.channel !== "dev" && scope.channel !== "prod" || scope.ownerId !== void 0 && (typeof scope.ownerId !== "string" || !scope.ownerId || scope.ownerId.length > 256) || scope.installationId !== void 0 && (typeof scope.installationId !== "string" || !/^[a-zA-Z0-9_-]{1,128}$/.test(scope.installationId))) {
    throw new Error("Invalid product/channel/owner scope");
  }
  return scope;
}
new TextEncoder();
new TextEncoder();
new TextDecoder("utf-8", { fatal: true });
new TextEncoder();
new TextDecoder("utf-8", { fatal: true });
var EVENTS = /* @__PURE__ */ new Set([
  "feature.started",
  "feature.stopped",
  "feature.failed",
  "application.notification",
  "application.error",
  "archive.capture.started",
  "archive.capture.completed",
  "archive.capture.failed",
  "archive.export.completed",
  "archive.export.failed",
  "archive.audit.completed",
  "archive.backup.completed",
  "archive.restore.completed"
]);
var MAX_EVENTS = 5e3;
var TELEMETRY_HARD_LIMIT = 1e4;
function validateTechnicalTelemetryEntry(input) {
  if (!input || typeof input !== "object" || Array.isArray(input) || Object.keys(input).some((key) => ![
    "id",
    "serviceId",
    "name",
    "timestamp",
    "count",
    "durationMs",
    "providerId",
    "errorClass",
    "state",
    "leaseOwner",
    "leaseUntil",
    "attempts"
  ].includes(key)) || !EVENTS.has(input.name) || typeof input.serviceId !== "string" || !/^[a-zA-Z][\w -]{2,64}$/.test(input.serviceId) || !Number.isSafeInteger(input.timestamp) || input.timestamp < 0 || input.timestamp > 864e13 || input.providerId !== void 0 && !["application", "vk-booster", "chatgpt-booster"].includes(input.providerId) || input.errorClass !== void 0 && !["network", "permission", "storage", "validation", "cancelled", "internal"].includes(input.errorClass) || input.count !== void 0 && (!Number.isSafeInteger(input.count) || input.count < 0 || input.count > 1e6) || input.durationMs !== void 0 && (!Number.isSafeInteger(input.durationMs) || input.durationMs < 0 || input.durationMs > 864e5))
    throw Error("Unsafe technical telemetry event");
}
function telemetryDatabaseName(scope) {
  assertServiceScope(scope);
  if (!scope.installationId)
    throw Error("Telemetry requires a verified installation scope");
  if (scope.ownerId !== void 0)
    throw Error("Account-linked telemetry is not supported");
  return `koba-telemetry:${scope.productId}:${scope.channel}:${scope.installationId}`;
}
class TelemetryDatabase extends Dexie$1 {
  events;
  metadata;
  constructor(name, options) {
    super(name, options);
    this.version(1).stores({ events: "++id,state,leaseUntil,timestamp", metadata: "key" });
  }
}
class DexieTelemetryJournal {
  databaseName;
  db;
  maxEvents;
  constructor(scope, options, maxEvents = MAX_EVENTS) {
    if (!Number.isSafeInteger(maxEvents) || maxEvents < 1 || maxEvents > MAX_EVENTS)
      throw Error("Invalid telemetry retention limit");
    this.maxEvents = maxEvents;
    this.databaseName = telemetryDatabaseName(scope);
    this.db = new TelemetryDatabase(this.databaseName, options);
  }
  async append(input) {
    validateTechnicalTelemetryEntry(input);
    await this.db.transaction("rw", this.db.events, this.db.metadata, async () => {
      if (await this.db.events.count() >= TELEMETRY_HARD_LIMIT) {
        const prior = await this.db.metadata.get("retention");
        await this.db.metadata.put({
          ...prior,
          key: "retention",
          discarded: (prior?.discarded ?? 0) + 1
        });
        return;
      }
      await this.db.events.add({
        serviceId: input.serviceId,
        name: input.name,
        timestamp: input.timestamp,
        ...input.count === void 0 ? {} : { count: input.count },
        ...input.durationMs === void 0 ? {} : { durationMs: input.durationMs },
        ...input.providerId === void 0 ? {} : { providerId: input.providerId },
        ...input.errorClass === void 0 ? {} : { errorClass: input.errorClass },
        state: "pending",
        leaseOwner: null,
        leaseUntil: 0,
        attempts: 0
      });
    });
  }
  async claim(owner, now = Date.now(), limit = 50) {
    if (!/^[a-zA-Z0-9_-]{8,128}$/.test(owner) || !Number.isSafeInteger(now) || now < 0 || !Number.isSafeInteger(limit) || limit < 1 || limit > 50)
      throw Error("Invalid telemetry lease");
    return this.db.transaction("rw", this.db.events, async () => {
      const rows = await this.db.events.orderBy("id").filter((row) => row.state === "pending" || row.state === "sending" && row.leaseUntil <= now).limit(limit).toArray();
      for (const row of rows) {
        row.state = "sending";
        row.leaseOwner = owner;
        row.leaseUntil = now + 45e3;
        row.attempts++;
      }
      await this.db.events.bulkPut(rows);
      return rows;
    });
  }
  async acknowledge(owner, ids) {
    return this.db.transaction("rw", this.db.events, async () => {
      let acknowledged = 0;
      for (const id2 of ids) {
        const row = await this.db.events.get(id2);
        if (row?.state === "sending" && row.leaseOwner === owner) {
          await this.db.events.put({ ...row, state: "sent", leaseOwner: null, leaseUntil: 0 });
          acknowledged++;
        }
      }
      return acknowledged;
    });
  }
  async release(owner, ids) {
    await this.db.transaction("rw", this.db.events, async () => {
      for (const id2 of ids) {
        const row = await this.db.events.get(id2);
        if (row?.state === "sending" && row.leaseOwner === owner)
          await this.db.events.put({ ...row, state: "pending", leaseOwner: null, leaseUntil: 0 });
      }
    });
  }
  async summary() {
    const [pending, sending, delivered, retained, metadata] = await Promise.all([
      this.db.events.where("state").equals("pending").count(),
      this.db.events.where("state").equals("sending").count(),
      this.db.events.where("state").equals("sent").count(),
      this.db.events.count(),
      this.db.metadata.get("retention")
    ]);
    return {
      pending,
      sending,
      delivered,
      retained,
      discarded: metadata?.discarded ?? 0,
      lastRotationAt: metadata?.lastRotationAt ?? null
    };
  }
  async list(options = {}) {
    const limit = Math.max(1, Math.min(TELEMETRY_HARD_LIMIT, Math.floor(options.limit ?? 50)));
    return this.db.events.orderBy("id").reverse().filter((row) => (!options.providerId || (row.providerId ?? "application") === options.providerId) && (options.beforeId === void 0 || (row.id ?? 0) < options.beforeId)).limit(limit).toArray();
  }
  async prune(maxEvents = this.maxEvents, maxAgeMs = 7 * 864e5, now = Date.now()) {
    if (!Number.isSafeInteger(maxEvents) || maxEvents < 1 || maxEvents > MAX_EVENTS || !Number.isSafeInteger(maxAgeMs) || maxAgeMs < 864e5 || !Number.isSafeInteger(now) || now < 0)
      throw Error("Invalid telemetry rotation policy");
    return this.db.transaction("rw", this.db.events, this.db.metadata, async () => {
      const rows = await this.db.events.orderBy("id").toArray();
      const eligible = rows.filter((row) => row.state !== "sending" || row.leaseUntil <= now);
      const ids = new Set(eligible.filter((row) => row.timestamp < now - maxAgeMs).map((row) => row.id).filter((id2) => id2 !== void 0));
      let excess = Math.max(0, rows.length - ids.size - maxEvents);
      for (const row of eligible) {
        if (!excess)
          break;
        if (row.id !== void 0 && !ids.has(row.id)) {
          ids.add(row.id);
          excess--;
        }
      }
      await this.db.events.bulkDelete([...ids]);
      const prior = await this.db.metadata.get("retention");
      await this.db.metadata.put({
        key: "retention",
        discarded: (prior?.discarded ?? 0) + ids.size,
        lastRotationAt: now
      });
      return ids.size;
    });
  }
  async readConfiguration() {
    return (await this.db.metadata.get("configuration"))?.configuration;
  }
  async writeConfiguration(configuration) {
    await this.db.metadata.put({ key: "configuration", configuration });
  }
  async readDeliveryStatus() {
    return (await this.db.metadata.get("delivery"))?.delivery;
  }
  async writeDeliveryStatus(delivery) {
    await this.db.metadata.put({ key: "delivery", delivery });
  }
  async clear() {
    await this.db.transaction("rw", this.db.events, this.db.metadata, async () => {
      await this.db.events.clear();
      await this.db.metadata.delete("retention");
    });
  }
  close() {
    this.db.close();
  }
}
function asTelemetryPort(scope, emitter) {
  assertServiceScope(scope);
  if (emitter.scope !== `${scope.productId}:${scope.channel}`)
    throw new Error("Telemetry emitter product/channel mismatch");
  return {
    scope,
    get available() {
      return emitter.available();
    },
    get enabled() {
      return emitter.isEnabled();
    },
    async emit(name, count, durationMs) {
      if (!isScopedTelemetryName(name))
        return;
      await emitter.record(name, count, durationMs);
    }
  };
}
class TelemetryPermissionRequired extends Error {
}
class TelemetryCollectorRejected extends Error {
}
async function sendOtlpRequest(request) {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 15e3);
  try {
    const response = await fetch(request.url, {
      method: "POST",
      credentials: "omit",
      redirect: "error",
      signal: request.signal ? AbortSignal.any([controller.signal, request.signal]) : controller.signal,
      headers: request.headers,
      body: request.body
    });
    if (response.status !== 200) {
      if ([429, 502, 503, 504].includes(response.status))
        throw new Error("OTLP collector did not acknowledge batch");
      throw new TelemetryCollectorRejected("OTLP collector did not acknowledge batch");
    }
    const reader = response.body?.getReader(), parts = [];
    let size = 0;
    if (reader)
      try {
        while (true) {
          const next = await reader.read();
          if (next.done)
            break;
          size += next.value.byteLength;
          if (size > 65536)
            throw new TelemetryCollectorRejected("Invalid OTLP acknowledgement");
          parts.push(next.value);
        }
      } finally {
        await reader.cancel().catch(() => {
          return;
        });
        reader.releaseLock();
      }
    const bytes = new Uint8Array(size);
    let at = 0;
    for (const part of parts) {
      bytes.set(part, at);
      at += part.byteLength;
    }
    let acknowledgement;
    try {
      acknowledgement = new TextDecoder("utf-8", { fatal: true }).decode(bytes);
    } catch {
      throw new TelemetryCollectorRejected("Invalid OTLP acknowledgement");
    }
    validateOtlpAcknowledgement(response.status, acknowledgement);
  } finally {
    clearTimeout(timeout);
  }
}
function validateOtlpAcknowledgement(status, body) {
  if (status !== 200) {
    if ([429, 502, 503, 504].includes(status))
      throw Error("OTLP collector did not acknowledge batch");
    throw new TelemetryCollectorRejected("OTLP collector did not acknowledge batch");
  }
  if (!body.trim())
    throw new TelemetryCollectorRejected("Invalid OTLP acknowledgement");
  if (body.length > 65536)
    throw new TelemetryCollectorRejected("Invalid OTLP acknowledgement");
  let value;
  try {
    value = JSON.parse(body);
  } catch {
    throw new TelemetryCollectorRejected("Invalid OTLP acknowledgement");
  }
  if (!value || typeof value !== "object" || Array.isArray(value))
    throw new TelemetryCollectorRejected("Invalid OTLP acknowledgement");
  const response = value, partial = response.partialSuccess ?? response.partial_success;
  if (partial === void 0)
    return;
  if (!partial || typeof partial !== "object" || Array.isArray(partial))
    throw new TelemetryCollectorRejected("Invalid OTLP acknowledgement");
  const rejected = partial.rejectedLogRecords ?? partial.rejected_log_records ?? 0;
  if ((typeof rejected !== "number" || !Number.isSafeInteger(rejected) || rejected < 0) && (typeof rejected !== "string" || !/^\d+$/.test(rejected)))
    throw new TelemetryCollectorRejected("Invalid OTLP acknowledgement");
  if (BigInt(rejected) > 0n)
    throw new TelemetryCollectorRejected("Collector rejected records; queue retained locally");
}
function resolveOtlpLogsEndpoint(value) {
  let endpoint;
  try {
    endpoint = new URL(value.trim());
  } catch {
    throw Error("Invalid OTLP endpoint");
  }
  if (endpoint.protocol !== "https:" || endpoint.username || endpoint.password || endpoint.search || endpoint.hash || !endpoint.hostname)
    throw Error("OTLP transport requires an HTTPS endpoint without credentials or query");
  if (endpoint.pathname.endsWith("/v1/logs"))
    return endpoint.href;
  return new URL("v1/logs", endpoint.href.replace(/\/?$/, "/")).href;
}
function otlpValue(value) {
  return typeof value === "number" ? { intValue: String(value) } : { stringValue: value };
}
function scopedOtlpPayload(rows, scope, version) {
  assertServiceScope(scope);
  if (!/^\d+\.\d+\.\d+$/.test(version))
    throw Error("Invalid telemetry version");
  for (const row of rows)
    validateTechnicalTelemetryEntry(row);
  const byService = /* @__PURE__ */ new Map();
  for (const row of rows) {
    const bucket = byService.get(row.serviceId) ?? [];
    bucket.push(row);
    byService.set(row.serviceId, bucket);
  }
  return JSON.stringify({
    resourceLogs: [...byService.entries()].map(([serviceId, records]) => ({
      resource: {
        attributes: [
          ["service.name", serviceId],
          ["service.namespace", "koba"],
          ["service.version", version],
          ["service.product", scope.productId],
          ["deployment.environment", scope.channel]
        ].map(([key, value]) => ({ key, value: otlpValue(value ?? "") }))
      },
      scopeLogs: [
        {
          scope: { name: `koba.${scope.productId}.${scope.channel}`, version },
          logRecords: records.map((event) => ({
            timeUnixNano: String(BigInt(event.timestamp) * 1000000n),
            severityNumber: event.name.endsWith("failed") || event.name.endsWith("error") ? 17 : 9,
            severityText: event.name.endsWith("failed") || event.name.endsWith("error") ? "ERROR" : "INFO",
            body: { stringValue: event.name },
            attributes: [
              { key: "event.provider", value: otlpValue(event.providerId ?? "application") },
              ...event.errorClass ? [{ key: "error.type", value: otlpValue(event.errorClass) }] : [],
              ...event.count === void 0 ? [] : [{ key: "event.count", value: otlpValue(event.count) }],
              ...event.durationMs === void 0 ? [] : [{ key: "event.duration_ms", value: otlpValue(event.durationMs) }]
            ]
          }))
        }
      ]
    }))
  });
}
class ScopedOtlpService {
  journal;
  emitter;
  port;
  leaseOwner;
  sender;
  scope;
  version;
  timer;
  stopped = false;
  busy = false;
  inFlight;
  delivery = {
    state: "off",
    collectorRejected: false,
    lastSentAt: null,
    nextAttemptAt: null,
    retryDelayMs: 3e4
  };
  deliveryEpoch = 0;
  changed;
  checkpoint = Promise.resolve();
  constructor(options) {
    this.scope = assertServiceScope(options.scope);
    if (!/^\d+\.\d+\.\d+$/.test(options.version))
      throw Error("Invalid telemetry version");
    this.version = options.version;
    this.changed = options.changed;
    this.sender = options.sender ?? sendOtlpRequest;
    this.journal = options.journal ?? new DexieTelemetryJournal(this.scope);
    this.leaseOwner = crypto.randomUUID().replaceAll("-", "");
    this.emitter = new ScopedTelemetry(options.serviceId, `${this.scope.productId}:${this.scope.channel}`, {
      send: async (event) => {
        if (event.productId !== this.scope.productId || event.channel !== this.scope.channel)
          throw Error("Telemetry scope mismatch");
        await this.journal.append({
          serviceId: event.serviceId,
          name: event.name,
          timestamp: event.timestamp,
          ...event.count !== void 0 ? { count: event.count } : {},
          ...event.durationMs !== void 0 ? { durationMs: event.durationMs } : {},
          ...event.providerId !== void 0 ? { providerId: event.providerId } : {},
          ...event.errorClass !== void 0 ? { errorClass: event.errorClass } : {}
        });
      }
    });
    this.port = asTelemetryPort(this.scope, this.emitter);
  }
  setLocalEnabled(enabled) {
    this.emitter.setEnabled(enabled);
    if (!enabled)
      this.stopDelivery();
  }
  deliveryStatus() {
    return { ...this.delivery };
  }
  restoreDeliveryStatus(value) {
    if (!value || typeof value !== "object")
      return;
    const status = value;
    const timestamp = (v) => v === null || typeof v === "number" && Number.isSafeInteger(v) && v >= 0;
    if (![
      "off",
      "idle",
      "sending",
      "offline",
      "retrying",
      "permission-required",
      "collector-rejected"
    ].includes(status.state) || status.collectorRejected !== void 0 && typeof status.collectorRejected !== "boolean" || !timestamp(status.lastSentAt) || !timestamp(status.nextAttemptAt) || !Number.isSafeInteger(status.retryDelayMs) || status.retryDelayMs < 3e4 || status.retryDelayMs > 3e5)
      return;
    this.delivery = {
      state: status.state === "sending" ? "retrying" : status.state,
      collectorRejected: status.collectorRejected ?? status.state === "collector-rejected",
      lastSentAt: status.lastSentAt,
      nextAttemptAt: status.nextAttemptAt,
      retryDelayMs: status.retryDelayMs
    };
  }
  resetDeliveryStatus() {
    this.deliveryEpoch++;
    this.updateDelivery({
      state: "off",
      collectorRejected: false,
      lastSentAt: null,
      nextAttemptAt: null,
      retryDelayMs: 3e4
    });
  }
  persistDeliveryStatus() {
    return this.checkpoint;
  }
  updateDelivery(patch) {
    this.delivery = { ...this.delivery, ...patch };
    const snapshot = this.deliveryStatus();
    this.checkpoint = this.checkpoint.then(() => this.changed?.(snapshot)).then(() => {
      return;
    }, () => {
      return;
    });
  }
  async flush(connection) {
    if (!this.emitter.isEnabled() || !connection.enabled || this.busy || this.stopped || this.delivery.collectorRejected)
      return 0;
    const epoch = this.deliveryEpoch;
    const url = resolveOtlpLogsEndpoint(connection.endpoint);
    if (typeof navigator !== "undefined" && navigator.onLine === false) {
      const retryDelayMs = this.nextRetryDelay();
      this.updateDelivery({ state: "offline", retryDelayMs, nextAttemptAt: Date.now() + retryDelayMs });
      await this.persistDeliveryStatus();
      return 0;
    }
    this.busy = true;
    this.updateDelivery({ state: "sending", nextAttemptAt: null });
    let ids = [];
    try {
      const rows = await this.journal.claim(this.leaseOwner);
      ids = rows.map((x) => x.id).filter((id2) => id2 !== void 0);
      if (rows.length === 0) {
        this.updateDelivery({ state: "idle", retryDelayMs: 3e4 });
        return 0;
      }
      if (epoch !== this.deliveryEpoch || this.stopped || !this.emitter.isEnabled()) {
        await this.journal.release(this.leaseOwner, ids);
        return 0;
      }
      this.inFlight = new AbortController();
      await this.persistDeliveryStatus();
      await this.sender({
        url,
        headers: { "content-type": "application/json", accept: "application/json" },
        body: scopedOtlpPayload(rows, this.scope, this.version),
        signal: this.inFlight.signal
      });
      if (epoch !== this.deliveryEpoch || this.stopped || !this.emitter.isEnabled()) {
        await this.journal.release(this.leaseOwner, ids);
        return 0;
      }
      const delivered = await this.journal.acknowledge(this.leaseOwner, ids);
      this.updateDelivery({
        state: this.stopped ? "off" : "idle",
        lastSentAt: Date.now(),
        retryDelayMs: 3e4
      });
      return delivered;
    } catch (error) {
      if (ids.length)
        await this.journal.release(this.leaseOwner, ids).catch(() => {
          return;
        });
      if (epoch !== this.deliveryEpoch)
        return 0;
      const retryDelayMs = this.nextRetryDelay();
      const rejected = error instanceof TelemetryCollectorRejected;
      this.updateDelivery({
        state: this.stopped ? "off" : rejected ? "collector-rejected" : error instanceof TelemetryPermissionRequired ? "permission-required" : "retrying",
        collectorRejected: rejected,
        retryDelayMs,
        nextAttemptAt: this.stopped || rejected ? null : Date.now() + retryDelayMs
      });
      return 0;
    } finally {
      this.busy = false;
      this.inFlight = void 0;
      await this.persistDeliveryStatus();
    }
  }
  startDelivery(getConnection) {
    this.stopped = false;
    if (this.delivery.collectorRejected) {
      this.updateDelivery({ state: "collector-rejected", nextAttemptAt: null });
      return;
    }
    if (this.timer !== void 0)
      return;
    const epoch = this.deliveryEpoch;
    if (this.delivery.state === "off")
      this.updateDelivery({ state: "idle" });
    let delay = this.delivery.nextAttemptAt === null ? this.delivery.retryDelayMs : Math.max(0, this.delivery.nextAttemptAt - Date.now());
    const cycle = async () => {
      if (this.stopped)
        return;
      try {
        const connection = await getConnection();
        if (this.stopped || epoch !== this.deliveryEpoch)
          return;
        if (connection.enabled && this.emitter.isEnabled()) {
          await this.flush(connection);
          delay = this.delivery.retryDelayMs;
        }
      } catch {
        if (this.stopped || epoch !== this.deliveryEpoch)
          return;
        delay = this.nextRetryDelay();
        this.updateDelivery({ state: "retrying", retryDelayMs: delay });
      }
      if (!this.stopped && epoch === this.deliveryEpoch && !this.delivery.collectorRejected) {
        this.updateDelivery({ nextAttemptAt: Date.now() + delay });
        this.timer = setTimeout(() => {
          this.timer = void 0;
          cycle();
        }, delay);
      }
    };
    this.updateDelivery({ nextAttemptAt: Date.now() + delay });
    this.timer = setTimeout(() => {
      this.timer = void 0;
      cycle();
    }, delay);
  }
  stopDelivery() {
    this.deliveryEpoch++;
    this.stopped = true;
    if (this.timer !== void 0)
      clearTimeout(this.timer);
    this.timer = void 0;
    this.inFlight?.abort();
    this.updateDelivery({ state: "off", nextAttemptAt: null });
  }
  nextRetryDelay() {
    return Math.min(3e5, Math.max(3e4, Math.round(this.delivery.retryDelayMs * 2 * (0.8 + Math.random() * 0.4))));
  }
  close() {
    this.stopDelivery();
    this.journal.close();
  }
}
var MESSAGE = "koba:application-telemetry";
var EMPTY_STATUS = {
  available: false,
  localEnabled: false,
  remoteAvailable: false,
  remoteEnabled: false,
  pending: null,
  discarded: null,
  retained: null,
  delivered: null,
  deliveryState: "unavailable",
  lastSentAt: null,
  nextAttemptAt: null,
  lastRotationAt: null,
  providers: []
};
function createChromiumTelemetryClient(scope) {
  const listeners = /* @__PURE__ */ new Set();
  let closed = false;
  let poll;
  let lastStatus = "";
  let configuration = null;
  async function request(command, value) {
    if (closed)
      throw Error("Telemetry connection closed");
    const result = await chrome.runtime.sendMessage({
      type: MESSAGE,
      scope,
      command,
      value
    });
    if (!result?.ok)
      throw Error(result?.error || "Сервис телеметрии недоступен.");
    return result.value;
  }
  async function changed() {
    for (const listener of listeners) {
      try {
        listener();
      } catch {
      }
    }
  }
  return {
    async status() {
      try {
        return await request("status");
      } catch {
        return { ...EMPTY_STATUS };
      }
    },
    async configuration() {
      configuration = await request("configuration");
      return configuration;
    },
    async configure(value) {
      await request("configure", value);
      configuration = await request("configuration");
      await changed();
    },
    probeEndpoint: (endpoint) => request("probe", endpoint),
    async setLocalEnabled(value) {
      await request("local", value);
      await changed();
    },
    async setRemoteEnabled(value) {
      await request("remote", { enabled: value, endpoint: configuration?.endpoint ?? "" });
      await changed();
    },
    records: (value) => request("records", value),
    exportRecords: (value) => request("export", value),
    async clearRecords() {
      await request("clear");
      await changed();
    },
    flush: () => request("flush"),
    async record(name, count, durationMs, context) {
      try {
        await request("record", { name, count, durationMs, context });
      } catch {
      }
      await changed();
    },
    subscribe(listener) {
      listeners.add(listener);
      if (poll === void 0)
        poll = setInterval(() => {
          request("status").then((status) => {
            const next = JSON.stringify(status);
            if (next !== lastStatus) {
              lastStatus = next;
              changed();
            }
          }).catch(() => {
            return;
          });
        }, 3e3);
      return () => {
        listeners.delete(listener);
        if (!listeners.size && poll !== void 0) {
          clearInterval(poll);
          poll = void 0;
        }
      };
    },
    close() {
      closed = true;
      listeners.clear();
      if (poll !== void 0)
        clearInterval(poll);
    }
  };
}
function installApplicationTelemetryBackground(scope = instanceScope()) {
  if (!isDevelopmentContextAllowed("chromium", scope))
    return () => {
      return;
    };
  const prefix = `koba-browser:${scope}:`;
  const store = {
    async get(key) {
      return (await chrome.storage.local.get(prefix + key))[prefix + key] === true;
    },
    async set(key, value) {
      await chrome.storage.local.set({ [prefix + key]: value });
    }
  };
  const controller = createApplicationTelemetry("chromium", store, scope, void 0, {
    local: true
  });
  const alarmName = `${MESSAGE}:${scope}`;
  async function syncAlarm() {
    if ((await controller.status()).localEnabled)
      await chrome.alarms.create(alarmName, { periodInMinutes: 1 });
    else
      await chrome.alarms.clear(alarmName);
  }
  const listener = (message, sender, respond) => {
    if (message?.type !== MESSAGE)
      return;
    if (sender.id !== chrome.runtime.id || message.scope !== scope) {
      respond({ ok: false, error: "Telemetry scope mismatch" });
      return;
    }
    const remote = message.command === "remote" && message.value && typeof message.value === "object" ? message.value : null;
    let permissionAction = null;
    const probeEndpoint = message.command === "probe" && typeof message.value === "string" ? message.value : null;
    const permissionEndpoint = probeEndpoint ?? (remote?.enabled === true && typeof remote.endpoint === "string" ? remote.endpoint : null);
    if (permissionEndpoint !== null) {
      try {
        const origin = new URL(resolveOtlpLogsEndpoint(permissionEndpoint)).origin;
        permissionAction = chrome.permissions.request({ origins: [`${origin}/*`] }).catch(() => false);
      } catch {
        permissionAction = Promise.resolve(false);
      }
    }
    (async () => {
      try {
        let value;
        switch (message.command) {
          case "status":
            value = await controller.status();
            break;
          case "configuration":
            value = await controller.configuration();
            break;
          case "configure":
            await controller.configure(validateTelemetryConfiguration(message.value));
            break;
          case "probe":
            if (!probeEndpoint || !permissionAction || !await permissionAction)
              value = { ok: false, endpoint: probeEndpoint ?? "", errorCode: "permission" };
            else
              value = await controller.probeEndpoint?.(probeEndpoint);
            break;
          case "local":
            if (typeof message.value !== "boolean")
              throw Error();
            await controller.setLocalEnabled(message.value);
            break;
          case "remote": {
            if (!remote || typeof remote.enabled !== "boolean" || typeof remote.endpoint !== "string")
              throw Error();
            if (remote.enabled) {
              if (!permissionAction || !await permissionAction || (await controller.configuration()).endpoint !== resolveOtlpLogsEndpoint(remote.endpoint))
                throw Error();
            }
            await controller.setRemoteEnabled(remote.enabled);
            break;
          }
          case "records": {
            const query = message.value && typeof message.value === "object" ? message.value : {};
            value = await controller.records(query);
            break;
          }
          case "export":
            if (message.value !== void 0 && !isTelemetryProviderId(message.value))
              throw Error();
            value = await controller.exportRecords(message.value);
            break;
          case "clear":
            await controller.clearRecords();
            break;
          case "flush":
            value = await controller.flush();
            break;
          case "record": {
            const v = message.value;
            if (!v?.name || !isScopedTelemetryName(v.name))
              throw Error();
            await controller.record(v.name, v.count, v.durationMs, v.context);
            break;
          }
          default:
            throw Error();
        }
        if (["local", "remote", "configure"].includes(message.command))
          await syncAlarm();
        respond({ ok: true, value });
      } catch {
        respond({
          ok: false,
          error: "Не удалось выполнить действие телеметрии. Проверьте параметры и разрешение endpoint."
        });
      }
    })();
    return true;
  };
  chrome.runtime.onMessage.addListener(listener);
  syncAlarm().catch(() => {
    return;
  });
  const onAlarm = (alarm) => {
    if (alarm.name !== alarmName)
      return;
    controller.status().then((status) => status.remoteEnabled && (status.nextAttemptAt === null || status.nextAttemptAt <= Date.now()) ? controller.flush() : void 0).catch(() => {
      return;
    });
  };
  chrome.alarms.onAlarm.addListener(onAlarm);
  return () => {
    chrome.runtime.onMessage.removeListener(listener);
    chrome.alarms.onAlarm.removeListener(onAlarm);
    chrome.alarms.clear(alarmName);
    controller.close();
  };
}
var OPT_IN_KEY = "telemetry.local.enabled";
var DEFAULT_TELEMETRY_CONFIGURATION = {
  schemaVersion: 1,
  remoteEnabled: false,
  endpoint: "",
  maxEvents: 5e3,
  maxAgeDays: 7,
  rotationMinutes: 5
};
function validateTelemetryConfiguration(value) {
  if (!value || typeof value !== "object" || Array.isArray(value))
    throw Error("Некорректные параметры телеметрии.");
  const v = value;
  if (Object.keys(v).some((key) => ![
    "schemaVersion",
    "remoteEnabled",
    "endpoint",
    "maxEvents",
    "maxAgeDays",
    "rotationMinutes"
  ].includes(key)) || v.schemaVersion !== 1 || typeof v.remoteEnabled !== "boolean" || typeof v.endpoint !== "string" || typeof v.maxEvents !== "number" || !Number.isSafeInteger(v.maxEvents) || v.maxEvents < 100 || v.maxEvents > 5e3 || typeof v.maxAgeDays !== "number" || !Number.isSafeInteger(v.maxAgeDays) || v.maxAgeDays < 1 || v.maxAgeDays > 90 || typeof v.rotationMinutes !== "number" || !Number.isSafeInteger(v.rotationMinutes) || v.rotationMinutes < 1 || v.rotationMinutes > 60)
    throw Error("Проверьте лимит (100–5000), срок (1–90 дней) и интервал (1–60 минут).");
  const endpoint = v.endpoint.trim() ? resolveOtlpLogsEndpoint(v.endpoint) : "";
  if (v.remoteEnabled && !endpoint)
    throw Error("Для внешней телеметрии нужен HTTPS endpoint.");
  return {
    schemaVersion: 1,
    remoteEnabled: v.remoteEnabled,
    endpoint,
    maxEvents: v.maxEvents,
    maxAgeDays: v.maxAgeDays,
    rotationMinutes: v.rotationMinutes
  };
}
function safeRecord(row) {
  if (row.id === void 0 || !isScopedTelemetryName(row.name))
    return null;
  return {
    id: row.id,
    name: row.name,
    timestamp: row.timestamp,
    providerId: isTelemetryProviderId(row.providerId) ? row.providerId : "application",
    state: row.state,
    attempts: row.attempts,
    ...row.count === void 0 ? {} : { count: row.count },
    ...row.durationMs === void 0 ? {} : { durationMs: row.durationMs },
    ...isTelemetryErrorClass(row.errorClass) ? { errorClass: row.errorClass } : {}
  };
}
function createApplicationTelemetry(target, store, scopeId = instanceScope(), journal, options = {}) {
  if (!options.local && typeof document !== "undefined")
    return createChromiumTelemetryClient(scopeId);
  const match = /^(vk-booster|chatgpt-booster|all-in-one):(dev|prod)$/.exec(scopeId);
  if (!match)
    throw Error("Telemetry requires compiled product/channel identity");
  const productId = match[1] ?? "";
  const scope = {
    productId,
    channel: match[2],
    installationId: `${productId}-${target}`
  };
  const settings = store;
  const suppliedVersion = "0.5.25";
  const version = /^\d+\.\d+\.\d+$/.test(suppliedVersion) ? suppliedVersion : "0.0.0";
  const listeners = /* @__PURE__ */ new Set();
  let enabled = false;
  let closed = false;
  let configuration = { ...DEFAULT_TELEMETRY_CONFIGURATION };
  let rotation;
  let loading;
  let writes = Promise.resolve();
  const remoteAvailable = options.remoteAvailable ?? target === "chromium";
  const notify = () => {
    if (!closed)
      for (const listener of listeners) {
        try {
          listener();
        } catch {
        }
      }
  };
  const sender = options.sender ?? void 0 ?? sendOtlpRequest;
  const service = new ScopedOtlpService({
    scope,
    version,
    serviceId: productId === "vk-booster" ? "VK Booster Service" : productId === "chatgpt-booster" ? "ChatGPT Booster Service" : "Koba Browser Tools",
    ...{},
    changed: (delivery) => {
      notify();
      if (!closed)
        return service.journal.writeDeliveryStatus(delivery).catch(() => {
          return;
        });
    },
    sender: async (request) => {
      const current = await readConfiguration();
      if (closed || !await settings.get(OPT_IN_KEY) || !current.remoteEnabled || current.endpoint !== request.url)
        throw Error("Telemetry consent revoked");
      {
        const origin = new URL(request.url).origin;
        if (!await chrome.permissions.contains({ origins: [`${origin}/*`] }))
          throw new TelemetryPermissionRequired();
      }
      await sender(request);
    }
  });
  async function readConfiguration() {
    const saved = await service.journal.readConfiguration();
    return saved === void 0 ? { ...DEFAULT_TELEMETRY_CONFIGURATION } : validateTelemetryConfiguration(saved);
  }
  function scheduleRotation() {
    if (rotation !== void 0)
      clearTimeout(rotation);
    rotation = void 0;
    if (!enabled || closed)
      return;
    rotation = setTimeout(() => {
      rotation = void 0;
      (async () => {
        try {
          configuration = await readConfiguration();
          if (await settings.get(OPT_IN_KEY) === true)
            await service.journal.prune(configuration.maxEvents, configuration.maxAgeDays * 864e5);
        } catch {
        }
        notify();
        scheduleRotation();
      })();
    }, configuration.rotationMinutes * 6e4);
  }
  function syncDelivery() {
    if (enabled && configuration.remoteEnabled && remoteAvailable)
      service.startDelivery(async () => {
        configuration = await readConfiguration();
        const consent = await settings.get(OPT_IN_KEY) === true;
        if (!consent || !configuration.remoteEnabled)
          service.stopDelivery();
        return { enabled: consent && configuration.remoteEnabled, endpoint: configuration.endpoint };
      });
    else
      service.stopDelivery();
  }
  function initialize() {
    if (!loading)
      loading = (async () => {
        try {
          enabled = await settings.get(OPT_IN_KEY) === true;
          configuration = await readConfiguration();
          service.restoreDeliveryStatus(await service.journal.readDeliveryStatus());
        } catch {
          enabled = false;
          configuration = { ...DEFAULT_TELEMETRY_CONFIGURATION };
        }
        if (closed)
          return;
        service.setLocalEnabled(enabled);
        if (enabled) {
          try {
            const summary = await service.journal.summary();
            if (!summary.lastRotationAt || Date.now() - summary.lastRotationAt >= configuration.rotationMinutes * 6e4)
              await service.journal.prune(configuration.maxEvents, configuration.maxAgeDays * 864e5);
          } catch {
          }
        }
        scheduleRotation();
        syncDelivery();
        await service.persistDeliveryStatus();
        notify();
      })();
    return loading;
  }
  function mutate(work) {
    const next = writes.then(async () => {
      await initialize();
      if (closed)
        throw Error("Telemetry controller closed");
      await work();
      await service.persistDeliveryStatus();
      notify();
    });
    writes = next.catch(() => {
      return;
    });
    return next;
  }
  initialize();
  return {
    async status() {
      await initialize();
      if (!closed) {
        try {
          const currentEnabled = await settings.get(OPT_IN_KEY) === true;
          const currentConfiguration = await readConfiguration();
          const changed = currentEnabled !== enabled || JSON.stringify(configuration) !== JSON.stringify(currentConfiguration);
          enabled = currentEnabled;
          configuration = currentConfiguration;
          if (changed) {
            service.setLocalEnabled(enabled);
            scheduleRotation();
            syncDelivery();
          }
        } catch {
        }
      }
      let summary = null;
      if (!closed)
        try {
          summary = await service.journal.summary();
        } catch {
        }
      const delivery = service.deliveryStatus();
      await service.persistDeliveryStatus();
      return {
        available: !closed,
        localEnabled: !closed && enabled,
        remoteAvailable: !closed && remoteAvailable,
        remoteEnabled: !closed && enabled && configuration.remoteEnabled,
        pending: summary ? summary.pending + summary.sending : null,
        discarded: summary?.discarded ?? null,
        retained: summary?.retained ?? null,
        delivered: summary?.delivered ?? null,
        deliveryState: closed ? "unavailable" : delivery.state,
        lastSentAt: delivery.lastSentAt,
        nextAttemptAt: delivery.nextAttemptAt,
        lastRotationAt: summary?.lastRotationAt ?? null,
        providers: productId === "all-in-one" ? ["application", "vk-booster", "chatgpt-booster"] : ["application", productId]
      };
    },
    async configuration() {
      await initialize();
      return { ...configuration };
    },
    async probeEndpoint(candidate) {
      let endpoint;
      try {
        endpoint = resolveOtlpLogsEndpoint(candidate);
      } catch {
        return { ok: false, endpoint: candidate, errorCode: "configuration" };
      }
      if (closed || !remoteAvailable)
        return { ok: false, endpoint, errorCode: "unavailable" };
      try {
        if (options.requestPermission && !await options.requestPermission(endpoint))
          return { ok: false, endpoint, errorCode: "permission" };
        if (target === "chromium" && !await chrome.permissions.contains({ origins: [`${new URL(endpoint).origin}/*`] }))
          return { ok: false, endpoint, errorCode: "permission" };
        await sender({
          url: endpoint,
          headers: { "content-type": "application/json", accept: "application/json" },
          body: '{"resourceLogs":[]}'
        });
        return { ok: true, endpoint };
      } catch (error) {
        return {
          ok: false,
          endpoint,
          errorCode: error instanceof TelemetryCollectorRejected ? "rejected" : "network"
        };
      }
    },
    configure(next) {
      return mutate(async () => {
        const validated = validateTelemetryConfiguration(next);
        validated.remoteEnabled = configuration.remoteEnabled && validated.endpoint === configuration.endpoint;
        const endpointChanged = validated.endpoint !== configuration.endpoint;
        service.stopDelivery();
        await service.journal.writeConfiguration(validated);
        configuration = validated;
        if (endpointChanged)
          service.resetDeliveryStatus();
        scheduleRotation();
        syncDelivery();
      });
    },
    setLocalEnabled(next) {
      return mutate(async () => {
        if (!next)
          service.stopDelivery();
        await settings.set(OPT_IN_KEY, next);
        enabled = next;
        if (!next) {
          configuration = { ...configuration, remoteEnabled: false };
          await service.journal.writeConfiguration(configuration);
        }
        service.setLocalEnabled(next);
        scheduleRotation();
        syncDelivery();
      });
    },
    async setRemoteEnabled(next) {
      const permission = next && options.requestPermission ? options.requestPermission(configuration.endpoint).catch(() => false) : Promise.resolve(true);
      return mutate(async () => {
        if (next && (!enabled || !remoteAvailable || !configuration.endpoint))
          throw Error("Включите локальный сбор и задайте доступный HTTPS endpoint.");
        if (!await permission)
          throw Error("Разрешение браузера для endpoint не предоставлено.");
        service.stopDelivery();
        if (next)
          service.resetDeliveryStatus();
        configuration = { ...configuration, remoteEnabled: next };
        await service.journal.writeConfiguration(configuration);
        syncDelivery();
      });
    },
    async records(query = {}) {
      await initialize();
      if (closed)
        return [];
      if (query.providerId !== void 0 && !isTelemetryProviderId(query.providerId))
        throw Error("Invalid telemetry provider");
      const rows = await service.journal.list({
        ...query,
        limit: Math.min(100, Math.max(1, query.limit ?? 50))
      });
      return rows.map(safeRecord).filter((row) => row !== null);
    },
    async exportRecords(providerId) {
      await initialize();
      if (closed || providerId !== void 0 && !isTelemetryProviderId(providerId))
        throw Error("Telemetry export unavailable");
      const rows = await service.journal.list({ providerId, limit: 1e4 });
      return JSON.stringify({
        schemaVersion: 1,
        productId,
        channel: scope.channel,
        exportedAt: Date.now(),
        events: rows.map(safeRecord).filter(Boolean)
      }, null, 2);
    },
    clearRecords() {
      return mutate(async () => {
        await service.journal.clear();
      });
    },
    async flush() {
      await initialize();
      if (!enabled || !configuration.remoteEnabled || !remoteAvailable || closed)
        return 0;
      syncDelivery();
      return service.flush({ enabled: true, endpoint: configuration.endpoint });
    },
    async record(name, count, durationMs, context) {
      try {
        await initialize();
        if (closed)
          return;
        const currentEnabled = await settings.get(OPT_IN_KEY) === true;
        if (currentEnabled !== enabled) {
          enabled = currentEnabled;
          service.setLocalEnabled(enabled);
          scheduleRotation();
          syncDelivery();
        }
        if (!enabled)
          return;
        const providerId = context?.providerId ?? (productId === "all-in-one" ? "application" : productId);
        if (providerId !== "application" && productId !== "all-in-one" && providerId !== productId)
          return;
        await service.emitter.record(name, count, durationMs, { ...context, providerId });
        notify();
      } catch {
      }
    },
    subscribe(listener) {
      listeners.add(listener);
      return () => {
        listeners.delete(listener);
      };
    },
    close() {
      closed = true;
      enabled = false;
      if (rotation !== void 0)
        clearTimeout(rotation);
      service.close();
      listeners.clear();
    }
  };
}
new TextEncoder();
const TOKEN_KEY = "telemetryToken";
const SETTINGS_KEY = "settings";
const ANALYTICS_KEY = "analyticsTransportLifetime";
let settingsWriteQueue = Promise.resolve();
let analyticsWriteQueue = Promise.resolve();
let analyticsCounters;
let analyticsDirty = false;
let analyticsFlushTimer;
const ANALYTICS_FLUSH_INTERVAL_MS = 500;
function enqueueSettingsWrite(work) {
  const result = settingsWriteQueue.then(work, work);
  settingsWriteQueue = result.then(
    () => void 0,
    () => void 0
  );
  return result;
}
function enqueueAnalyticsWrite(work) {
  const result = analyticsWriteQueue.then(work, work);
  analyticsWriteQueue = result.then(
    () => void 0,
    () => void 0
  );
  return result;
}
async function replaceSettings(settings) {
  return await enqueueSettingsWrite(async () => {
    const normalized = normalizeSettings(settings);
    await chrome.storage.local.set({ [SETTINGS_KEY]: normalized });
    return normalized;
  });
}
async function updateSettings(patch) {
  return await enqueueSettingsWrite(async () => {
    const stored = await chrome.storage.local.get(SETTINGS_KEY);
    const next = mergeSettings(stored[SETTINGS_KEY], patch);
    await chrome.storage.local.set({ [SETTINGS_KEY]: next });
    return next;
  });
}
async function readAnalytics() {
  if (analyticsCounters) return { ...analyticsCounters };
  const stored = await chrome.storage.local.get(ANALYTICS_KEY);
  analyticsCounters = {
    ...EMPTY_TRANSPORT_COUNTERS,
    ...stored[ANALYTICS_KEY]
  };
  return { ...analyticsCounters };
}
async function flushAnalytics() {
  if (analyticsFlushTimer) {
    clearTimeout(analyticsFlushTimer);
    analyticsFlushTimer = void 0;
  }
  if (!analyticsDirty || !analyticsCounters) return;
  analyticsDirty = false;
  await chrome.storage.local.set({ [ANALYTICS_KEY]: { ...analyticsCounters } });
}
function scheduleAnalyticsFlush() {
  if (analyticsFlushTimer) return;
  analyticsFlushTimer = setTimeout(() => {
    analyticsFlushTimer = void 0;
    void enqueueAnalyticsWrite(flushAnalytics).catch((error) => {
      analyticsDirty = true;
      console.warn("[ChatGPT Booster] Analytics persistence failed", error);
      scheduleAnalyticsFlush();
    });
  }, ANALYTICS_FLUSH_INTERVAL_MS);
}
async function recordAnalyticsBatch(events) {
  return await enqueueAnalyticsWrite(async () => {
    let next = await readAnalytics();
    for (const event of events) next = applyTransportCounterEvent(next, event);
    analyticsCounters = next;
    if (events.length) {
      analyticsDirty = true;
      scheduleAnalyticsFlush();
    }
    return { ...next };
  });
}
async function recordAnalytics(event) {
  return await recordAnalyticsBatch([event]);
}
async function postTelemetry(message) {
  const settings = normalizeSettings(
    (await chrome.storage.local.get(SETTINGS_KEY))[SETTINGS_KEY]
  );
  const configuredEndpoint = settings.telemetry.endpoint.trim();
  if (!configuredEndpoint) throw new Error("Telemetry endpoint is not configured");
  const parsed = new URL(message.url);
  const configured = new URL(configuredEndpoint);
  if (parsed.protocol !== "https:" || parsed.origin !== configured.origin) {
    throw new Error("Telemetry origin does not match the configured endpoint");
  }
  const stored = await chrome.storage.local.get(TOKEN_KEY);
  const token = typeof stored[TOKEN_KEY] === "string" ? stored[TOKEN_KEY] : "";
  if (!token) throw new Error("Telemetry token is not configured");
  const response = await fetch(message.url, {
    method: "POST",
    headers: {
      "content-type": "application/json",
      authorization: `Bearer ${token}`
    },
    body: message.body
  });
  if (!response.ok) throw new Error(`Telemetry HTTP ${response.status}`);
  return { ok: true, status: response.status };
}
chrome.runtime.onMessage.addListener(
  (message, _sender, sendResponse) => {
    if (!message?.type?.startsWith("chatgpt-booster:")) return;
    const development = instanceScope().endsWith(":dev");
    if (!isDevelopmentContextAllowed()) {
      sendResponse({
        ok: false,
        granted: false,
        error: "Unsupported Browser Tools installation scope"
      });
      return false;
    }
    if (development && (message.type === "chatgpt-booster:telemetry-post" || message.type === "chatgpt-booster:telemetry-permission-check")) {
      sendResponse({ ok: false, granted: false, error: "Use application telemetry settings" });
      return false;
    }
    void (async () => {
      try {
        if (message.type === "chatgpt-booster:telemetry-permission-check") {
          const configured = normalizeSettings(
            (await chrome.storage.local.get(SETTINGS_KEY))[SETTINGS_KEY]
          ).telemetry.endpoint.trim();
          const origin = new URL(configured).origin;
          if (new URL(message.origin).origin !== origin || !origin.startsWith("https://"))
            throw new Error("Telemetry permission origin does not match settings");
          sendResponse({
            ok: true,
            granted: await chrome.permissions.contains({ origins: [`${origin}/*`] })
          });
          return;
        }
        if (message.type === "chatgpt-booster:settings-set") {
          sendResponse({ ok: true, settings: await replaceSettings(message.settings) });
          return;
        }
        if (message.type === "chatgpt-booster:settings-update") {
          sendResponse({ ok: true, settings: await updateSettings(message.patch) });
          return;
        }
        if (message.type === "chatgpt-booster:analytics-get") {
          sendResponse({ ok: true, counters: await readAnalytics() });
          return;
        }
        if (message.type === "chatgpt-booster:analytics-record") {
          sendResponse({ ok: true, counters: await recordAnalytics(message.event) });
          return;
        }
        if (message.type === "chatgpt-booster:analytics-record-batch") {
          sendResponse({ ok: true, counters: await recordAnalyticsBatch(message.events) });
          return;
        }
        const result = await postTelemetry(message);
        sendResponse(result);
      } catch (error) {
        sendResponse({
          ok: false,
          error: error instanceof Error ? error.message : "Background operation failed"
        });
      }
    })();
    return true;
  }
);
const CHATGPT_MATCH = "https://chatgpt.com/*";
const ownShellRootId = instanceKey("koba-browser-tools-root");
async function bootstrapExistingChatGptTabs() {
  if (!isDevelopmentContextAllowed()) return;
  const tabs = await chrome.tabs.query({ url: CHATGPT_MATCH });
  await Promise.all(
    tabs.filter((tab) => typeof tab.id === "number").map(async (tab) => {
      try {
        const [presence] = await chrome.scripting.executeScript({
          target: { tabId: tab.id },
          world: "ISOLATED",
          injectImmediately: true,
          // A separate PROD, DEV or aggregate root is NOT this extension.
          // Pass the build-owned root into the injected context explicitly:
          // executeScript serializes the function without module closures.
          func: (expectedRootId) => Boolean(document.getElementById(expectedRootId)),
          args: [ownShellRootId]
        });
        if (presence?.result === true) return;
        await chrome.scripting.executeScript({
          target: { tabId: tab.id },
          files: ["observer.js"],
          world: "MAIN",
          injectImmediately: true
        });
        await chrome.scripting.executeScript({
          target: { tabId: tab.id },
          files: ["content.js"],
          world: "ISOLATED",
          injectImmediately: true
        });
      } catch {
      }
    })
  );
}
chrome.runtime.onInstalled.addListener(() => {
  void bootstrapExistingChatGptTabs();
});
chrome.runtime.onStartup.addListener(() => {
  void bootstrapExistingChatGptTabs();
});
const installTelemetryBackground = installApplicationTelemetryBackground;
installTelemetryBackground();
