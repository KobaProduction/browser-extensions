(function() {
  "use strict";
  function object$1(value) {
    return value !== null && typeof value === "object" && !Array.isArray(value) ? value : void 0;
  }
  function conversationRequestErrorCode(payload, status, fallback = "request_rejected") {
    const error = object$1(payload), nested = object$1(error?.error), detail = object$1(error?.detail);
    const code = error?.code ?? error?.error_code ?? nested?.code;
    if (code === "conversation_too_large" || code === "tokenless_resume_unavailable" || code === "persisted_final_available")
      return code;
    if (status === 413 && detail?.code === "conversation_length_exceeds_limit" && typeof detail.message === "string")
      return "conversation_too_large";
    return fallback;
  }
  const object = (value) => value !== null && typeof value === "object" && !Array.isArray(value) ? value : null;
  function fullSourceEnvelope(value) {
    const message = object(value.message) ?? (value.type === "input_message" ? object(value.input_message) : null);
    const author = object(message?.author), content = object(message?.content);
    return typeof message?.id === "string" && !!message.id.trim() && typeof author?.role === "string" && !!author.role.trim() && typeof content?.content_type === "string" && !!content.content_type.trim();
  }
  const forbidden = (key) => ["__proto__", "constructor", "prototype"].includes(key);
  const field = (value, short, long) => Object.hasOwn(value, short) ? value[short] : value[long];
  function applyNativeDelta(baseline, delta, depth = 0) {
    if (depth > 100) throw Error("Native delta nesting exceeds supported depth");
    const op = field(delta, "o", "op"), path = field(delta, "p", "path") ?? "";
    const replacement = field(delta, "v", "value");
    if (typeof path !== "string" || path.length > 1024 || !["add", "replace", "append", "remove", "patch", "truncate"].includes(String(op)))
      throw Error("Unsupported native delta operation");
    if (op !== "remove" && !Object.hasOwn(delta, "v") && !Object.hasOwn(delta, "value"))
      throw Error("Native delta value missing");
    const keys = path === "" ? [] : (path.startsWith("/") ? path.slice(1) : path).split("/").map((key2) => {
      if (/~(?![01])/.test(key2)) throw Error("Invalid native delta pointer");
      return key2.replace(/~1/g, "/").replace(/~0/g, "~");
    });
    if (keys.some(forbidden)) throw Error("Unsafe native delta pointer");
    const root = { value: baseline };
    let parent = root;
    let key = "value";
    for (const nextKey of keys) {
      let next = parent[key];
      if (next === void 0) {
        next = /^(0|[1-9]\d*)$/.test(nextKey) ? [] : {};
        parent[key] = next;
      }
      if (!next || typeof next !== "object") throw Error("Invalid native delta parent");
      parent = next;
      key = nextKey;
      if (Array.isArray(parent) && (!/^(0|[1-9]\d*)$/.test(key) || Number(key) > parent.length))
        throw Error("Invalid native delta array index");
    }
    const target = parent, current = target[key];
    if (op === "patch") {
      if (!Array.isArray(replacement)) throw Error("Invalid native patch list");
      let next = current;
      for (const item of replacement) {
        const patch = object(item);
        if (!patch) throw Error("Invalid native patch");
        next = applyNativeDelta(next, patch, depth + 1);
      }
      target[key] = next;
    } else if (op === "append") {
      if (typeof current === "string") {
        if (typeof replacement !== "string") throw Error("Invalid native text append");
        target[key] = current + replacement;
      } else if (Array.isArray(current)) {
        current.push(...structuredClone(Array.isArray(replacement) ? replacement : [replacement]));
      } else if (object(current) && object(replacement)) {
        const destination = current, addition = replacement;
        for (const name of Object.keys(addition)) {
          if (forbidden(name)) throw Error("Unsafe native object append");
          destination[name] = structuredClone(addition[name]);
        }
      } else target[key] = structuredClone(replacement);
    } else if (op === "truncate") {
      if (!Number.isSafeInteger(replacement) || Number(replacement) < 0 || typeof current !== "string" && !Array.isArray(current) || Number(replacement) > current.length)
        throw Error("Invalid native truncate");
      if (typeof current === "string") target[key] = current.substring(0, Number(replacement));
      else current.length = Number(replacement);
    } else if (op === "remove") {
      if (!Object.hasOwn(target, key)) throw Error("Missing native delta removal target");
      if (Array.isArray(parent)) parent.splice(Number(key), 1);
      else delete target[key];
    } else if (Array.isArray(parent) && op === "add")
      parent.splice(Number(key), 0, structuredClone(replacement));
    else target[key] = structuredClone(replacement);
    return root.value;
  }
  class ConversationStreamDecoder {
    baseline = null;
    poisoned = false;
    gapEvidence = [];
    deltaEncoding = null;
    previousDelta = { channel: 0, op: "add", path: "" };
    channelBaselines = /* @__PURE__ */ new Map();
    poisonedChannels = /* @__PURE__ */ new Set();
    hasGap() {
      return this.poisoned || this.poisonedChannels.size > 0;
    }
    markGap(input) {
      this.poisoned = true;
      this.gapEvidence.push({ kind: "source_patch_gap", source: structuredClone(input) });
    }
    takeGapEvidence() {
      const evidence = this.gapEvidence;
      this.gapEvidence = [];
      return evidence;
    }
    retainedBaseline() {
      if (this.deltaEncoding === "v1") {
        const baseline = this.channelBaselines.get(this.previousDelta.channel);
        return baseline ? structuredClone(baseline) : null;
      }
      return this.baseline ? structuredClone(this.baseline) : null;
    }
    decode(input, eventType) {
      if (eventType === "delta_encoding") {
        this.deltaEncoding = typeof input === "string" ? input : "unsupported";
        if (input !== "v1") this.markGap({ event: eventType, source: input });
        else {
          this.previousDelta = { channel: 0, op: "add", path: "" };
          this.channelBaselines.clear();
          this.poisonedChannels.clear();
          this.poisoned = false;
        }
        return null;
      }
      if (eventType === "delta") return this.decodeNativeDelta(input);
      if (this.deltaEncoding !== null) {
        const value2 = object(input);
        if (value2 && (object(value2.message) || value2.type === "input_message") && !fullSourceEnvelope(value2)) {
          this.markGap({ event: eventType ?? null, source: input });
          return null;
        }
        return value2 ? { payload: value2, evidence: value2 } : null;
      }
      const value = object(input);
      if (!value) {
        if (typeof input === "string" || Array.isArray(input)) this.markGap(input);
        return null;
      }
      if ([
        "safety_review_update",
        "conversation_async_status",
        "main_stream_complete",
        "message_stream_complete"
      ].includes(String(value.type)))
        return { payload: value, evidence: value };
      if (Object.hasOwn(value, "message") || value.type === "input_message") {
        if (!fullSourceEnvelope(value)) {
          this.markGap(input);
          return null;
        }
        this.poisoned = false;
        this.baseline = structuredClone(value);
        return { payload: value, evidence: value };
      }
      const nativePatch = typeof value.o === "string" && (typeof value.p === "string" || value.o === "patch");
      const patches = Array.isArray(value.patches) ? value.patches : value.o === "patch" && Array.isArray(value.v) ? value.v : nativePatch ? [value] : null;
      const root = object(value.v);
      if (root && (value.p === "" || value.p === void 0) && (value.o === void 0 || value.o === "add" || value.o === "replace")) {
        if (!fullSourceEnvelope(root)) {
          this.markGap(input);
          return null;
        }
        this.baseline = structuredClone(root);
        this.poisoned = false;
        return { payload: this.baseline, evidence: value };
      }
      if (!patches) {
        if (value.type === void 0 && value.v !== void 0) {
          this.markGap(input);
          return null;
        }
        return { payload: value, evidence: value };
      }
      const reject = () => {
        this.markGap(input);
        return null;
      };
      if (this.poisoned) return reject();
      let next = this.baseline ? structuredClone(this.baseline) : null;
      try {
        for (const candidate of patches) {
          const patch = object(candidate);
          if (!patch) return reject();
          const operation = patch.op ?? patch.o, path = patch.path ?? patch.p;
          const replacement = Object.hasOwn(patch, "value") ? patch.value : patch.v;
          if (typeof path !== "string" || path.length > 1024 || !["add", "replace", "append", "remove"].includes(String(operation)))
            return reject();
          if (path === "") {
            if (operation !== "add" && operation !== "replace") return reject();
            next = structuredClone(replacement);
            continue;
          }
          if (!path.startsWith("/") || !next) return reject();
          const keys = path.slice(1).split("/").map((key2) => key2.replace(/~1/g, "/").replace(/~0/g, "~"));
          if (keys.some((key2) => ["__proto__", "constructor", "prototype"].includes(key2))) return reject();
          let parent = next;
          for (const key2 of keys.slice(0, -1)) {
            if (!parent || typeof parent !== "object" || !Object.hasOwn(parent, key2)) return reject();
            parent = parent[key2];
          }
          if (!parent || typeof parent !== "object") return reject();
          const target = parent, key = keys.at(-1);
          if (key === void 0) return reject();
          if (Array.isArray(parent) && key !== "-" && (!/^(0|[1-9]\d*)$/.test(key) || Number(key) > parent.length || operation !== "add" && Number(key) >= parent.length))
            return reject();
          if (operation === "append") {
            if (typeof target[key] === "string" && typeof replacement === "string")
              target[key] += replacement;
            else if (Array.isArray(target[key]) && Array.isArray(replacement))
              target[key] = [...target[key], ...structuredClone(replacement)];
            else return reject();
          } else if (operation === "remove") {
            if (!Object.hasOwn(target, key)) return reject();
            if (Array.isArray(parent)) parent.splice(Number(key), 1);
            else delete target[key];
          } else if (Array.isArray(parent) && operation === "add")
            parent.splice(key === "-" ? parent.length : Number(key), 0, structuredClone(replacement));
          else {
            if (operation === "replace" && !Object.hasOwn(target, key)) return reject();
            target[key] = structuredClone(replacement);
          }
        }
        const result = object(next);
        if (!result || !fullSourceEnvelope(result)) return reject();
        this.baseline = result;
        return { payload: result, evidence: value };
      } catch {
        return reject();
      }
    }
    decodeNativeDelta(input) {
      const value = object(input);
      const evidence = { event: "delta", encoding: this.deltaEncoding, source: structuredClone(input) };
      if (this.deltaEncoding !== "v1" || !value) {
        this.markGap(evidence);
        return null;
      }
      const previous = this.previousDelta;
      const inherited = (short, fallback) => Object.hasOwn(value, short) ? value[short] : fallback;
      const channel = inherited("c", previous.channel);
      const path = inherited("p", previous.path);
      const op = inherited("o", previous.op);
      if (!Number.isSafeInteger(channel) || Number(channel) < 0 || typeof path !== "string" || typeof op !== "string") {
        this.markGap(evidence);
        return null;
      }
      const delta = {
        channel: Number(channel),
        path,
        op,
        ...Object.hasOwn(value, "v") || Object.hasOwn(value, "value") ? { value: field(value, "v", "value") } : {}
      };
      this.previousDelta = delta;
      const reject = () => {
        this.poisonedChannels.add(delta.channel);
        this.gapEvidence.push({ kind: "source_patch_gap", source: evidence });
        return null;
      };
      const fullRoot = delta.path === "" && (delta.op === "add" || delta.op === "replace");
      if (this.poisoned || this.poisonedChannels.has(delta.channel) && !fullRoot) return reject();
      try {
        const baseline = this.channelBaselines.get(delta.channel);
        const next = applyNativeDelta(
          baseline ? structuredClone(baseline) : void 0,
          delta
        );
        if (next === void 0 && delta.op === "remove" && delta.path === "") {
          this.channelBaselines.delete(delta.channel);
          return null;
        }
        const payload = object(next);
        if (!payload || (object(payload.message) || payload.type === "input_message") && !fullSourceEnvelope(payload))
          return reject();
        if (Object.hasOwn(payload, "message") && !object(payload.message) && payload.type !== "safety_review_update")
          return reject();
        this.channelBaselines.set(delta.channel, payload);
        if (fullRoot) this.poisonedChannels.delete(delta.channel);
        return { payload: structuredClone(payload), evidence };
      } catch {
        return reject();
      }
    }
  }
  const consumers = /* @__PURE__ */ new WeakMap();
  const bindings = /* @__PURE__ */ new WeakMap();
  function registerNativeAccountConsumer(target, consumer) {
    consumers.set(target, consumer);
    return () => {
      if (consumers.get(target) !== consumer) return;
      consumers.delete(target);
      bindings.get(target)?.controller.abort();
      bindings.delete(target);
    };
  }
  const TRANSPORT_BATCH_EVENT = "chatgpt-booster:transport-batch";
  const TRANSPORT_CONFIG_EVENT = "chatgpt-booster:transport-config";
  const observerScope = "all-in-one:dev";
  const observerTargetId = "chromium";
  const TRANSPORT_CHANNEL = "chatgpt-booster:transport:" + observerScope + (":" + observerTargetId);
  const ARCHIVE_POLICY_EVENT = "chatgpt-booster:archive-policy";
  const ARCHIVE_NETWORK_EVENT = "chatgpt-booster:archive-network";
  const ARCHIVE_CONTRACT_ERROR_EVENT = "chatgpt-booster:archive-native-contract-error";
  const CONVERSATION_REQUEST_EVENT = "chatgpt-booster:conversation-request";
  const CONVERSATION_STOP_EVENT = "chatgpt-booster:conversation-stop";
  const CONVERSATION_STREAM_STATUS_EVENT = "chatgpt-booster:conversation-stream-status";
  const CONVERSATION_STREAM_EVENT = "chatgpt-booster:conversation-stream";
  const CONVERSATION_CATALOG_EVENT = "chatgpt-booster:conversation-catalog";
  const CONVERSATION_ACCOUNT_EVENT = "chatgpt-booster:conversation-account";
  const ARCHIVE_ASSET_EVENT = "chatgpt-booster:archive-asset";
  const ARCHIVE_ASSET_FETCH_REQUEST_EVENT = "chatgpt-booster:archive-asset-fetch-request";
  const ARCHIVE_ASSET_FETCH_RESULT_EVENT = "chatgpt-booster:archive-asset-fetch-result";
  const ARCHIVE_ASSET_FETCH_CANCEL_EVENT = "chatgpt-booster:archive-asset-fetch-cancel";
  const DENY_ARCHIVE = {
    enabled: false,
    defaultEnabled: false,
    projects: {},
    conversations: {},
    manualConversationId: null,
    manualStartedAt: null
  };
  let archivePolicy = { ...DENY_ARCHIVE };
  const archiveProjects = /* @__PURE__ */ new Map();
  const archiveReads = /* @__PURE__ */ new Map();
  const bufferedInitialPages = /* @__PURE__ */ new Map();
  function pageConversationId(pathname = location.pathname) {
    const match = pathname.match(/(?:^|\/)c\/([^/?#]+)/);
    return match?.[1] ? decodeURIComponent(match[1]) : void 0;
  }
  function archiveProjectId(payload, conversationId) {
    const incoming = typeof payload.gizmo_id === "string" && payload.gizmo_id.startsWith("g-p-") ? payload.gizmo_id : null;
    return "gizmo_id" in payload ? incoming : archiveProjects.get(conversationId) ?? null;
  }
  function publishConversationPage(detail) {
    if (!observerTarget) return;
    const projectId = archiveProjectId(detail.payload, detail.conversationId);
    if (!captureAllowed(detail.conversationId, projectId)) return;
    archiveProjects.set(detail.conversationId, projectId);
    observerTarget.postMessage(
      { channel: TRANSPORT_CHANNEL, type: ARCHIVE_EVENT, detail },
      observerTarget.location.origin
    );
  }
  function publishPreloadPage(detail) {
    if (!observerTarget || pageConversationId() !== detail.conversationId) return;
    observerTarget.postMessage(
      { channel: TRANSPORT_CHANNEL, type: ARCHIVE_PRELOAD_EVENT, detail },
      observerTarget.location.origin
    );
  }
  function beginArchiveRequest(sourceUrl, requestId, accountId, accountEpoch) {
    const id = conversationHistoryId(sourceUrl);
    if (!id) return void 0;
    const url = new URL(
      sourceUrl,
      typeof location === "undefined" ? "https://chatgpt.com/" : location.href
    );
    const isInitial = !url.pathname.endsWith("/messages");
    if (isInitial) archiveReads.set(id, { readId: requestId, readStartedAt: Date.now() });
    const read = archiveReads.get(id) ?? { readId: requestId, readStartedAt: Date.now() };
    if (archiveReads.size > 128) {
      const oldest = archiveReads.keys().next().value;
      if (oldest) {
        archiveReads.delete(oldest);
        archiveProjects.delete(oldest);
      }
    }
    return {
      ...read,
      isInitial,
      requestedBefore: url.searchParams.get("before"),
      accountId,
      accountEpoch
    };
  }
  function captureAllowed(id, projectId) {
    return archivePolicy.manualConversationId === id || archivePolicy.enabled && (archivePolicy.conversations[id] ?? (projectId ? archivePolicy.projects[projectId] : void 0) ?? archivePolicy.defaultEnabled);
  }
  function shouldObserveArchiveConversation(id) {
    if (pageConversationId() === id || archivePolicy.manualConversationId === id) return true;
    if (!archivePolicy.enabled) return false;
    const conversationRule = archivePolicy.conversations[id];
    if (conversationRule !== void 0) return conversationRule;
    if (archiveProjects.has(id)) return captureAllowed(id, archiveProjects.get(id) ?? null);
    return archivePolicy.defaultEnabled || Object.values(archivePolicy.projects).some(Boolean);
  }
  function conversationStreamStatusTarget(sourceUrl) {
    try {
      const url = new URL(sourceUrl, "https://chatgpt.com/");
      if (url.origin !== "https://chatgpt.com") return null;
      const match = url.pathname.match(/^\/backend-api\/conversation\/([^/]+)\/stream_status$/);
      return match?.[1] ? decodeURIComponent(match[1]) : null;
    } catch {
      return null;
    }
  }
  function isConversationStreamStatusUrl(sourceUrl) {
    return conversationStreamStatusTarget(sourceUrl) !== null;
  }
  function normalizeConversationStreamStatus(value) {
    if (typeof value !== "string") return null;
    const normalized = value.trim().toUpperCase();
    return ["IS_STREAMING", "COMPLETE", "FAILURE", "UNAVAILABLE"].includes(normalized) ? normalized : null;
  }
  function conversationStreamStatusFromPayload(sourceUrl, payload, observedAt, httpStatus) {
    const conversationId = conversationStreamStatusTarget(sourceUrl);
    if (!conversationId) return null;
    const record = requestPayload(payload);
    const status = httpStatus === 404 ? "UNAVAILABLE" : normalizeConversationStreamStatus(record?.status);
    if (!status) return null;
    return { conversationId, status, observedAt, httpStatus };
  }
  function publishConversationStreamStatus(detail) {
    if (!observerTarget || !detail) return;
    observerTarget.postMessage(
      { channel: TRANSPORT_CHANNEL, type: CONVERSATION_STREAM_STATUS_EVENT, detail },
      observerTarget.location.origin
    );
  }
  function observeConversationStreamStatusResponse(response, sourceUrl, requestId) {
    if (!isConversationStreamStatusUrl(sourceUrl)) return;
    const observedAt = Date.now();
    if (response.status === 404) {
      const detail = conversationStreamStatusFromPayload(sourceUrl, null, observedAt, response.status);
      publishConversationStreamStatus(detail ? { ...detail, ...requestId ? { requestId } : {} } : null);
      return;
    }
    void response.clone().json().then((payload) => {
      const detail = conversationStreamStatusFromPayload(sourceUrl, payload, observedAt, response.status);
      publishConversationStreamStatus(detail ? { ...detail, ...requestId ? { requestId } : {} } : null);
    }).catch(() => void 0);
  }
  function publishConversationStream(detail) {
    if (!observerTarget || !detail) return;
    observerTarget.postMessage(
      { channel: TRANSPORT_CHANNEL, type: CONVERSATION_STREAM_EVENT, detail },
      observerTarget.location.origin
    );
  }
  function conversationStreamEventFromPayload(payload, fallbackConversationId, observedAt) {
    const value = requestPayload(payload);
    if (!value) return null;
    const conversationId = typeof value.conversation_id === "string" ? value.conversation_id : fallbackConversationId;
    if (value.type === "stream_handoff" && typeof value.conversation_id === "string" && value.conversation_id.trim())
      return { conversationId: value.conversation_id, kind: "handoff", observedAt };
    if (typeof value.error === "string" && value.error.trim()) {
      const errorCode = typeof value.error_code === "string" && value.error_code.trim() ? value.error_code : null;
      const errorReason = typeof value.error_reason === "string" && value.error_reason.trim() ? value.error_reason : null;
      const canRetry = typeof value.can_retry === "boolean" ? value.can_retry : null;
      return {
        conversationId,
        kind: "error",
        errorCode,
        errorReason,
        canRetry,
        observedAt
      };
    }
    const directMessage = conversationMessageRecord(value.message);
    if (directMessage) return { conversationId, kind: "message", record: directMessage, observedAt };
    if (value.type === "input_message") {
      const inputMessage = conversationMessageRecord(value.input_message);
      if (inputMessage) return { conversationId, kind: "message", record: inputMessage, observedAt };
    }
    if (value.type === "message_stream_complete")
      return { conversationId, kind: "complete", phase: "message", observedAt };
    if (value.type === "main_stream_complete")
      return { conversationId, kind: "complete", phase: "main", observedAt };
    if (value.type === "conversation_async_status") {
      const asyncStatus = value.async_status;
      if (asyncStatus === null || typeof asyncStatus === "number" || typeof asyncStatus === "string")
        return { conversationId, kind: "async-status", asyncStatus, observedAt };
      return null;
    }
    if (value.type === "safety_review_update") {
      if (typeof value.active !== "boolean") return null;
      const protectionType = value.protection_type === "bio" || value.protection_type === "cyber" ? value.protection_type : null;
      const message = typeof value.message === "string" && value.message.trim() ? value.message : null;
      return {
        conversationId,
        kind: "safety-review",
        active: value.active,
        protectionType,
        message,
        observedAt
      };
    }
    return null;
  }
  function observeConversationStreamResponse(response, conversationId, accountId, requestEpoch, currentEpoch, requestId, userMessageId, onConversationKnown) {
    if (!response.ok || !/event-stream/i.test(response.headers.get("content-type") ?? "")) return;
    const body = response.clone().body;
    if (!body) return;
    const reader = body.getReader();
    const decoder = new TextDecoder();
    let buffer = "";
    let nativeConversationId = conversationId;
    const sourceDecoder = new ConversationStreamDecoder();
    let terminalSeen = false;
    let handedOff = false;
    const publishRetainedGapEvidence = () => {
      const baseline = sourceDecoder.retainedBaseline();
      const normalized = baseline ? conversationStreamEventFromPayload(baseline, nativeConversationId, Date.now()) : null;
      if (normalized?.kind === "message" && requestEpoch === currentEpoch()) {
        publishConversationStream({
          ...normalized,
          accountId,
          requestId,
          userMessageId,
          evidence: sourceDecoder.takeGapEvidence()
        });
      }
    };
    void (async () => {
      try {
        while (true) {
          const { done, value } = await reader.read();
          if (requestEpoch !== currentEpoch()) break;
          if (done) {
            if (!terminalSeen && !handedOff)
              publishConversationStream({
                conversationId: nativeConversationId,
                kind: "error",
                errorCode: "stream_interrupted",
                errorReason: null,
                canRetry: true,
                observedAt: Date.now(),
                accountId,
                requestId,
                userMessageId
              });
            break;
          }
          buffer += decoder.decode(value, { stream: true });
          buffer = buffer.replace(/\r\n/g, "\n");
          let boundary = buffer.indexOf("\n\n");
          while (boundary >= 0) {
            const block = buffer.slice(0, boundary);
            buffer = buffer.slice(boundary + 2);
            const data = block.split("\n").filter((line) => line.startsWith("data:")).map((line) => line.slice(5).trimStart()).join("\n");
            const eventType = block.split("\n").filter((line) => line.startsWith("event:")).at(-1)?.slice(6).trim() ?? null;
            if (data === "[DONE]" && requestEpoch === currentEpoch()) {
              terminalSeen = true;
              if (!handedOff)
                publishConversationStream(
                  sourceDecoder.hasGap() ? {
                    conversationId: nativeConversationId,
                    kind: "error",
                    errorCode: "source_patch_gap",
                    errorReason: null,
                    canRetry: true,
                    observedAt: Date.now(),
                    accountId,
                    requestId,
                    userMessageId
                  } : {
                    conversationId: nativeConversationId,
                    kind: "complete",
                    phase: "main",
                    observedAt: Date.now(),
                    accountId,
                    requestId,
                    userMessageId
                  }
                );
            }
            if (data && data !== "[DONE]") {
              try {
                const decoded = eventType === "delta_encoding" && data === "v1" ? data : JSON.parse(data);
                const source = sourceDecoder.decode(decoded, eventType);
                if (!source && sourceDecoder.hasGap()) {
                  publishConversationStream({
                    conversationId: nativeConversationId,
                    kind: "error",
                    errorCode: "source_patch_gap",
                    errorReason: null,
                    canRetry: true,
                    observedAt: Date.now(),
                    accountId,
                    requestId,
                    userMessageId
                  });
                  publishRetainedGapEvidence();
                }
                const normalized = !source && sourceDecoder.hasGap() ? null : conversationStreamEventFromPayload(
                  source?.payload ?? decoded,
                  nativeConversationId,
                  Date.now()
                );
                if (normalized?.conversationId) {
                  nativeConversationId = normalized.conversationId;
                  onConversationKnown(
                    nativeConversationId,
                    normalized.kind === "message" ? normalized.record : void 0
                  );
                }
                if (normalized?.kind === "handoff") handedOff = true;
                if (normalized?.kind === "complete" && normalized.phase === "main" || normalized?.kind === "error" || normalized?.kind === "message" && requestPayload(normalized.record.author)?.role === "assistant" && (normalized.record.recipient === void 0 || normalized.record.recipient === null || normalized.record.recipient === "all") && (normalized.record.channel === void 0 || normalized.record.channel === null || normalized.record.channel === "final") && normalized.record.end_turn === true && normalized.record.status === "finished_successfully")
                  terminalSeen = true;
                if (!normalized) {
                  const value2 = requestPayload(decoded);
                  const sourceId = typeof value2?.conversation_id === "string" ? value2.conversation_id : nativeConversationId;
                  const expectedMessage = value2?.type === "input_message" || value2?.message !== void 0 && (value2?.type === void 0 || value2?.type === "message");
                  if (sourceId && expectedMessage && shouldObserveArchiveConversation(sourceId))
                    observerTarget?.postMessage(
                      {
                        channel: TRANSPORT_CHANNEL,
                        type: ARCHIVE_CONTRACT_ERROR_EVENT,
                        detail: { conversationId: sourceId, path: "stream.message" }
                      },
                      observerTarget.location.origin
                    );
                }
                if (requestEpoch === currentEpoch() && !(sourceDecoder.hasGap() && (normalized?.kind === "complete" || normalized?.kind === "async-status")))
                  publishConversationStream(
                    normalized ? {
                      ...normalized,
                      accountId,
                      requestId,
                      userMessageId,
                      ...normalized.kind === "message" && source ? { evidence: [...sourceDecoder.takeGapEvidence(), source.evidence] } : {}
                    } : null
                  );
              } catch {
                sourceDecoder.markGap({ unparsedSourceData: data });
                publishRetainedGapEvidence();
                if (requestEpoch === currentEpoch())
                  publishConversationStream({
                    conversationId: nativeConversationId,
                    kind: "error",
                    errorCode: "source_patch_gap",
                    errorReason: null,
                    canRetry: true,
                    observedAt: Date.now(),
                    accountId,
                    requestId,
                    userMessageId
                  });
              }
            }
            boundary = buffer.indexOf("\n\n");
          }
        }
      } catch {
        if (!terminalSeen && !handedOff && requestEpoch === currentEpoch())
          publishConversationStream({
            conversationId: nativeConversationId,
            kind: "error",
            errorCode: "stream_interrupted",
            errorReason: null,
            canRetry: true,
            observedAt: Date.now(),
            accountId,
            requestId,
            userMessageId
          });
      } finally {
        reader.releaseLock();
      }
    })();
  }
  function isConversationStopUrl(sourceUrl) {
    try {
      const url = new URL(sourceUrl, "https://chatgpt.com/");
      return url.origin === "https://chatgpt.com" && url.pathname === "/backend-api/stop_conversation";
    } catch {
      return false;
    }
  }
  function conversationIdFromBody(body) {
    const payload = requestPayload(body);
    return typeof payload?.conversation_id === "string" ? payload.conversation_id : null;
  }
  function conversationStopTargetFromBody(sourceUrl, method, body) {
    if (method.toUpperCase() !== "POST" || !isConversationStopUrl(sourceUrl)) return null;
    return conversationIdFromBody(body);
  }
  function publishConversationStop(detail) {
    if (!observerTarget || !detail) return;
    observerTarget.postMessage(
      { channel: TRANSPORT_CHANNEL, type: CONVERSATION_STOP_EVENT, detail },
      observerTarget.location.origin
    );
  }
  function isConversationRequestUrl(sourceUrl) {
    try {
      const url = new URL(sourceUrl, "https://chatgpt.com/");
      return url.origin === "https://chatgpt.com" && /^\/backend-api\/(?:f\/)?conversation$/.test(url.pathname);
    } catch {
      return false;
    }
  }
  function isConversationResumeUrl(sourceUrl) {
    try {
      const url = new URL(sourceUrl, "https://chatgpt.com/");
      return url.origin === "https://chatgpt.com" && url.pathname === "/backend-api/f/conversation/resume";
    } catch {
      return false;
    }
  }
  function sourceTimestampMs(value) {
    if (typeof value !== "number" || !Number.isFinite(value) || value <= 0) return null;
    return value < 1e10 ? value * 1e3 : value;
  }
  function conversationMessageRecord(value) {
    if (!value || typeof value !== "object" || Array.isArray(value)) return null;
    const record = value;
    const author = record.author;
    if (typeof record.id !== "string" || !author || typeof author !== "object" || Array.isArray(author) || typeof author.role !== "string" || !Object.hasOwn(record, "content"))
      return null;
    return record;
  }
  function requestPayload(value) {
    if (typeof value === "string") {
      try {
        const parsed = JSON.parse(value);
        return parsed && typeof parsed === "object" && !Array.isArray(parsed) ? parsed : null;
      } catch {
        return null;
      }
    }
    return value && typeof value === "object" && !Array.isArray(value) ? value : null;
  }
  function conversationRequestTimingFromBody(sourceUrl, method, body, observedAt) {
    if (method.toUpperCase() !== "POST" || !isConversationRequestUrl(sourceUrl)) return null;
    const payload = requestPayload(body);
    const messages = Array.isArray(payload?.messages) ? payload.messages : [];
    const user = [...messages].reverse().find((item) => {
      if (!item || typeof item !== "object" || Array.isArray(item)) return false;
      const author = item.author;
      return Boolean(
        author && typeof author === "object" && !Array.isArray(author) && author.role === "user"
      );
    });
    const sourceStartedAt = sourceTimestampMs(user?.create_time);
    const attribution = payload?.turn_attribution;
    const composer = !!attribution && typeof attribution === "object" && !Array.isArray(attribution) && attribution.turn_trigger === "composer";
    const effortPresent = !!payload && Object.hasOwn(payload, "thinking_effort");
    const selection = payload?.action === "next" && composer && typeof payload.conversation_id === "string" && payload.conversation_id && typeof user?.id === "string" && user.id && typeof payload.model === "string" && payload.model && (!effortPresent || typeof payload.thinking_effort === "string") && Number.isFinite(observedAt) ? {
      schema: SUBMISSION_SELECTION_SCHEMA,
      messageId: user.id,
      requestedModel: payload.model,
      thinkingEffort: effortPresent ? payload.thinking_effort : null,
      effortPresent,
      observedAtMs: observedAt,
      source: "native-composer-submit"
    } : void 0;
    const submission = payload?.action === "next" && composer && messages.length === 1 && typeof user?.id === "string" && user.id && typeof payload.parent_message_id === "string" && payload.parent_message_id && user.content && typeof user.content === "object" && !Array.isArray(user.content) ? { message: structuredClone(user), parentMessageId: payload.parent_message_id } : void 0;
    return {
      ...selection ? { submissionSelection: selection } : {},
      ...submission ? { submission } : {},
      ...payload?.action === "next" && composer && (!Object.hasOwn(payload, "conversation_id") || payload.conversation_id === null) && messages.length === 1 && typeof user?.id === "string" && user.id && typeof payload.parent_message_id === "string" && payload.parent_message_id && user.content && typeof user.content === "object" && !Array.isArray(user.content) ? {
        creation: {
          message: structuredClone(user),
          parentMessageId: payload.parent_message_id,
          ...typeof payload.gizmo_id === "string" && /^g-p-[A-Za-z0-9_-]+$/.test(payload.gizmo_id) && payload.gizmo_id.length <= 256 ? { projectId: payload.gizmo_id } : {}
        }
      } : {},
      conversationId: typeof payload?.conversation_id === "string" ? payload.conversation_id : null,
      userMessageId: typeof user?.id === "string" ? user.id : null,
      ...payload && Object.hasOwn(payload, "conversation_origin") ? {
        conversationOrigin: typeof payload.conversation_origin === "string" ? payload.conversation_origin : null
      } : {},
      startedAt: sourceStartedAt ?? observedAt,
      observedAt,
      source: sourceStartedAt ? "message_create_time" : "transport_request"
    };
  }
  function publishConversationRequest(detail, accountId) {
    if (!observerTarget || !detail) return;
    observerTarget.postMessage(
      {
        channel: TRANSPORT_CHANNEL,
        type: CONVERSATION_REQUEST_EVENT,
        detail: { ...detail, accountId }
      },
      observerTarget.location.origin
    );
  }
  function conversationCatalogProjectId(sourceUrl) {
    try {
      const url = new URL(sourceUrl, "https://chatgpt.com/");
      if (url.origin !== "https://chatgpt.com") return void 0;
      if (url.pathname === "/backend-api/conversations") return null;
      const match = url.pathname.match(/^\/backend-api\/gizmos\/([^/]+)\/conversations$/);
      return match?.[1] ? decodeURIComponent(match[1]) : void 0;
    } catch {
      return void 0;
    }
  }
  function isAccountCheckUrl(sourceUrl) {
    try {
      const url = new URL(sourceUrl, "https://chatgpt.com/");
      return url.origin === "https://chatgpt.com" && /^\/backend-api\/accounts\/check(?:\/[^/]+)?$/.test(url.pathname);
    } catch {
      return false;
    }
  }
  function isConversationCatalogUrl(sourceUrl) {
    return conversationCatalogProjectId(sourceUrl) !== void 0;
  }
  function nativeProjectDetailId(sourceUrl) {
    try {
      const url = new URL(sourceUrl, "https://chatgpt.com/");
      if (url.origin !== "https://chatgpt.com") return null;
      const match = url.pathname.match(/^\/backend-api\/gizmos\/([^/]+)$/);
      const id = match?.[1] ? decodeURIComponent(match[1]) : "";
      return id.startsWith("g-p-") && id.length > 4 && id.length <= 256 && !/[\s/?#]/.test(id) ? id : null;
    } catch {
      return null;
    }
  }
  function projectCatalogFromPayload(sourceUrl, payload, observedAt) {
    const id = nativeProjectDetailId(sourceUrl);
    const gizmo = requestPayload(requestPayload(payload)?.gizmo);
    const title = requestPayload(gizmo?.display)?.name;
    if (!id || gizmo?.id !== id || typeof title !== "string" || !title.trim() || title.length > 4096)
      return null;
    return { items: [], projects: [{ projectId: id, title }], observedAt };
  }
  function conversationCatalogFromPayload(sourceUrl, payload, observedAt) {
    const routeProjectId = conversationCatalogProjectId(sourceUrl);
    if (routeProjectId === void 0) return null;
    const value = requestPayload(payload);
    const items = Array.isArray(value?.items) ? value.items : [];
    const normalized = items.flatMap((item) => {
      const record = requestPayload(item);
      if (!record || typeof record.id !== "string") return [];
      const gizmoId = typeof record.gizmo_id === "string" && record.gizmo_id.startsWith("g-p-") ? record.gizmo_id : null;
      return [
        {
          conversationId: record.id,
          title: typeof record.title === "string" ? record.title : null,
          projectId: Object.hasOwn(record, "gizmo_id") ? gizmoId : routeProjectId,
          projectKnown: Object.hasOwn(record, "gizmo_id") || routeProjectId !== null,
          conversationOrigin: typeof record.conversation_origin === "string" ? record.conversation_origin : null
        }
      ];
    });
    return normalized.length ? { items: normalized, observedAt } : null;
  }
  function publishConversationCatalog(detail) {
    if (!observerTarget || !detail) return;
    observerTarget.postMessage(
      { channel: TRANSPORT_CHANNEL, type: CONVERSATION_CATALOG_EVENT, detail },
      observerTarget.location.origin
    );
  }
  function observeConversationCatalogResponse(response, sourceUrl, accountId, requestEpoch, currentEpoch, requestStartedAt) {
    const projectDetail = nativeProjectDetailId(sourceUrl) !== null;
    if (!response.ok || !isConversationCatalogUrl(sourceUrl) && !projectDetail) return;
    if (projectDetail && !accountId) return;
    const contentType = response.headers.get("content-type") ?? "";
    if (!/json/i.test(contentType)) return;
    void response.clone().json().then((payload) => {
      if (currentEpoch() !== requestEpoch) return;
      const detail = projectDetail ? projectCatalogFromPayload(sourceUrl, payload, Date.now()) : conversationCatalogFromPayload(sourceUrl, payload, Date.now());
      if (detail) publishConversationCatalog({ ...detail, accountId, requestStartedAt });
    }).catch(() => void 0);
  }
  function isArchiveObservedUrl(sourceUrl) {
    return sourceUrl.includes("/backend-api/conversations/") || sourceUrl.includes("/backend-api/files/download/");
  }
  function archiveNetwork(id, sourceUrl, phase, status) {
    const conversationId = conversationHistoryId(sourceUrl);
    if (!conversationId || !captureAllowed(conversationId, archiveProjects.get(conversationId) ?? null))
      return;
    observerTarget?.postMessage(
      {
        channel: TRANSPORT_CHANNEL,
        type: ARCHIVE_NETWORK_EVENT,
        detail: { id, conversationId, phase, status, timestamp: Date.now() }
      },
      observerTarget.location.origin
    );
  }
  const ARCHIVE_EVENT = "chatgpt-booster:archive-event";
  const ARCHIVE_PRELOAD_EVENT = "chatgpt-booster:archive-preload";
  const SUBMISSION_SELECTION_SCHEMA = "chatgpt-submit-selection-2026-10-v1";
  const DEFAULT_CONFIG = {
    enabled: false,
    captureBodies: false,
    maxBodyChars: 2048
  };
  const SECRET_KEY = /(authorization|cookie|token|secret|password|passwd|api[-_]?key|session|credential|verify|turnstile|proof|challenge)/i;
  const JSON_SECRET_VALUE = /("(?:authorization|cookie|token|secret|password|passwd|api[-_]?key|session|credential|verify|turnstile|proof|challenge)[^"]*"\s*:\s*")[^"]*(")/gi;
  const QUERY_SECRET_TEXT = /([?&](?:token|access_token|api_key|key|session|secret|auth|verify|turnstile|proof|challenge)=)[^&#\s"]*/gi;
  const JWT_LIKE = /\beyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\b/g;
  function redactTextSecrets(value) {
    return value.replace(/Bearer\s+[A-Za-z0-9._~+/-]+=*/gi, "Bearer [REDACTED]").replace(JSON_SECRET_VALUE, "$1[REDACTED]$2").replace(QUERY_SECRET_TEXT, "$1[REDACTED]").replace(JWT_LIKE, "[REDACTED_JWT]");
  }
  function classifyError(error) {
    const message = error instanceof Error ? error.message.slice(0, 300) : String(error || "transport failed").slice(0, 300);
    const name = error instanceof Error ? error.name : "";
    if (name === "AbortError" || /abort(ed|ing)?|signal is aborted|BodyStreamBuffer was aborted/i.test(message)) {
      return { message, errorClass: "aborted" };
    }
    if (/stream/i.test(message)) return { message, errorClass: "stream" };
    return { message, errorClass: "network" };
  }
  const UUIDISH = /^[0-9a-f]{8}-[0-9a-f-]{27,}$/i;
  const LONG_ID = /^[A-Za-z0-9_-]{24,}$/;
  function sanitizeTransportUrl(input, baseHref = typeof location === "undefined" ? "https://chatgpt.com/" : location.href) {
    try {
      const url = new URL(input, baseHref);
      for (const [key] of url.searchParams) {
        if (SECRET_KEY.test(key)) url.searchParams.set(key, "[REDACTED]");
      }
      url.pathname = url.pathname.split("/").map((part) => UUIDISH.test(part) || LONG_ID.test(part) ? ":id" : part).join("/");
      return url.toString();
    } catch {
      return input.slice(0, 512);
    }
  }
  function redact(value, depth = 0) {
    if (depth > 6) return "[TRUNCATED]";
    if (Array.isArray(value)) return value.slice(0, 50).map((item) => redact(item, depth + 1));
    if (value && typeof value === "object") {
      const result = {};
      for (const [key, child] of Object.entries(value).slice(0, 100)) {
        result[key] = SECRET_KEY.test(key) ? "[REDACTED]" : redact(child, depth + 1);
      }
      return result;
    }
    if (typeof value === "string" && /Bearer\s+[A-Za-z0-9._~+/-]+=*/i.test(value)) {
      return "[REDACTED]";
    }
    return value;
  }
  function sanitizeBodyPreview(value, maxChars) {
    if (value == null) return void 0;
    let text;
    if (typeof value === "string") {
      try {
        text = JSON.stringify(redact(JSON.parse(value)));
      } catch {
        text = value;
      }
    } else if (value instanceof URLSearchParams) {
      const params = new URLSearchParams(value);
      for (const [key] of params) if (SECRET_KEY.test(key)) params.set(key, "[REDACTED]");
      text = params.toString();
    } else if (value instanceof FormData) {
      const result = {};
      for (const [key, child] of value.entries()) {
        result[key] = SECRET_KEY.test(key) ? "[REDACTED]" : typeof child === "string" ? child : `[Blob ${child.type || "unknown"} ${child.size}B]`;
      }
      text = JSON.stringify(result);
    } else if (value instanceof Blob) {
      return `[Blob ${value.type || "unknown"} ${value.size}B]`;
    } else if (value instanceof ArrayBuffer || ArrayBuffer.isView(value)) {
      return "[Binary]";
    } else {
      try {
        text = JSON.stringify(redact(value));
      } catch {
        text = String(value);
      }
    }
    const redacted = redactTextSecrets(text);
    return redacted.length > maxChars ? `${redacted.slice(0, maxChars)}…` : redacted;
  }
  let observerTarget = typeof window === "undefined" ? void 0 : window;
  let transportEmissionEnabled = false;
  let transportBatch = [];
  let transportBatchTimer;
  const TRANSPORT_BATCH_DELAY_MS = 50;
  const TRANSPORT_BATCH_MAX = 50;
  function flushTransportBatch() {
    if (transportBatchTimer) {
      clearTimeout(transportBatchTimer);
      transportBatchTimer = void 0;
    }
    if (!observerTarget || transportBatch.length === 0) {
      transportBatch = [];
      return;
    }
    const details = transportBatch;
    transportBatch = [];
    observerTarget.postMessage(
      {
        channel: TRANSPORT_CHANNEL,
        type: TRANSPORT_BATCH_EVENT,
        details
      },
      "*"
    );
  }
  function emit(detail) {
    if (!observerTarget || !transportEmissionEnabled) return;
    transportBatch.push(detail);
    if (transportBatch.length >= TRANSPORT_BATCH_MAX) {
      flushTransportBatch();
      return;
    }
    transportBatchTimer ??= setTimeout(flushTransportBatch, TRANSPORT_BATCH_DELAY_MS);
  }
  function conversationHistoryId(input) {
    try {
      const url = new URL(input, location.href);
      if (url.origin !== "https://chatgpt.com") return void 0;
      const match = url.pathname.match(/^\/backend-api\/conversations\/([^/]+)(?:\/messages)?$/);
      return match?.[1] ? decodeURIComponent(match[1]) : void 0;
    } catch {
      return void 0;
    }
  }
  function archiveFileResolverId(input) {
    try {
      const url = new URL(input, "https://chatgpt.com");
      if (url.origin !== "https://chatgpt.com") return void 0;
      const match = url.pathname.match(/^\/backend-api\/files\/download\/(file_[A-Za-z0-9_-]+)$/);
      return match?.[1];
    } catch {
      return void 0;
    }
  }
  function archiveAssetContentUrl(value, assetId) {
    try {
      const url = new URL(value, "https://chatgpt.com");
      if (url.origin === "https://chatgpt.com" && url.pathname === "/backend-api/estuary/content" && url.searchParams.get("id") === assetId)
        return url.href;
    } catch {
    }
    return null;
  }
  function parseArchiveAssetResolution(value, assetId) {
    if (!value || typeof value !== "object" || Array.isArray(value)) return void 0;
    const payload = value;
    if (payload.status !== "success" || typeof payload.download_url !== "string") return void 0;
    const downloadUrl = archiveAssetContentUrl(payload.download_url, assetId);
    if (!downloadUrl) return void 0;
    try {
      return {
        assetId,
        downloadUrl,
        fileName: typeof payload.file_name === "string" ? payload.file_name : null,
        mimeType: typeof payload.mime_type === "string" ? payload.mime_type : null,
        fileSizeBytes: typeof payload.file_size_bytes === "number" && Number.isFinite(payload.file_size_bytes) ? payload.file_size_bytes : null,
        observedAt: Date.now()
      };
    } catch {
      return void 0;
    }
  }
  function publishAssetResolution(value, sourceUrl) {
    const assetId = archiveFileResolverId(sourceUrl);
    if (!observerTarget || !assetId) return;
    const detail = parseArchiveAssetResolution(value, assetId);
    if (!detail) return;
    observerTarget.postMessage(
      { channel: TRANSPORT_CHANNEL, type: ARCHIVE_ASSET_EVENT, detail },
      observerTarget.location.origin
    );
  }
  function observeArchiveAssetResponse(response, sourceUrl) {
    if (!response.ok || !archiveFileResolverId(sourceUrl)) return;
    void response.clone().json().then((value) => publishAssetResolution(value, sourceUrl)).catch(() => void 0);
  }
  function isConversationHistoryPayload(value) {
    if (!value || typeof value !== "object" || Array.isArray(value)) return false;
    const record = value;
    return Array.isArray(record.messages) && Boolean(record.page_info && typeof record.page_info === "object");
  }
  function observeConversationArchiveResponse(response, sourceUrl, read, activeAccountEpoch) {
    const conversationId = conversationHistoryId(sourceUrl);
    if (!observerTarget || !response.ok || !conversationId || !read) return;
    if (read.accountEpoch !== activeAccountEpoch()) return;
    if (!read.isInitial && !shouldObserveArchiveConversation(conversationId)) return;
    const contentType = response.headers.get("content-type") ?? "";
    if (!/json/i.test(contentType)) return;
    const declaredSize = Number(response.headers.get("content-length")) || 0;
    if (declaredSize > 32 * 1024 * 1024) return;
    void response.clone().json().then((payload) => {
      if (!observerTarget || read.accountEpoch !== activeAccountEpoch()) return;
      if (!isConversationHistoryPayload(payload)) {
        if (shouldObserveArchiveConversation(conversationId))
          observerTarget.postMessage(
            {
              channel: TRANSPORT_CHANNEL,
              type: ARCHIVE_CONTRACT_ERROR_EVENT,
              detail: { conversationId, path: "payload.messages/page_info" }
            },
            observerTarget.location.origin
          );
        return;
      }
      const detail = {
        kind: "conversation-page",
        ...read,
        timestamp: Date.now(),
        sourceUrl,
        conversationId,
        payload
      };
      const buffered = bufferedInitialPages.get(conversationId);
      if (read.isInitial && (!buffered || read.readStartedAt > (buffered.readStartedAt ?? buffered.timestamp) || read.readId === buffered.readId && detail.timestamp >= buffered.timestamp)) {
        bufferedInitialPages.delete(conversationId);
        bufferedInitialPages.set(conversationId, detail);
        while (bufferedInitialPages.size > 32) {
          const oldest = bufferedInitialPages.keys().next().value;
          if (!oldest) break;
          bufferedInitialPages.delete(oldest);
        }
      }
      const projectId = archiveProjectId(payload, conversationId);
      if (!captureAllowed(conversationId, projectId)) publishPreloadPage(detail);
      publishConversationPage(detail);
    }).catch(() => void 0);
  }
  function observeFetchResponseBody(response, context, config) {
    if (!config.captureBodies) return;
    const contentType = response.headers.get("content-type") ?? "";
    if (!/(text|json|event-stream|javascript|xml)/i.test(contentType)) return;
    const body = response.clone().body;
    if (!body) return;
    const reader = body.getReader();
    const decoder = new TextDecoder();
    void (async () => {
      try {
        while (true) {
          const { done, value } = await reader.read();
          if (done) break;
          const text = decoder.decode(value, { stream: true });
          if (!text) continue;
          emit({
            id: context.id,
            kind: "fetch",
            direction: "inbound",
            phase: "message",
            timestamp: Date.now(),
            method: context.method,
            url: context.url,
            contentType,
            size: value.byteLength,
            bodyPreview: sanitizeBodyPreview(text, config.maxBodyChars)
          });
        }
      } catch (error) {
        const classified = classifyError(error);
        emit({
          id: context.id,
          kind: "fetch",
          direction: "inbound",
          phase: "error",
          timestamp: Date.now(),
          method: context.method,
          url: context.url,
          error: classified.message,
          errorClass: classified.errorClass
        });
      } finally {
        reader.releaseLock();
      }
    })();
  }
  let sequence = 0;
  let observerIdentity;
  function nextId(kind) {
    observerIdentity ??= crypto.randomUUID();
    sequence += 1;
    return `${kind}-${observerIdentity}-${sequence}`;
  }
  function installTransportObserver(target = window) {
    const marker = "__chatgptBoosterTransportObserverInstalled__:" + TRANSPORT_CHANNEL;
    const tagged = target;
    if (tagged[marker]) return () => void 0;
    tagged[marker] = true;
    const registryKey = "__kobaBrowserNativeHookLayers__";
    let shared = tagged[registryKey];
    if (!shared) {
      shared = {
        active: /* @__PURE__ */ new Set(),
        originalFetch: Object.getOwnPropertyDescriptor(target, "fetch"),
        hostFetch: target.fetch,
        originalXhrOpen: target.XMLHttpRequest.prototype.open,
        originalXhrSend: target.XMLHttpRequest.prototype.send,
        originalWebSocket: target.WebSocket,
        originalEventSource: target.EventSource,
        fetchGetters: /* @__PURE__ */ new Set(),
        xhrOpens: /* @__PURE__ */ new Set(),
        xhrSends: /* @__PURE__ */ new Set()
      };
      tagged[registryKey] = shared;
    }
    shared.active.add(marker);
    let observerActive = true;
    observerTarget = target;
    archivePolicy = { ...DENY_ARCHIVE };
    let verifiedAccountIds = /* @__PURE__ */ new Set();
    let nativeRegistrySelectedId = null;
    let selectedAccountId = null;
    let confirmedCatalogAccountId = null;
    let emittedAccountId = null;
    let accountEpoch = 0;
    const activeRuns = /* @__PURE__ */ new Map();
    const nativeStreamRuns = /* @__PURE__ */ new Map();
    let accountSelectionSerial = 0;
    const publishAccount = (accountId, observedAt) => {
      if (emittedAccountId === accountId) return;
      emittedAccountId = accountId;
      accountEpoch += 1;
      archiveReads.clear();
      activeRuns.clear();
      nativeStreamRuns.clear();
      archiveProjects.clear();
      bufferedInitialPages.clear();
      target.postMessage(
        {
          channel: TRANSPORT_CHANNEL,
          type: CONVERSATION_ACCOUNT_EVENT,
          detail: { accountId, observedAt }
        },
        target.location.origin
      );
    };
    const verifyAccountCatalog = (response, selectionSerialAtRequest, selectedAtRequest) => {
      if (!response.ok || !/json/i.test(response.headers.get("content-type") ?? "")) return;
      void response.clone().json().then((value) => {
        const unchanged = accountSelectionSerial === selectionSerialAtRequest && selectedAtRequest === selectedAccountId;
        const initialSelection = selectedAtRequest === null && selectedAccountId !== null && accountSelectionSerial === selectionSerialAtRequest + 1;
        if (!unchanged && !initialSelection) return;
        const root = requestPayload(value);
        const accounts = requestPayload(root?.accounts);
        if (!accounts) return;
        const ids = /* @__PURE__ */ new Set();
        for (const [key, raw] of Object.entries(accounts)) {
          if (key === "default") continue;
          const account = requestPayload(requestPayload(raw)?.account);
          if (typeof account?.account_id === "string" && account.account_id === key) ids.add(key);
        }
        verifiedAccountIds = ids;
        nativeRegistrySelectedId = null;
        const confirmedByCatalog = selectedAccountId && confirmedCatalogAccountId === selectedAccountId && ids.has(selectedAccountId) ? selectedAccountId : null;
        const confirmedByUniqueRegistry = selectedAccountId === null && ids.size === 1 ? ids.values().next().value ?? null : null;
        publishAccount(confirmedByCatalog ?? confirmedByUniqueRegistry, Date.now());
      }).catch(() => void 0);
    };
    const observeAccountSelector = (sourceUrl, method, headerValue, observedAt) => {
      if (method.toUpperCase() !== "GET" || !isConversationCatalogUrl(sourceUrl)) return;
      if ((headerValue?.trim() || null) !== selectedAccountId) return;
      confirmedCatalogAccountId = selectedAccountId;
      const confirmed = selectedAccountId && verifiedAccountIds.has(selectedAccountId) && (nativeRegistrySelectedId === null || nativeRegistrySelectedId === selectedAccountId) ? selectedAccountId : null;
      publishAccount(confirmed, observedAt);
    };
    const unregisterNativeAccount = registerNativeAccountConsumer(target, {
      begin: () => ({ selected: selectedAccountId, serial: accountSelectionSerial }),
      accept(registry, ticket) {
        if (!observerActive) return;
        const started = ticket;
        const unchanged = started.serial === accountSelectionSerial && started.selected === selectedAccountId;
        const initialSelection = started.selected === null && selectedAccountId === registry.selectedAccountId && accountSelectionSerial === started.serial + 1;
        if (!unchanged && !initialSelection) return;
        if (selectedAccountId !== null && selectedAccountId !== registry.selectedAccountId) return;
        verifiedAccountIds = new Set(registry.accountIds);
        nativeRegistrySelectedId = registry.selectedAccountId;
        publishAccount(
          confirmedCatalogAccountId === registry.selectedAccountId && selectedAccountId === registry.selectedAccountId && verifiedAccountIds.has(registry.selectedAccountId) ? registry.selectedAccountId : null,
          Date.now()
        );
      }
    });
    const onArchivePolicy = (event) => {
      if (event.origin !== target.location.origin || event.source !== target) return;
      const data = event.data;
      if (data?.channel !== TRANSPORT_CHANNEL || data.type !== ARCHIVE_POLICY_EVENT || !data.detail) return;
      archivePolicy = { ...DENY_ARCHIVE, ...data.detail };
      const id = pageConversationId();
      const currentBuffered = id ? bufferedInitialPages.get(id) : void 0;
      if (currentBuffered) {
        publishPreloadPage(currentBuffered);
        if (archivePolicy.manualConversationId === id) publishConversationPage(currentBuffered);
      }
    };
    target.addEventListener("message", onArchivePolicy);
    let config = { ...DEFAULT_CONFIG };
    const onConfig = (event) => {
      if (event.origin && event.origin !== target.location.origin) return;
      const data = event.data;
      if (data?.channel !== TRANSPORT_CHANNEL || data.type !== TRANSPORT_CONFIG_EVENT) return;
      const detail = data.detail;
      config = {
        enabled: detail?.enabled ?? config.enabled,
        captureBodies: detail?.captureBodies ?? config.captureBodies,
        maxBodyChars: Math.min(Math.max(detail?.maxBodyChars ?? config.maxBodyChars, 128), 16384)
      };
      transportEmissionEnabled = config.enabled;
      setRealtimeTransportHooksEnabled(transportEmissionEnabled);
      if (!transportEmissionEnabled) flushTransportBatch();
    };
    target.addEventListener("message", onConfig);
    const fetchWrapperMarker = "__chatgptBoosterFetchWrapper__";
    const originalFetchDescriptor = Object.getOwnPropertyDescriptor(target, "fetch");
    let fetchHost = target.fetch;
    let fetchWrapper;
    let fetchCallDepth = 0;
    const archiveAssetFetches = /* @__PURE__ */ new Map();
    const onArchiveAssetFetch = (event) => {
      if (event.origin !== target.location.origin || event.source !== target) return;
      const data = event.data;
      if (data?.channel !== TRANSPORT_CHANNEL || data.type !== ARCHIVE_ASSET_FETCH_REQUEST_EVENT) return;
      const detail = data.detail;
      if (typeof detail?.requestId !== "string" || typeof detail.assetId !== "string" || typeof detail.url !== "string")
        return;
      const safeUrl = archiveAssetContentUrl(detail.url, detail.assetId);
      if (!safeUrl) return;
      const controller = new AbortController();
      archiveAssetFetches.set(detail.requestId, controller);
      void (async () => {
        try {
          const response = await fetchHost.call(target, safeUrl, {
            credentials: "omit",
            signal: controller.signal
          });
          if (!response.ok) throw new Error(`HTTP ${response.status}`);
          const announced = Number(response.headers.get("content-length"));
          if (Number.isFinite(announced) && announced > 512 * 1024 * 1024)
            throw new Error("Asset exceeds 512 MiB export limit");
          const buffer = await response.arrayBuffer();
          if (buffer.byteLength > 512 * 1024 * 1024) throw new Error("Asset exceeds 512 MiB export limit");
          target.postMessage(
            {
              channel: TRANSPORT_CHANNEL,
              type: ARCHIVE_ASSET_FETCH_RESULT_EVENT,
              detail: {
                requestId: detail.requestId,
                assetId: detail.assetId,
                ok: true,
                bytes: buffer
              }
            },
            target.location.origin,
            [buffer]
          );
        } catch (error) {
          if (controller.signal.aborted) return;
          target.postMessage(
            {
              channel: TRANSPORT_CHANNEL,
              type: ARCHIVE_ASSET_FETCH_RESULT_EVENT,
              detail: {
                requestId: detail.requestId,
                assetId: detail.assetId,
                ok: false,
                error: error instanceof Error ? error.message : "Asset fetch failed"
              }
            },
            target.location.origin
          );
        } finally {
          archiveAssetFetches.delete(detail.requestId);
        }
      })();
    };
    const onArchiveAssetFetchCancel = (event) => {
      if (event.origin !== target.location.origin || event.source !== target) return;
      const data = event.data;
      if (data?.channel !== TRANSPORT_CHANNEL || data.type !== ARCHIVE_ASSET_FETCH_CANCEL_EVENT) return;
      const requestId = data.detail?.requestId;
      if (typeof requestId === "string") archiveAssetFetches.get(requestId)?.abort();
    };
    target.addEventListener("message", onArchiveAssetFetch);
    target.addEventListener("message", onArchiveAssetFetchCancel);
    const createFetchWrapper = (upstream) => {
      const callUpstream = (input, init) => {
        fetchCallDepth += 1;
        try {
          return upstream.call(target, input, init);
        } finally {
          fetchCallDepth -= 1;
        }
      };
      const wrapped = ((input, init) => {
        if (!observerActive) return callUpstream(input, init);
        if (fetchCallDepth > 0) return upstream.call(target, input, init);
        const request = input instanceof Request ? input : void 0;
        const rawUrl = request?.url ?? String(input);
        if (!transportEmissionEnabled && !isArchiveObservedUrl(rawUrl) && !isConversationRequestUrl(rawUrl) && !isConversationStopUrl(rawUrl) && !isConversationStreamStatusUrl(rawUrl) && !isConversationCatalogUrl(rawUrl) && !nativeProjectDetailId(rawUrl) && !isAccountCheckUrl(rawUrl))
          return callUpstream(input, init);
        return (async () => {
          const diagnosticsEnabled = transportEmissionEnabled;
          const id = nextId("fetch");
          const started = diagnosticsEnabled ? performance.now() : 0;
          const method = init?.method ?? request?.method ?? "GET";
          const url = diagnosticsEnabled ? sanitizeTransportUrl(rawUrl) : "";
          const body = diagnosticsEnabled && config.captureBodies ? sanitizeBodyPreview(init?.body, config.maxBodyChars) : void 0;
          const requestBoundaryAt = Date.now();
          const accountSelectedAtRequest = selectedAccountId;
          const selectionSerialAtRequest = accountSelectionSerial;
          const headers = new Headers(request?.headers);
          if (init?.headers)
            new Headers(init.headers).forEach((value, key) => {
              headers.set(key, value);
            });
          const projectOwnerAtRequest = emittedAccountId && (!headers.get("chatgpt-account-id")?.trim() || headers.get("chatgpt-account-id")?.trim() === emittedAccountId) ? emittedAccountId : null;
          if (method.toUpperCase() === "GET" && isConversationCatalogUrl(rawUrl)) {
            const candidate = headers.get("chatgpt-account-id")?.trim() || null;
            if (candidate !== selectedAccountId) {
              selectedAccountId = candidate;
              accountSelectionSerial++;
              confirmedCatalogAccountId = null;
              if (emittedAccountId === null) accountEpoch += 1;
              publishAccount(null, requestBoundaryAt);
            }
          }
          const conversationRequest = conversationRequestTimingFromBody(
            rawUrl,
            method,
            init?.body,
            requestBoundaryAt
          );
          if (conversationRequest?.conversationId)
            activeRuns.set(conversationRequest.conversationId, { id, at: requestBoundaryAt });
          const statusConversationId = conversationStreamStatusTarget(rawUrl);
          const statusRunAtRequest = statusConversationId ? activeRuns.get(statusConversationId)?.id : void 0;
          const resumeConversationId = isConversationResumeUrl(rawUrl) ? conversationIdFromBody(init?.body) : null;
          const resumeRunAtRequest = resumeConversationId ? activeRuns.get(resumeConversationId)?.id : void 0;
          publishConversationRequest(
            conversationRequest ? { ...conversationRequest, requestId: id } : null,
            emittedAccountId
          );
          const stopConversationId = conversationStopTargetFromBody(rawUrl, method, init?.body);
          const stopRunAtRequest = stopConversationId ? activeRuns.get(stopConversationId)?.id : void 0;
          if (stopConversationId)
            publishConversationStop({
              conversationId: stopConversationId,
              requestId: stopRunAtRequest,
              phase: "requested",
              timestamp: requestBoundaryAt,
              status: null
            });
          if (diagnosticsEnabled)
            emit({
              id,
              kind: "fetch",
              direction: "outbound",
              phase: "request",
              timestamp: requestBoundaryAt,
              method,
              url,
              ...body ? { bodyPreview: body } : {}
            });
          const historyRead = beginArchiveRequest(rawUrl, id, emittedAccountId, accountEpoch);
          const accountCheckEpoch = accountEpoch;
          archiveNetwork(id, rawUrl, "request");
          try {
            const response = await callUpstream(input, init);
            if (!response.ok && (conversationRequest || resumeConversationId)) {
              void response.clone().json().catch(() => null).then((payload) => {
                if (accountCheckEpoch !== accountEpoch || !observerActive) return;
                publishConversationStream({
                  conversationId: conversationRequest?.conversationId ?? resumeConversationId,
                  kind: "error",
                  errorCode: conversationRequestErrorCode(
                    payload,
                    response.status,
                    resumeConversationId ? "network_error" : "request_rejected"
                  ),
                  errorReason: null,
                  canRetry: response.status === 429 || response.status >= 500,
                  observedAt: Date.now(),
                  accountId: emittedAccountId,
                  requestId: conversationRequest ? id : resumeRunAtRequest,
                  userMessageId: conversationRequest?.userMessageId ?? null
                });
              });
            }
            if (stopConversationId)
              publishConversationStop({
                conversationId: stopConversationId,
                requestId: stopRunAtRequest,
                phase: response.ok ? "confirmed" : "failed",
                timestamp: Date.now(),
                status: response.status
              });
            archiveNetwork(id, rawUrl, response.ok ? "response" : "error", response.status);
            observeConversationArchiveResponse(response, rawUrl, historyRead, () => accountEpoch);
            if (accountCheckEpoch === accountEpoch) {
              if (response.ok)
                observeAccountSelector(
                  rawUrl,
                  method,
                  headers.get("chatgpt-account-id"),
                  requestBoundaryAt
                );
              if (method.toUpperCase() === "GET" || !nativeProjectDetailId(rawUrl))
                observeConversationCatalogResponse(
                  response,
                  rawUrl,
                  nativeProjectDetailId(rawUrl) ? projectOwnerAtRequest : emittedAccountId,
                  accountEpoch,
                  () => observerActive ? accountEpoch : -1,
                  requestBoundaryAt
                );
            }
            if (method.toUpperCase() === "GET" && isAccountCheckUrl(rawUrl))
              verifyAccountCatalog(response, selectionSerialAtRequest, accountSelectedAtRequest);
            observeConversationStreamStatusResponse(response, rawUrl, statusRunAtRequest);
            if (method.toUpperCase() === "POST" && isConversationRequestUrl(rawUrl))
              observeConversationStreamResponse(
                response,
                conversationIdFromBody(init?.body),
                historyRead?.accountId ?? emittedAccountId,
                accountCheckEpoch,
                () => accountEpoch,
                id,
                conversationRequest?.userMessageId ?? null,
                (nativeId, message) => {
                  if ((activeRuns.get(nativeId)?.at ?? 0) <= requestBoundaryAt)
                    activeRuns.set(nativeId, { id, at: requestBoundaryAt });
                  const nativeRequestId = requestPayload(message?.metadata)?.request_id;
                  if (typeof nativeRequestId === "string" && nativeRequestId.length > 0 && nativeRequestId.length <= 1024) {
                    nativeStreamRuns.set(JSON.stringify([nativeId, nativeRequestId]), {
                      id,
                      at: requestBoundaryAt
                    });
                    if (nativeStreamRuns.size > 128) {
                      const oldest = nativeStreamRuns.keys().next().value;
                      if (oldest !== void 0) nativeStreamRuns.delete(oldest);
                    }
                  }
                }
              );
            if (method.toUpperCase() === "POST" && resumeConversationId)
              observeConversationStreamResponse(
                response,
                resumeConversationId,
                emittedAccountId,
                accountCheckEpoch,
                () => accountEpoch,
                resumeRunAtRequest ?? id,
                null,
                () => void 0
              );
            observeArchiveAssetResponse(response, rawUrl);
            if (diagnosticsEnabled) {
              observeFetchResponseBody(response, { id, method, url }, config);
              emit({
                id,
                kind: "fetch",
                direction: "inbound",
                phase: "response",
                timestamp: Date.now(),
                method,
                url,
                status: response.status,
                durationMs: Math.round((performance.now() - started) * 100) / 100,
                contentType: response.headers.get("content-type") ?? void 0,
                size: Number(response.headers.get("content-length")) || void 0
              });
            }
            return response;
          } catch (error) {
            if ((conversationRequest || resumeConversationId) && accountCheckEpoch === accountEpoch)
              publishConversationStream({
                conversationId: conversationRequest?.conversationId ?? resumeConversationId,
                kind: "error",
                errorCode: "network_error",
                errorReason: null,
                canRetry: true,
                observedAt: Date.now(),
                accountId: emittedAccountId,
                requestId: conversationRequest ? id : resumeRunAtRequest,
                userMessageId: conversationRequest?.userMessageId ?? null
              });
            if (stopConversationId)
              publishConversationStop({
                conversationId: stopConversationId,
                requestId: stopRunAtRequest,
                phase: "failed",
                timestamp: Date.now(),
                status: null
              });
            archiveNetwork(id, rawUrl, "error", 0);
            if (diagnosticsEnabled) {
              const classified = classifyError(error);
              emit({
                id,
                kind: "fetch",
                direction: "inbound",
                phase: "error",
                timestamp: Date.now(),
                method,
                url,
                durationMs: Math.round((performance.now() - started) * 100) / 100,
                error: classified.message,
                errorClass: classified.errorClass
              });
            }
            throw error;
          }
        })();
      });
      Object.defineProperty(wrapped, fetchWrapperMarker, { value: true });
      return wrapped;
    };
    fetchWrapper = createFetchWrapper(fetchHost);
    const ownFetchGetter = () => fetchWrapper;
    shared.fetchGetters.add(ownFetchGetter);
    Object.defineProperty(target, "fetch", {
      configurable: true,
      enumerable: originalFetchDescriptor?.enumerable ?? true,
      get: ownFetchGetter,
      set: (next) => {
        if (typeof next !== "function" || next[fetchWrapperMarker]) return;
        fetchHost = next;
        fetchWrapper = createFetchWrapper(fetchHost);
      }
    });
    const OriginalXHR = target.XMLHttpRequest;
    const originalOpen = OriginalXHR.prototype.open;
    const originalSend = OriginalXHR.prototype.send;
    const xhrMeta = /* @__PURE__ */ new WeakMap();
    const wrappedXhrOpen = function(method, url, asyncFlag = true, user, password) {
      xhrMeta.set(this, { method, rawUrl: String(url) });
      return originalOpen.call(this, method, url, asyncFlag, user ?? null, password ?? null);
    };
    const wrappedXhrSend = function(body) {
      if (!observerActive) return originalSend.call(this, body);
      const meta = xhrMeta.get(this);
      if (!meta) return originalSend.call(this, body);
      const diagnosticsEnabled = transportEmissionEnabled;
      const resolverObserved = Boolean(archiveFileResolverId(meta.rawUrl));
      const conversationRequest = isConversationRequestUrl(meta.rawUrl);
      const conversationStop = isConversationStopUrl(meta.rawUrl);
      const conversationStreamStatus = isConversationStreamStatusUrl(meta.rawUrl);
      if (!diagnosticsEnabled && !resolverObserved && !conversationRequest && !conversationStop && !conversationStreamStatus)
        return originalSend.call(this, body);
      const id = nextId("xhr");
      const safeUrl = diagnosticsEnabled ? sanitizeTransportUrl(meta.rawUrl) : "";
      const started = diagnosticsEnabled ? performance.now() : 0;
      const requestBoundaryAt = Date.now();
      const xhrAccountEpoch = accountEpoch;
      const requestTiming = conversationRequestTimingFromBody(
        meta.rawUrl,
        meta.method,
        body,
        requestBoundaryAt
      );
      if (requestTiming?.conversationId)
        activeRuns.set(requestTiming.conversationId, { id, at: requestBoundaryAt });
      const statusId = conversationStreamStatusTarget(meta.rawUrl);
      const statusRun = statusId ? activeRuns.get(statusId)?.id : void 0;
      publishConversationRequest(
        requestTiming ? { ...requestTiming, requestId: id } : null,
        emittedAccountId
      );
      const stopConversationId = meta.method.toUpperCase() === "POST" && conversationStop ? conversationIdFromBody(body) : null;
      const stopRun = stopConversationId ? activeRuns.get(stopConversationId)?.id : void 0;
      if (stopConversationId)
        publishConversationStop({
          conversationId: stopConversationId,
          requestId: stopRun,
          phase: "requested",
          timestamp: requestBoundaryAt,
          status: null
        });
      if (diagnosticsEnabled)
        emit({
          id,
          kind: "xhr",
          direction: "outbound",
          phase: "request",
          timestamp: requestBoundaryAt,
          method: meta.method,
          url: safeUrl,
          ...config.captureBodies ? { bodyPreview: sanitizeBodyPreview(body, config.maxBodyChars) } : {}
        });
      this.addEventListener(
        "loadend",
        () => {
          if (!observerActive || xhrAccountEpoch !== accountEpoch) return;
          if (stopConversationId)
            publishConversationStop({
              conversationId: stopConversationId,
              requestId: stopRun,
              phase: this.status >= 200 && this.status < 300 ? "confirmed" : "failed",
              timestamp: Date.now(),
              status: this.status || null
            });
          if (diagnosticsEnabled)
            emit({
              id,
              kind: "xhr",
              direction: "inbound",
              phase: "response",
              timestamp: Date.now(),
              method: meta.method,
              url: safeUrl,
              status: this.status,
              durationMs: Math.round((performance.now() - started) * 100) / 100,
              contentType: this.getResponseHeader("content-type") ?? void 0
            });
          if (conversationStreamStatus) {
            try {
              const value = this.responseType === "json" ? this.response : JSON.parse(this.responseText);
              const detail = conversationStreamStatusFromPayload(
                meta.rawUrl,
                value,
                Date.now(),
                this.status
              );
              publishConversationStreamStatus(
                detail ? { ...detail, ...statusRun ? { requestId: statusRun } : {} } : null
              );
            } catch {
              if (this.status === 404)
                publishConversationStreamStatus(
                  conversationStreamStatusFromPayload(meta.rawUrl, null, Date.now(), this.status)
                );
            }
          }
          if (requestTiming && (this.status < 200 || this.status >= 300)) {
            let payload = null;
            try {
              payload = this.responseType === "json" ? this.response : JSON.parse(this.responseText);
            } catch {
            }
            publishConversationStream({
              conversationId: requestTiming.conversationId,
              requestId: id,
              userMessageId: requestTiming.userMessageId,
              kind: "error",
              errorCode: conversationRequestErrorCode(
                payload,
                this.status,
                this.status ? "request_rejected" : "network_error"
              ),
              errorReason: null,
              canRetry: this.status === 0 || this.status === 429 || this.status >= 500,
              observedAt: Date.now(),
              accountId: emittedAccountId
            });
          }
          if (resolverObserved && this.status >= 200 && this.status < 300) {
            try {
              const value = this.responseType === "json" ? this.response : JSON.parse(this.responseText);
              publishAssetResolution(value, meta.rawUrl);
            } catch {
            }
          }
          if (diagnosticsEnabled && config.captureBodies) {
            try {
              const value = this.responseType === "json" ? this.response : this.responseText;
              const bodyPreview = sanitizeBodyPreview(value, config.maxBodyChars);
              if (bodyPreview) {
                emit({
                  id,
                  kind: "xhr",
                  direction: "inbound",
                  phase: "message",
                  timestamp: Date.now(),
                  method: meta.method,
                  url: safeUrl,
                  bodyPreview
                });
              }
            } catch {
            }
          }
        },
        { once: true }
      );
      return originalSend.call(this, body);
    };
    shared.xhrOpens.add(wrappedXhrOpen);
    shared.xhrSends.add(wrappedXhrSend);
    OriginalXHR.prototype.open = wrappedXhrOpen;
    OriginalXHR.prototype.send = wrappedXhrSend;
    const OriginalWebSocket = target.WebSocket;
    const WrappedWebSocket = function(url, protocols) {
      const ws = protocols === void 0 ? new OriginalWebSocket(url) : new OriginalWebSocket(url, protocols);
      const socketAccountEpoch = accountEpoch;
      const socketDecoders = /* @__PURE__ */ new Map();
      const sourceSocket = (() => {
        try {
          const host = new URL(String(url), target.location.href).hostname;
          return host === "chatgpt.com" || host.endsWith(".chatgpt.com");
        } catch {
          return false;
        }
      })();
      let id;
      let safe;
      const diagnosticMeta = () => {
        if (!transportEmissionEnabled) return void 0;
        id ??= nextId("websocket");
        safe ??= sanitizeTransportUrl(String(url));
        return { id, safe };
      };
      const originalSendWs = ws.send.bind(ws);
      ws.send = (data) => {
        const meta = diagnosticMeta();
        if (meta)
          emit({
            id: meta.id,
            kind: "websocket",
            direction: "outbound",
            phase: "message",
            timestamp: Date.now(),
            url: meta.safe,
            size: typeof data === "string" ? data.length : void 0,
            ...config.captureBodies ? { bodyPreview: sanitizeBodyPreview(data, config.maxBodyChars) } : {}
          });
        return originalSendWs(data);
      };
      ws.addEventListener("open", () => {
        const meta = diagnosticMeta();
        if (meta)
          emit({
            id: meta.id,
            kind: "websocket",
            direction: "outbound",
            phase: "open",
            timestamp: Date.now(),
            url: meta.safe
          });
      });
      ws.addEventListener("message", (event) => {
        if (observerActive && sourceSocket && socketAccountEpoch === accountEpoch && confirmedCatalogAccountId && typeof event.data === "string") {
          try {
            const envelope = JSON.parse(event.data);
            const candidate = requestPayload(envelope);
            const payload = candidate?.type === "message" && requestPayload(candidate.data) ? candidate.data : envelope;
            const value = requestPayload(payload);
            const key = typeof value?.stream_id === "string" ? value.stream_id : typeof value?.conversation_id === "string" ? value.conversation_id : null;
            let source = null;
            let sourceDecoder;
            if (key) {
              let decoder = socketDecoders.get(key);
              if (!decoder) {
                decoder = new ConversationStreamDecoder();
                socketDecoders.set(key, decoder);
              }
              sourceDecoder = decoder;
              source = decoder.decode(payload);
              if (decoder.hasGap()) {
                const conversationId = typeof value?.conversation_id === "string" ? value.conversation_id : null;
                if (conversationId)
                  publishConversationStream({
                    conversationId,
                    kind: "error",
                    errorCode: "source_patch_gap",
                    errorReason: null,
                    canRetry: true,
                    observedAt: Date.now(),
                    accountId: confirmedCatalogAccountId
                  });
                const baseline = decoder.retainedBaseline();
                const retained = baseline ? conversationStreamEventFromPayload(baseline, conversationId, Date.now()) : null;
                if (retained?.kind === "message" && retained.conversationId && shouldObserveArchiveConversation(retained.conversationId))
                  publishConversationStream({
                    ...retained,
                    accountId: confirmedCatalogAccountId,
                    evidence: decoder.takeGapEvidence()
                  });
              }
              if (socketDecoders.size > 32) {
                const oldest = socketDecoders.keys().next().value;
                if (oldest !== void 0) socketDecoders.delete(oldest);
              }
            }
            const detail = !source && sourceDecoder?.hasGap() ? null : conversationStreamEventFromPayload(source?.payload ?? payload, null, Date.now());
            const nativeRequestId = detail?.kind === "message" ? requestPayload(detail.record.metadata)?.request_id : null;
            const correlatedRun = detail?.conversationId && typeof nativeRequestId === "string" ? nativeStreamRuns.get(JSON.stringify([detail.conversationId, nativeRequestId])) : void 0;
            if (detail?.conversationId && shouldObserveArchiveConversation(detail.conversationId) && !(sourceDecoder?.hasGap() && (detail.kind === "complete" || detail.kind === "async-status")))
              publishConversationStream({
                ...detail,
                accountId: confirmedCatalogAccountId,
                ...correlatedRun ? { requestId: correlatedRun.id } : {},
                ...detail.kind === "message" && source ? { evidence: [...sourceDecoder?.takeGapEvidence() ?? [], source.evidence] } : {}
              });
          } catch {
            for (const decoder of socketDecoders.values()) {
              decoder.markGap({ unparsedSocketEnvelope: event.data, correlation: "socket_only" });
              const baseline = decoder.retainedBaseline();
              const retained = baseline ? conversationStreamEventFromPayload(baseline, null, Date.now()) : null;
              if (retained?.conversationId && shouldObserveArchiveConversation(retained.conversationId)) {
                publishConversationStream({
                  conversationId: retained.conversationId,
                  kind: "error",
                  errorCode: "source_patch_gap",
                  errorReason: null,
                  canRetry: true,
                  observedAt: Date.now(),
                  accountId: confirmedCatalogAccountId
                });
                if (retained.kind === "message")
                  publishConversationStream({
                    ...retained,
                    accountId: confirmedCatalogAccountId,
                    evidence: decoder.takeGapEvidence()
                  });
              }
            }
          }
        }
        const meta = diagnosticMeta();
        if (meta)
          emit({
            id: meta.id,
            kind: "websocket",
            direction: "inbound",
            phase: "message",
            timestamp: Date.now(),
            url: meta.safe,
            size: typeof event.data === "string" ? event.data.length : void 0,
            ...config.captureBodies ? { bodyPreview: sanitizeBodyPreview(event.data, config.maxBodyChars) } : {}
          });
      });
      ws.addEventListener("close", () => {
        const meta = diagnosticMeta();
        if (meta)
          emit({
            id: meta.id,
            kind: "websocket",
            direction: "inbound",
            phase: "close",
            timestamp: Date.now(),
            url: meta.safe
          });
      });
      ws.addEventListener("error", () => {
        const meta = diagnosticMeta();
        if (meta)
          emit({
            id: meta.id,
            kind: "websocket",
            direction: "inbound",
            phase: "error",
            timestamp: Date.now(),
            url: meta.safe,
            errorClass: "socket"
          });
      });
      return ws;
    };
    Object.setPrototypeOf(WrappedWebSocket, OriginalWebSocket);
    WrappedWebSocket.prototype = OriginalWebSocket.prototype;
    const OriginalEventSource = target.EventSource;
    const WrappedEventSource = function(url, eventSourceInitDict) {
      const source = new OriginalEventSource(url, eventSourceInitDict);
      let id;
      let safe;
      const diagnosticMeta = () => {
        if (!transportEmissionEnabled) return void 0;
        id ??= nextId("eventsource");
        safe ??= sanitizeTransportUrl(String(url));
        return { id, safe };
      };
      source.addEventListener("open", () => {
        const meta = diagnosticMeta();
        if (meta)
          emit({
            id: meta.id,
            kind: "eventsource",
            direction: "inbound",
            phase: "open",
            timestamp: Date.now(),
            url: meta.safe
          });
      });
      source.addEventListener("message", (event) => {
        const meta = diagnosticMeta();
        if (meta)
          emit({
            id: meta.id,
            kind: "eventsource",
            direction: "inbound",
            phase: "message",
            timestamp: Date.now(),
            url: meta.safe,
            size: event.data?.length,
            ...config.captureBodies ? {
              bodyPreview: sanitizeBodyPreview(event.data, config.maxBodyChars)
            } : {}
          });
      });
      source.addEventListener("error", () => {
        const meta = diagnosticMeta();
        if (meta)
          emit({
            id: meta.id,
            kind: "eventsource",
            direction: "inbound",
            phase: "error",
            timestamp: Date.now(),
            url: meta.safe,
            errorClass: "stream"
          });
      });
      return source;
    };
    Object.setPrototypeOf(WrappedEventSource, OriginalEventSource);
    WrappedEventSource.prototype = OriginalEventSource.prototype;
    function setRealtimeTransportHooksEnabled(enabled) {
      enabled = enabled || observerActive;
      if (enabled) {
        if (target.WebSocket === OriginalWebSocket) target.WebSocket = WrappedWebSocket;
        if (target.EventSource === OriginalEventSource) target.EventSource = WrappedEventSource;
        return;
      }
      if (target.WebSocket === WrappedWebSocket) target.WebSocket = OriginalWebSocket;
      if (target.EventSource === WrappedEventSource) target.EventSource = OriginalEventSource;
    }
    setRealtimeTransportHooksEnabled(true);
    return () => {
      if (!observerActive) return;
      observerActive = false;
      unregisterNativeAccount();
      target.removeEventListener("message", onConfig);
      target.removeEventListener("message", onArchivePolicy);
      target.removeEventListener("message", onArchiveAssetFetch);
      target.removeEventListener("message", onArchiveAssetFetchCancel);
      for (const controller of archiveAssetFetches.values()) controller.abort();
      archiveAssetFetches.clear();
      const currentDescriptor = Object.getOwnPropertyDescriptor(target, "fetch");
      shared.active.delete(marker);
      if (shared.active.size === 0) {
        if (currentDescriptor?.get && shared.fetchGetters.has(currentDescriptor.get)) {
          if (shared.originalFetch) Object.defineProperty(target, "fetch", shared.originalFetch);
          else
            Object.defineProperty(target, "fetch", {
              configurable: true,
              enumerable: true,
              writable: true,
              value: shared.hostFetch
            });
        }
        if (shared.xhrOpens.has(OriginalXHR.prototype.open))
          OriginalXHR.prototype.open = shared.originalXhrOpen;
        if (shared.xhrSends.has(OriginalXHR.prototype.send))
          OriginalXHR.prototype.send = shared.originalXhrSend;
        if (target.WebSocket && target.WebSocket !== shared.originalWebSocket)
          setRealtimeTransportHooksEnabled(false);
        if (target.EventSource && target.EventSource !== shared.originalEventSource)
          setRealtimeTransportHooksEnabled(false);
        delete tagged[registryKey];
      } else {
        if (currentDescriptor?.get === ownFetchGetter) {
          if (originalFetchDescriptor) Object.defineProperty(target, "fetch", originalFetchDescriptor);
          else
            Object.defineProperty(target, "fetch", {
              configurable: true,
              writable: true,
              enumerable: true,
              value: fetchHost
            });
        }
        if (OriginalXHR.prototype.open === wrappedXhrOpen) OriginalXHR.prototype.open = originalOpen;
        if (OriginalXHR.prototype.send === wrappedXhrSend) OriginalXHR.prototype.send = originalSend;
      }
      setRealtimeTransportHooksEnabled(false);
      bufferedInitialPages.clear();
      verifiedAccountIds.clear();
      selectedAccountId = null;
      emittedAccountId = null;
      transportEmissionEnabled = false;
      flushTransportBatch();
      delete tagged[marker];
    };
  }
  let detach = null;
  window.addEventListener("message", (event) => {
    if (event.source !== window || event.origin !== location.origin) return;
    const payload = event.data;
    if (payload?.channel !== TRANSPORT_CHANNEL) return;
    if (payload.type === "koba:observer:enable" && !detach) {
      detach = installTransportObserver(window);
    } else if (payload.type === "koba:observer:disable") {
      detach?.();
      detach = null;
    }
  });
})();
