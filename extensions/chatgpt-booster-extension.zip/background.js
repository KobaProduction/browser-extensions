function instanceScope() {
  return "chatgpt-booster:dev";
}
function scopedIdentity(base, scope, legacyOwner) {
  if (legacyOwner && scope === legacyOwner)
    return base;
  if (!/^(vk-booster|chatgpt-booster|all-in-one):(dev|prod)$/.test(scope))
    throw new Error("Unsupported Booster instance scope");
  return base + ":" + scope;
}
function instanceKey(base, legacyOwner) {
  return scopedIdentity(base, instanceScope(), legacyOwner);
}
instanceKey("koba:open-feature");
instanceKey("koba:close-shell");
function normalizeExportOverride(value) {
  if (!value || typeof value !== "object" || Array.isArray(value)) return {};
  const input = value;
  const result = {};
  if (typeof input.format === "string" && /^[a-z0-9][a-z0-9._-]{0,63}$/i.test(input.format.trim()))
    result.format = input.format.trim();
  if (input.level === "conversation" || input.level === "custom" || input.level === "full")
    result.level = input.level;
  if (input.packaging === "none" || input.packaging === "zip" || input.packaging === "gzip")
    result.packaging = input.packaging;
  for (const field of [
    "reasoning",
    "tools",
    "internal",
    "reasoningRecap",
    "reasoningFull",
    "toolCalls",
    "toolResults",
    "toolSourceContent",
    "modelEvidence",
    "dictationEditEvidence",
    "sourceRevisions",
    "attachmentMetadata",
    "images",
    "files"
  ])
    if (typeof input[field] === "boolean") result[field] = input[field];
  return result;
}
function normalizeExportOverrides(value) {
  const incoming = value && typeof value === "object" && !Array.isArray(value) ? value : {};
  const parse = (source) => {
    if (!source || typeof source !== "object" || Array.isArray(source)) return {};
    const accepted = [];
    for (const [key, override] of Object.entries(source)) {
      try {
        const identity = JSON.parse(key);
        if (!Array.isArray(identity) || identity.length !== 2 || identity.some((part) => typeof part !== "string" || !part || part.trim() !== part))
          continue;
        const normalized = normalizeExportOverride(override);
        if (Object.keys(normalized).length) accepted.push([key, normalized]);
      } catch {
      }
    }
    return Object.fromEntries(accepted);
  };
  return { projects: parse(incoming.projects), conversations: parse(incoming.conversations) };
}
const DEFAULT_CAPTURE_RULE = {
  enabled: false,
  reasoning: true,
  tools: true,
  internal: true
};
const DEFAULT_EXPORT_OPTIONS = {
  format: "markdown",
  packaging: "none",
  level: "conversation",
  reasoning: true,
  tools: true,
  internal: false,
  reasoningRecap: true,
  reasoningFull: true,
  toolCalls: true,
  toolResults: true,
  toolSourceContent: false,
  modelEvidence: true,
  dictationEditEvidence: false,
  sourceRevisions: false,
  attachmentMetadata: false,
  images: false,
  files: false
};
instanceKey("chatgpt-booster:archive-updated", "chatgpt-booster:prod");
instanceKey("chatgpt-booster:archive-contract-error", "chatgpt-booster:prod");
instanceKey("chatgpt-booster:open-archive", "chatgpt-booster:prod");
instanceKey("chatgpt-booster:open-capture-settings", "chatgpt-booster:prod");
instanceKey("chatgpt-booster:history-loader-state", "chatgpt-booster:prod");
instanceKey("chatgpt-booster:history-loader-start", "chatgpt-booster:prod");
instanceKey("chatgpt-booster:history-loader-stop", "chatgpt-booster:prod");
function normalizeCaptureRule(value) {
  return {
    enabled: value?.enabled === true,
    reasoning: typeof value?.reasoning === "boolean" ? value.reasoning : true,
    tools: typeof value?.tools === "boolean" ? value.tools : true,
    internal: typeof value?.internal === "boolean" ? value.internal : true
  };
}
function normalizeExportOptions(value) {
  return {
    format: typeof value?.format === "string" && /^[a-z0-9][a-z0-9._-]{0,63}$/i.test(value.format.trim()) ? value.format.trim() : DEFAULT_EXPORT_OPTIONS.format,
    level: value?.level === "custom" || value?.level === "full" ? value.level : "conversation",
    packaging: value?.packaging === "zip" || value?.packaging === "gzip" ? value.packaging : "none",
    reasoning: typeof value?.reasoning === "boolean" ? value.reasoning : true,
    tools: typeof value?.tools === "boolean" ? value.tools : true,
    internal: value?.internal === true,
    reasoningRecap: value?.reasoningRecap !== false,
    reasoningFull: value?.reasoningFull !== false,
    toolCalls: value?.toolCalls !== false,
    toolResults: value?.toolResults !== false,
    toolSourceContent: value?.toolSourceContent === true,
    modelEvidence: value?.modelEvidence !== false,
    dictationEditEvidence: value?.dictationEditEvidence === true,
    sourceRevisions: value?.sourceRevisions === true,
    attachmentMetadata: value?.attachmentMetadata === true,
    images: value?.images === true,
    files: value?.files === true
  };
}
const EMPTY_TRANSPORT_COUNTERS = {
  requestsSent: 0,
  responsesReceived: 0,
  messagesSent: 0,
  messagesReceived: 0,
  errors: 0,
  lastEventAt: null
};
function applyTransportCounterEvent(current, event) {
  const next = { ...current, lastEventAt: event.timestamp };
  if (event.phase === "error" && event.errorClass !== "aborted") next.errors += 1;
  if (event.phase === "request") next.requestsSent += 1;
  if (event.phase === "response") next.responsesReceived += 1;
  if (event.phase === "message" && event.direction === "outbound") next.messagesSent += 1;
  if (event.phase === "message" && event.direction === "inbound") next.messagesReceived += 1;
  return next;
}
function clampRatio(value, fallback = 0.65) {
  return typeof value === "number" && Number.isFinite(value) ? Math.max(0, Math.min(1, value)) : fallback;
}
const SETTINGS_SCHEMA_VERSION = 8;
function clampWindowRatio(value, fallback, min, max) {
  return typeof value === "number" && Number.isFinite(value) ? Math.max(min, Math.min(max, value)) : fallback;
}
const DEFAULT_SETTINGS = {
  schemaVersion: SETTINGS_SCHEMA_VERSION,
  enabled: true,
  language: "auto",
  features: {
    messageMetadata: true,
    activityIndicator: true,
    toolInspector: true,
    requestTimer: true
  },
  historyLoader: {
    speedPxPerSecond: 2600,
    burstDurationMs: 650,
    pauseMs: 90
  },
  alerts: {
    responseCompleteSound: false,
    longRunningSound: false,
    longRunningThresholdMs: 12e4
  },
  monitoring: {
    intervalMs: 500
  },
  launcher: {
    x: null,
    y: null,
    side: "right",
    heightRatio: 0.65
  },
  observer: {
    enabled: false,
    captureBodies: false,
    maxBodyChars: 2048
  },
  telemetry: {
    enabled: false,
    endpoint: ""
  },
  archive: { defaultRule: { ...DEFAULT_CAPTURE_RULE }, projects: {}, conversations: {} },
  export: { ...DEFAULT_EXPORT_OPTIONS },
  exportOverrides: { projects: {}, conversations: {} },
  ui: {
    archiveStart: "latest",
    activeSection: "modules",
    telemetryExpanded: true,
    archiveWindow: {
      xRatio: 0.08,
      yRatio: 0.08,
      widthRatio: 0.72,
      heightRatio: 0.82,
      minimizedSide: "right",
      minimizedHeightRatio: 0.45
    }
  }
};
function normalizeSettings(value) {
  const incomingSchema = value?.schemaVersion ?? 0;
  return {
    ...DEFAULT_SETTINGS,
    ...value,
    schemaVersion: SETTINGS_SCHEMA_VERSION,
    language: value?.language ?? DEFAULT_SETTINGS.language,
    features: {
      ...DEFAULT_SETTINGS.features,
      ...value?.features
    },
    historyLoader: {
      speedPxPerSecond: clampWindowRatio(
        value?.historyLoader?.speedPxPerSecond,
        DEFAULT_SETTINGS.historyLoader.speedPxPerSecond,
        600,
        6e3
      ),
      burstDurationMs: clampWindowRatio(
        value?.historyLoader?.burstDurationMs,
        DEFAULT_SETTINGS.historyLoader.burstDurationMs,
        180,
        1600
      ),
      pauseMs: clampWindowRatio(
        value?.historyLoader?.pauseMs,
        DEFAULT_SETTINGS.historyLoader.pauseMs,
        20,
        1200
      )
    },
    alerts: {
      responseCompleteSound: value?.alerts?.responseCompleteSound ?? DEFAULT_SETTINGS.alerts.responseCompleteSound,
      longRunningSound: value?.alerts?.longRunningSound ?? DEFAULT_SETTINGS.alerts.longRunningSound,
      longRunningThresholdMs: clampWindowRatio(
        value?.alerts?.longRunningThresholdMs,
        DEFAULT_SETTINGS.alerts.longRunningThresholdMs,
        15e3,
        30 * 6e4
      )
    },
    monitoring: {
      intervalMs: clampWindowRatio(
        value?.monitoring?.intervalMs,
        DEFAULT_SETTINGS.monitoring.intervalMs,
        100,
        1e4
      )
    },
    launcher: {
      ...DEFAULT_SETTINGS.launcher,
      // Schema < 3 stored absolute viewport pixels. They are resolution-specific,
      // so migration intentionally discards them instead of pretending they are portable.
      x: null,
      y: null,
      side: incomingSchema >= 3 && value?.launcher?.side === "left" ? "left" : DEFAULT_SETTINGS.launcher.side,
      heightRatio: incomingSchema >= 3 ? clampRatio(value?.launcher?.heightRatio) : DEFAULT_SETTINGS.launcher.heightRatio
    },
    observer: {
      ...DEFAULT_SETTINGS.observer,
      ...value?.observer,
      enabled: incomingSchema >= 5 ? value?.observer?.enabled ?? DEFAULT_SETTINGS.observer.enabled : value && (value.observer?.captureBodies === true || value.telemetry?.enabled === true) ? value.observer?.enabled ?? true : false
    },
    telemetry: {
      ...DEFAULT_SETTINGS.telemetry,
      ...value?.telemetry,
      endpoint: incomingSchema < 2 ? DEFAULT_SETTINGS.telemetry.endpoint : value?.telemetry?.endpoint ?? DEFAULT_SETTINGS.telemetry.endpoint
    },
    archive: {
      defaultRule: normalizeCaptureRule(value?.archive?.defaultRule),
      projects: mergeCaptureRules({}, value?.archive?.projects),
      conversations: mergeCaptureRules({}, value?.archive?.conversations)
    },
    export: normalizeExportOptions(value?.export),
    exportOverrides: normalizeExportOverrides(value?.exportOverrides),
    ui: {
      ...DEFAULT_SETTINGS.ui,
      ...value?.ui,
      archiveStart: value?.ui?.archiveStart === "first" ? "first" : "latest",
      archiveWindow: {
        ...DEFAULT_SETTINGS.ui.archiveWindow,
        ...value?.ui?.archiveWindow,
        xRatio: clampWindowRatio(
          value?.ui?.archiveWindow?.xRatio,
          DEFAULT_SETTINGS.ui.archiveWindow.xRatio,
          0,
          0.95
        ),
        yRatio: clampWindowRatio(
          value?.ui?.archiveWindow?.yRatio,
          DEFAULT_SETTINGS.ui.archiveWindow.yRatio,
          0,
          0.95
        ),
        widthRatio: clampWindowRatio(
          value?.ui?.archiveWindow?.widthRatio,
          DEFAULT_SETTINGS.ui.archiveWindow.widthRatio,
          0.32,
          0.96
        ),
        heightRatio: clampWindowRatio(
          value?.ui?.archiveWindow?.heightRatio,
          DEFAULT_SETTINGS.ui.archiveWindow.heightRatio,
          0.4,
          0.96
        ),
        minimizedSide: value?.ui?.archiveWindow?.minimizedSide === "left" ? "left" : "right",
        minimizedHeightRatio: clampRatio(value?.ui?.archiveWindow?.minimizedHeightRatio)
      }
    }
  };
}
function mergeExportOverrides(current, patch) {
  if (!patch) return current;
  const merge = (previous, incoming) => {
    const result = { ...previous };
    for (const [key, update] of Object.entries(incoming ?? {})) {
      if (update === null) delete result[key];
      else result[key] = { ...previous[key], ...update };
    }
    return result;
  };
  return normalizeExportOverrides({
    projects: merge(current.projects, patch.projects),
    conversations: merge(current.conversations, patch.conversations)
  });
}
function mergeSettings(current, patch) {
  const normalized = normalizeSettings(current);
  return normalizeSettings({
    ...normalized,
    ...patch,
    features: {
      ...normalized.features,
      ...patch.features
    },
    historyLoader: {
      ...normalized.historyLoader,
      ...patch.historyLoader
    },
    alerts: {
      ...normalized.alerts,
      ...patch.alerts
    },
    monitoring: {
      ...normalized.monitoring,
      ...patch.monitoring
    },
    launcher: {
      ...normalized.launcher,
      ...patch.launcher
    },
    observer: {
      ...normalized.observer,
      ...patch.observer
    },
    telemetry: {
      ...normalized.telemetry,
      ...patch.telemetry
    },
    archive: {
      defaultRule: { ...normalized.archive.defaultRule, ...patch.archive?.defaultRule },
      projects: mergeCaptureRules(normalized.archive.projects, patch.archive?.projects),
      conversations: mergeCaptureRules(
        normalized.archive.conversations,
        patch.archive?.conversations
      )
    },
    export: { ...normalized.export, ...patch.export },
    exportOverrides: mergeExportOverrides(normalized.exportOverrides, patch.exportOverrides),
    ui: {
      ...normalized.ui,
      ...patch.ui,
      archiveWindow: {
        ...normalized.ui.archiveWindow,
        ...patch.ui?.archiveWindow
      }
    }
  });
}
instanceKey("chatgpt-booster:open-settings", "chatgpt-booster:prod");
function mergeCaptureRules(current, patch) {
  const entries = new Map(Object.entries(current));
  for (const [id, rule] of Object.entries(patch ?? {})) {
    if (rule === null) entries.delete(id);
    else if (rule && typeof rule === "object") entries.set(id, normalizeCaptureRule(rule));
  }
  return Object.fromEntries(entries);
}
const TOKEN_KEY = "telemetryToken";
const SETTINGS_KEY = "settings";
const ANALYTICS_KEY = "analyticsTransportLifetime";
let settingsWriteQueue = Promise.resolve();
let analyticsWriteQueue = Promise.resolve();
let analyticsCounters;
let analyticsDirty = false;
let analyticsFlushTimer;
const ANALYTICS_FLUSH_INTERVAL_MS = 500;
function enqueueSettingsWrite(work) {
  const result = settingsWriteQueue.then(work, work);
  settingsWriteQueue = result.then(
    () => void 0,
    () => void 0
  );
  return result;
}
function enqueueAnalyticsWrite(work) {
  const result = analyticsWriteQueue.then(work, work);
  analyticsWriteQueue = result.then(
    () => void 0,
    () => void 0
  );
  return result;
}
async function replaceSettings(settings) {
  return await enqueueSettingsWrite(async () => {
    const normalized = normalizeSettings(settings);
    await chrome.storage.local.set({ [SETTINGS_KEY]: normalized });
    return normalized;
  });
}
async function updateSettings(patch) {
  return await enqueueSettingsWrite(async () => {
    const stored = await chrome.storage.local.get(SETTINGS_KEY);
    const next = mergeSettings(stored[SETTINGS_KEY], patch);
    await chrome.storage.local.set({ [SETTINGS_KEY]: next });
    return next;
  });
}
async function readAnalytics() {
  if (analyticsCounters) return { ...analyticsCounters };
  const stored = await chrome.storage.local.get(ANALYTICS_KEY);
  analyticsCounters = {
    ...EMPTY_TRANSPORT_COUNTERS,
    ...stored[ANALYTICS_KEY]
  };
  return { ...analyticsCounters };
}
async function flushAnalytics() {
  if (analyticsFlushTimer) {
    clearTimeout(analyticsFlushTimer);
    analyticsFlushTimer = void 0;
  }
  if (!analyticsDirty || !analyticsCounters) return;
  analyticsDirty = false;
  await chrome.storage.local.set({ [ANALYTICS_KEY]: { ...analyticsCounters } });
}
function scheduleAnalyticsFlush() {
  if (analyticsFlushTimer) return;
  analyticsFlushTimer = setTimeout(() => {
    analyticsFlushTimer = void 0;
    void enqueueAnalyticsWrite(flushAnalytics).catch((error) => {
      analyticsDirty = true;
      console.warn("[ChatGPT Booster] Analytics persistence failed", error);
      scheduleAnalyticsFlush();
    });
  }, ANALYTICS_FLUSH_INTERVAL_MS);
}
async function recordAnalyticsBatch(events) {
  return await enqueueAnalyticsWrite(async () => {
    let next = await readAnalytics();
    for (const event of events) next = applyTransportCounterEvent(next, event);
    analyticsCounters = next;
    if (events.length) {
      analyticsDirty = true;
      scheduleAnalyticsFlush();
    }
    return { ...next };
  });
}
async function recordAnalytics(event) {
  return await recordAnalyticsBatch([event]);
}
async function postTelemetry(message) {
  const settings = normalizeSettings(
    (await chrome.storage.local.get(SETTINGS_KEY))[SETTINGS_KEY]
  );
  const configuredEndpoint = settings.telemetry.endpoint.trim();
  if (!configuredEndpoint) throw new Error("Telemetry endpoint is not configured");
  const parsed = new URL(message.url);
  const configured = new URL(configuredEndpoint);
  if (parsed.protocol !== "https:" || parsed.origin !== configured.origin) {
    throw new Error("Telemetry origin does not match the configured endpoint");
  }
  const stored = await chrome.storage.local.get(TOKEN_KEY);
  const token = typeof stored[TOKEN_KEY] === "string" ? stored[TOKEN_KEY] : "";
  if (!token) throw new Error("Telemetry token is not configured");
  const response = await fetch(message.url, {
    method: "POST",
    headers: {
      "content-type": "application/json",
      authorization: `Bearer ${token}`
    },
    body: message.body
  });
  if (!response.ok) throw new Error(`Telemetry HTTP ${response.status}`);
  return { ok: true, status: response.status };
}
chrome.runtime.onMessage.addListener(
  (message, _sender, sendResponse) => {
    if (!message?.type?.startsWith("chatgpt-booster:")) return;
    void (async () => {
      try {
        if (message.type === "chatgpt-booster:telemetry-permission-check") {
          const configured = normalizeSettings(
            (await chrome.storage.local.get(SETTINGS_KEY))[SETTINGS_KEY]
          ).telemetry.endpoint.trim();
          const origin = new URL(configured).origin;
          if (new URL(message.origin).origin !== origin || !origin.startsWith("https://"))
            throw new Error("Telemetry permission origin does not match settings");
          sendResponse({ ok: true, granted: await chrome.permissions.contains({ origins: [`${origin}/*`] }) });
          return;
        }
        if (message.type === "chatgpt-booster:settings-set") {
          sendResponse({ ok: true, settings: await replaceSettings(message.settings) });
          return;
        }
        if (message.type === "chatgpt-booster:settings-update") {
          sendResponse({ ok: true, settings: await updateSettings(message.patch) });
          return;
        }
        if (message.type === "chatgpt-booster:analytics-get") {
          sendResponse({ ok: true, counters: await readAnalytics() });
          return;
        }
        if (message.type === "chatgpt-booster:analytics-record") {
          sendResponse({ ok: true, counters: await recordAnalytics(message.event) });
          return;
        }
        if (message.type === "chatgpt-booster:analytics-record-batch") {
          sendResponse({ ok: true, counters: await recordAnalyticsBatch(message.events) });
          return;
        }
        const result = await postTelemetry(message);
        sendResponse(result);
      } catch (error) {
        sendResponse({
          ok: false,
          error: error instanceof Error ? error.message : "Background operation failed"
        });
      }
    })();
    return true;
  }
);
const CHATGPT_MATCH = "https://chatgpt.com/*";
const ownShellRootId = instanceKey("koba-browser-tools-root");
async function bootstrapExistingChatGptTabs() {
  const tabs = await chrome.tabs.query({ url: CHATGPT_MATCH });
  await Promise.all(
    tabs.filter((tab) => typeof tab.id === "number").map(async (tab) => {
      try {
        const [presence] = await chrome.scripting.executeScript({
          target: { tabId: tab.id },
          world: "ISOLATED",
          injectImmediately: true,
          // A separate PROD, DEV or aggregate root is NOT this extension.
          // Pass the build-owned root into the injected context explicitly:
          // executeScript serializes the function without module closures.
          func: (expectedRootId) => Boolean(document.getElementById(expectedRootId)),
          args: [ownShellRootId]
        });
        if (presence?.result === true) return;
        await chrome.scripting.executeScript({
          target: { tabId: tab.id },
          files: ["observer.js"],
          world: "MAIN",
          injectImmediately: true
        });
        await chrome.scripting.executeScript({
          target: { tabId: tab.id },
          files: ["content.js"],
          world: "ISOLATED",
          injectImmediately: true
        });
      } catch {
      }
    })
  );
}
chrome.runtime.onInstalled.addListener(() => {
  void bootstrapExistingChatGptTabs();
});
chrome.runtime.onStartup.addListener(() => {
  void bootstrapExistingChatGptTabs();
});
