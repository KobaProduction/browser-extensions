(function() {
  "use strict";
  const archiveMessages = {
    en: {
      "dock.open": "Open toolkit",
      "dock.close": "Close toolkit",
      "dock.drag": "Drag to either edge",
      "dock.title": "ChatGPT Booster",
      "dock.collect": "Collect conversation",
      "dock.export": "Export saved chat",
      "dock.archive": "Browse archive",
      "dock.settings": "Settings",
      "dock.capture": "Capture rules",
      "dock.noChat": "Open a conversation to collect its history.",
      "dock.messages": "Messages",
      "dock.details": "Service records",
      "dock.olderAvailable": "Earlier history is available",
      "dock.startReached": "Conversation start is loaded",
      "dock.historyUnknown": "Earlier-history state is unknown",
      "dock.records": "Stored records",
      "dock.unverified": "Saved history is not verified",
      "dock.partial": "History is incomplete",
      "dock.verified": "History snapshot verified",
      "dock.none": "Not saved locally",
      "dock.coverageNote": "Verification covers observed history pages, not every branch or attachment file.",
      "dock.collectConfirm": "Collect a fresh history snapshot?",
      "dock.collectNote": "Scrolls upward through the current ChatGPT conversation and saves normal history responses. It does not reload the tab.",
      "dock.proceed": "Collect",
      "dock.stop": "Stop collection",
      "dock.pages": "Saved pages",
      "dock.version": "Build",
      "dock.autoOn": "Automatic capture enabled",
      "dock.autoOff": "Automatic capture disabled",
      "dock.autoChatOn": "Auto-save · chat · on",
      "dock.autoChatOff": "Auto-save · chat · off",
      "dock.autoProjectOn": "Auto-save · project · on",
      "dock.autoProjectOff": "Auto-save · project · off",
      "dock.autoDefaultOn": "Auto-save · default · on",
      "dock.autoDefaultOff": "Auto-save · default · off",
      "dock.autoMasterOff": "Auto-save · Booster disabled",
      "dock.closeShort": "Close",
      "phase.idle": "Idle",
      "phase.preparing": "Preparing",
      "phase.scrolling": "Scrolling upward",
      "phase.waiting_for_load": "Waiting for history",
      "phase.backoff": "Retry delay",
      "phase.complete": "Snapshot saved",
      "phase.cancelled": "Collection stopped",
      "phase.error": "Collection failed",
      "identity.copy": "Copy identifier",
      "identity.copied": "Identifier copied",
      "identity.failed": "Copy failed",
      "identity.unknownProject": "Project name not yet observed",
      "identity.untitled": "Untitled conversation",
      "capture.title": "Selective capture",
      "capture.subtitle": "Choose exactly what Booster should save for this scope.",
      "capture.scope": "Apply to",
      "capture.global": "Default for other chats",
      "capture.project": "Project",
      "capture.conversation": "Conversation",
      "capture.inherit": "Inherit rule",
      "capture.on": "Save automatically",
      "capture.off": "Do not save automatically",
      "capture.policy": "Automatic capture",
      "capture.explanation": "Chat rules override project rules. Manual collection works even when automatic capture is off. Changing a rule never deletes saved data.",
      "capture.reasoning": "Save reasoning records",
      "capture.tools": "Save tool calls and results",
      "capture.internal": "Save other internal records",
      "capture.saved": "Rule saved",
      "capture.apply": "Save rule",
      "capture.scopeHint": "Open a project or chat to configure it here. Existing rules also appear in this selector.",
      "scope.localArchive": "Local archive",
      "scope.archived": "Saved locally",
      "scope.notArchived": "Not saved locally",
      "scope.rule": "Rule source",
      "scope.source.conversation": "Conversation override",
      "scope.source.project": "Project rule",
      "scope.source.default": "Default rule",
      "scope.settings": "Archive settings",
      "tool.provider": "Provider",
      "tool.calledAt": "Called",
      "tool.action": "Action",
      "tool.details": "Details",
      "reader.title": "Local archive",
      "reader.readonly": "Read-only · saved data only",
      "reader.search": "Find a project or conversation",
      "reader.searchMessages": "Find text in this conversation",
      "reader.empty": "No saved conversations. Collection is manual or enabled per scope.",
      "reader.missing": "This conversation has not been saved. Select a saved chat or collect the current chat.",
      "reader.loading": "Reading local archive…",
      "reader.error": "The local archive could not be read.",
      "reader.noProject": "Outside projects",
      "reader.refresh": "Refresh archive",
      "reader.export": "Export",
      "reader.user": "You",
      "reader.answer": "Assistant",
      "reader.reasoning": "Reasoning",
      "reader.tool_call": "Tool call",
      "reader.tool_result": "Tool result",
      "reader.internal": "Internal record",
      "reader.details": "Service records",
      "reader.raw": "Original record / metadata",
      "reader.unassigned": "Records without a confirmed exchange",
      "reader.adjacency": "Some records are grouped by order, not a confirmed parent link.",
      "reader.more": "Show more exchanges",
      "reader.loadingEarlier": "Loading older exchanges…",
      "reader.loadingNewer": "Loading newer exchanges…",
      "reader.returnLatest": "Back to latest",
      "reader.firstKnown": "First known saved",
      "reader.moreNewer": "Next newer",
      "reader.windowSearchOnly": "Search is limited to the messages currently loaded in this window.",
      "reader.windowGraphOnly": "The graph shows only the loaded window, not the complete message history.",
      "reader.newestFirst": "Newest first",
      "reader.chronological": "Oldest first",
      "reader.branchMissing": "Branch source is not stored in this project",
      "reader.noResults": "No matches",
      "reader.noText": "No text in this saved record; see metadata.",
      "reader.branch": "Branched from",
      "reader.close": "Close archive",
      "reader.minimize": "Minimize archive",
      "reader.expandReasoning": "Expand reasoning",
      "reader.collapseReasoning": "Collapse reasoning",
      "reader.expand": "Expand",
      "reader.collapse": "Collapse",
      "reader.show": "Show",
      "reader.hide": "Hide",
      "reader.sentAt": "Sent",
      "reader.editedAt": "Edited",
      "reader.editedShort": "edited",
      "reader.timeUnknown": "Timestamp unavailable",
      "reader.model": "Model",
      "reader.thinking": "Thinking mode",
      "reader.metadataOnly": "Metadata only",
      "reader.openTool": "Open tool source",
      "reader.back": "Conversations",
      "reader.savedToStart": "The selected saved path is verified against native page and parent-link evidence",
      "reader.savedPartial": "The selected saved path has not been fully verified",
      "reader.lastRefreshCheck": "Last update check",
      "reader.updateUnchecked": "Updates have not been checked for this saved copy",
      "reader.currentLatestSaved": "The latest message currently shown in ChatGPT is stored locally",
      "reader.currentNewer": "The current ChatGPT conversation has a newer message than the local copy",
      "export.title": "Export conversation",
      "export.modelEvidenceScope": "Requested model and effort are available only for observed native submissions under the verified account. Recollecting old history cannot reconstruct them.",
      "export.timebaseHint": "Derived timestamps use whole Unix seconds (UTC). Technical copies retain original precision; native fragments are not rewritten.",
      "export.sourceAdapter": "Source adapter",
      "reader.returnExport": "Back to export",
      "reader.cancelNavigation": "Cancel loading",
      "reader.navigationCancelled": "Loading stopped. Select a message or reopen the requested location.",
      "reader.moreOlder": "Previous messages",
      "reader.jumpMessage": "Open message by ID",
      "reader.messageId": "Source message ID",
      "reader.openMessage": "Open message",
      "reader.messageMissing": "This message is not present in the selected saved copy. No different record was substituted.",
      "reader.savedInspection": "Inspecting the saved copy; the current ChatGPT view is not substituted.",
      "reader.targetUnsequenced": "This message has no source timestamp. Only the exact record is shown; chronological neighbors cannot be inferred.",
      "reader.reopenCurrentCopy": "Open in the current saved revision",
      "export.inspectMessage": "Open this message in Archive",
      "export.collectionSaving": "Saving collected pages. Native scrolling has stopped.",
      "export.collectionLoading": "Collecting history in the current ChatGPT tab",
      "export.collectionResumeExplicit": "Resume starts only on your explicit action after rechecking context.",
      "export.collectionStoppedUser": "Collection was stopped manually.",
      "export.collectionStoppedClosed": "Collection stopped when Export was closed.",
      "export.collectionStoppedSuspended": "Collection paused while another surface was open.",
      "export.collectionStoppedHidden": "Collection paused because the tab became hidden.",
      "export.collectionStoppedTakeover": "Collection stopped after you took over the conversation scroll.",
      "export.collectionStoppedNavigation": "Collection stopped because the open conversation changed.",
      "export.collectionStoppedAccount": "Collection permission was revoked on account change.",
      "export.collectionStoppedSelection": "Collection stopped because the selected conversation version changed.",
      "export.collectionStoppedPolicy": "Collection paused because its capture policy changed.",
      "export.collectionStoppedSource": "Collection stopped on an incompatible source signature.",
      "export.collectionStoppedSuperseded": "A new explicit collection replaced the previous run.",
      "export.collectionStoppedExpired": "The collection permission expired.",
      "export.collectionStoppedRuntime": "Collection stopped with the page runtime. Consent is not restored automatically.",
      "phase.saving": "Saving collected pages",
      "archive.error.tabHidden": "Keep the ChatGPT tab visible to start collection.",
      "export.captureExcluded": "Currently excluded by capture settings",
      "export.inspectTitle": "Saved-copy diagnostics",
      "export.inspectRefresh": "Recheck",
      "export.inspectLoading": "Reading saved-copy evidence…",
      "export.inspectFailed": "Could not inspect the saved copy. Retry without clearing stored data.",
      "export.inspectBlocked": "Preparation is blocked by the conditions below",
      "export.inspectPendingPath": "Source is available; the selected chain will be checked at Prepare",
      "export.inspectFinalGate": "This snapshot is not export permission. Prepare rechecks the entire selected chain and source revision.",
      "export.savedRecordCount": "Saved source records",
      "export.gatePages": "Linked source pages",
      "export.gateCapture": "Capture coverage",
      "export.gatePath": "Selected chain",
      "export.gateHead": "Match with the open chat",
      "export.gateVerified": "Verified",
      "export.gatePartial": "Incomplete",
      "export.gateUnknown": "Not established",
      "export.gateOmitted": "Records were excluded",
      "export.gateCheckpoint": "Saved verification exists",
      "export.gateAtPrepare": "Checked at preparation",
      "export.gateMatches": "Matches",
      "export.gateMismatch": "Different selected version",
      "export.collectionOpenChat": "To collect missing history, open this conversation in the native ChatGPT tab first.",
      "export.collectionUnavailable": "History collection is not active in this runtime.",
      "export.captureRepairHint": "Changing export options cannot restore records excluded during capture. Review capture categories, then explicitly collect again.",
      "export.inspectCaptureSettings": "Capture settings",
      "export.inspectNoFiles": "Continue without file bytes",
      "export.inspectUseJson": "Use JSON for technical copy",
      "export.inspectArchive": "Inspect saved history",
      "export.blocker.account": "The active account is not verified. No saved namespace can be selected safely.",
      "export.blocker.signature": "The observed source signature is unsupported. Update the adapter; stored data will not be reset.",
      "export.blocker.storage": "Saved data could not be read. Recheck storage availability; do not reset the archive.",
      "export.blocker.noCopy": "This account has no saved copy of this conversation.",
      "export.blocker.noSelection": "The native selected message ID is missing.",
      "export.blocker.noPages": "No initial read with pagination evidence is saved.",
      "export.blocker.pages": "The initial page and its continuations do not prove the full history. Collect the missing pages.",
      "export.blocker.captureUnknown": "The saved read does not establish whether any records were excluded.",
      "export.blocker.omissions": "Capture excluded source records. Even a messages-only export requires a verifiable parent chain.",
      "export.blocker.head": "The open chat and saved copy select different message versions.",
      "export.blocker.changed": "The saved source changed during inspection or preparation. Read its current state again.",
      "export.blocker.tip": "The selected final message is not present in the saved copy.",
      "export.blocker.parent": "A referenced parent message is missing. Inspect or recollect the saved history.",
      "export.blocker.parentUnknown": "The native source does not prove a parent link or root. Chronological order cannot replace that evidence.",
      "export.blocker.cycle": "The observed parent links contain a cycle. This chain cannot be exported as complete.",
      "export.blocker.limit": "The selected chain exceeds the supported traversal limit. No shortened complete file was produced.",
      "export.blocker.assets": "Binary attachment export is unavailable in v4. Keep attachment metadata or disable file-byte options.",
      "export.blocker.json": "Technical copies preserve source JSON and cannot use Markdown or text.",
      "archive.error.disabled": "Booster is disabled. Enable it in settings before collecting.",
      "export.statusMissing": "No local copy is available yet",
      "export.statusPartial": "Local copy exists, but the saved chain has not reached the beginning",
      "export.statusNewer": "The open ChatGPT conversation has a newer message than the local copy",
      "export.statusCurrent": "The local copy reaches the beginning and includes the current latest message",
      "export.statusSaved": "The saved conversation chain reaches the beginning",
      "export.refreshFirst": "Update before export",
      "export.refreshStarting": "Starting update…",
      "export.format": "Format",
      "export.level": "Contents",
      "export.profileConversation": "Messages only. Markdown and text omit diagnostic metadata.",
      "export.profileCustom": "Include selected reasoning or tool details.",
      "export.profileFull": "Preserve all raw records and diagnostic context. File bytes are optional.",
      "export.conversation": "1 · Readable conversation",
      "export.custom": "2 · Selected details",
      "export.full": "3 · Technical backup",
      "export.reasoning": "Reasoning",
      "export.tools": "Tool calls and results",
      "export.internal": "Other internal records",
      "export.reasoningRecap": "Reasoning recaps",
      "export.reasoningFull": "Full reasoning records where captured",
      "export.toolCalls": "Tool invocations",
      "export.toolResults": "Tool results",
      "export.toolSourceContent": "Native tool content in JSON (may be large)",
      "export.modelEvidence": "Observed models and submitted model/effort changes",
      "export.dictationEditEvidence": "Source-confirmed dictation edits",
      "export.sourceRevisions": "Stored source revision history (not confirmed user edits)",
      "export.attachmentMetadata": "Attachment descriptors only (no file bytes)",
      "export.evidenceWarning": "Unknown model choices, effort settings and user edits are not inferred.",
      "export.images": "Image files",
      "export.files": "Other files",
      "export.metadata": "Attachment metadata is retained. Binary files are not fetched by default.",
      "export.binaryUnavailable": "File packages use only signed asset URLs already observed from the normal ChatGPT client. Missing or expired assets are listed in manifest.json instead of being silently omitted.",
      "export.download": "Export file",
      "export.prepare": "Prepare export",
      "export.readyDownload": "Download prepared file",
      "export.phaseChecking": "Checking source and page coverage",
      "export.phaseTracing": "Reading the selected message chain",
      "export.phaseSerializing": "Processing source records",
      "export.phasePackaging": "Packaging ZIP contents",
      "export.phaseVerifying": "Checking source revision before download",
      "export.phaseReady": "File prepared",
      "export.progressRecords": "source records",
      "export.progressBytes": "bytes",
      "export.progressStage": "stage",
      "export.cancelled": "Preparation cancelled. Settings retained; start again explicitly.",
      "export.preparedSize": "Prepared file size",
      "export.working": "Preparing export…",
      "export.saved": "Export created",
      "export.savedPartial": "Export created, but completeness evidence is partial. Check coverage and manifest.json for omissions.",
      "export.remember": "Format and contents selection are remembered.",
      "export.failed": "Export failed",
      "archive.error.incompatibleSource": "ChatGPT history format is not supported by this Booster build. Archive capture and export are disabled for this conversation. Saved data is unchanged.",
      "reader.staleWindow": "Saved history changed in another tab. Refresh to load a consistent window.",
      "archive.error.sourceChanged": "Conversation changed during export. Reload the saved version and prepare again.",
      "archive.error.unverifiedPath": "This version has incomplete or unverified ancestry and cannot be exported as a complete conversation.",
      "archive.error.technicalRequiresJson": "A technical source copy requires JSON output.",
      "archive.error.assetsUnverified": "Binary attachments are not supported in the new archive export.",
      "archive.error.noChat": "No conversation is available.",
      "archive.error.draft": "Save or clear the draft and its attachments before collecting.",
      "archive.error.attachments": "Remove or send pending attachments before collecting.",
      "archive.error.generating": "Wait for the current reply to finish before collecting.",
      "archive.error.timeout": "Collection time limit reached.",
      "archive.error.noProgress": "No new history pages were observed. The archive is not marked complete.",
      "archive.error.network": "This conversation’s history requests failed repeatedly.",
      "archive.error.storage": "The local database could not save this conversation.",
      "archive.error.auth": "The ChatGPT account could not be verified for this archive read or changed during it. Retry after the account finishes loading.",
      "archive.error.unknown": "The operation failed. Existing archive data is preserved.",
      "common.cancel": "Cancel",
      "common.saveError": "Settings could not be saved."
    },
    ru: {
      "dock.open": "Открыть инструменты",
      "dock.close": "Закрыть инструменты",
      "dock.drag": "Перетащите к левому или правому краю",
      "dock.title": "ChatGPT Booster",
      "dock.collect": "Собрать диалог",
      "dock.export": "Экспорт сохранённого чата",
      "dock.archive": "Открыть архив",
      "dock.settings": "Настройки",
      "dock.capture": "Правила сохранения",
      "dock.noChat": "Откройте диалог для сбора его истории.",
      "dock.messages": "Сообщения",
      "dock.details": "Служебные записи",
      "dock.olderAvailable": "Есть более ранняя история",
      "dock.startReached": "Начало диалога загружено",
      "dock.historyUnknown": "Неизвестно, есть ли более ранняя история",
      "dock.records": "Сохранённые записи",
      "dock.unverified": "Полнота сохранённой истории не проверена",
      "dock.partial": "История сохранена частично",
      "dock.verified": "Снимок истории проверен",
      "dock.none": "Нет локальной копии",
      "dock.coverageNote": "Проверка относится к наблюдённым страницам истории, а не ко всем веткам и файлам вложений.",
      "dock.collectConfirm": "Собрать свежий снимок истории?",
      "dock.collectNote": "Прокручивает текущий диалог ChatGPT вверх и сохраняет штатные ответы истории. Вкладка не перезагружается.",
      "dock.proceed": "Собрать",
      "dock.stop": "Остановить сбор",
      "dock.pages": "Сохранено страниц",
      "dock.version": "Сборка",
      "dock.autoOn": "Автосохранение включено",
      "dock.autoOff": "Автосохранение выключено",
      "dock.autoChatOn": "Автосохранение · чат · включено",
      "dock.autoChatOff": "Автосохранение · чат · выключено",
      "dock.autoProjectOn": "Автосохранение · проект · включено",
      "dock.autoProjectOff": "Автосохранение · проект · выключено",
      "dock.autoDefaultOn": "Автосохранение · по умолчанию · включено",
      "dock.autoDefaultOff": "Автосохранение · по умолчанию · выключено",
      "dock.autoMasterOff": "Автосохранение · Booster выключен",
      "dock.closeShort": "Закрыть",
      "phase.idle": "Ожидание",
      "phase.preparing": "Подготовка",
      "phase.scrolling": "Прокрутка вверх",
      "phase.waiting_for_load": "Ожидание истории",
      "phase.backoff": "Пауза перед повтором",
      "phase.complete": "Снимок сохранён",
      "phase.cancelled": "Сбор остановлен",
      "phase.error": "Ошибка сбора",
      "identity.copy": "Скопировать идентификатор",
      "identity.copied": "Идентификатор скопирован",
      "identity.failed": "Не удалось скопировать",
      "identity.unknownProject": "Название проекта ещё не получено",
      "identity.untitled": "Диалог без названия",
      "capture.title": "Выборочное сохранение",
      "capture.subtitle": "Настройте, что именно Booster должен сохранять для этой области.",
      "capture.scope": "Область действия",
      "capture.global": "По умолчанию для остальных чатов",
      "capture.project": "Проект",
      "capture.conversation": "Диалог",
      "capture.inherit": "Наследовать правило",
      "capture.on": "Сохранять автоматически",
      "capture.off": "Не сохранять автоматически",
      "capture.policy": "Автосохранение",
      "capture.explanation": "Правило чата важнее правила проекта. Ручной сбор работает и при выключенном автосохранении. Смена правила не удаляет ранее сохранённые данные.",
      "capture.reasoning": "Сохранять размышления",
      "capture.tools": "Сохранять вызовы и результаты инструментов",
      "capture.internal": "Сохранять остальные внутренние записи",
      "capture.saved": "Правило сохранено",
      "capture.apply": "Сохранить правило",
      "capture.scopeHint": "Откройте нужный проект или чат, чтобы настроить его здесь. Уже заданные правила также доступны в списке.",
      "scope.localArchive": "Локальный архив",
      "scope.archived": "Сохранено локально",
      "scope.notArchived": "Локальной копии нет",
      "scope.rule": "Источник правила",
      "scope.source.conversation": "Правило диалога",
      "scope.source.project": "Правило проекта",
      "scope.source.default": "Правило по умолчанию",
      "scope.settings": "Настройки архива",
      "tool.provider": "Провайдер",
      "tool.calledAt": "Вызвано",
      "tool.action": "Действие",
      "tool.details": "Подробнее",
      "reader.title": "Локальный архив",
      "reader.readonly": "Только чтение · только сохранённые данные",
      "reader.search": "Найти проект или диалог",
      "reader.searchMessages": "Найти текст в этом диалоге",
      "reader.empty": "Сохранённых диалогов пока нет. Сбор запускается вручную или включается для выбранной области.",
      "reader.missing": "Этот диалог ещё не сохранён. Выберите чат из архива или соберите текущий диалог.",
      "reader.loading": "Чтение локального архива…",
      "reader.error": "Не удалось прочитать локальный архив.",
      "reader.noProject": "Вне проектов",
      "reader.refresh": "Обновить архив",
      "reader.export": "Экспорт",
      "reader.user": "Вы",
      "reader.answer": "Ассистент",
      "reader.reasoning": "Размышления",
      "reader.tool_call": "Вызов инструмента",
      "reader.tool_result": "Результат инструмента",
      "reader.internal": "Внутренняя запись",
      "reader.details": "Служебные записи",
      "reader.raw": "Исходная запись / метаданные",
      "reader.unassigned": "Записи без подтверждённой связи с обменом репликами",
      "reader.adjacency": "Часть записей сгруппирована по порядку, без подтверждённой родительской связи.",
      "reader.more": "Показать следующие обмены",
      "reader.loadingEarlier": "Подгружаем предыдущие сообщения…",
      "reader.loadingNewer": "Подгружаем следующие сообщения…",
      "reader.returnLatest": "К последним",
      "reader.firstKnown": "К первым сохранённым",
      "reader.moreNewer": "Следующие сообщения",
      "reader.windowSearchOnly": "Поиск выполняется только по сообщениям загруженного окна.",
      "reader.windowGraphOnly": "Граф показывает только загруженное окно, не всю историю сообщений.",
      "reader.newestFirst": "Новые сверху",
      "reader.chronological": "Старые сверху",
      "reader.branchMissing": "Исходный диалог ветки не сохранён в этом проекте",
      "reader.noResults": "Совпадений нет",
      "reader.noText": "В сохранённой записи нет текста; доступны метаданные.",
      "reader.branch": "Ветка от диалога",
      "reader.close": "Закрыть архив",
      "reader.minimize": "Свернуть архив",
      "reader.expandReasoning": "Развернуть размышления",
      "reader.collapseReasoning": "Свернуть размышления",
      "reader.expand": "Развернуть",
      "reader.collapse": "Свернуть",
      "reader.show": "Показать",
      "reader.hide": "Скрыть",
      "reader.sentAt": "Отправлено",
      "reader.editedAt": "Редактировано",
      "reader.editedShort": "изменено",
      "reader.timeUnknown": "Время недоступно",
      "reader.model": "Модель",
      "reader.thinking": "Режим мышления",
      "reader.metadataOnly": "Только метаданные",
      "reader.openTool": "Открыть источник инструмента",
      "reader.back": "Диалоги",
      "reader.savedToStart": "Выбранная сохранённая цепочка подтверждена страницами источника и связями сообщений",
      "reader.savedPartial": "Выбранная сохранённая цепочка пока не подтверждена полностью",
      "reader.lastRefreshCheck": "Последняя проверка обновления",
      "reader.updateUnchecked": "Обновления этой сохранённой копии ещё не проверялись",
      "reader.currentLatestSaved": "Последнее сообщение, показанное сейчас в ChatGPT, есть в локальной копии",
      "reader.currentNewer": "В текущем ChatGPT есть сообщение новее локальной копии",
      "export.title": "Экспорт диалога",
      "export.modelEvidenceScope": "Запрошенные модель и effort доступны только для наблюдавшихся отправок под подтверждённым аккаунтом. Повторное чтение старой истории не восстанавливает эти сведения.",
      "export.timebaseHint": "Вычисляемые временные поля — целые Unix-секунды UTC. Техническая копия сохраняет исходную точность; нативные фрагменты не переписываются.",
      "export.sourceAdapter": "Адаптер источника",
      "reader.returnExport": "Вернуться к экспорту",
      "reader.cancelNavigation": "Остановить загрузку",
      "reader.navigationCancelled": "Загрузка остановлена. Выберите сообщение или снова откройте нужную запись.",
      "reader.moreOlder": "Предыдущие сообщения",
      "reader.jumpMessage": "Перейти к сообщению по ID",
      "reader.messageId": "ID исходного сообщения",
      "reader.openMessage": "Открыть сообщение",
      "reader.messageMissing": "Этого сообщения нет в выбранной сохранённой копии. Другая запись вместо него не открывалась.",
      "reader.savedInspection": "Просмотр сохранённой копии; содержимое текущей вкладки ChatGPT не подставляется.",
      "reader.targetUnsequenced": "У сообщения нет исходного времени. Показана только точная запись; соседние по времени сообщения не додумываются.",
      "reader.reopenCurrentCopy": "Открыть в актуальной сохранённой ревизии",
      "export.inspectMessage": "Открыть это сообщение в архиве",
      "export.collectionSaving": "Сохраняем собранные страницы. Прокрутка уже остановлена.",
      "export.collectionLoading": "Собираем историю в текущей вкладке ChatGPT",
      "export.collectionResumeExplicit": "Возобновление — только вручную после повторной проверки контекста.",
      "export.collectionStoppedUser": "Сбор остановлен вручную.",
      "export.collectionStoppedClosed": "Сбор остановлен при закрытии экспорта.",
      "export.collectionStoppedSuspended": "Сбор приостановлен при переходе в другую панель.",
      "export.collectionStoppedHidden": "Сбор приостановлен: вкладка скрыта.",
      "export.collectionStoppedTakeover": "Сбор остановлен после вашего вмешательства в прокрутку чата.",
      "export.collectionStoppedNavigation": "Сбор остановлен из-за перехода в другой диалог.",
      "export.collectionStoppedAccount": "Разрешение на сбор отозвано при смене аккаунта.",
      "export.collectionStoppedSelection": "Сбор остановлен: выбранная версия диалога изменилась.",
      "export.collectionStoppedPolicy": "Сбор приостановлен из-за изменения правил захвата.",
      "export.collectionStoppedSource": "Сбор остановлен из-за несовместимой сигнатуры источника.",
      "export.collectionStoppedSuperseded": "Новый явный запуск заменил предыдущий сбор.",
      "export.collectionStoppedExpired": "Срок разрешения на сбор истёк.",
      "export.collectionStoppedRuntime": "Сбор остановлен вместе с окружением страницы. Разрешение автоматически не восстанавливается.",
      "phase.saving": "Сохранение собранных страниц",
      "archive.error.tabHidden": "Для запуска сбора вкладка ChatGPT должна быть видимой.",
      "export.captureExcluded": "Сейчас исключены настройками захвата",
      "export.inspectTitle": "Состояние сохранённой копии",
      "export.inspectRefresh": "Проверить снова",
      "export.inspectLoading": "Читаем данные сохранённой копии…",
      "export.inspectFailed": "Не удалось прочитать состояние архива. Повторите без удаления сохранённых данных.",
      "export.inspectBlocked": "Подготовке мешают причины ниже",
      "export.inspectPendingPath": "Источник доступен; выбранная цепочка будет проверена при подготовке",
      "export.inspectFinalGate": "Эта сводка не разрешает экспорт автоматически. Подготовка заново проверит всю выбранную цепочку и ревизию источника.",
      "export.savedRecordCount": "Сохранённых исходных записей",
      "export.gatePages": "Связность страниц источника",
      "export.gateCapture": "Полнота захвата",
      "export.gatePath": "Выбранная цепочка",
      "export.gateHead": "Совпадение с открытым чатом",
      "export.gateVerified": "Подтверждено",
      "export.gatePartial": "Неполно",
      "export.gateUnknown": "Не установлено",
      "export.gateOmitted": "Есть исключённые записи",
      "export.gateCheckpoint": "Есть сохранённое подтверждение",
      "export.gateAtPrepare": "Проверяется при подготовке",
      "export.gateMatches": "Совпадает",
      "export.gateMismatch": "Выбрана другая версия",
      "export.collectionOpenChat": "Для сбора недостающей истории сначала откройте этот диалог в самой вкладке ChatGPT.",
      "export.collectionUnavailable": "Сбор истории в этом окружении не запущен.",
      "export.captureRepairHint": "Параметры экспорта не восстановят записи, исключённые при захвате. Проверьте категории захвата, затем запустите сбор вручную.",
      "export.inspectCaptureSettings": "Настройки захвата",
      "export.inspectNoFiles": "Убрать содержимое файлов",
      "export.inspectUseJson": "Выбрать JSON для технической копии",
      "export.inspectArchive": "Открыть сохранённую историю",
      "export.blocker.account": "Аккаунт не подтверждён. Безопасно выбрать его сохранённые данные нельзя.",
      "export.blocker.signature": "Сигнатура источника не поддерживается. Требуется обновление адаптера; сохранённые данные не сбрасываются.",
      "export.blocker.storage": "Сохранённые данные не удалось прочитать. Проверьте доступность хранилища, не сбрасывая архив.",
      "export.blocker.noCopy": "У этого аккаунта нет сохранённой копии данного диалога.",
      "export.blocker.noSelection": "Неизвестен идентификатор выбранного сообщения источника.",
      "export.blocker.noPages": "Нет сохранённого начального чтения с доказательством пагинации.",
      "export.blocker.pages": "Начальная страница и продолжения не подтверждают всю историю. Соберите недостающие страницы.",
      "export.blocker.captureUnknown": "По сохранённому чтению неизвестно, были ли исключены записи.",
      "export.blocker.omissions": "При захвате исключены записи. Даже экспорт основных сообщений требует подтверждаемой цепочки родителей.",
      "export.blocker.head": "Открытый чат и сохранённая копия указывают на разные версии сообщений.",
      "export.blocker.changed": "Сохранённый источник изменился во время чтения или подготовки. Получите актуальное состояние снова.",
      "export.blocker.tip": "Выбранного конечного сообщения нет в сохранённой копии.",
      "export.blocker.parent": "Отсутствует сообщение, указанное как родитель. Проверьте или повторно соберите историю.",
      "export.blocker.parentUnknown": "Источник не подтверждает родителя или корень. Порядок по времени не заменяет это доказательство.",
      "export.blocker.cycle": "В наблюдаемых родительских связях обнаружен цикл. Эту цепочку нельзя экспортировать как полную.",
      "export.blocker.limit": "Выбранная цепочка превышает поддерживаемый предел обхода. Усечённый файл не выдан за полный.",
      "export.blocker.assets": "Выгрузка бинарных вложений в v4 недоступна. Оставьте метаданные или отключите содержимое файлов.",
      "export.blocker.json": "Техническая копия сохраняет исходный JSON и не поддерживает Markdown или текст.",
      "archive.error.disabled": "Booster отключён. Включите его в настройках перед сбором.",
      "export.statusMissing": "Локальной копии пока нет",
      "export.statusPartial": "Локальная копия есть, но сохранённая цепочка ещё не дошла до начала",
      "export.statusNewer": "В открытом ChatGPT есть сообщение новее локальной копии",
      "export.statusCurrent": "Локальная копия дошла до начала и содержит текущее последнее сообщение",
      "export.statusSaved": "Сохранённая цепочка диалога дошла до начала",
      "export.refreshFirst": "Обновить перед экспортом",
      "export.refreshStarting": "Запуск обновления…",
      "export.format": "Формат",
      "export.level": "Содержимое",
      "export.profileConversation": "Только реплики. Markdown и текст — без служебного мусора.",
      "export.profileCustom": "Дополнительные размышления и инструменты по выбору.",
      "export.profileFull": "Все исходные записи и диагностика. Файлы добавляются отдельно.",
      "export.conversation": "1 · Чистый диалог",
      "export.custom": "2 · Настроить служебные записи",
      "export.full": "3 · Техническая копия",
      "export.reasoning": "Размышления",
      "export.tools": "Вызовы и результаты инструментов",
      "export.internal": "Остальные внутренние записи",
      "export.reasoningRecap": "Сводки размышлений",
      "export.reasoningFull": "Полные записи размышлений, если сохранены",
      "export.toolCalls": "Вызовы инструментов",
      "export.toolResults": "Результаты инструментов",
      "export.toolSourceContent": "Исходное содержимое инструментов в JSON (может быть большим)",
      "export.modelEvidence": "Наблюдаемые модели и изменения отправленных model/effort",
      "export.dictationEditEvidence": "Подтверждённые источником правки диктовки",
      "export.sourceRevisions": "История исходных версий (не обязательно правки пользователя)",
      "export.attachmentMetadata": "Метаданные вложений без содержимого файлов",
      "export.evidenceWarning": "Неизвестный выбор модели, настройки мышления и правки пользователя не додумываются.",
      "export.images": "Файлы изображений",
      "export.files": "Другие файлы",
      "export.metadata": "Метаданные вложений сохраняются. Байты файлов по умолчанию не загружаются.",
      "export.binaryUnavailable": "Файлы добавляются только по подписанным URL, которые уже получил штатный клиент ChatGPT. Недоступные или просроченные вложения явно перечисляются в manifest.json.",
      "export.download": "Экспортировать файл",
      "export.prepare": "Подготовить экспорт",
      "export.readyDownload": "Скачать подготовленный файл",
      "export.phaseChecking": "Проверяем источник и непрерывность страниц",
      "export.phaseTracing": "Читаем выбранную цепочку сообщений",
      "export.phaseSerializing": "Обрабатываем исходные записи",
      "export.phasePackaging": "Упаковываем содержимое ZIP",
      "export.phaseVerifying": "Проверяем ревизию источника перед скачиванием",
      "export.phaseReady": "Файл подготовлен",
      "export.progressRecords": "исходных записей",
      "export.progressBytes": "байт",
      "export.progressStage": "этап",
      "export.cancelled": "Подготовка отменена. Настройки сохранены; повторный запуск — вручную.",
      "export.preparedSize": "Размер подготовленного файла",
      "export.working": "Подготовка экспорта…",
      "export.saved": "Экспорт создан",
      "export.savedPartial": "Архив создан; в manifest.json перечислены недоступные или непроверенные файлы.",
      "export.remember": "Формат и состав экспорта запоминаются.",
      "export.failed": "Не удалось выполнить экспорт",
      "archive.error.incompatibleSource": "Формат истории ChatGPT несовместим с этой версией Booster. Сохранение и экспорт этого диалога остановлены. Данные архива не изменены.",
      "reader.staleWindow": "Сохранённая история изменилась в другой вкладке. Обновите архив, чтобы загрузить согласованное окно.",
      "archive.error.sourceChanged": "Диалог изменился во время экспорта. Повторно откройте сохранённую версию.",
      "archive.error.unverifiedPath": "Невозможно подтвердить всю цепочку выбранной версии. Полный экспорт заблокирован.",
      "archive.error.technicalRequiresJson": "Для технической копии необходим JSON.",
      "archive.error.assetsUnverified": "Бинарные вложения пока не поддерживаются новым архивом.",
      "archive.error.noChat": "Диалог недоступен.",
      "archive.error.draft": "Сохраните или очистите черновик и его вложения перед сбором.",
      "archive.error.attachments": "Отправьте или удалите ожидающие вложения перед сбором.",
      "archive.error.generating": "Дождитесь завершения текущего ответа перед сбором.",
      "archive.error.timeout": "Достигнут лимит времени сбора.",
      "archive.error.noProgress": "Новые страницы истории не поступили. Архив не отмечен как полный.",
      "archive.error.network": "Повторные ошибки загрузки истории этого диалога.",
      "archive.error.storage": "Не удалось сохранить диалог в локальную базу.",
      "archive.error.auth": "Не удалось подтвердить аккаунт для чтения архива или аккаунт изменился во время операции. Повторите после загрузки ChatGPT.",
      "archive.error.unknown": "Операция не выполнена. Существующий архив сохранён.",
      "common.cancel": "Отмена",
      "common.saveError": "Не удалось сохранить настройки."
    }
  };
  const messages = {
    en: {
      ...archiveMessages.en,
      "common.on": "On",
      "common.off": "Off",
      "common.close": "Close",
      "common.auto": "Auto",
      "language.english": "English",
      "language.russian": "Русский",
      "control.title": "ChatGPT Booster",
      "control.subtitle": "Control Center",
      "control.loading": "Loading settings…",
      "control.booster": "Booster",
      "control.boosterDescription": "Master switch for page enhancements. Settings access always remains available.",
      "control.language": "Language",
      "control.languageDescription": "Automatically follows the browser language unless overridden.",
      "control.modules": "Modules",
      "control.analytics": "Analytics",
      "control.other": "Other",
      "control.currentTab": "Current tab",
      "control.allTime": "All time",
      "control.messageMetadata": "Message metadata",
      "control.messageMetadataDescription": "Adds one compact timestamp/details control to ChatGPT message action rows.",
      "control.activityIndicator": "Live activity indicator",
      "control.activityIndicatorDescription": "Shows the temporary thinking/tool/responding indicator while an answer is active.",
      "control.toolInspector": "Tool Inspector",
      "control.toolInspectorDescription": "Adds an Inspect control beside detected MCP/tool activity and exposes client-visible payloads, timestamps and DOM diagnostics.",
      "control.historyScroll": "History scroll",
      "control.historyScrollDescription": "Controls the continuous scroll bursts used by History Loader.",
      "control.historyScrollSpeed": "Speed",
      "control.historyScrollPause": "Pause between bursts",
      "control.requestTimer": "Request timer",
      "control.requestTimerDescription": "Shows request and reasoning elapsed time above the ChatGPT disclaimer.",
      "control.responseCompleteSound": "Completion sound",
      "control.responseCompleteSoundDescription": "Play a short sound when the current response finishes.",
      "control.longRunningSound": "Long-running alert",
      "control.longRunningSoundDescription": "Play a different sound when one request exceeds the configured threshold.",
      "control.longRunningThreshold": "Alert threshold",
      "control.monitoringInterval": "UI refresh interval",
      "control.monitoringIntervalDescription": "One shared ticker refreshes live durations and alert checks at this interval.",
      "control.observer": "Transport Observer",
      "control.observerDescription": "Passively observes fetch, XHR, WebSocket and EventSource activity without blocking requests.",
      "control.captureBodies": "Capture body previews",
      "control.captureBodiesDescription": "Diagnostic mode. Captures redacted and truncated request/message previews.",
      "control.telemetry": "Telemetry",
      "control.telemetryDescription": "Exports sanitized Booster diagnostics over OTLP/HTTP.",
      "control.telemetryEndpoint": "OTLP endpoint",
      "control.telemetryToken": "Bearer token",
      "control.tokenConfigured": "Token configured",
      "control.tokenMissing": "Token not configured",
      "control.saveToken": "Save token",
      "control.changeToken": "Change",
      "control.cancel": "Cancel",
      "control.testTelemetry": "Test telemetry",
      "control.testingTelemetry": "Testing…",
      "control.telemetryTestSuccess": "Telemetry test succeeded",
      "control.telemetryTestFailed": "Telemetry test failed",
      "control.telemetryEndpointPlaceholder": "https://collector.example.com",
      "control.transportCounters": "Transport counters",
      "control.requestsSent": "Requests sent",
      "control.responsesReceived": "Responses received",
      "control.messagesSent": "Messages sent",
      "control.messagesReceived": "Messages received",
      "control.errors": "Errors",
      "control.analyticsOverview": "Transport activity",
      "control.analyticsDescription": "Live activity observed by Booster in this tab, with lifetime totals for context.",
      "control.requestTraffic": "HTTP activity",
      "control.messageTraffic": "Stream messages",
      "control.outbound": "Outbound",
      "control.inbound": "Inbound",
      "control.lastActivity": "Last activity",
      "control.noActivity": "No activity yet",
      "control.resetCurrent": "Reset tab counters",
      "control.saving": "Saving…",
      "control.saved": "Saved",
      "control.live": "Settings apply live",
      "quick.title": "Current chat",
      "quick.settings": "Settings",
      "quick.currentConversation": "Current conversation",
      "quick.project": "Project",
      "quick.messages": "Messages",
      "quick.branch": "Branch",
      "quick.noConversation": "No conversation",
      "quick.noConversationDescription": "Open a ChatGPT conversation to use archive actions.",
      "quick.notArchived": "Not archived yet",
      "quick.partial": "Archive is partial",
      "quick.complete": "Archive is complete",
      "quick.readToTop": "Read older history",
      "quick.reread": "Re-read from top",
      "quick.openArchive": "Open archive",
      "quick.loadingHistory": "Reading history…",
      "quick.pages": "pages",
      "quick.stop": "Stop",
      "quick.loaderError": "History loader failed",
      "archive.title": "Local archive",
      "archive.subtitle": "Read-only · IndexedDB",
      "archive.refresh": "Refresh",
      "archive.close": "Close",
      "archive.back": "Back",
      "archive.empty": "The archive is empty. Open a chat so Booster can observe its history.",
      "archive.noProject": "No project",
      "archive.project": "Project",
      "archive.untitled": "Untitled",
      "archive.showRaw": "Show raw / metadata",
      "archive.hideRaw": "Hide raw",
      "archive.selectConversation": "Select a conversation on the left.",
      "archiveReset.title": "Danger zone",
      "archiveReset.description": "Permanently delete all conversations, messages, history pages, coverage and attachment metadata stored in the local Booster archive.",
      "archiveReset.action": "Clear local archive",
      "archiveReset.confirmTitle": "DELETE ALL LOCAL ARCHIVES?",
      "archiveReset.confirmDescription": "This removes every Booster archive record stored in this browser. Capture settings are kept, but the archived data itself is deleted.",
      "archiveReset.irreversible": "This cannot be undone. Export anything you need before continuing.",
      "archiveReset.cancel": "Keep archive",
      "archiveReset.confirm": "Delete everything",
      "archiveReset.clearing": "Deleting…",
      "launcher.title": "ChatGPT Booster — drag to move, click for chat actions",
      "activity.idle": "Idle",
      "activity.thinking": "Thinking",
      "activity.tool": "Tool activity",
      "activity.responding": "Responding",
      "activity.complete": "Completed",
      "activity.duration": "Duration",
      "activity.requestDuration": "Request duration",
      "activity.reasoningDuration": "Reasoning duration",
      "activity.startedAt": "Request started",
      "activity.reasoningStartedAt": "Reasoning started",
      "activity.completedAt": "Completed",
      "activity.lastActivityAt": "Last activity",
      "activity.sinceLastChange": "since last change",
      "requestStatus.request": "Request",
      "requestStatus.reasoning": "Reasoning",
      "work.browserOnly": "Work mode · browser inspection only",
      "work.subagents": "Subagents",
      "work.active": "active",
      "messageMeta.title": "Message details",
      "tool.inspect": "Inspect",
      "tool.copyDiagnostics": "Copy diagnostics",
      "tool.confidence": "Confidence",
      "tool.clientPayload": "Arguments",
      "tool.result": "Result",
      "tool.recipient": "Recipient",
      "tool.startedAt": "Started",
      "tool.finishedAt": "Finished",
      "tool.duration": "Duration",
      "tool.path": "Connector path",
      "tool.link": "Link",
      "tool.noPayload": "No structured arguments/result are exposed in this DOM block.",
      "tool.domEvidence": "DOM evidence",
      "menu.openSettings": "ChatGPT Booster: Open settings",
      "menu.openSettingsTitle": "Open ChatGPT Booster Control Center"
    },
    ru: {
      ...archiveMessages.ru,
      "common.on": "Вкл.",
      "common.off": "Выкл.",
      "common.close": "Закрыть",
      "common.auto": "Авто",
      "language.english": "English",
      "language.russian": "Русский",
      "control.title": "ChatGPT Booster",
      "control.subtitle": "Центр управления",
      "control.loading": "Загрузка настроек…",
      "control.booster": "Booster",
      "control.boosterDescription": "Главный переключатель улучшений страницы. Доступ к настройкам остаётся всегда.",
      "control.language": "Язык",
      "control.languageDescription": "Автоматически использует язык браузера, если не выбран вручную.",
      "control.modules": "Модули",
      "control.analytics": "Аналитика",
      "control.other": "Прочее",
      "control.currentTab": "Текущая вкладка",
      "control.allTime": "За всё время",
      "control.messageMetadata": "Метаданные сообщений",
      "control.messageMetadataDescription": "Добавляет один компактный контрол времени и деталей в строку действий сообщения.",
      "control.activityIndicator": "Живая активность",
      "control.activityIndicatorDescription": "Показывает временный индикатор размышления, инструмента или ответа, пока ответ выполняется.",
      "control.toolInspector": "Инспектор инструментов",
      "control.toolInspectorDescription": "Добавляет кнопку Inspect рядом с найденными MCP/инструментами и показывает доступные клиенту payload, время и DOM-диагностику.",
      "control.historyScroll": "Прокрутка истории",
      "control.historyScrollDescription": "Настраивает плавные импульсы прокрутки, которыми History Loader читает старую историю.",
      "control.historyScrollSpeed": "Скорость",
      "control.historyScrollPause": "Пауза между импульсами",
      "control.requestTimer": "Таймер запроса",
      "control.requestTimerDescription": "Показывает длительность запроса и размышления над предупреждением ChatGPT.",
      "control.responseCompleteSound": "Звук завершения",
      "control.responseCompleteSoundDescription": "Короткий сигнал после завершения текущего ответа.",
      "control.longRunningSound": "Сигнал долгого запроса",
      "control.longRunningSoundDescription": "Другой сигнал, если один запрос работает дольше заданного порога.",
      "control.longRunningThreshold": "Порог сигнала",
      "control.monitoringInterval": "Интервал обновления UI",
      "control.monitoringIntervalDescription": "Один общий ticker обновляет живые длительности и проверяет триггеры с этим интервалом.",
      "control.observer": "Наблюдатель транспорта",
      "control.observerDescription": "Пассивно наблюдает fetch, XHR, WebSocket и EventSource, не блокируя запросы.",
      "control.captureBodies": "Снимать превью body",
      "control.captureBodiesDescription": "Диагностический режим. Сохраняет очищенные и обрезанные превью запросов и сообщений.",
      "control.telemetry": "Телеметрия",
      "control.telemetryDescription": "Отправляет очищенную диагностику Booster по OTLP/HTTP.",
      "control.telemetryEndpoint": "OTLP endpoint",
      "control.telemetryToken": "Bearer token",
      "control.tokenConfigured": "Токен настроен",
      "control.tokenMissing": "Токен не настроен",
      "control.saveToken": "Сохранить токен",
      "control.changeToken": "Изменить",
      "control.cancel": "Отмена",
      "control.testTelemetry": "Тест телеметрии",
      "control.testingTelemetry": "Проверка…",
      "control.telemetryTestSuccess": "Телеметрия работает",
      "control.telemetryTestFailed": "Ошибка телеметрии",
      "control.telemetryEndpointPlaceholder": "https://collector.example.com",
      "control.transportCounters": "Счётчики транспорта",
      "control.requestsSent": "Отправлено запросов",
      "control.responsesReceived": "Получено ответов",
      "control.messagesSent": "Отправлено сообщений",
      "control.messagesReceived": "Получено сообщений",
      "control.errors": "Ошибки",
      "control.analyticsOverview": "Активность транспорта",
      "control.analyticsDescription": "Живая активность Booster в этой вкладке и суммарные счётчики для сравнения.",
      "control.requestTraffic": "HTTP-активность",
      "control.messageTraffic": "Потоковые сообщения",
      "control.outbound": "Исходящее",
      "control.inbound": "Входящее",
      "control.lastActivity": "Последняя активность",
      "control.noActivity": "Событий ещё не было",
      "control.resetCurrent": "Сбросить вкладку",
      "control.saving": "Сохранение…",
      "control.saved": "Сохранено",
      "control.live": "Настройки применяются сразу",
      "quick.title": "Текущий чат",
      "quick.settings": "Настройки",
      "quick.currentConversation": "Текущий диалог",
      "quick.project": "Проект",
      "quick.messages": "Сообщений",
      "quick.branch": "Ветка",
      "quick.noConversation": "Чат не открыт",
      "quick.noConversationDescription": "Откройте диалог ChatGPT, чтобы использовать действия архива.",
      "quick.notArchived": "Ещё не архивирован",
      "quick.partial": "Архив загружен частично",
      "quick.complete": "Архив загружен полностью",
      "quick.readToTop": "Дочитать историю",
      "quick.reread": "Перечитать с начала",
      "quick.openArchive": "Открыть архив",
      "quick.loadingHistory": "Читаю историю…",
      "quick.pages": "страниц",
      "quick.stop": "Остановить",
      "quick.loaderError": "Ошибка загрузчика истории",
      "archive.title": "Локальный архив",
      "archive.subtitle": "Только чтение · IndexedDB",
      "archive.refresh": "Обновить",
      "archive.close": "Закрыть",
      "archive.back": "Назад",
      "archive.empty": "Архив пока пуст. Откройте чат, чтобы Booster увидел его историю.",
      "archive.noProject": "Без проекта",
      "archive.project": "Проект",
      "archive.untitled": "Без названия",
      "archive.showRaw": "Показать raw / metadata",
      "archive.hideRaw": "Скрыть raw",
      "archive.selectConversation": "Выберите диалог слева.",
      "archiveReset.title": "Опасная зона",
      "archiveReset.description": "Безвозвратно удалить все диалоги, сообщения, страницы истории, данные полноты и метаданные вложений из локального архива Booster.",
      "archiveReset.action": "Очистить локальный архив",
      "archiveReset.confirmTitle": "УДАЛИТЬ ВЕСЬ ЛОКАЛЬНЫЙ АРХИВ?",
      "archiveReset.confirmDescription": "Будут удалены все архивные данные Booster, сохранённые в этом браузере. Настройки сохранения останутся, но сам архив исчезнет.",
      "archiveReset.irreversible": "Это действие нельзя отменить. Перед продолжением экспортируйте всё, что нужно сохранить.",
      "archiveReset.cancel": "Оставить архив",
      "archiveReset.confirm": "Удалить всё",
      "archiveReset.clearing": "Удаление…",
      "launcher.title": "ChatGPT Booster — перетащите для перемещения, нажмите для действий чата",
      "activity.idle": "Ожидание",
      "activity.thinking": "Размышляет",
      "activity.tool": "Инструмент",
      "activity.responding": "Отвечает",
      "activity.complete": "Завершено",
      "activity.duration": "Длительность",
      "activity.requestDuration": "Длительность запроса",
      "activity.reasoningDuration": "Длительность размышления",
      "activity.startedAt": "Запрос начат",
      "activity.reasoningStartedAt": "Размышление начато",
      "activity.completedAt": "Завершено",
      "activity.lastActivityAt": "Последнее действие",
      "activity.sinceLastChange": "с последнего изменения",
      "requestStatus.request": "Запрос",
      "requestStatus.reasoning": "Размышление",
      "work.browserOnly": "Режим Work · браузер только для проверки",
      "work.subagents": "Субагенты",
      "work.active": "активно",
      "messageMeta.title": "Детали сообщения",
      "tool.inspect": "Inspect",
      "tool.copyDiagnostics": "Копировать диагностику",
      "tool.confidence": "Уверенность",
      "tool.clientPayload": "Аргументы",
      "tool.result": "Результат",
      "tool.recipient": "Получатель",
      "tool.startedAt": "Начало",
      "tool.finishedAt": "Окончание",
      "tool.duration": "Длительность",
      "tool.path": "Путь коннектора",
      "tool.link": "Ссылка",
      "tool.noPayload": "В этом DOM-блоке нет структурированных аргументов или результата.",
      "tool.domEvidence": "DOM-данные",
      "menu.openSettings": "ChatGPT Booster: Открыть настройки",
      "menu.openSettingsTitle": "Открыть центр управления ChatGPT Booster"
    }
  };
  function detectBrowserLocale(languages = navigator.languages?.length ? navigator.languages : [navigator.language]) {
    return languages.some((language) => language.toLowerCase().startsWith("ru")) ? "ru" : "en";
  }
  function resolveLocale(preference, languages) {
    if (preference === "ru" || preference === "en") return preference;
    return detectBrowserLocale(languages);
  }
  function translate(locale, key) {
    return messages[locale][key] ?? messages.en[key];
  }
  const styles = '/*! tailwindcss v4.3.3 | MIT License | https://tailwindcss.com */\n@layer properties {\n  @supports (((-webkit-hyphens: none)) and (not (margin-trim: inline))) or ((-moz-orient: inline) and (not (color: rgb(from red r g b)))) {\n    *, :before, :after, ::backdrop {\n      --tw-rotate-x: initial;\n      --tw-rotate-y: initial;\n      --tw-rotate-z: initial;\n      --tw-skew-x: initial;\n      --tw-skew-y: initial;\n      --tw-border-style: solid;\n      --tw-leading: initial;\n      --tw-font-weight: initial;\n      --tw-ordinal: initial;\n      --tw-slashed-zero: initial;\n      --tw-numeric-figure: initial;\n      --tw-numeric-spacing: initial;\n      --tw-numeric-fraction: initial;\n      --tw-shadow: 0 0 #0000;\n      --tw-shadow-color: initial;\n      --tw-shadow-alpha: 100%;\n      --tw-inset-shadow: 0 0 #0000;\n      --tw-inset-shadow-color: initial;\n      --tw-inset-shadow-alpha: 100%;\n      --tw-ring-color: initial;\n      --tw-ring-shadow: 0 0 #0000;\n      --tw-inset-ring-color: initial;\n      --tw-inset-ring-shadow: 0 0 #0000;\n      --tw-ring-inset: initial;\n      --tw-ring-offset-width: 0px;\n      --tw-ring-offset-color: #fff;\n      --tw-ring-offset-shadow: 0 0 #0000;\n      --tw-outline-style: solid;\n      --tw-blur: initial;\n      --tw-brightness: initial;\n      --tw-contrast: initial;\n      --tw-grayscale: initial;\n      --tw-hue-rotate: initial;\n      --tw-invert: initial;\n      --tw-opacity: initial;\n      --tw-saturate: initial;\n      --tw-sepia: initial;\n      --tw-drop-shadow: initial;\n      --tw-drop-shadow-color: initial;\n      --tw-drop-shadow-alpha: 100%;\n      --tw-drop-shadow-size: initial;\n    }\n  }\n}\n\n@layer theme {\n  :root, :host {\n    --font-sans: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue",\n      "Noto Sans", Arial, sans-serif, "Apple Color Emoji", "Segoe UI Emoji",\n      "Segoe UI Symbol", "Noto Color Emoji";\n    --font-mono: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono",\n      "Courier New", monospace;\n    --spacing: .25rem;\n    --text-xs: .75rem;\n    --text-xs--line-height: calc(1 / .75);\n    --text-sm: .875rem;\n    --text-sm--line-height: calc(1.25 / .875);\n    --text-base: 1rem;\n    --text-base--line-height: calc(1.5 / 1);\n    --font-weight-medium: 500;\n    --font-weight-semibold: 600;\n    --default-transition-duration: .15s;\n    --default-transition-timing-function: cubic-bezier(.4, 0, .2, 1);\n    --default-font-family: var(--font-sans);\n    --default-mono-font-family: var(--font-mono);\n  }\n}\n\n@layer base {\n  *, :after, :before, ::backdrop {\n    box-sizing: border-box;\n    border: 0 solid;\n    margin: 0;\n    padding: 0;\n  }\n\n  ::file-selector-button {\n    box-sizing: border-box;\n    border: 0 solid;\n    margin: 0;\n    padding: 0;\n  }\n\n  html, :host {\n    -webkit-text-size-adjust: 100%;\n    tab-size: 4;\n    line-height: 1.5;\n    font-family: var(--default-font-family, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", "Noto Sans", Arial, sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol", "Noto Color Emoji");\n    font-feature-settings: var(--default-font-feature-settings, normal);\n    font-variation-settings: var(--default-font-variation-settings, normal);\n    -webkit-tap-highlight-color: transparent;\n  }\n\n  hr {\n    height: 0;\n    color: inherit;\n    border-top-width: 1px;\n  }\n\n  abbr:where([title]) {\n    -webkit-text-decoration: underline dotted;\n    text-decoration: underline dotted;\n  }\n\n  h1, h2, h3, h4, h5, h6 {\n    font-size: inherit;\n    font-weight: inherit;\n  }\n\n  a {\n    color: inherit;\n    -webkit-text-decoration: inherit;\n    -webkit-text-decoration: inherit;\n    -webkit-text-decoration: inherit;\n    text-decoration: inherit;\n  }\n\n  b, strong {\n    font-weight: bolder;\n  }\n\n  code, kbd, samp, pre {\n    font-family: var(--default-mono-font-family, ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", "Courier New", monospace);\n    font-feature-settings: var(--default-mono-font-feature-settings, normal);\n    font-variation-settings: var(--default-mono-font-variation-settings, normal);\n    font-size: 1em;\n  }\n\n  small {\n    font-size: 80%;\n  }\n\n  sub, sup {\n    vertical-align: baseline;\n    font-size: 75%;\n    line-height: 0;\n    position: relative;\n  }\n\n  sub {\n    bottom: -.25em;\n  }\n\n  sup {\n    top: -.5em;\n  }\n\n  table {\n    text-indent: 0;\n    border-color: inherit;\n    border-collapse: collapse;\n  }\n\n  :-moz-focusring:where(:not(iframe)) {\n    outline: auto;\n  }\n\n  progress {\n    vertical-align: baseline;\n  }\n\n  summary {\n    display: list-item;\n  }\n\n  ol, ul, menu {\n    list-style: none;\n  }\n\n  img, svg, video, canvas, audio, iframe, embed, object {\n    vertical-align: middle;\n    display: block;\n  }\n\n  img, video {\n    max-width: 100%;\n    height: auto;\n  }\n\n  button, input, select, optgroup, textarea {\n    font: inherit;\n    font-feature-settings: inherit;\n    font-variation-settings: inherit;\n    letter-spacing: inherit;\n    color: inherit;\n    opacity: 1;\n    background-color: #0000;\n    border-radius: 0;\n  }\n\n  ::file-selector-button {\n    font: inherit;\n    font-feature-settings: inherit;\n    font-variation-settings: inherit;\n    letter-spacing: inherit;\n    color: inherit;\n    opacity: 1;\n    background-color: #0000;\n    border-radius: 0;\n  }\n\n  :where(select:is([multiple], [size])) optgroup {\n    font-weight: bolder;\n  }\n\n  :where(select:is([multiple], [size])) optgroup option {\n    padding-inline-start: 20px;\n  }\n\n  ::file-selector-button {\n    margin-inline-end: 4px;\n  }\n\n  ::placeholder {\n    opacity: 1;\n  }\n\n  @supports (not ((-webkit-appearance: -apple-pay-button))) or (contain-intrinsic-size: 1px) {\n    ::placeholder {\n      color: currentColor;\n    }\n\n    @supports (color: color-mix(in lab, red, red)) {\n      ::placeholder {\n        color: color-mix(in oklab, currentcolor 50%, transparent);\n      }\n    }\n  }\n\n  textarea {\n    resize: vertical;\n  }\n\n  ::-webkit-search-decoration {\n    -webkit-appearance: none;\n  }\n\n  ::-webkit-date-and-time-value {\n    min-height: 1lh;\n    text-align: inherit;\n  }\n\n  ::-webkit-datetime-edit {\n    display: inline-flex;\n  }\n\n  ::-webkit-datetime-edit-fields-wrapper {\n    padding: 0;\n  }\n\n  ::-webkit-datetime-edit {\n    padding-block: 0;\n  }\n\n  ::-webkit-datetime-edit-year-field {\n    padding-block: 0;\n  }\n\n  ::-webkit-datetime-edit-month-field {\n    padding-block: 0;\n  }\n\n  ::-webkit-datetime-edit-day-field {\n    padding-block: 0;\n  }\n\n  ::-webkit-datetime-edit-hour-field {\n    padding-block: 0;\n  }\n\n  ::-webkit-datetime-edit-minute-field {\n    padding-block: 0;\n  }\n\n  ::-webkit-datetime-edit-second-field {\n    padding-block: 0;\n  }\n\n  ::-webkit-datetime-edit-millisecond-field {\n    padding-block: 0;\n  }\n\n  ::-webkit-datetime-edit-meridiem-field {\n    padding-block: 0;\n  }\n\n  ::-webkit-calendar-picker-indicator {\n    line-height: 1;\n  }\n\n  :-moz-ui-invalid {\n    box-shadow: none;\n  }\n\n  button, input:where([type="button"], [type="reset"], [type="submit"]) {\n    appearance: button;\n  }\n\n  ::file-selector-button {\n    appearance: button;\n  }\n\n  ::-webkit-inner-spin-button {\n    height: auto;\n  }\n\n  ::-webkit-outer-spin-button {\n    height: auto;\n  }\n\n  [hidden]:where(:not([hidden="until-found"])) {\n    display: none !important;\n  }\n}\n\n@layer components;\n\n@layer utilities {\n  .collapse {\n    visibility: collapse;\n  }\n\n  .invisible {\n    visibility: hidden;\n  }\n\n  .visible {\n    visibility: visible;\n  }\n\n  .absolute {\n    position: absolute;\n  }\n\n  .fixed {\n    position: fixed;\n  }\n\n  .relative {\n    position: relative;\n  }\n\n  .static {\n    position: static;\n  }\n\n  .sticky {\n    position: sticky;\n  }\n\n  .top-41 {\n    top: calc(var(--spacing) * 41);\n  }\n\n  .col-span-2 {\n    grid-column: span 2 / span 2;\n  }\n\n  .container {\n    width: 100%;\n  }\n\n  @media (min-width: 40rem) {\n    .container {\n      max-width: 40rem;\n    }\n  }\n\n  @media (min-width: 48rem) {\n    .container {\n      max-width: 48rem;\n    }\n  }\n\n  @media (min-width: 64rem) {\n    .container {\n      max-width: 64rem;\n    }\n  }\n\n  @media (min-width: 80rem) {\n    .container {\n      max-width: 80rem;\n    }\n  }\n\n  @media (min-width: 96rem) {\n    .container {\n      max-width: 96rem;\n    }\n  }\n\n  .m-0 {\n    margin: 0;\n  }\n\n  .mt-2 {\n    margin-top: calc(var(--spacing) * 2);\n  }\n\n  .mb-2 {\n    margin-bottom: calc(var(--spacing) * 2);\n  }\n\n  .block {\n    display: block;\n  }\n\n  .contents {\n    display: contents;\n  }\n\n  .flex {\n    display: flex;\n  }\n\n  .grid {\n    display: grid;\n  }\n\n  .hidden {\n    display: none;\n  }\n\n  .inline {\n    display: inline;\n  }\n\n  .inline-flex {\n    display: inline-flex;\n  }\n\n  .table {\n    display: table;\n  }\n\n  .size-3 {\n    width: calc(var(--spacing) * 3);\n    height: calc(var(--spacing) * 3);\n  }\n\n  .size-3\\.5 {\n    width: calc(var(--spacing) * 3.5);\n    height: calc(var(--spacing) * 3.5);\n  }\n\n  .size-4 {\n    width: calc(var(--spacing) * 4);\n    height: calc(var(--spacing) * 4);\n  }\n\n  .size-5 {\n    width: calc(var(--spacing) * 5);\n    height: calc(var(--spacing) * 5);\n  }\n\n  .size-6 {\n    width: calc(var(--spacing) * 6);\n    height: calc(var(--spacing) * 6);\n  }\n\n  .size-7 {\n    width: calc(var(--spacing) * 7);\n    height: calc(var(--spacing) * 7);\n  }\n\n  .size-8 {\n    width: calc(var(--spacing) * 8);\n    height: calc(var(--spacing) * 8);\n  }\n\n  .h-7 {\n    height: calc(var(--spacing) * 7);\n  }\n\n  .h-8 {\n    height: calc(var(--spacing) * 8);\n  }\n\n  .h-9 {\n    height: calc(var(--spacing) * 9);\n  }\n\n  .max-h-\\[420px\\] {\n    max-height: 420px;\n  }\n\n  .min-h-\\[130px\\] {\n    min-height: 130px;\n  }\n\n  .w-full {\n    width: 100%;\n  }\n\n  .min-w-0 {\n    min-width: 0;\n  }\n\n  .flex-1 {\n    flex: 1;\n  }\n\n  .shrink-0 {\n    flex-shrink: 0;\n  }\n\n  .grow {\n    flex-grow: 1;\n  }\n\n  .rotate-180 {\n    rotate: 180deg;\n  }\n\n  .transform {\n    transform: var(--tw-rotate-x, ) var(--tw-rotate-y, ) var(--tw-rotate-z, ) var(--tw-skew-x, ) var(--tw-skew-y, );\n  }\n\n  .resize {\n    resize: both;\n  }\n\n  .grid-cols-2 {\n    grid-template-columns: repeat(2, minmax(0, 1fr));\n  }\n\n  .flex-wrap {\n    flex-wrap: wrap;\n  }\n\n  .items-center {\n    align-items: center;\n  }\n\n  .justify-between {\n    justify-content: space-between;\n  }\n\n  .justify-center {\n    justify-content: center;\n  }\n\n  .justify-end {\n    justify-content: flex-end;\n  }\n\n  .gap-2 {\n    gap: calc(var(--spacing) * 2);\n  }\n\n  .gap-3 {\n    gap: calc(var(--spacing) * 3);\n  }\n\n  .self-start {\n    align-self: flex-start;\n  }\n\n  .truncate {\n    text-overflow: ellipsis;\n    white-space: nowrap;\n    overflow: hidden;\n  }\n\n  .overflow-x-hidden {\n    overflow-x: hidden;\n  }\n\n  .overflow-y-auto {\n    overflow-y: auto;\n  }\n\n  .rounded-lg {\n    border-radius: var(--radius);\n  }\n\n  .rounded-md {\n    border-radius: calc(var(--radius) - 2px);\n  }\n\n  .border {\n    border-style: var(--tw-border-style);\n    border-width: 1px;\n  }\n\n  .border-l-2 {\n    border-left-style: var(--tw-border-style);\n    border-left-width: 2px;\n  }\n\n  .border-border {\n    border-color: var(--border);\n  }\n\n  .border-transparent {\n    border-color: #0000;\n  }\n\n  .bg-background {\n    background-color: var(--background);\n  }\n\n  .bg-card {\n    background-color: var(--card);\n  }\n\n  .bg-primary {\n    background-color: var(--primary);\n  }\n\n  .bg-secondary {\n    background-color: var(--secondary);\n  }\n\n  .p-3 {\n    padding: calc(var(--spacing) * 3);\n  }\n\n  .px-2 {\n    padding-inline: calc(var(--spacing) * 2);\n  }\n\n  .px-3 {\n    padding-inline: calc(var(--spacing) * 3);\n  }\n\n  .px-4 {\n    padding-inline: calc(var(--spacing) * 4);\n  }\n\n  .py-0\\.5 {\n    padding-block: calc(var(--spacing) * .5);\n  }\n\n  .py-2 {\n    padding-block: calc(var(--spacing) * 2);\n  }\n\n  .pl-2 {\n    padding-left: calc(var(--spacing) * 2);\n  }\n\n  .text-base {\n    font-size: var(--text-base);\n    line-height: var(--tw-leading, var(--text-base--line-height));\n  }\n\n  .text-sm {\n    font-size: var(--text-sm);\n    line-height: var(--tw-leading, var(--text-sm--line-height));\n  }\n\n  .text-xs {\n    font-size: var(--text-xs);\n    line-height: var(--tw-leading, var(--text-xs--line-height));\n  }\n\n  .text-\\[11px\\] {\n    font-size: 11px;\n  }\n\n  .leading-4 {\n    --tw-leading: calc(var(--spacing) * 4);\n    line-height: calc(var(--spacing) * 4);\n  }\n\n  .font-medium {\n    --tw-font-weight: var(--font-weight-medium);\n    font-weight: var(--font-weight-medium);\n  }\n\n  .font-semibold {\n    --tw-font-weight: var(--font-weight-semibold);\n    font-weight: var(--font-weight-semibold);\n  }\n\n  .break-words {\n    overflow-wrap: break-word;\n  }\n\n  .whitespace-nowrap {\n    white-space: nowrap;\n  }\n\n  .whitespace-pre-wrap {\n    white-space: pre-wrap;\n  }\n\n  .text-foreground {\n    color: var(--foreground);\n  }\n\n  .text-muted-foreground {\n    color: var(--muted-foreground);\n  }\n\n  .text-primary-foreground {\n    color: var(--primary-foreground);\n  }\n\n  .text-secondary-foreground {\n    color: var(--secondary-foreground);\n  }\n\n  .ordinal {\n    --tw-ordinal: ordinal;\n    font-variant-numeric: var(--tw-ordinal, ) var(--tw-slashed-zero, ) var(--tw-numeric-figure, ) var(--tw-numeric-spacing, ) var(--tw-numeric-fraction, );\n  }\n\n  .tabular-nums {\n    --tw-numeric-spacing: tabular-nums;\n    font-variant-numeric: var(--tw-ordinal, ) var(--tw-slashed-zero, ) var(--tw-numeric-figure, ) var(--tw-numeric-spacing, ) var(--tw-numeric-fraction, );\n  }\n\n  .shadow {\n    --tw-shadow: 0 1px 3px 0 var(--tw-shadow-color, #0000001a), 0 1px 2px -1px var(--tw-shadow-color, #0000001a);\n    box-shadow: var(--tw-inset-shadow), var(--tw-inset-ring-shadow), var(--tw-ring-offset-shadow), var(--tw-ring-shadow), var(--tw-shadow);\n  }\n\n  .outline {\n    outline-style: var(--tw-outline-style);\n    outline-width: 1px;\n  }\n\n  .blur {\n    --tw-blur: blur(8px);\n    filter: var(--tw-blur, ) var(--tw-brightness, ) var(--tw-contrast, ) var(--tw-grayscale, ) var(--tw-hue-rotate, ) var(--tw-invert, ) var(--tw-saturate, ) var(--tw-sepia, ) var(--tw-drop-shadow, );\n  }\n\n  .filter {\n    filter: var(--tw-blur, ) var(--tw-brightness, ) var(--tw-contrast, ) var(--tw-grayscale, ) var(--tw-hue-rotate, ) var(--tw-invert, ) var(--tw-saturate, ) var(--tw-sepia, ) var(--tw-drop-shadow, );\n  }\n\n  .transition {\n    transition-property: color, background-color, border-color, outline-color, text-decoration-color, fill, stroke, --tw-gradient-from, --tw-gradient-via, --tw-gradient-to, opacity, box-shadow, transform, translate, scale, rotate, filter, -webkit-backdrop-filter, backdrop-filter, display, content-visibility, overlay, pointer-events;\n    transition-timing-function: var(--tw-ease, var(--default-transition-timing-function));\n    transition-duration: var(--tw-duration, var(--default-transition-duration));\n  }\n\n  .transition-colors {\n    transition-property: color, background-color, border-color, outline-color, text-decoration-color, fill, stroke, --tw-gradient-from, --tw-gradient-via, --tw-gradient-to;\n    transition-timing-function: var(--tw-ease, var(--default-transition-timing-function));\n    transition-duration: var(--tw-duration, var(--default-transition-duration));\n  }\n\n  .transition-transform {\n    transition-property: transform, translate, scale, rotate;\n    transition-timing-function: var(--tw-ease, var(--default-transition-timing-function));\n    transition-duration: var(--tw-duration, var(--default-transition-duration));\n  }\n\n  .outline-none {\n    --tw-outline-style: none;\n    outline-style: none;\n  }\n\n  @media (hover: hover) {\n    .hover\\:bg-accent:hover {\n      background-color: var(--accent);\n    }\n\n    .hover\\:bg-primary\\/90:hover {\n      background-color: var(--primary);\n    }\n\n    @supports (color: color-mix(in lab, red, red)) {\n      .hover\\:bg-primary\\/90:hover {\n        background-color: color-mix(in oklab, var(--primary) 90%, transparent);\n      }\n    }\n\n    .hover\\:text-accent-foreground:hover {\n      color: var(--accent-foreground);\n    }\n  }\n\n  .focus-visible\\:ring-2:focus-visible {\n    --tw-ring-shadow: var(--tw-ring-inset, ) 0 0 0 calc(2px + var(--tw-ring-offset-width)) var(--tw-ring-color, currentcolor);\n    box-shadow: var(--tw-inset-shadow), var(--tw-inset-ring-shadow), var(--tw-ring-offset-shadow), var(--tw-ring-shadow), var(--tw-shadow);\n  }\n\n  .focus-visible\\:ring-ring:focus-visible {\n    --tw-ring-color: var(--ring);\n  }\n\n  .disabled\\:pointer-events-none:disabled {\n    pointer-events: none;\n  }\n\n  .disabled\\:opacity-50:disabled {\n    opacity: .5;\n  }\n}\n\n:host {\n  --background: oklch(98.5% 0 0);\n  --foreground: oklch(14.5% 0 0);\n  --card: oklch(100% 0 0);\n  --card-foreground: oklch(14.5% 0 0);\n  --primary: oklch(20.5% 0 0);\n  --primary-foreground: oklch(98.5% 0 0);\n  --secondary: oklch(97% 0 0);\n  --secondary-foreground: oklch(20.5% 0 0);\n  --muted: oklch(97% 0 0);\n  --muted-foreground: oklch(55.6% 0 0);\n  --accent: oklch(97% 0 0);\n  --accent-foreground: oklch(20.5% 0 0);\n  --border: oklch(92.2% 0 0);\n  --ring: oklch(70.8% 0 0);\n  --radius: .625rem;\n  all: initial;\n  color: var(--foreground);\n  font-family: Inter, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, Segoe UI, sans-serif;\n}\n\n@media (prefers-color-scheme: dark) {\n  :host {\n    --background: oklch(14.5% 0 0);\n    --foreground: oklch(98.5% 0 0);\n    --card: oklch(20.5% 0 0);\n    --card-foreground: oklch(98.5% 0 0);\n    --primary: oklch(92.2% 0 0);\n    --primary-foreground: oklch(20.5% 0 0);\n    --secondary: oklch(26.9% 0 0);\n    --secondary-foreground: oklch(98.5% 0 0);\n    --muted: oklch(26.9% 0 0);\n    --muted-foreground: oklch(70.8% 0 0);\n    --accent: oklch(26.9% 0 0);\n    --accent-foreground: oklch(98.5% 0 0);\n    --border: oklch(100% 0 0 / .12);\n    --ring: oklch(55.6% 0 0);\n  }\n}\n\n* {\n  box-sizing: border-box;\n  border-color: var(--border);\n}\n\n.booster-shell {\n  z-index: 2147483647;\n  position: fixed;\n  bottom: 20px;\n  right: 20px;\n}\n\n.booster-button {\n  border: 1px solid var(--border);\n  background: var(--card);\n  width: 42px;\n  height: 42px;\n  color: var(--card-foreground);\n  cursor: pointer;\n  border-radius: 14px;\n  font: 700 15px / 1 inherit;\n  box-shadow: 0 10px 30px #0003;\n}\n\n.booster-panel {\n  border: 1px solid var(--border);\n  background: var(--card);\n  width: 300px;\n  color: var(--card-foreground);\n  border-radius: 16px;\n  margin-bottom: 10px;\n  padding: 14px;\n  box-shadow: 0 18px 45px #0000003d;\n}\n\n.booster-panel h2 {\n  margin: 0 0 6px;\n  font-size: 15px;\n  font-weight: 700;\n}\n\n.booster-panel p {\n  color: var(--muted-foreground);\n  margin: 0;\n  font-size: 12px;\n  line-height: 1.45;\n}\n\n.booster-control-center {\n  border: 1px solid var(--border);\n  background: var(--card);\n  width: min(760px, 100vw - 32px);\n  color: var(--card-foreground);\n  border-radius: 18px;\n  margin-bottom: 10px;\n  overflow: hidden;\n  box-shadow: 0 22px 60px #00000047;\n}\n\n.booster-control-header, .booster-control-footer {\n  justify-content: space-between;\n  align-items: center;\n  gap: 12px;\n  display: flex;\n}\n\n.booster-control-header {\n  border-bottom: 1px solid var(--border);\n  padding: 14px 14px 12px;\n}\n\n.booster-control-header strong {\n  font-size: 14px;\n}\n\n.booster-control-header p {\n  color: var(--muted-foreground);\n  margin: 3px 0 0;\n  font-size: 11px;\n}\n\n.booster-control-body {\n  gap: 10px;\n  padding: 12px;\n  display: grid;\n}\n\n.booster-loading {\n  color: var(--muted-foreground);\n  padding: 18px;\n  font-size: 12px;\n}\n\n.booster-section-label {\n  color: var(--muted-foreground);\n  letter-spacing: .08em;\n  text-transform: uppercase;\n  padding: 2px 2px 0;\n  font-size: 10px;\n  font-weight: 700;\n}\n\n.booster-setting-card {\n  border: 1px solid var(--border);\n  background: var(--background);\n  border-radius: 12px;\n  justify-content: space-between;\n  align-items: center;\n  gap: 16px;\n  padding: 12px;\n  display: flex;\n}\n\n.booster-setting-card-stack {\n  align-items: stretch;\n  display: grid;\n}\n\n.booster-range-grid {\n  gap: 10px;\n  min-width: 220px;\n  display: grid;\n}\n\n.booster-range-grid label {\n  gap: 5px;\n  display: grid;\n}\n\n.booster-range-grid label > span {\n  color: var(--muted-foreground);\n  justify-content: space-between;\n  gap: 12px;\n  font-size: 10px;\n  display: flex;\n}\n\n.booster-range-grid label > span b {\n  color: var(--foreground);\n  font-variant-numeric: tabular-nums;\n}\n\n.booster-range-grid input[type="range"] {\n  width: 100%;\n  accent-color: var(--primary);\n}\n\n.booster-setting-disabled {\n  opacity: .55;\n}\n\n.booster-setting-copy {\n  gap: 5px;\n  min-width: 0;\n  display: grid;\n}\n\n.booster-setting-copy b {\n  font-size: 12px;\n}\n\n.booster-setting-copy > span {\n  color: var(--muted-foreground);\n  font-size: 11px;\n  line-height: 1.4;\n}\n\n.booster-switch {\n  border: 1px solid var(--border);\n  background: var(--muted);\n  cursor: pointer;\n  border-radius: 999px;\n  flex: none;\n  width: 36px;\n  height: 20px;\n  padding: 0;\n  transition: background .12s, border-color .12s;\n  position: relative;\n}\n\n.booster-switch:disabled {\n  cursor: not-allowed;\n}\n\n.booster-switch > span {\n  background: var(--foreground);\n  border-radius: 999px;\n  width: 14px;\n  height: 14px;\n  transition: transform .12s;\n  position: absolute;\n  top: 2px;\n  left: 2px;\n}\n\n.booster-switch-on {\n  background: var(--primary);\n  border-color: var(--primary);\n}\n\n.booster-switch-on > span {\n  background: var(--primary-foreground);\n  transform: translateX(16px);\n}\n\n.booster-info-card {\n  background: var(--muted);\n  color: var(--foreground);\n  border-radius: 12px;\n  padding: 11px 12px;\n  font-size: 11px;\n}\n\n.booster-info-card ul {\n  color: var(--muted-foreground);\n  gap: 4px;\n  margin: 8px 0 0 18px;\n  padding: 0;\n  line-height: 1.35;\n  display: grid;\n}\n\n.booster-control-footer {\n  padding-top: 2px;\n}\n\n.booster-save-state {\n  color: var(--muted-foreground);\n  align-items: center;\n  gap: 5px;\n  font-size: 10px;\n  display: inline-flex;\n}\n\n.booster-overlay-root {\n  pointer-events: none;\n}\n\n.booster-launcher {\n  z-index: 2147483647;\n  border: 2px solid var(--primary);\n  justify-content: center;\n  align-items: center;\n  gap: 1px;\n  width: 46px;\n  height: 46px;\n  display: inline-flex;\n  position: fixed;\n}\n\n@supports (color: color-mix(in lab, red, red)) {\n  .booster-launcher {\n    border: 2px solid color-mix(in oklab, var(--primary) 55%, transparent);\n  }\n}\n\n.booster-launcher {\n  background: var(--primary);\n  color: var(--primary-foreground);\n  box-shadow: 0 12px 36px #00000047, 0 0 0 3px var(--primary);\n  border-radius: 15px;\n}\n\n@supports (color: color-mix(in lab, red, red)) {\n  .booster-launcher {\n    box-shadow: 0 12px 36px #00000047, 0 0 0 3px color-mix(in oklab, var(--primary) 18%, transparent);\n  }\n}\n\n.booster-launcher {\n  cursor: grab;\n  pointer-events: auto;\n  touch-action: none;\n  -webkit-user-select: none;\n  user-select: none;\n  font: 800 17px / 1 inherit;\n}\n\n.booster-launcher:hover {\n  transform: scale(1.04);\n}\n\n.booster-launcher-dragging {\n  cursor: grabbing;\n  transform: scale(1.06);\n}\n\n.booster-launcher-grip {\n  opacity: .7;\n  width: 11px;\n  height: 11px;\n}\n\n.booster-modal-backdrop {\n  z-index: 2147483646;\n  -webkit-backdrop-filter: blur(3px);\n  backdrop-filter: blur(3px);\n  pointer-events: auto;\n  background: #00000061;\n  place-items: center;\n  padding: 16px;\n  display: grid;\n  position: fixed;\n  inset: 0;\n}\n\n.booster-modal-surface {\n  width: min(760px, 100vw - 32px);\n  max-height: calc(100vh - 32px);\n  overflow: auto;\n}\n\n.booster-modal-surface .booster-control-center {\n  width: 100%;\n  margin: 0;\n}\n\n.booster-popup-host {\n  background: var(--background);\n  min-width: 360px;\n}\n\n.booster-select {\n  border: 1px solid var(--border);\n  background: var(--background);\n  min-width: 92px;\n  height: 32px;\n  color: var(--foreground);\n  cursor: pointer;\n  border-radius: 8px;\n  outline: none;\n  flex: none;\n  padding: 0 28px 0 10px;\n  font: 500 12px / 1 inherit;\n}\n\n.booster-select:focus {\n  box-shadow: 0 0 0 2px var(--ring);\n}\n\n.booster-stack-card {\n  border: 1px solid var(--border);\n  background: var(--background);\n  border-radius: 12px;\n  gap: 10px;\n  padding: 12px;\n  display: grid;\n}\n\n.booster-stack-card label {\n  color: var(--muted-foreground);\n  gap: 6px;\n  font-size: 11px;\n  display: grid;\n}\n\n.booster-input {\n  border: 1px solid var(--border);\n  background: var(--background);\n  width: 100%;\n  min-width: 0;\n  height: 32px;\n  color: var(--foreground);\n  border-radius: 8px;\n  outline: none;\n  padding: 0 10px;\n  font: 500 11px / 1 inherit;\n}\n\n.booster-input:focus {\n  box-shadow: 0 0 0 2px var(--ring);\n}\n\n.booster-counter-grid {\n  color: var(--muted-foreground);\n  grid-template-columns: repeat(2, minmax(0, 1fr));\n  gap: 6px 12px;\n  margin-top: 8px;\n  display: grid;\n}\n\n.booster-counter-grid span {\n  justify-content: space-between;\n  gap: 8px;\n  display: flex;\n}\n\n.booster-counter-grid b {\n  color: var(--foreground);\n}\n\n.booster-header-copy {\n  min-width: 0;\n}\n\n.booster-header-actions {\n  align-items: center;\n  gap: 10px;\n  display: flex;\n}\n\n.booster-header-toggle-label {\n  color: var(--muted-foreground);\n  font-size: 11px;\n  font-weight: 600;\n}\n\n.booster-settings-layout {\n  grid-template-columns: 150px minmax(0, 1fr);\n  min-height: 360px;\n  display: grid;\n}\n\n.booster-settings-nav {\n  border-right: 1px solid var(--border);\n  background: var(--muted);\n  align-content: start;\n  gap: 4px;\n  padding: 12px 8px;\n  display: grid;\n}\n\n@supports (color: color-mix(in lab, red, red)) {\n  .booster-settings-nav {\n    background: color-mix(in oklab, var(--muted) 58%, transparent);\n  }\n}\n\n.booster-settings-nav button {\n  width: 100%;\n  color: var(--muted-foreground);\n  cursor: pointer;\n  text-align: left;\n  background: none;\n  border: 0;\n  border-radius: 9px;\n  align-items: center;\n  gap: 8px;\n  padding: 9px 10px;\n  font: 600 11px / 1.2 inherit;\n  display: flex;\n}\n\n.booster-settings-nav button:hover, .booster-settings-nav button.active {\n  background: var(--background);\n  color: var(--foreground);\n}\n\n.booster-settings-content {\n  align-content: start;\n  gap: 10px;\n  min-width: 0;\n  padding: 14px;\n  display: grid;\n}\n\n.booster-setting-card-flat {\n  border: 0;\n  border-bottom: 1px solid var(--border);\n  border-radius: 0;\n  padding: 0 0 10px;\n}\n\n.booster-analytics-grid {\n  grid-template-columns: repeat(2, minmax(0, 1fr));\n  gap: 12px;\n  display: grid;\n}\n\n.booster-counter-card {\n  border: 1px solid var(--border);\n  background: var(--background);\n  border-radius: 12px;\n  padding: 12px;\n}\n\n.booster-counter-title {\n  margin-bottom: 8px;\n  font-size: 12px;\n  font-weight: 700;\n}\n\n.booster-disclosure {\n  width: 100%;\n  color: var(--foreground);\n  cursor: pointer;\n  text-align: left;\n  background: none;\n  border: 0;\n  justify-content: space-between;\n  align-items: center;\n  gap: 16px;\n  padding: 0;\n  display: flex;\n}\n\n.booster-disclosure > span {\n  gap: 3px;\n  display: grid;\n}\n\n.booster-disclosure b {\n  font-size: 12px;\n}\n\n.booster-disclosure small {\n  color: var(--muted-foreground);\n  font-size: 11px;\n}\n\n.rotate-180 {\n  transform: rotate(180deg);\n}\n\n.booster-telemetry-body {\n  gap: 10px;\n  padding-top: 10px;\n  display: grid;\n}\n\n.booster-field {\n  color: var(--muted-foreground);\n  gap: 6px;\n  font-size: 11px;\n  display: grid;\n}\n\n.booster-telemetry-test-row {\n  align-items: center;\n  gap: 10px;\n  min-width: 0;\n  display: flex;\n}\n\n.booster-test-success {\n  color: oklch(62% .17 145);\n  font-size: 11px;\n}\n\n.booster-test-error {\n  color: oklch(63% .2 25);\n  text-overflow: ellipsis;\n  white-space: nowrap;\n  min-width: 0;\n  font-size: 11px;\n  overflow: hidden;\n}\n\n.booster-modal-surface {\n  width: min(760px, 100vw - 32px);\n}\n\n@media (max-width: 620px) {\n  .booster-control-center, .booster-modal-surface {\n    width: calc(100vw - 20px);\n  }\n\n  .booster-settings-layout {\n    grid-template-columns: 1fr;\n  }\n\n  .booster-settings-nav {\n    border-right: 0;\n    border-bottom: 1px solid var(--border);\n    grid-template-columns: repeat(3, minmax(0, 1fr));\n  }\n\n  .booster-settings-nav button {\n    justify-content: center;\n  }\n\n  .booster-analytics-grid {\n    grid-template-columns: 1fr;\n  }\n}\n\n.booster-launcher-icon {\n  width: 21px;\n  height: 21px;\n}\n\n.booster-launcher-open {\n  box-shadow: 0 14px 40px #00000057, 0 0 0 4px var(--primary);\n}\n\n@supports (color: color-mix(in lab, red, red)) {\n  .booster-launcher-open {\n    box-shadow: 0 14px 40px #00000057, 0 0 0 4px color-mix(in oklab, var(--primary) 24%, transparent);\n  }\n}\n\n.booster-quick-menu {\n  z-index: 2147483647;\n  border: 1px solid var(--border);\n  background: var(--card);\n  width: 330px;\n  color: var(--card-foreground);\n  pointer-events: auto;\n  border-radius: 18px;\n  position: fixed;\n  overflow: hidden;\n  box-shadow: 0 22px 60px #0000004d;\n}\n\n.booster-quick-header, .booster-loader-status, .booster-quick-actions, .booster-quick-context, .booster-quick-empty, .booster-loader-error {\n  padding: 12px 14px;\n}\n\n.booster-quick-header, .booster-loader-status {\n  justify-content: space-between;\n  align-items: center;\n  gap: 10px;\n  display: flex;\n}\n\n.booster-quick-header {\n  border-bottom: 1px solid var(--border);\n}\n\n.booster-quick-header > div, .booster-loader-status > div {\n  gap: 2px;\n  min-width: 0;\n  display: grid;\n}\n\n.booster-quick-header strong, .booster-loader-status strong {\n  font-size: 13px;\n}\n\n.booster-quick-header span, .booster-loader-status span, .booster-quick-context code, .booster-quick-empty, .booster-loader-error {\n  color: var(--muted-foreground);\n  font-size: 11px;\n}\n\n.booster-icon-button {\n  border: 1px solid var(--border);\n  background: var(--secondary);\n  width: 30px;\n  height: 30px;\n  color: var(--secondary-foreground);\n  cursor: pointer;\n  border-radius: 9px;\n  flex: none;\n  justify-content: center;\n  align-items: center;\n  display: inline-flex;\n}\n\n.booster-icon-button:hover {\n  background: var(--accent);\n}\n\n.booster-quick-context {\n  gap: 7px;\n  display: grid;\n}\n\n.booster-quick-context > strong {\n  text-overflow: ellipsis;\n  white-space: nowrap;\n  font-size: 13px;\n  overflow: hidden;\n}\n\n.booster-quick-context code {\n  text-overflow: ellipsis;\n  white-space: nowrap;\n  overflow: hidden;\n}\n\n.booster-quick-chips, .booster-archive-meta {\n  flex-wrap: wrap;\n  gap: 5px;\n  display: flex;\n}\n\n.booster-quick-chips span, .booster-archive-meta span {\n  background: var(--muted);\n  max-width: 100%;\n  color: var(--muted-foreground);\n  text-overflow: ellipsis;\n  white-space: nowrap;\n  border-radius: 999px;\n  padding: 3px 6px;\n  font-size: 10px;\n  overflow: hidden;\n}\n\n.booster-loader-status {\n  border-top: 1px solid var(--border);\n  border-bottom: 1px solid var(--border);\n  background: var(--secondary);\n}\n\n@supports (color: color-mix(in lab, red, red)) {\n  .booster-loader-status {\n    background: color-mix(in oklab, var(--secondary) 70%, transparent);\n  }\n}\n\n.booster-loader-error {\n  border-top: 1px solid var(--border);\n}\n\n.booster-spin {\n  animation: 1.2s linear infinite booster-spin;\n}\n\n@keyframes booster-spin {\n  to {\n    transform: rotate(360deg);\n  }\n}\n\n.booster-quick-actions {\n  grid-template-columns: 1fr 1fr;\n  gap: 8px;\n  display: grid;\n}\n\n.booster-quick-primary, .booster-quick-secondary {\n  border: 1px solid var(--border);\n  cursor: pointer;\n  border-radius: 11px;\n  justify-content: center;\n  align-items: center;\n  gap: 7px;\n  min-height: 38px;\n  font: 600 11px / 1.2 inherit;\n  display: inline-flex;\n}\n\n.booster-quick-primary {\n  background: var(--primary);\n  color: var(--primary-foreground);\n}\n\n.booster-quick-secondary {\n  background: var(--secondary);\n  color: var(--secondary-foreground);\n}\n\n.booster-quick-primary:disabled, .booster-quick-secondary:disabled {\n  cursor: not-allowed;\n  opacity: .45;\n}\n\n.booster-archive-backdrop {\n  padding: 10px;\n}\n\n.booster-archive-surface {\n  pointer-events: auto;\n  width: min(1180px, 100vw - 20px);\n  height: min(820px, 100vh - 20px);\n}\n\n.booster-archive-browser {\n  border: 1px solid var(--border);\n  background: var(--card);\n  width: 100%;\n  height: 100%;\n  color: var(--card-foreground);\n  border-radius: 20px;\n  grid-template-rows: auto minmax(0, 1fr);\n  display: grid;\n  overflow: hidden;\n  box-shadow: 0 28px 80px #00000061;\n}\n\n.booster-archive-header {\n  border-bottom: 1px solid var(--border);\n  justify-content: space-between;\n  align-items: center;\n  gap: 12px;\n  min-height: 58px;\n  padding: 10px 14px;\n  display: flex;\n}\n\n.booster-archive-title, .booster-archive-header-actions {\n  align-items: center;\n  gap: 9px;\n  display: flex;\n}\n\n.booster-archive-title > div {\n  gap: 1px;\n  display: grid;\n}\n\n.booster-archive-title strong {\n  font-size: 14px;\n}\n\n.booster-archive-title span {\n  color: var(--muted-foreground);\n  font-size: 10px;\n}\n\n.booster-archive-layout {\n  grid-template-columns: 300px minmax(0, 1fr);\n  min-height: 0;\n  display: grid;\n}\n\n.booster-archive-sidebar {\n  border-right: 1px solid var(--border);\n  background: var(--secondary);\n  padding: 10px;\n  overflow: auto;\n}\n\n@supports (color: color-mix(in lab, red, red)) {\n  .booster-archive-sidebar {\n    background: color-mix(in oklab, var(--secondary) 38%, var(--card));\n  }\n}\n\n.booster-archive-group {\n  margin-bottom: 12px;\n}\n\n.booster-archive-project {\n  color: var(--muted-foreground);\n  text-transform: uppercase;\n  align-items: center;\n  gap: 6px;\n  padding: 6px 7px;\n  font-size: 10px;\n  font-weight: 700;\n  display: flex;\n}\n\n.booster-archive-project span {\n  text-overflow: ellipsis;\n  white-space: nowrap;\n  flex: 1;\n  min-width: 0;\n  overflow: hidden;\n}\n\n.booster-archive-conversation {\n  width: 100%;\n  color: inherit;\n  text-align: left;\n  cursor: pointer;\n  background: none;\n  border: 1px solid #0000;\n  border-radius: 11px;\n  gap: 3px;\n  margin: 2px 0;\n  padding: 9px 10px;\n  display: grid;\n}\n\n.booster-archive-conversation:hover, .booster-archive-conversation.active {\n  border-color: var(--border);\n  background: var(--card);\n}\n\n.booster-archive-conversation strong, .booster-archive-conversation span {\n  text-overflow: ellipsis;\n  white-space: nowrap;\n  overflow: hidden;\n}\n\n.booster-archive-conversation strong {\n  font-size: 12px;\n}\n\n.booster-archive-conversation span {\n  color: var(--muted-foreground);\n  font-size: 10px;\n}\n\n.booster-archive-content {\n  background: var(--background);\n  min-width: 0;\n  overflow: auto;\n}\n\n.booster-archive-conversation-head {\n  z-index: 2;\n  border-bottom: 1px solid var(--border);\n  background: var(--card);\n  justify-content: space-between;\n  align-items: flex-start;\n  gap: 14px;\n  padding: 12px 16px;\n  display: flex;\n  position: sticky;\n  top: 0;\n}\n\n@supports (color: color-mix(in lab, red, red)) {\n  .booster-archive-conversation-head {\n    background: color-mix(in oklab, var(--card) 94%, transparent);\n  }\n}\n\n.booster-archive-conversation-head {\n  -webkit-backdrop-filter: blur(10px);\n  backdrop-filter: blur(10px);\n}\n\n.booster-archive-conversation-head > div:first-child {\n  grid-template-columns: auto minmax(0, 1fr);\n  align-items: center;\n  gap: 2px 8px;\n  min-width: 0;\n  display: grid;\n}\n\n.booster-archive-conversation-head strong {\n  text-overflow: ellipsis;\n  white-space: nowrap;\n  font-size: 13px;\n  overflow: hidden;\n}\n\n.booster-archive-conversation-head span {\n  color: var(--muted-foreground);\n  text-overflow: ellipsis;\n  white-space: nowrap;\n  grid-column: 2;\n  font-size: 9px;\n  overflow: hidden;\n}\n\n.booster-archive-back {\n  background: var(--secondary);\n  width: 28px;\n  height: 28px;\n  color: var(--secondary-foreground);\n  cursor: pointer;\n  border: 0;\n  border-radius: 8px;\n  grid-row: 1 / span 2;\n  justify-content: center;\n  align-items: center;\n  display: inline-flex;\n}\n\n.booster-archive-messages {\n  gap: 10px;\n  padding: 14px 16px 40px;\n  display: grid;\n}\n\n.booster-archive-message {\n  border: 1px solid var(--border);\n  background: var(--card);\n  border-radius: 14px;\n  max-width: 920px;\n  padding: 11px 13px;\n}\n\n.booster-archive-message.role-user {\n  background: var(--secondary);\n  margin-left: auto;\n}\n\n@supports (color: color-mix(in lab, red, red)) {\n  .booster-archive-message.role-user {\n    background: color-mix(in oklab, var(--secondary) 82%, var(--card));\n  }\n}\n\n.booster-archive-message.role-tool {\n  border-style: dashed;\n}\n\n.booster-archive-message-head {\n  color: var(--muted-foreground);\n  text-transform: uppercase;\n  flex-wrap: wrap;\n  gap: 5px 10px;\n  margin-bottom: 8px;\n  font-size: 9px;\n  display: flex;\n}\n\n.booster-archive-message-head strong {\n  color: var(--foreground);\n}\n\n.booster-archive-message-text {\n  white-space: pre-wrap;\n  overflow-wrap: anywhere;\n  font-size: 12px;\n  line-height: 1.55;\n}\n\n.booster-raw-toggle {\n  color: var(--muted-foreground);\n  cursor: pointer;\n  background: none;\n  border: 0;\n  align-items: center;\n  gap: 4px;\n  margin-top: 10px;\n  padding: 0;\n  font: 600 10px / 1 inherit;\n  display: inline-flex;\n}\n\n.booster-archive-raw {\n  background: var(--muted);\n  max-height: 360px;\n  color: var(--foreground);\n  white-space: pre-wrap;\n  border-radius: 10px;\n  margin: 9px 0 0;\n  padding: 10px;\n  font: 10px / 1.45 ui-monospace, SFMono-Regular, Menlo, Consolas, monospace;\n  overflow: auto;\n}\n\n.booster-archive-empty, .booster-archive-error {\n  color: var(--muted-foreground);\n  padding: 24px;\n  font-size: 12px;\n}\n\n.booster-archive-error {\n  color: #dc2626;\n}\n\n@media (max-width: 760px) {\n  .booster-archive-layout {\n    grid-template-columns: 220px minmax(0, 1fr);\n  }\n\n  .booster-quick-menu {\n    width: min(330px, 100vw - 24px);\n  }\n}\n\n.booster-identity {\n  vertical-align: middle;\n  align-items: center;\n  gap: 6px;\n  min-width: 0;\n  max-width: 100%;\n  display: inline-flex;\n}\n\n.booster-dock {\n  z-index: 2147483647;\n  pointer-events: auto;\n  width: 44px;\n  height: 44px;\n  position: fixed;\n}\n\n.booster-dock-toggle {\n  z-index: 2;\n  border: 1px solid var(--border);\n  background: var(--primary);\n  width: 44px;\n  height: 44px;\n  color: var(--primary-foreground);\n  cursor: grab;\n  touch-action: none;\n  -webkit-user-select: none;\n  user-select: none;\n  justify-content: center;\n  align-items: center;\n  padding: 0;\n  display: flex;\n  position: relative;\n}\n\n.booster-dock.right .booster-dock-toggle {\n  border-radius: 12px 0 0 12px;\n}\n\n.booster-dock.left .booster-dock-toggle {\n  border-radius: 0 12px 12px 0;\n}\n\n.booster-dock.dragging .booster-dock-toggle {\n  cursor: grabbing;\n}\n\n.booster-dock-shell {\n  border: 1px solid var(--border);\n  background: var(--card);\n  width: min(284px, 100vw);\n  color: var(--card-foreground);\n  position: absolute;\n  overflow: hidden;\n  box-shadow: 0 12px 32px #00000038;\n}\n\n.booster-dock.right .booster-dock-shell {\n  border-radius: 16px 0 0 16px;\n  right: 0;\n}\n\n.booster-dock.left .booster-dock-shell {\n  border-radius: 0 16px 16px 0;\n  left: 0;\n}\n\n.booster-dock.grow-up .booster-dock-shell {\n  padding-bottom: 44px;\n  bottom: 0;\n}\n\n.booster-dock.grow-down .booster-dock-shell {\n  padding-top: 44px;\n  top: 0;\n}\n\n.booster-dock-content {\n  overscroll-behavior: contain;\n  overflow-y: auto;\n}\n\n.booster-dock-close-bar {\n  box-sizing: border-box;\n  background: var(--primary);\n  height: 44px;\n  color: var(--primary-foreground);\n  letter-spacing: .01em;\n  cursor: grab;\n  touch-action: none;\n  -webkit-user-select: none;\n  user-select: none;\n  border: 0;\n  align-items: center;\n  gap: 8px;\n  padding: 0 12px;\n  font: 650 11px / 1 inherit;\n  display: flex;\n  position: absolute;\n  left: -1px;\n  right: -1px;\n}\n\n.booster-dock.grow-up .booster-dock-close-bar {\n  border-top: 1px solid var(--primary-foreground);\n  bottom: -1px;\n}\n\n@supports (color: color-mix(in lab, red, red)) {\n  .booster-dock.grow-up .booster-dock-close-bar {\n    border-top: 1px solid color-mix(in oklab, var(--primary-foreground) 18%, transparent);\n  }\n}\n\n.booster-dock.grow-down .booster-dock-close-bar {\n  border-bottom: 1px solid var(--primary-foreground);\n  top: -1px;\n}\n\n@supports (color: color-mix(in lab, red, red)) {\n  .booster-dock.grow-down .booster-dock-close-bar {\n    border-bottom: 1px solid color-mix(in oklab, var(--primary-foreground) 18%, transparent);\n  }\n}\n\n.booster-dock.right .booster-dock-close-bar, .booster-dock.left .booster-dock-close-bar {\n  justify-content: flex-start;\n  padding-inline: 12px;\n}\n\n.booster-dock-close-bar:hover {\n  filter: brightness(1.04);\n}\n\n.booster-dock-close-bar:active {\n  cursor: grabbing;\n}\n\n.booster-dock-close-bar svg {\n  flex: none;\n}\n\n.booster-dock-context {\n  gap: 5px;\n  padding: 11px 12px 7px;\n  display: grid;\n}\n\n.booster-dock-context > .booster-identity:first-child {\n  font-size: 13px;\n  font-weight: 650;\n}\n\n.booster-dock-context > .booster-identity {\n  font-size: 12px;\n}\n\n.booster-dock-context p {\n  color: var(--muted-foreground);\n  margin: 0;\n  font-size: 11px;\n  line-height: 1.5;\n}\n\n.booster-dock-context time {\n  font-size: 10px;\n  display: block;\n}\n\n.booster-dock-counts {\n  color: var(--muted-foreground);\n  flex-wrap: wrap;\n  gap: 6px 10px;\n  font-size: 10px;\n  display: flex;\n}\n\n.booster-dock-counts b {\n  color: var(--foreground);\n  font-weight: 650;\n}\n\n.booster-capture-shortcut {\n  color: var(--muted-foreground);\n  font: inherit;\n  text-align: left;\n  cursor: pointer;\n  background: none;\n  border: 0;\n  align-items: center;\n  gap: 6px;\n  padding: 3px 0;\n  font-size: 10px;\n  display: inline-flex;\n}\n\n.booster-dock-actions {\n  flex-direction: column;\n  gap: 1px;\n  padding: 4px 5px 6px;\n  display: flex;\n}\n\n.booster-dock-actions > button {\n  width: 100%;\n  min-height: 34px;\n  color: inherit;\n  text-align: left;\n  font: inherit;\n  cursor: pointer;\n  background: none;\n  border: 0;\n  border-radius: 8px;\n  align-items: center;\n  gap: 10px;\n  padding: 6px 9px;\n  font-size: 12px;\n  display: flex;\n}\n\n.booster-dock-actions > button:hover:not(:disabled) {\n  background: var(--muted);\n}\n\n.booster-dock-actions > button:disabled {\n  opacity: .4;\n  cursor: not-allowed;\n}\n\n.booster-dock.grow-down .booster-dock-content {\n  flex-direction: column-reverse;\n  display: flex;\n}\n\n.booster-dock.grow-down .booster-dock-actions {\n  flex-direction: column-reverse;\n}\n\n.booster-dock-progress {\n  border-block: 1px solid var(--border);\n  justify-content: space-between;\n  align-items: center;\n  gap: 8px;\n  padding: 8px 12px;\n  font-size: 12px;\n  display: flex;\n}\n\n.booster-identity-label {\n  text-overflow: ellipsis;\n  white-space: nowrap;\n  min-width: 0;\n  overflow: hidden;\n}\n\n.booster-identity-copy {\n  width: 24px;\n  height: 24px;\n  color: var(--muted-foreground);\n  cursor: pointer;\n  opacity: 0;\n  background: none;\n  border: 0;\n  border-radius: 5px;\n  flex: none;\n  justify-content: center;\n  align-items: center;\n  padding: 4px;\n  display: inline-flex;\n}\n\n.booster-identity:hover .booster-identity-copy, .booster-identity:focus-within .booster-identity-copy, .booster-reader-group-header:hover .booster-identity-copy {\n  opacity: 1;\n}\n\n.booster-identity-copy:hover {\n  background: var(--muted);\n}\n\n.booster-sr-only {\n  clip-path: inset(50%);\n  white-space: nowrap;\n  width: 1px;\n  height: 1px;\n  position: absolute;\n  overflow: hidden;\n}\n\n.booster-modal-backdrop {\n  -webkit-backdrop-filter: none;\n  backdrop-filter: none;\n}\n\n.booster-dialog {\n  border: 1px solid var(--border);\n  background: var(--card);\n  width: min(760px, 100vw - 32px);\n  max-height: calc(100dvh - 32px);\n  color: var(--card-foreground);\n  pointer-events: auto;\n  border-radius: 16px;\n  outline: none;\n  font-size: 14px;\n  overflow: auto;\n  box-shadow: 0 20px 60px #0000004d;\n}\n\n.booster-dialog .booster-control-center {\n  width: 100%;\n  box-shadow: none;\n  border: 0;\n  border-radius: 0;\n  margin: 0;\n}\n\n.booster-dialog-wide {\n  width: min(1220px, 100vw - 32px);\n  height: min(860px, 100dvh - 32px);\n  overflow: hidden;\n}\n\n.booster-section-header {\n  border-bottom: 1px solid var(--border);\n  justify-content: space-between;\n  align-items: center;\n  gap: 12px;\n  min-height: 64px;\n  padding: 12px 18px;\n  display: flex;\n}\n\n.booster-section-header strong {\n  font-size: 15px;\n}\n\n.booster-section-header p {\n  color: var(--muted-foreground);\n  margin: 3px 0 0;\n  font-size: 11px;\n}\n\n.booster-form-body {\n  gap: 16px;\n  padding: 20px;\n  line-height: 1.5;\n  display: grid;\n}\n\n.booster-form-body h2, .booster-capture-settings h3 {\n  margin: 0;\n  font-size: 16px;\n  font-weight: 650;\n}\n\n.booster-form-body > label {\n  gap: 6px;\n  font-size: 12px;\n  font-weight: 600;\n  display: grid;\n}\n\n.booster-form-body select, .booster-reader input {\n  border: 1px solid var(--border);\n  background: var(--background);\n  width: 100%;\n  min-width: 0;\n  min-height: 38px;\n  color: var(--foreground);\n  font: inherit;\n  border-radius: 8px;\n  padding: 8px 10px;\n  font-size: 12px;\n}\n\n.booster-checkboxes {\n  border: 0;\n  gap: 10px;\n  margin: 0;\n  padding: 0;\n  display: grid;\n}\n\n.booster-checkboxes label {\n  align-items: center;\n  gap: 8px;\n  font-size: 13px;\n  display: flex;\n}\n\n.booster-checkboxes input {\n  width: 16px;\n  height: 16px;\n}\n\n.booster-export-suboptions {\n  border-inline-start: 1px solid var(--border);\n  gap: 8px;\n  margin-inline-start: 22px;\n  padding-inline-start: 12px;\n  display: grid;\n}\n\n.booster-note {\n  color: var(--muted-foreground);\n  overflow-wrap: anywhere;\n  margin: 8px 0;\n  font-size: 12px;\n  line-height: 1.6;\n}\n\n.booster-notice {\n  border: 1px solid var(--border);\n  background: var(--muted);\n  border-radius: 8px;\n  margin: 0;\n  padding: 12px;\n  font-size: 12px;\n  line-height: 1.6;\n}\n\n.booster-error {\n  color: var(--foreground);\n  border: 1px solid #c2410c;\n  border-radius: 8px;\n  margin: 8px 12px;\n  padding: 8px 10px;\n  font-size: 12px;\n  line-height: 1.5;\n}\n\n.booster-action-primary, .booster-action-secondary {\n  border: 1px solid var(--border);\n  cursor: pointer;\n  min-height: 38px;\n  font: inherit;\n  border-radius: 8px;\n  justify-content: center;\n  align-items: center;\n  gap: 8px;\n  padding: 9px 14px;\n  font-size: 12px;\n  display: inline-flex;\n}\n\n.booster-action-primary {\n  background: var(--primary);\n  color: var(--primary-foreground);\n  text-decoration: none;\n}\n\n.booster-action-secondary {\n  background: var(--secondary);\n  color: var(--secondary-foreground);\n}\n\n.booster-action-primary:disabled, .booster-action-secondary:disabled, .booster-icon-button:disabled {\n  opacity: .45;\n  cursor: not-allowed;\n}\n\n.booster-capture-settings > .booster-form-body {\n  padding-inline: 0;\n}\n\n.booster-reader {\n  grid-template-rows: auto minmax(0, 1fr);\n  height: 100%;\n  display: grid;\n}\n\n.booster-reader-heading {\n  align-items: center;\n  gap: 10px;\n  display: flex;\n}\n\n.booster-reader-layout {\n  grid-template-columns: minmax(210px, 27%) minmax(0, 1fr);\n  min-height: 0;\n  display: grid;\n}\n\n.booster-reader-sidebar {\n  border-right: 1px solid var(--border);\n  background: var(--card);\n  overscroll-behavior: contain;\n  min-width: 0;\n  padding: 12px;\n  overflow: auto;\n}\n\n.booster-reader-group {\n  margin-top: 12px;\n}\n\n.booster-reader-group-header {\n  align-items: center;\n  gap: 2px;\n  min-height: 38px;\n  display: flex;\n}\n\n.booster-group-toggle {\n  min-width: 0;\n  color: inherit;\n  cursor: pointer;\n  text-align: left;\n  font: inherit;\n  background: none;\n  border: 0;\n  flex: 1;\n  align-items: center;\n  gap: 6px;\n  padding: 6px 0;\n  font-size: 12px;\n  display: flex;\n}\n\n.booster-group-toggle svg {\n  flex-shrink: 0;\n}\n\n.booster-group-toggle span {\n  white-space: nowrap;\n  text-overflow: ellipsis;\n  flex: 1;\n  min-width: 0;\n  overflow: hidden;\n}\n\n.booster-group-toggle small {\n  color: var(--muted-foreground);\n  font-size: 10px;\n}\n\n.booster-reader-chat-list {\n  gap: 3px;\n  padding-left: 10px;\n  display: grid;\n}\n\n.booster-reader-chat-list > button {\n  color: inherit;\n  font: inherit;\n  text-align: left;\n  cursor: pointer;\n  white-space: nowrap;\n  text-overflow: ellipsis;\n  background: none;\n  border: 1px solid #0000;\n  border-radius: 8px;\n  align-items: center;\n  gap: 6px;\n  padding: 10px;\n  font-size: 12px;\n  display: flex;\n  overflow: hidden;\n}\n\n.booster-reader-chat-list > button:hover, .booster-reader-chat-list > button.active {\n  background: var(--muted);\n  border-color: var(--border);\n}\n\n.booster-reader-main {\n  background: var(--background);\n  flex-direction: column;\n  min-width: 0;\n  min-height: 0;\n  display: flex;\n  overflow: hidden;\n}\n\n.booster-reader-chat-header {\n  justify-content: space-between;\n  align-items: flex-start;\n  gap: 12px;\n  display: flex;\n}\n\n.booster-reader-chat-header > div {\n  min-width: 0;\n}\n\n.booster-reader-chat-header h2 {\n  margin: 0 0 4px;\n  font-size: 18px;\n  line-height: 1.4;\n}\n\n.booster-reader-chat-header > div > .booster-identity {\n  color: var(--muted-foreground);\n  font-size: 12px;\n}\n\n.booster-reader-summary {\n  color: var(--muted-foreground);\n  flex-wrap: wrap;\n  gap: 6px 14px;\n  margin-block: 10px 0;\n  font-size: 11px;\n  display: flex;\n}\n\n.booster-reader-summary b {\n  color: var(--foreground);\n}\n\n.booster-reader-summary p {\n  flex-basis: 100%;\n  margin: 2px 0 0;\n  line-height: 1.5;\n}\n\n.booster-reader-exchanges {\n  gap: 20px;\n  margin-top: 0;\n  display: grid;\n}\n\n.booster-exchange {\n  border-bottom: 1px solid var(--border);\n  padding-bottom: 16px;\n}\n\n.booster-graph-message {\n  margin-left: calc(min(var(--graph-lane, 0), 3) * 15px);\n  grid-template-columns: 34px minmax(0, 1fr);\n  align-items: stretch;\n  min-width: 0;\n  display: grid;\n}\n\n.booster-graph-rail {\n  background: linear-gradient(var(--border), var(--border)) center / 2px 100% no-repeat;\n  justify-content: center;\n  min-height: 40px;\n  display: flex;\n  position: relative;\n}\n\n.booster-graph-dot {\n  border: 2px solid var(--background);\n  outline: 2px solid var(--primary);\n  background: var(--primary);\n  z-index: 1;\n  border-radius: 50%;\n  align-self: flex-start;\n  width: 12px;\n  height: 12px;\n  margin-top: 14px;\n  position: sticky;\n  top: 12px;\n}\n\n.booster-graph-dot.is-assistant {\n  background: var(--secondary);\n  outline-color: var(--muted-foreground);\n  border-radius: 4px;\n}\n\n.booster-graph-message.is-fork .booster-graph-rail:before {\n  content: "";\n  border-top: 2px solid var(--primary);\n  border-radius: 6px;\n  position: absolute;\n  top: 20px;\n  left: 0;\n  right: 50%;\n}\n\n.booster-graph-content {\n  min-width: 0;\n  padding-bottom: 10px;\n}\n\n.booster-graph-branch-label {\n  border: 1px solid var(--border);\n  color: var(--muted-foreground);\n  border-radius: 999px;\n  align-items: center;\n  gap: 5px;\n  margin: 2px 0 8px 4px;\n  padding: 3px 8px;\n  font-size: 11px;\n  display: inline-flex;\n}\n\n.booster-mobile-back {\n  display: none;\n}\n\n.booster-dialog :is(button, input, select, summary):focus-visible, .booster-dock :is(button, summary):focus-visible {\n  outline: 2px solid var(--ring);\n  outline-offset: 2px;\n}\n\n@media (hover: none) {\n  .booster-identity-copy {\n    opacity: 1;\n  }\n}\n\n@media (max-width: 640px) {\n  .booster-reader-layout {\n    display: block;\n  }\n\n  .booster-reader-sidebar, .booster-reader-main {\n    height: 100%;\n  }\n\n  .booster-reader-sidebar {\n    display: none;\n  }\n\n  .booster-reader-list-mode .booster-reader-sidebar {\n    display: block;\n  }\n\n  .booster-reader-main {\n    padding: 0;\n  }\n\n  .booster-reader-list-mode .booster-reader-main {\n    display: none;\n  }\n\n  .booster-mobile-back {\n    color: inherit;\n    font: inherit;\n    cursor: pointer;\n    background: none;\n    border: 0;\n    align-items: center;\n    gap: 6px;\n    margin-bottom: 12px;\n    padding: 6px 0;\n    font-size: 12px;\n    display: inline-flex;\n  }\n\n  .booster-reader-chat-header {\n    flex-wrap: wrap;\n  }\n\n  .booster-dialog, .booster-dialog-wide {\n    width: calc(100vw - 16px);\n    max-height: calc(100dvh - 16px);\n  }\n\n  .booster-modal-backdrop {\n    padding: 8px;\n  }\n}\n\n.booster-archive-workspace-root {\n  z-index: 2147483645;\n  pointer-events: none;\n  position: fixed;\n  inset: 0;\n}\n\n.booster-archive-workspace {\n  border: 1px solid var(--border);\n  background: var(--background);\n  pointer-events: auto;\n  resize: none;\n  border-radius: 14px;\n  min-width: 520px;\n  min-height: 360px;\n  position: fixed;\n  overflow: hidden;\n  box-shadow: 0 22px 70px #00000052;\n}\n\n.booster-archive-workspace .booster-reader {\n  border-radius: inherit;\n  background: var(--background);\n  height: 100%;\n  overflow: hidden;\n}\n\n.booster-archive-workspace [data-archive-drag-handle] {\n  cursor: move;\n  -webkit-user-select: none;\n  user-select: none;\n  touch-action: none;\n}\n\n.booster-archive-grip {\n  color: var(--muted-foreground);\n  flex: none;\n}\n\n.booster-archive-resize {\n  z-index: 4;\n  background: linear-gradient(135deg, transparent 0 48%, var(--muted-foreground) 49% 54%, transparent 55% 64%, var(--muted-foreground) 65% 70%, transparent 71%);\n  opacity: .55;\n  cursor: nwse-resize;\n  touch-action: none;\n  border: 0;\n  width: 18px;\n  height: 18px;\n  padding: 0;\n  position: absolute;\n  bottom: 0;\n  right: 0;\n}\n\n.booster-archive-dock-button {\n  z-index: 2147483646;\n  border: 1px solid var(--primary);\n  place-items: center;\n  width: 42px;\n  height: 42px;\n  padding: 0;\n  display: grid;\n  position: fixed;\n}\n\n@supports (color: color-mix(in lab, red, red)) {\n  .booster-archive-dock-button {\n    border: 1px solid color-mix(in oklab, var(--primary) 60%, var(--border));\n  }\n}\n\n.booster-archive-dock-button {\n  background: var(--primary);\n  color: var(--primary-foreground);\n  cursor: grab;\n  pointer-events: auto;\n  touch-action: none;\n  border-radius: 10px 0 0 10px;\n  box-shadow: 0 10px 30px #00000047;\n}\n\n.booster-archive-dock-button[style*="left: 0px"] {\n  border-radius: 0 10px 10px 0;\n}\n\n.booster-archive-dock-button:active {\n  cursor: grabbing;\n}\n\n.booster-archive-dock-corner {\n  opacity: .65;\n  width: 9px;\n  height: 9px;\n  position: absolute;\n  bottom: 3px;\n  right: 3px;\n}\n\n.booster-reader-chat-actions {\n  flex-wrap: wrap;\n  justify-content: flex-end;\n  gap: 6px;\n  display: flex;\n}\n\n.booster-exchange-details {\n  border-left: 2px solid var(--border);\n  gap: 6px;\n  margin: 10px 0 10px 12px;\n  padding: 8px 0 8px 12px;\n  display: grid;\n}\n\n@supports (color: color-mix(in lab, red, red)) {\n  .booster-exchange-details {\n    border-left: 2px solid color-mix(in oklab, var(--border) 78%, var(--primary));\n  }\n}\n\n.booster-exchange-details-label {\n  color: var(--muted-foreground);\n  letter-spacing: .04em;\n  text-transform: uppercase;\n  font-size: 10px;\n  font-weight: 650;\n}\n\n.booster-markdown {\n  overflow-wrap: anywhere;\n  font-size: 13px;\n  line-height: 1.65;\n}\n\n.booster-markdown > :first-child {\n  margin-top: 0;\n}\n\n.booster-markdown > :last-child {\n  margin-bottom: 0;\n}\n\n.booster-markdown p {\n  margin: .55em 0;\n}\n\n.booster-markdown h1, .booster-markdown h2, .booster-markdown h3, .booster-markdown h4, .booster-markdown h5, .booster-markdown h6 {\n  color: var(--foreground);\n  margin: 1em 0 .45em;\n  font-weight: 700;\n  line-height: 1.3;\n}\n\n.booster-markdown h1 {\n  font-size: 1.45em;\n}\n\n.booster-markdown h2 {\n  font-size: 1.28em;\n}\n\n.booster-markdown h3 {\n  font-size: 1.14em;\n}\n\n.booster-markdown :is(ul, ol) {\n  margin: .6em 0;\n  padding-left: 1.45em;\n}\n\n.booster-markdown li {\n  margin: .22em 0;\n}\n\n.booster-markdown blockquote {\n  border-left: 3px solid var(--border);\n  color: var(--muted-foreground);\n  margin: .7em 0;\n  padding: .2em 0 .2em .9em;\n}\n\n.booster-markdown code {\n  background: var(--muted);\n  border-radius: 5px;\n  padding: .15em .35em;\n  font: .92em / 1.45 ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;\n}\n\n.booster-markdown pre {\n  border: 1px solid var(--border);\n  background: var(--muted);\n  border-radius: 9px;\n  max-width: 100%;\n  margin: .75em 0;\n  padding: 11px 12px;\n  overflow: auto;\n}\n\n@supports (color: color-mix(in lab, red, red)) {\n  .booster-markdown pre {\n    background: color-mix(in oklab, var(--muted) 72%, var(--background));\n  }\n}\n\n.booster-markdown pre code {\n  white-space: pre;\n  background: none;\n  padding: 0;\n}\n\n.booster-markdown a {\n  color: var(--primary);\n}\n\n@supports (color: color-mix(in lab, red, red)) {\n  .booster-markdown a {\n    color: color-mix(in oklab, var(--primary) 78%, #3b82f6);\n  }\n}\n\n.booster-markdown a {\n  text-underline-offset: 2px;\n  text-decoration: underline;\n}\n\n.booster-markdown hr {\n  background: var(--border);\n  border: 0;\n  height: 1px;\n  margin: 1em 0;\n}\n\n.booster-markdown-table-wrap {\n  max-width: 100%;\n  margin: .8em 0;\n  overflow-x: auto;\n}\n\n.booster-markdown table {\n  border-collapse: collapse;\n  width: max-content;\n  min-width: 100%;\n  font-size: 12px;\n}\n\n.booster-markdown :is(th, td) {\n  border: 1px solid var(--border);\n  text-align: left;\n  vertical-align: top;\n  padding: 6px 9px;\n}\n\n.booster-markdown th {\n  background: var(--muted);\n}\n\n.booster-record {\n  border: 1px solid var(--border);\n  background: var(--card);\n  border-radius: 11px;\n  min-width: 0;\n  max-width: 100%;\n  margin-block: 7px;\n  padding: 11px 13px;\n  position: relative;\n  overflow: hidden;\n}\n\n.booster-record-user {\n  background: var(--muted);\n  margin-left: min(52px, 8%);\n}\n\n.booster-record-reasoning, .booster-record-tool_call, .booster-record-tool_result, .booster-record-internal {\n  background: var(--muted);\n  margin-block: 4px;\n  padding: 8px 10px;\n}\n\n@supports (color: color-mix(in lab, red, red)) {\n  .booster-record-reasoning, .booster-record-tool_call, .booster-record-tool_result, .booster-record-internal {\n    background: color-mix(in oklab, var(--muted) 45%, var(--background));\n  }\n}\n\n.booster-record-header {\n  color: var(--muted-foreground);\n  flex-wrap: wrap;\n  align-items: center;\n  gap: 5px 10px;\n  margin-bottom: 8px;\n  font-size: 10px;\n  display: flex;\n}\n\n.booster-record-header strong {\n  color: var(--foreground);\n  font-size: 11px;\n}\n\n.booster-record-internal-header {\n  justify-content: space-between;\n}\n\n.booster-record-kind {\n  align-items: center;\n  gap: 6px;\n  display: inline-flex;\n}\n\n.booster-record-expand, .booster-record-meta-button, .booster-tool-action {\n  color: var(--muted-foreground);\n  cursor: pointer;\n  background: none;\n  border: 0;\n  border-radius: 6px;\n  align-items: center;\n  gap: 4px;\n  padding: 3px 6px;\n  font: 600 10px / 1.25 inherit;\n  display: inline-flex;\n}\n\n.booster-record-expand:hover, .booster-record-meta-button:hover, .booster-tool-action:hover {\n  background: var(--muted);\n  color: var(--foreground);\n}\n\n.booster-record-meta-button {\n  margin-top: 7px;\n}\n\n.booster-reasoning-preview {\n  max-height: 76px;\n  color: var(--foreground);\n  position: relative;\n  overflow: hidden;\n}\n\n@supports (color: color-mix(in lab, red, red)) {\n  .booster-reasoning-preview {\n    color: color-mix(in oklab, var(--foreground) 82%, var(--muted-foreground));\n  }\n}\n\n.booster-reasoning-preview:not(.expanded):after {\n  background: linear-gradient(transparent, var(--muted));\n  height: 30px;\n  position: absolute;\n  bottom: 0;\n  left: 0;\n  right: 0;\n}\n\n@supports (color: color-mix(in lab, red, red)) {\n  .booster-reasoning-preview:not(.expanded):after {\n    background: linear-gradient(transparent, color-mix(in oklab, var(--muted) 45%, var(--background)));\n  }\n}\n\n.booster-reasoning-preview:not(.expanded):after {\n  content: "";\n  pointer-events: none;\n}\n\n.booster-reasoning-preview.expanded {\n  max-height: none;\n  overflow: visible;\n}\n\n.booster-reasoning-preview .booster-markdown {\n  font-size: 11px;\n  line-height: 1.55;\n}\n\n.booster-tool-row {\n  grid-template-columns: 28px minmax(0, 1fr) auto;\n  align-items: center;\n  gap: 8px;\n  display: grid;\n}\n\n.booster-tool-icon {\n  border: 1px solid var(--border);\n  object-fit: cover;\n  background: var(--background);\n  border-radius: 7px;\n  width: 28px;\n  height: 28px;\n}\n\n.booster-tool-icon-fallback {\n  color: var(--muted-foreground);\n  place-items: center;\n  display: grid;\n}\n\n.booster-tool-copy {\n  gap: 1px;\n  min-width: 0;\n  display: grid;\n}\n\n.booster-tool-copy strong {\n  color: var(--foreground);\n  text-overflow: ellipsis;\n  white-space: nowrap;\n  font-size: 11px;\n  overflow: hidden;\n}\n\n.booster-tool-copy > span {\n  color: var(--muted-foreground);\n  font-size: 9px;\n}\n\n.booster-tool-copy p {\n  color: var(--muted-foreground);\n  text-overflow: ellipsis;\n  white-space: nowrap;\n  margin: 2px 0 0;\n  font-size: 10px;\n  overflow: hidden;\n}\n\n.booster-tool-actions {\n  align-items: center;\n  gap: 2px;\n  display: flex;\n}\n\n.booster-json-viewer {\n  background: var(--background);\n  max-height: min(70vh, 620px);\n  margin: 0;\n  padding: 14px 16px 22px;\n  overflow: auto;\n}\n\n@supports (color: color-mix(in lab, red, red)) {\n  .booster-json-viewer {\n    background: color-mix(in oklab, var(--background) 86%, #0f172a);\n  }\n}\n\n.booster-json-viewer {\n  color: var(--foreground);\n  tab-size: 2;\n  white-space: pre;\n  font: 11px / 1.55 ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;\n}\n\n.booster-tool-expanded {\n  border-top: 1px solid var(--border);\n  margin-top: 8px;\n  padding-top: 8px;\n}\n\n.booster-tool-expanded .booster-markdown {\n  font-size: 11px;\n}\n\n.booster-tool-expanded .booster-json-viewer {\n  border: 1px solid var(--border);\n  border-radius: 8px;\n  max-height: 260px;\n  font-size: 10px;\n}\n\n.booster-internal-row {\n  width: 100%;\n  color: inherit;\n  cursor: pointer;\n  text-align: left;\n  background: none;\n  border: 0;\n  grid-template-columns: auto minmax(0, 1fr) auto;\n  align-items: center;\n  gap: 8px;\n  padding: 0;\n  display: grid;\n}\n\n.booster-internal-row > span:first-child {\n  align-items: center;\n  gap: 5px;\n  font-size: 10px;\n  display: inline-flex;\n}\n\n.booster-internal-preview {\n  color: var(--muted-foreground);\n  text-overflow: ellipsis;\n  white-space: nowrap;\n  font-size: 10px;\n  overflow: hidden;\n}\n\n.booster-record-modal-header {\n  border-bottom: 1px solid var(--border);\n  justify-content: space-between;\n  align-items: flex-start;\n  gap: 14px;\n  padding: 12px 14px;\n  display: flex;\n}\n\n.booster-record-modal-header > div {\n  gap: 2px;\n  min-width: 0;\n  display: grid;\n}\n\n.booster-record-modal-header strong {\n  font-size: 13px;\n}\n\n.booster-record-modal-header span {\n  color: var(--muted-foreground);\n  text-overflow: ellipsis;\n  white-space: nowrap;\n  font-size: 10px;\n  overflow: hidden;\n}\n\n.booster-json-key {\n  color: #60a5fa;\n}\n\n.booster-json-string {\n  color: #86efac;\n}\n\n.booster-json-number {\n  color: #fbbf24;\n}\n\n.booster-json-boolean {\n  color: #c084fc;\n}\n\n.booster-json-null {\n  color: #94a3b8;\n}\n\n.booster-capture-surface {\n  border: 1px solid var(--border);\n  background: var(--background);\n  border-radius: 14px;\n  overflow: hidden;\n}\n\n.booster-capture-surface > .booster-capture-settings {\n  padding: 14px 16px 18px;\n}\n\n@media (max-width: 680px) {\n  .booster-archive-workspace {\n    border-radius: 10px;\n    min-width: 0;\n    min-height: 0;\n  }\n\n  .booster-tool-row {\n    grid-template-columns: 26px minmax(0, 1fr);\n  }\n\n  .booster-tool-actions {\n    grid-column: 2;\n    justify-content: flex-start;\n  }\n\n  .booster-reader-chat-actions {\n    justify-content: flex-start;\n    width: 100%;\n  }\n}\n\n.booster-analytics-dashboard {\n  gap: 12px;\n  display: grid;\n}\n\n.booster-analytics-header {\n  justify-content: space-between;\n  align-items: flex-start;\n  gap: 14px;\n  display: flex;\n}\n\n.booster-analytics-header > div {\n  gap: 3px;\n  display: grid;\n}\n\n.booster-analytics-header strong {\n  font-size: 14px;\n}\n\n.booster-analytics-header span {\n  max-width: 520px;\n  color: var(--muted-foreground);\n  font-size: 11px;\n  line-height: 1.45;\n}\n\n.booster-analytics-reset {\n  white-space: nowrap;\n  min-height: 30px;\n  padding: 5px 8px;\n}\n\n.booster-analytics-metrics {\n  grid-template-columns: repeat(3, minmax(0, 1fr));\n  gap: 8px;\n  display: grid;\n}\n\n.booster-analytics-metrics article {\n  border: 1px solid var(--border);\n  background: var(--background);\n  border-radius: 11px;\n  gap: 2px;\n  min-width: 0;\n  padding: 10px 11px;\n  display: grid;\n}\n\n@supports (color: color-mix(in lab, red, red)) {\n  .booster-analytics-metrics article {\n    background: color-mix(in oklab, var(--background) 82%, var(--muted));\n  }\n}\n\n.booster-analytics-metrics :where(article > span), .booster-analytics-metrics :where(small) {\n  color: var(--muted-foreground);\n  font-size: 9px;\n  line-height: 1.35;\n}\n\n.booster-analytics-metrics strong {\n  font-variant-numeric: tabular-nums;\n  margin-top: 2px;\n  font-size: 24px;\n  line-height: 1;\n}\n\n.booster-analytics-metrics article.warning {\n  border-color: #ef4444;\n}\n\n@supports (color: color-mix(in lab, red, red)) {\n  .booster-analytics-metrics article.warning {\n    border-color: color-mix(in oklab, #ef4444 45%, var(--border));\n  }\n}\n\n.booster-analytics-metrics article.warning {\n  background: #ef4444;\n}\n\n@supports (color: color-mix(in lab, red, red)) {\n  .booster-analytics-metrics article.warning {\n    background: color-mix(in oklab, #ef4444 8%, var(--background));\n  }\n}\n\n.booster-analytics-flow-grid {\n  grid-template-columns: repeat(2, minmax(0, 1fr));\n  gap: 8px;\n  display: grid;\n}\n\n.booster-analytics-flow-card {\n  border: 1px solid var(--border);\n  background: var(--background);\n  border-radius: 11px;\n  gap: 9px;\n  padding: 11px;\n  display: grid;\n}\n\n.booster-analytics-flow-card > header {\n  justify-content: space-between;\n  align-items: center;\n  gap: 8px;\n  font-size: 11px;\n  display: flex;\n}\n\n.booster-analytics-flow-card :where(header > span) {\n  color: var(--muted-foreground);\n  align-items: center;\n  gap: 5px;\n  display: inline-flex;\n}\n\n.booster-analytics-flow-card :where(header b) {\n  font-variant-numeric: tabular-nums;\n  font-size: 12px;\n}\n\n.booster-analytics-flow-row {\n  color: var(--muted-foreground);\n  grid-template-columns: minmax(88px, .9fr) minmax(80px, 1.3fr) auto;\n  align-items: center;\n  gap: 7px;\n  font-size: 9px;\n  display: grid;\n}\n\n.booster-analytics-flow-row > div {\n  background: var(--muted);\n  border-radius: 999px;\n  height: 5px;\n  overflow: hidden;\n}\n\n.booster-analytics-flow-row i {\n  border-radius: inherit;\n  background: var(--primary);\n  height: 100%;\n  display: block;\n}\n\n.booster-analytics-flow-row b {\n  min-width: 24px;\n  color: var(--foreground);\n  text-align: right;\n  font-variant-numeric: tabular-nums;\n  font-size: 10px;\n}\n\n.booster-analytics-footer {\n  background: var(--muted);\n  color: var(--muted-foreground);\n  border-radius: 9px;\n  flex-wrap: wrap;\n  justify-content: space-between;\n  gap: 8px 16px;\n  padding: 8px 10px;\n  font-size: 10px;\n  display: flex;\n}\n\n.booster-analytics-footer span {\n  align-items: center;\n  gap: 5px;\n  display: inline-flex;\n}\n\n.booster-analytics-footer b {\n  color: var(--foreground);\n  font-weight: 650;\n}\n\n.booster-analytics-footer .warning {\n  color: #ef4444;\n}\n\n@media (max-width: 720px) {\n  .booster-analytics-metrics, .booster-analytics-flow-grid {\n    grid-template-columns: 1fr;\n  }\n\n  .booster-analytics-header {\n    flex-direction: column;\n  }\n}\n\n.booster-record-header {\n  min-width: 0;\n}\n\n.booster-record-header-tools {\n  align-items: center;\n  gap: 2px;\n  margin-left: auto;\n  display: inline-flex;\n}\n\n.booster-record-icon-button {\n  width: 24px;\n  height: 24px;\n  color: var(--muted-foreground);\n  cursor: pointer;\n  background: none;\n  border: 0;\n  border-radius: 6px;\n  flex: none;\n  justify-content: center;\n  align-items: center;\n  padding: 0;\n  display: inline-flex;\n}\n\n.booster-record-icon-button:hover {\n  background: var(--muted);\n  color: var(--foreground);\n}\n\n.booster-record-edited {\n  color: var(--muted-foreground);\n  white-space: nowrap;\n  font-size: 9px;\n}\n\n.booster-record-raw-corner {\n  position: absolute;\n  top: 5px;\n  right: 5px;\n}\n\n.booster-tool-row {\n  min-width: 0;\n  max-width: 100%;\n  overflow: hidden;\n}\n\n.booster-tool-row.is-clickable {\n  cursor: pointer;\n}\n\n.booster-tool-copy, .booster-tool-actions {\n  min-width: 0;\n}\n\n.booster-tool-actions {\n  flex: none;\n}\n\n.booster-tool-action {\n  flex: none;\n  text-decoration: none;\n}\n\n.booster-tool-expanded {\n  min-width: 0;\n  max-width: 100%;\n  overflow: auto hidden;\n}\n\n.booster-internal-row {\n  min-width: 0;\n  max-width: 100%;\n  overflow: hidden;\n}\n\n.booster-internal-row.disabled {\n  cursor: default;\n  opacity: .8;\n}\n\n.booster-internal-preview {\n  text-overflow: ellipsis;\n  white-space: nowrap;\n  min-width: 0;\n  max-width: 100%;\n  padding-right: 2px;\n}\n\n.booster-json-modal {\n  background: var(--background);\n  flex-direction: column;\n  width: 100%;\n  min-width: 0;\n  height: 100%;\n  min-height: 0;\n  display: flex;\n  overflow: hidden;\n}\n\n.booster-json-modal .booster-json-viewer {\n  box-sizing: border-box;\n  flex: auto;\n  width: 100%;\n  min-width: 0;\n  max-width: 100%;\n  max-height: none;\n  overflow: auto;\n}\n\n.booster-dialog-wide:has(.booster-json-modal) {\n  min-width: 0;\n  min-height: 0;\n  display: flex;\n}\n\n.booster-reader-main, .booster-reader-exchanges, .booster-exchange, .booster-exchange-details {\n  min-width: 0;\n  max-width: 100%;\n}\n\n.booster-reader-main {\n  overflow-x: hidden;\n}\n\n.booster-export-status {\n  border: 1px solid var(--border);\n  background: var(--muted);\n  border-radius: 10px;\n  grid-template-columns: auto minmax(0, 1fr) auto;\n  align-items: center;\n  gap: 8px;\n  padding: 9px 10px;\n  display: grid;\n}\n\n@supports (color: color-mix(in lab, red, red)) {\n  .booster-export-status {\n    background: color-mix(in oklab, var(--muted) 52%, var(--background));\n  }\n}\n\n.booster-export-status.warning {\n  border-color: #f59e0b;\n}\n\n@supports (color: color-mix(in lab, red, red)) {\n  .booster-export-status.warning {\n    border-color: color-mix(in oklab, #f59e0b 44%, var(--border));\n  }\n}\n\n.booster-export-status.warning {\n  background: #f59e0b;\n}\n\n@supports (color: color-mix(in lab, red, red)) {\n  .booster-export-status.warning {\n    background: color-mix(in oklab, #f59e0b 7%, var(--background));\n  }\n}\n\n.booster-export-status > div {\n  gap: 2px;\n  min-width: 0;\n  display: grid;\n}\n\n.booster-export-status strong {\n  font-size: 10px;\n  line-height: 1.4;\n}\n\n.booster-export-status span {\n  color: var(--muted-foreground);\n  font-size: 9px;\n}\n\n.booster-export-status .booster-action-secondary {\n  white-space: nowrap;\n  min-height: 30px;\n  padding: 5px 8px;\n}\n\n.booster-dock-context > .booster-dock-history-state {\n  color: var(--muted-foreground);\n  font-size: 9px;\n  line-height: 1.35;\n}\n\n.booster-export-preferences {\n  gap: 8px;\n  display: grid;\n}\n\n.booster-export-preferences > label {\n  gap: 6px;\n  font-size: 12px;\n  font-weight: 600;\n  display: grid;\n}\n\n.booster-export-preferences > .booster-note {\n  margin: 0;\n}\n\n.booster-reader-message-jump, .booster-reader-message-jump form, .booster-export-preview-record {\n  flex-wrap: wrap;\n  align-items: center;\n  gap: 8px;\n  display: flex;\n}\n\n.booster-reader-message-jump input {\n  flex: 1;\n  min-width: 160px;\n}\n\n.booster-export-preview-record > span {\n  overflow-wrap: anywhere;\n  flex: 220px;\n}\n\n.booster-message-target {\n  outline: 2px solid var(--primary);\n  outline-offset: 2px;\n  border-radius: 6px;\n}\n\n[data-archive-message] {\n  scroll-margin-block: 20px;\n}\n\n.booster-export-readiness {\n  border: 1px solid var(--border);\n  border-radius: 8px;\n  gap: 10px;\n  padding: 12px;\n  font-size: 12px;\n  display: grid;\n}\n\n.booster-export-readiness > header, .booster-export-recovery-actions {\n  flex-wrap: wrap;\n  align-items: center;\n  gap: 8px;\n  display: flex;\n}\n\n.booster-export-readiness > header {\n  justify-content: space-between;\n}\n\n.booster-export-readiness dl {\n  gap: 6px;\n  margin: 0;\n  display: grid;\n}\n\n.booster-export-readiness dl > div {\n  flex-wrap: wrap;\n  justify-content: space-between;\n  gap: 6px 12px;\n  display: flex;\n}\n\n.booster-export-readiness dd {\n  text-align: end;\n  margin: 0;\n}\n\n.booster-export-readiness p {\n  margin: 0;\n}\n\n.booster-export-blockers {\n  gap: 6px;\n  margin: 0;\n  padding-inline-start: 18px;\n  display: grid;\n}\n\n.booster-export-blockers li {\n  overflow-wrap: anywhere;\n}\n\n.booster-export-progress {\n  border: 1px solid var(--border);\n  border-radius: 8px;\n  gap: 8px;\n  padding: 10px;\n  display: grid;\n}\n\n.booster-export-progress > p {\n  overflow-wrap: anywhere;\n  margin: 0;\n  font-size: 12px;\n}\n\n.booster-export-progress progress {\n  width: 100%;\n  height: 8px;\n  accent-color: var(--primary);\n  display: block;\n}\n\n.booster-export-preview-content {\n  border: 1px solid var(--border);\n  border-radius: 8px;\n  gap: 8px;\n  max-height: min(360px, 48vh);\n  padding: 10px;\n  display: grid;\n  overflow: auto;\n}\n\n.booster-export-preview-content .booster-note {\n  white-space: pre-wrap;\n  margin: 0;\n}\n\n.booster-export-preview-skeleton {\n  gap: 8px;\n  display: grid;\n}\n\n.booster-export-preview-skeleton > span {\n  background: var(--muted);\n  border-radius: 6px;\n  height: 30px;\n  display: block;\n}\n\n.booster-export-dialog input[type="text"] {\n  border: 1px solid var(--border);\n  background: var(--background);\n  width: 100%;\n  min-height: 38px;\n  color: var(--foreground);\n  font: inherit;\n  border-radius: 8px;\n  padding: 8px 10px;\n}\n\n.booster-meta-badges {\n  align-items: center;\n  gap: 2px;\n  display: inline-flex;\n}\n\n.booster-meta-badges.compact {\n  gap: 0;\n}\n\n.booster-meta-trigger {\n  width: 28px;\n  height: 28px;\n  color: var(--muted-foreground);\n  cursor: help;\n  border-radius: 8px;\n  outline: none;\n  justify-content: center;\n  align-items: center;\n  display: inline-flex;\n}\n\n.booster-meta-trigger.is-clickable {\n  cursor: pointer;\n}\n\n.booster-meta-trigger:hover, .booster-meta-trigger:focus-visible {\n  background: var(--muted);\n  color: var(--foreground);\n}\n\n.booster-meta-trigger:focus-visible {\n  box-shadow: 0 0 0 2px var(--ring);\n}\n\n.booster-floating-popover {\n  z-index: 2147483647;\n  border: 1px solid var(--border, #94a3b842);\n  background: var(--popover, #202020);\n  width: max-content;\n  min-width: 190px;\n  max-width: min(420px, 100vw - 16px);\n  color: var(--popover-foreground, #f4f4f5);\n  letter-spacing: normal;\n  white-space: normal;\n  pointer-events: none;\n  border-radius: 10px;\n  margin: 0;\n  padding: 9px 10px;\n  font-family: inherit;\n  font-size: 12px;\n  font-weight: 400;\n  line-height: 1.45;\n  position: fixed;\n  inset: auto;\n  box-shadow: 0 14px 38px #0000006b;\n}\n\n.booster-floating-popover:has(.booster-message-meta-body), .booster-floating-popover:has(.booster-tool-detail-popover) {\n  border-color: #4ade8052;\n  box-shadow: 0 14px 38px #0000006b, 0 0 0 1px #22c55e0d;\n}\n\n.booster-floating-popover.is-interactive {\n  pointer-events: auto;\n}\n\n.booster-floating-popover:not(:popover-open):not(.is-open) {\n  display: none;\n}\n\n.booster-meta-lines {\n  grid-template-columns: max-content minmax(0, 1fr);\n  gap: 3px 10px;\n  display: grid;\n}\n\n.booster-meta-label {\n  color: var(--muted-foreground);\n  font-size: 10px;\n  font-weight: 600;\n}\n\n.booster-meta-value {\n  overflow-wrap: anywhere;\n  min-width: 0;\n  color: var(--popover-foreground);\n  font-variant-numeric: tabular-nums;\n}\n\n.booster-scope-popover {\n  gap: 10px;\n  min-width: 260px;\n  display: grid;\n}\n\n.booster-scope-popover > header {\n  gap: 1px;\n  display: grid;\n}\n\n.booster-scope-title {\n  max-width: 280px;\n  color: var(--foreground);\n  text-overflow: ellipsis;\n  white-space: nowrap;\n  font-size: 12px;\n  overflow: hidden;\n}\n\n.booster-scope-kind {\n  color: var(--muted-foreground);\n  font-size: 10px;\n}\n\n.booster-scope-actions {\n  flex-wrap: wrap;\n  gap: 5px;\n  display: flex;\n}\n\n.booster-scope-actions button {\n  border: 1px solid var(--border);\n  background: var(--background);\n  min-height: 28px;\n  color: var(--foreground);\n  cursor: pointer;\n  font: inherit;\n  border-radius: 7px;\n  align-items: center;\n  gap: 5px;\n  padding: 4px 8px;\n  font-size: 10px;\n  display: inline-flex;\n}\n\n.booster-scope-actions button:hover {\n  background: var(--muted);\n}\n\n.booster-live-tool-row {\n  width: min(100%, 48rem);\n  color: var(--muted-foreground);\n  align-items: center;\n  gap: 6px;\n  padding: 4px 0;\n  display: flex;\n}\n\n.booster-live-tool-copy {\n  flex: auto;\n  align-items: baseline;\n  gap: 6px;\n  min-width: 0;\n  display: flex;\n}\n\n.booster-live-tool-name {\n  color: var(--foreground);\n  text-overflow: ellipsis;\n  white-space: nowrap;\n  font-size: 11px;\n  font-weight: 650;\n  overflow: hidden;\n}\n\n.booster-live-tool-action-name {\n  color: var(--muted-foreground);\n  text-overflow: ellipsis;\n  white-space: nowrap;\n  font-size: 10px;\n  overflow: hidden;\n}\n\n.booster-live-tool-details {\n  border: 1px solid var(--border);\n  background: var(--card);\n  width: min(100%, 48rem);\n  color: var(--card-foreground);\n  border-radius: 12px;\n  margin-top: 4px;\n  padding: 10px;\n  box-shadow: 0 8px 24px #0000001f;\n}\n\n.booster-chat-save-marker {\n  background: none;\n  border-radius: 999px;\n  flex: 0 0 6px;\n  width: 6px;\n  height: 6px;\n  display: block;\n}\n\n.booster-chat-save-marker.is-enabled {\n  background: #22c55e;\n  box-shadow: 0 0 0 1px #22c55e40, 0 0 6px #22c55e61;\n}\n\n.booster-chat-save-marker.is-work {\n  background: #ef4444;\n  box-shadow: 0 0 0 1px #ef444452, 0 0 8px #ef44448c;\n}\n\n.booster-project-status-badge {\n  color: #a1a1aa;\n  background: #ffffff08;\n  border: 1px solid #94a3b852;\n  border-radius: 8px;\n  justify-content: center;\n  align-items: center;\n  width: 24px;\n  height: 24px;\n  transition: border-color .12s, background-color .12s, color .12s;\n  display: inline-flex;\n}\n\n.booster-project-status-badge.is-enabled {\n  color: #4ade80;\n  background: #22c55e14;\n  border-color: #22c55eb8;\n}\n\n.booster-project-status-badge.is-disabled {\n  color: #f87171;\n  background: #ef444412;\n  border-color: #ef444494;\n}\n\n.booster-agent-activity {\n  border: 1px solid var(--border, #94a3b838);\n  background: var(--background, #202020);\n  border-radius: 999px;\n  align-items: center;\n  gap: 6px;\n  max-width: min(100%, 520px);\n  min-height: 28px;\n  padding: 3px 8px;\n  display: inline-flex;\n}\n\n@supports (color: color-mix(in lab, red, red)) {\n  .booster-agent-activity {\n    background: color-mix(in srgb, var(--background, #202020) 88%, transparent);\n  }\n}\n\n.booster-agent-activity {\n  color: var(--muted-foreground);\n  pointer-events: auto;\n  font-size: 11px;\n  line-height: 1.2;\n}\n\n.booster-agent-activity[data-phase="tool"] {\n  border-style: dashed;\n}\n\n.booster-agent-activity > svg {\n  flex: none;\n}\n\n.booster-agent-activity-phase {\n  color: var(--foreground);\n  flex: none;\n  font-weight: 600;\n}\n\n.booster-agent-activity-label {\n  text-overflow: ellipsis;\n  white-space: nowrap;\n  min-width: 0;\n  overflow: hidden;\n}\n\n.booster-agent-activity-timer {\n  min-width: 3.2em;\n  color: var(--foreground);\n  font-variant-numeric: tabular-nums;\n  text-align: end;\n  flex: none;\n  margin-inline-start: auto;\n}\n\n.booster-danger-zone {\n  background: #7f1d1d14;\n  border: 1px solid #ef444473;\n  border-radius: 12px;\n  justify-content: space-between;\n  align-items: center;\n  gap: 16px;\n  padding: 12px;\n  display: flex;\n}\n\n.booster-danger-zone .booster-setting-copy > div, .booster-danger-zone .booster-setting-copy b {\n  color: #f87171;\n}\n\n.booster-destructive-button {\n  color: #fff;\n  cursor: pointer;\n  background: #b91c1c;\n  border: 1px solid #ef44448c;\n  border-radius: 8px;\n  flex: none;\n  min-height: 34px;\n  padding: 7px 12px;\n  font-size: 12px;\n  font-weight: 700;\n}\n\n.booster-destructive-button:hover:not(:disabled) {\n  background: #991b1b;\n}\n\n.booster-destructive-button:disabled {\n  opacity: .55;\n  cursor: default;\n}\n\n.booster-destructive-dialog {\n  grid-template-columns: auto minmax(0, 1fr);\n  gap: 14px;\n  padding: 22px;\n  display: grid;\n}\n\n.booster-destructive-dialog strong {\n  color: #f87171;\n  letter-spacing: .025em;\n  font-size: 17px;\n}\n\n.booster-destructive-dialog p {\n  color: var(--muted-foreground);\n  margin: 8px 0 0;\n  font-size: 12px;\n  line-height: 1.55;\n}\n\n.booster-destructive-icon {\n  color: #f87171;\n  background: #7f1d1d33;\n  border-radius: 50%;\n  justify-content: center;\n  align-items: center;\n  width: 42px;\n  height: 42px;\n  display: flex;\n}\n\n.booster-destructive-warning {\n  color: #f87171;\n  font-weight: 700;\n}\n\n.booster-destructive-actions {\n  grid-column: 1 / -1;\n  justify-content: flex-end;\n  gap: 8px;\n  padding-top: 4px;\n  display: flex;\n}\n\n.booster-meta-trigger-time {\n  color: #4ade80;\n  font-variant-numeric: tabular-nums;\n  cursor: pointer;\n  background: #22c55e17;\n  border: 1px solid #4ade806b;\n  gap: 0;\n  width: 26px;\n  min-width: 26px;\n  height: 26px;\n  padding: 0;\n}\n\n.booster-meta-trigger-time:hover, .booster-meta-trigger-time:focus-visible {\n  color: #86efac;\n  background: #22c55e29;\n  border-color: #4ade80b8;\n}\n\n.booster-meta-time-text {\n  letter-spacing: .01em;\n  font-size: 9px;\n  font-weight: 650;\n}\n\n.booster-message-meta-popover {\n  max-width: min(420px, 100vw - 16px);\n}\n\n.booster-message-meta-body {\n  gap: 12px;\n  min-width: 260px;\n  display: grid;\n}\n\n.booster-message-meta-header {\n  border-bottom: 1px solid var(--border);\n  justify-content: space-between;\n  align-items: baseline;\n  gap: 12px;\n  padding-bottom: 7px;\n  display: flex;\n}\n\n.booster-message-meta-header strong {\n  color: var(--popover-foreground);\n  font-size: 12px;\n  font-weight: 650;\n}\n\n.booster-message-meta-header span {\n  color: #4ade80;\n  font-variant-numeric: tabular-nums;\n  font-size: 10px;\n  font-weight: 650;\n}\n\n.booster-meta-raw-toggle {\n  border: 1px solid var(--border);\n  width: fit-content;\n  color: var(--muted-foreground);\n  font: inherit;\n  cursor: pointer;\n  background: none;\n  border-radius: 7px;\n  padding: 4px 7px;\n}\n\n.booster-meta-raw-toggle:hover {\n  background: var(--muted);\n  color: var(--foreground);\n}\n\n.booster-message-meta-raw {\n  white-space: pre-wrap;\n  overflow-wrap: anywhere;\n  background: #0003;\n  border-radius: 8px;\n  max-width: 390px;\n  max-height: 260px;\n  margin: 0;\n  padding: 8px;\n  font: 10px / 1.4 ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;\n  overflow: auto;\n}\n\n.booster-live-tool-icon {\n  object-fit: cover;\n  border-radius: 999px;\n  flex: 0 0 16px;\n  width: 16px;\n  height: 16px;\n}\n\n.booster-tool-time-chip {\n  color: #c084fc;\n  font-variant-numeric: tabular-nums;\n  background: #7e22ce1c;\n  border: 1px solid #a855f775;\n  gap: 5px;\n  width: auto;\n  min-width: 76px;\n  padding: 0 8px;\n  font-size: 10px;\n  font-weight: 700;\n}\n\n.booster-tool-time-chip:hover, .booster-tool-time-chip:focus-visible {\n  color: #d8b4fe;\n  background: #7e22ce30;\n  border-color: #c084fcc2;\n}\n\n.booster-agent-activity[data-phase="thinking"], .booster-agent-activity[data-phase="tool"], .booster-agent-activity[data-phase="responding"], .booster-agent-activity[data-phase="complete"] {\n  color: #4ade80;\n  background: #22c55e17;\n  border-color: #4ade807a;\n}\n\n.booster-agent-activity[data-phase="thinking"] .booster-agent-activity-phase, .booster-agent-activity[data-phase="tool"] .booster-agent-activity-phase, .booster-agent-activity[data-phase="responding"] .booster-agent-activity-phase, .booster-agent-activity[data-phase="complete"] .booster-agent-activity-phase, .booster-agent-activity[data-phase="thinking"] .booster-agent-activity-timer, .booster-agent-activity[data-phase="tool"] .booster-agent-activity-timer, .booster-agent-activity[data-phase="responding"] .booster-agent-activity-timer, .booster-agent-activity[data-phase="complete"] .booster-agent-activity-timer {\n  color: currentColor;\n}\n\n.booster-tool-inspect-trigger {\n  color: #4ade80;\n  pointer-events: auto;\n  background: #22c55e14;\n  border: 1px solid #4ade8061;\n  border-radius: 7px;\n  width: 24px;\n  height: 24px;\n}\n\n.booster-tool-inspect-trigger:hover, .booster-tool-inspect-trigger:focus-visible {\n  color: #86efac;\n  background: #22c55e26;\n  border-color: #4ade80ad;\n}\n\n.booster-tool-detail-popover {\n  gap: 10px;\n  width: min(390px, 100vw - 24px);\n  display: grid;\n}\n\n.booster-tool-detail-popover > header {\n  align-items: center;\n  gap: 8px;\n  display: flex;\n}\n\n.booster-tool-detail-popover > header strong {\n  text-overflow: ellipsis;\n  white-space: nowrap;\n  color: var(--popover-foreground);\n  font-size: 11px;\n  display: block;\n  overflow: hidden;\n}\n\n.booster-tool-detail-popover > header span {\n  text-overflow: ellipsis;\n  white-space: nowrap;\n  color: var(--muted-foreground);\n  font-size: 10px;\n  display: block;\n  overflow: hidden;\n}\n\n.booster-tool-payload {\n  gap: 5px;\n  display: grid;\n}\n\n.booster-tool-payload > strong, .booster-tool-evidence > summary {\n  color: var(--muted-foreground);\n  font-size: 10px;\n  font-weight: 650;\n}\n\n.booster-tool-evidence > summary {\n  cursor: pointer;\n}\n\n.booster-tool-attributes {\n  grid-template-columns: max-content minmax(0, 1fr);\n  gap: 3px 8px;\n  margin: 8px 0 0;\n  font: 9px / 1.35 ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;\n  display: grid;\n}\n\n.booster-tool-attributes dt {\n  color: var(--muted-foreground);\n}\n\n.booster-tool-attributes dd {\n  overflow-wrap: anywhere;\n  min-width: 0;\n  margin: 0;\n}\n\n.booster-tool-evidence pre {\n  white-space: pre-wrap;\n  overflow-wrap: anywhere;\n  background: #0003;\n  border-radius: 7px;\n  max-height: 180px;\n  margin: 8px 0 0;\n  padding: 7px;\n  font: 9px / 1.4 ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;\n  overflow: auto;\n}\n\n.booster-tool-link {\n  overflow-wrap: anywhere;\n  color: #4ade80;\n  align-items: center;\n  gap: 4px;\n  min-width: 0;\n  text-decoration: none;\n  display: inline-flex;\n}\n\n.booster-tool-link:hover {\n  color: #86efac;\n  text-decoration: underline;\n}\n\n.booster-work-mode-warning {\n  color: #fca5a5;\n  background: #ef44441a;\n  border: 1px solid #ef44448c;\n  border-radius: 999px;\n  align-items: center;\n  gap: 7px;\n  padding: 4px 9px;\n  font-family: inherit;\n  font-size: 10px;\n  line-height: 1.25;\n  display: inline-flex;\n}\n\n.booster-work-mode-warning strong {\n  color: #f87171;\n  font-weight: 750;\n}\n\n.booster-work-mode-warning > span:before {\n  content: "·";\n  color: #f87171b8;\n  margin-inline-end: 7px;\n}\n\n.booster-request-status {\n  color: #86efac;\n  font-variant-numeric: tabular-nums;\n  background: #22c55e12;\n  border: 1px solid #4ade8047;\n  border-radius: 999px;\n  align-items: center;\n  gap: 6px;\n  padding: 3px 8px;\n  font-family: inherit;\n  font-size: 10px;\n  line-height: 1.25;\n  display: inline-flex;\n}\n\n.booster-request-spinner {\n  border: 1.5px solid #4ade8047;\n  border-top-color: #4ade80;\n  border-radius: 50%;\n  flex: 0 0 11px;\n  width: 11px;\n  height: 11px;\n  animation: .9s linear infinite booster-request-spin;\n}\n\n@keyframes booster-request-spin {\n  to {\n    transform: rotate(360deg);\n  }\n}\n\n.booster-request-status > span {\n  align-items: center;\n  gap: 4px;\n  display: inline-flex;\n}\n\n.booster-request-status > span + span:before {\n  content: "·";\n  color: var(--muted-foreground);\n}\n\n.booster-request-status-label {\n  color: var(--muted-foreground);\n  font-weight: 500;\n}\n\n.booster-request-status strong {\n  color: #4ade80;\n  font-size: 10px;\n  font-weight: 700;\n}\n\n.booster-request-status[data-phase="tool"] strong {\n  color: #c084fc;\n}\n\n.booster-request-status[data-phase="responding"] strong {\n  color: #86efac;\n}\n\n.booster-alert-setting-actions {\n  grid-template-columns: auto minmax(180px, 1fr);\n  align-items: center;\n  gap: 14px;\n  display: grid;\n}\n\n.booster-alert-threshold {\n  gap: 5px;\n  display: grid;\n}\n\n.booster-alert-threshold > span {\n  color: var(--muted-foreground);\n  justify-content: space-between;\n  gap: 10px;\n  font-size: 10px;\n  display: flex;\n}\n\n.booster-alert-threshold b {\n  color: var(--foreground);\n  font-variant-numeric: tabular-nums;\n}\n\n.booster-alert-threshold input[type="range"] {\n  width: 100%;\n  accent-color: var(--primary);\n}\n\n.booster-tool-path {\n  max-width: 280px;\n  font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;\n  font-size: 9px;\n}\n\n.booster-reader-pinned {\n  border-bottom: 1px solid var(--border);\n  background: var(--background);\n  flex: none;\n  min-width: 0;\n  max-height: 52%;\n  padding: 12px 20px 10px;\n  overflow: auto;\n}\n\n.booster-reader-reading-surface {\n  flex: 1 1 0;\n  min-width: 0;\n  min-height: 0;\n  position: relative;\n}\n\n.booster-reader-scroll {\n  scrollbar-gutter: stable;\n  overscroll-behavior: contain;\n  min-width: 0;\n  height: 100%;\n  padding: 18px 20px 30px;\n  overflow: hidden auto;\n}\n\n.booster-reader-chat-header h2 {\n  overflow-wrap: anywhere;\n  font-size: 16px;\n}\n\n.booster-reader-chat-actions {\n  justify-content: flex-start;\n  margin-top: 9px;\n}\n\n.booster-reader-find {\n  margin-top: 8px;\n}\n\n.booster-reader-find input {\n  border: 1px solid var(--border);\n  background: var(--card);\n  width: 100%;\n  min-width: 0;\n  color: var(--foreground);\n  font: inherit;\n  border-radius: 8px;\n  padding: 8px 10px;\n  font-size: 12px;\n  display: block;\n}\n\n.booster-reader-chat-list > button span {\n  text-overflow: ellipsis;\n  min-width: 0;\n  overflow: hidden;\n}\n\n.booster-reader-chat-list > button.is-branch {\n  border-inline-start: 2px solid var(--primary);\n}\n\n@supports (color: color-mix(in lab, red, red)) {\n  .booster-reader-chat-list > button.is-branch {\n    border-inline-start: 2px solid color-mix(in oklab, var(--primary) 35%, transparent);\n  }\n}\n\n.booster-reader-branch-icon {\n  opacity: .66;\n  flex: none;\n}\n\n.booster-reader-loading {\n  color: var(--muted-foreground);\n  align-items: center;\n  gap: 8px;\n  font-size: 12px;\n  display: flex;\n}\n\n.booster-reader-older-loading {\n  z-index: 2;\n  border: 1px solid var(--border);\n  background: var(--card);\n  color: var(--foreground);\n  white-space: nowrap;\n  pointer-events: none;\n  border-radius: 100px;\n  align-items: center;\n  gap: 7px;\n  padding: 8px 12px;\n  font-size: 11px;\n  display: flex;\n  position: absolute;\n  inset: 6px auto auto 50%;\n  transform: translateX(-50%);\n  box-shadow: 0 3px 12px #0000001f;\n}\n\n.booster-reader-spinner {\n  flex: none;\n  animation: .9s linear infinite booster-archive-spin;\n}\n\n@keyframes booster-archive-spin {\n  to {\n    rotate: 360deg;\n  }\n}\n\n@media (prefers-reduced-motion: reduce) {\n  .booster-reader-spinner {\n    animation: none;\n  }\n}\n\n@media (max-width: 640px) {\n  .booster-reader-pinned {\n    padding: 10px 12px;\n  }\n\n  .booster-reader-scroll {\n    padding: 12px 12px 24px;\n  }\n}\n\n.booster-reader-reading-surface > .booster-reader-scroll {\n  flex: auto;\n  min-width: 0;\n}\n\n.booster-reader-map {\n  border-left: 1px solid var(--border);\n  background: var(--card);\n  flex-direction: column;\n  flex: 0 0 108px;\n  order: 2;\n  align-items: center;\n  width: 108px;\n  padding: 7px 3px;\n  display: flex;\n}\n\n.booster-reader-map-track {\n  background: linear-gradient(var(--border), var(--border)) center / 2px 100% no-repeat;\n  flex: 1;\n  width: 100%;\n  min-height: 0;\n  position: relative;\n}\n\n.booster-reader-map-node {\n  left: calc(18px + min(var(--map-lane, 0), 3) * 23px);\n  border: 1px solid var(--background);\n  background: var(--muted-foreground);\n  cursor: pointer;\n  z-index: 1;\n  border-radius: 3px;\n  width: 8px;\n  height: 8px;\n  padding: 0;\n  position: absolute;\n  transform: translate(-50%, -50%);\n}\n\n.booster-reader-map-node.is-user {\n  background: var(--primary);\n  border-radius: 50%;\n}\n\n.booster-reader-map-node.is-fork {\n  width: 12px;\n  height: 12px;\n  box-shadow: 0 0 0 2px var(--primary);\n}\n\n.booster-reader-map-node:hover, .booster-reader-map-node:focus-visible, .booster-reader-map-node.is-near {\n  outline: 1px solid var(--ring);\n  z-index: 4;\n  width: 13px;\n  height: 13px;\n}\n\n.booster-reader-map-position {\n  border: 1px solid var(--ring);\n  background: var(--primary);\n  height: 19px;\n  position: absolute;\n  left: 0;\n  right: 0;\n  transform: translateY(-50%);\n}\n\n@supports (color: color-mix(in lab, red, red)) {\n  .booster-reader-map-position {\n    background: color-mix(in oklab, var(--primary) 16%, transparent);\n  }\n}\n\n.booster-reader-map-position {\n  pointer-events: none;\n  z-index: 0;\n  border-radius: 6px;\n}\n\n.booster-reader-map-end {\n  color: var(--foreground);\n  cursor: pointer;\n  background: none;\n  border: 0;\n  font-size: 15px;\n}\n\n.booster-reader-pinned {\n  max-height: 35%;\n  padding: 8px 12px;\n}\n\n.booster-reader-summary {\n  align-items: center;\n  margin-top: 4px;\n}\n\n.booster-reader-coverage {\n  align-items: center;\n  gap: 5px;\n  display: inline-flex;\n}\n\n.booster-reader-project-label {\n  color: var(--muted-foreground);\n  font-weight: 400;\n}\n\n.booster-reader-chat-actions {\n  margin-top: 4px;\n}\n\n.booster-reader-chat-actions .booster-action-secondary {\n  padding: 5px 8px;\n}\n\n.booster-reader-heading {\n  justify-content: center;\n}\n\n.booster-reader-exchanges {\n  gap: 12px;\n}\n\n.booster-reader-map-node.is-fork:after {\n  content: "";\n  width: calc(min(var(--map-lane, 0), 3) * 23px);\n  border-top: 2px solid var(--primary);\n  position: absolute;\n  top: 50%;\n  right: 80%;\n}\n\n.booster-reader-loading {\n  justify-content: center;\n  min-height: 130px;\n  font-size: 13px;\n}\n\n.booster-reader-map-node {\n  transition: top .1s ease-out, width .12s ease-out, height .12s ease-out;\n}\n\n.booster-reader-map-node:hover:before, .booster-reader-map-node:focus-visible:before {\n  content: attr(data-preview);\n  z-index: 12;\n  border: 1px solid var(--border);\n  background: var(--card);\n  width: 240px;\n  min-width: 170px;\n  max-width: min(240px, 60vw);\n  color: var(--foreground);\n  white-space: normal;\n  text-align: left;\n  pointer-events: none;\n  border-radius: 8px;\n  padding: 10px 12px;\n  font-size: 12px;\n  font-weight: 400;\n  line-height: 1.45;\n  position: absolute;\n  top: -8px;\n  right: calc(100% + 15px);\n  box-shadow: 0 7px 24px oklab(0% none none / .18);\n}\n\n.booster-reader .booster-section-header {\n  min-height: 42px;\n  padding-block: 6px;\n}\n\n.booster-reader-heading {\n  gap: 7px;\n}\n\n.booster-reader-heading strong {\n  font-size: 12px;\n}\n\n.booster-reader-heading p {\n  opacity: .7;\n  margin: 0;\n  font-size: 10px;\n}\n\n.booster-reader-older-loading {\n  border-radius: 10px;\n  font-size: 12px;\n  inset: 50% auto auto 50%;\n}\n\n.booster-reader-map-links {\n  pointer-events: none;\n  width: 100%;\n  height: 100%;\n  position: absolute;\n  inset: 0;\n  overflow: visible;\n}\n\n.booster-reader-map-links path {\n  fill: none;\n  stroke: var(--primary);\n  stroke-width: 1.5px;\n  vector-effect: non-scaling-stroke;\n  opacity: .58;\n}\n\n.booster-reader-fork-choices {\n  flex-wrap: wrap;\n  gap: 6px;\n  max-height: 115px;\n  margin-top: 6px;\n  display: flex;\n  overflow: auto;\n}\n\n.booster-reader-fork-group {\n  border: 1px solid var(--border);\n  border-radius: 7px;\n  flex-wrap: wrap;\n  align-items: center;\n  gap: 5px;\n  padding: 5px 8px;\n  font-size: 11px;\n  display: flex;\n}\n\n.booster-reader-fork-group > span {\n  color: var(--muted-foreground);\n  font-weight: 600;\n}\n\n.booster-reader-fork-choice {\n  text-overflow: ellipsis;\n  white-space: nowrap;\n  background: var(--secondary);\n  border: 1px solid var(--border);\n  cursor: pointer;\n  border-radius: 6px;\n  max-width: 180px;\n  padding: 4px 6px;\n  font-size: 11px;\n  overflow: hidden;\n}\n\n.booster-reader-fork-choice:hover, .booster-reader-fork-choice:focus-visible {\n  border-color: var(--ring);\n}\n\n.booster-reader-map-track {\n  background: none;\n}\n\n.booster-reader-map-links path {\n  stroke-width: 2.5px;\n  opacity: .95;\n}\n\n.booster-reader-map-node.is-fork {\n  background: var(--primary);\n  box-shadow: 0 0 0 3px var(--card), 0 0 0 5px var(--primary);\n}\n\n.booster-reader-map-node.is-fork:after {\n  display: none;\n}\n\n@media (max-width: 700px) {\n  .booster-reader-map {\n    flex-basis: 88px;\n    width: 88px;\n  }\n\n  .booster-reader-map-node {\n    left: calc(12px + min(var(--map-lane, 0), 3) * 19px);\n  }\n}\n\n.booster-reader-map-warning {\n  border: 1px solid var(--border);\n  width: 19px;\n  height: 19px;\n  color: var(--foreground);\n  text-align: center;\n  cursor: help;\n  border-radius: 50%;\n  font-size: 12px;\n}\n\n.booster-archive-flow-graph {\n  scrollbar-gutter: stable;\n  overflow-x: auto;\n}\n\n.booster-gitgraph-content {\n  width: max-content;\n  min-width: 0;\n  padding: 4px 8px 10px;\n}\n\n.booster-gitgraph-segment {\n  width: max-content;\n}\n\n.booster-gitgraph-gap {\n  border-left: 2px dashed var(--border);\n  height: 21px;\n  color: var(--muted-foreground);\n  padding: 1px 9px;\n  font-size: 13px;\n  line-height: 20px;\n}\n\n.booster-gitgraph-segment-canvas svg g[data-archive-graph-node] {\n  cursor: pointer;\n  outline: none;\n}\n\n.booster-gitgraph-segment-canvas svg g[data-archive-graph-node]:is(:hover, :focus-visible) > use {\n  filter: drop-shadow(0 0 3px var(--ring));\n}\n\n.booster-gitgraph-segment-canvas svg g[data-archive-graph-node][aria-current="true"] > use {\n  filter: drop-shadow(0 0 3px var(--foreground));\n}\n\n.booster-reader-reading-surface {\n  display: block;\n}\n\n.booster-reader-reading-surface > .booster-reader-scroll {\n  width: 100%;\n  height: 100%;\n}\n\n.booster-reader-history-toggle.active {\n  background: var(--muted);\n  border-color: var(--ring);\n}\n\n.booster-archive-flow-graph {\n  z-index: 5;\n  order: unset;\n  overscroll-behavior: contain;\n  border: 1px solid var(--border);\n  background: var(--background);\n  scrollbar-gutter: stable;\n  border-radius: 12px;\n  flex: none;\n  width: min(360px, 100% - 16px);\n  max-width: none;\n  height: auto;\n  display: block;\n  position: absolute;\n  inset: 8px 8px 8px auto;\n  overflow: hidden auto;\n  box-shadow: 0 10px 32px #00000047;\n}\n\n.booster-history-header {\n  z-index: 3;\n  border-bottom: 1px solid var(--border);\n  background: var(--background);\n  justify-content: space-between;\n  align-items: flex-start;\n  gap: 10px;\n  min-width: 0;\n  padding: 15px 14px 10px;\n  display: flex;\n  position: sticky;\n  top: 0;\n}\n\n.booster-history-header > div {\n  min-width: 0;\n}\n\n.booster-history-heading {\n  color: var(--foreground);\n  font-size: 14px;\n  font-weight: 650;\n  line-height: 20px;\n}\n\n.booster-history-header p {\n  color: var(--muted-foreground);\n  margin: 3px 0 0;\n  font-size: 11px;\n}\n\n.booster-history-close {\n  border: 1px solid var(--border);\n  background: var(--card);\n  width: 28px;\n  height: 28px;\n  color: var(--muted-foreground);\n  cursor: pointer;\n  border-radius: 7px;\n  flex: 0 0 28px;\n  place-items: center;\n  font-size: 19px;\n  display: grid;\n}\n\n.booster-history-close:hover {\n  color: var(--foreground);\n  background: var(--muted);\n}\n\n.booster-history-state {\n  color: var(--foreground);\n  align-items: center;\n  gap: 7px;\n  padding: 12px 14px 0;\n  font-size: 11px;\n  font-weight: 550;\n  display: flex;\n}\n\n.booster-history-state-dot {\n  background: var(--primary);\n  border-radius: 50%;\n  flex: 0 0 7px;\n  width: 7px;\n  height: 7px;\n}\n\n.booster-history-state-dot.is-unverified {\n  background: var(--muted-foreground);\n}\n\n.booster-history-range {\n  color: var(--muted-foreground);\n  font-variant-numeric: tabular-nums;\n  white-space: nowrap;\n  margin-left: auto;\n  font-weight: 400;\n}\n\n.booster-history-explainer {\n  color: var(--muted-foreground);\n  margin: 6px 14px 0;\n  font-size: 11px;\n  line-height: 1.45;\n}\n\n.booster-history-evidence {\n  background: var(--muted);\n  color: var(--muted-foreground);\n  border-radius: 6px;\n  margin: 10px 14px 2px;\n  padding: 7px 9px;\n  font-size: 10px;\n}\n\n.booster-gitgraph-content {\n  width: 100%;\n  min-width: 0;\n  min-height: 0;\n  padding: 12px 9px 16px;\n  display: block;\n}\n\n.booster-gitgraph-segment {\n  width: 100%;\n  position: relative;\n}\n\n.booster-gitgraph-segment-canvas {\n  min-width: 0;\n}\n\n.booster-gitgraph-segment-labels {\n  pointer-events: none;\n  height: 100%;\n  position: absolute;\n  inset: 0 8px 0 80px;\n}\n\n.booster-graph-message {\n  width: 100%;\n  height: 28px;\n  color: var(--foreground);\n  text-align: left;\n  cursor: pointer;\n  pointer-events: auto;\n  background: none;\n  border: 1px solid #0000;\n  border-radius: 5px;\n  flex-direction: column;\n  justify-content: center;\n  gap: 1px;\n  padding: 1px 7px;\n  display: flex;\n  position: absolute;\n  right: 0;\n}\n\n.booster-graph-message:hover, .booster-graph-message:focus-visible {\n  border-color: var(--border);\n  background: var(--muted);\n}\n\n.booster-graph-message[aria-current="true"] {\n  background: var(--primary);\n}\n\n@supports (color: color-mix(in lab, red, red)) {\n  .booster-graph-message[aria-current="true"] {\n    background: color-mix(in oklab, var(--primary) 12%, var(--card));\n  }\n}\n\n.booster-graph-message[aria-current="true"] {\n  border-color: var(--primary);\n}\n\n@supports (color: color-mix(in lab, red, red)) {\n  .booster-graph-message[aria-current="true"] {\n    border-color: color-mix(in oklab, var(--primary) 35%, var(--border));\n  }\n}\n\n.booster-graph-message-role {\n  color: var(--muted-foreground);\n  font-size: 9px;\n  line-height: 12px;\n}\n\n.booster-graph-message-preview {\n  width: 100%;\n  color: var(--foreground);\n  white-space: nowrap;\n  text-overflow: ellipsis;\n  font-size: 11px;\n  line-height: 14px;\n  overflow: hidden;\n}\n\n.booster-history-list {\n  flex-direction: column;\n  gap: 2px;\n  padding: 12px 9px 14px;\n  display: flex;\n}\n\n.booster-history-list-row {\n  width: 100%;\n  min-height: 48px;\n  color: var(--foreground);\n  text-align: left;\n  cursor: pointer;\n  background: none;\n  border: 1px solid #0000;\n  border-radius: 8px;\n  align-items: stretch;\n  gap: 10px;\n  padding: 6px 8px;\n  display: flex;\n}\n\n.booster-history-list-row:hover, .booster-history-list-row:focus-visible {\n  background: var(--muted);\n  border-color: var(--border);\n}\n\n.booster-history-list-row[aria-current="true"] {\n  background: var(--primary);\n}\n\n@supports (color: color-mix(in lab, red, red)) {\n  .booster-history-list-row[aria-current="true"] {\n    background: color-mix(in oklab, var(--primary) 10%, var(--card));\n  }\n}\n\n.booster-history-list-row[aria-current="true"] {\n  border-color: var(--primary);\n}\n\n@supports (color: color-mix(in lab, red, red)) {\n  .booster-history-list-row[aria-current="true"] {\n    border-color: color-mix(in oklab, var(--primary) 32%, var(--border));\n  }\n}\n\n.booster-history-list-rail {\n  flex: 0 0 12px;\n  justify-content: center;\n  padding-top: 7px;\n  display: flex;\n}\n\n.booster-history-list-dot {\n  border: 2px solid var(--muted-foreground);\n  border-radius: 50%;\n  width: 8px;\n  height: 8px;\n}\n\n.booster-history-list-dot.is-user {\n  background: var(--primary);\n  border-color: var(--primary);\n}\n\n.booster-history-list-copy {\n  flex-direction: column;\n  flex: 1;\n  gap: 3px;\n  min-width: 0;\n  display: flex;\n}\n\n.booster-history-list-meta {\n  color: var(--muted-foreground);\n  font-size: 10px;\n  line-height: 13px;\n}\n\n.booster-history-list-preview {\n  -webkit-line-clamp: 2;\n  overflow-wrap: anywhere;\n  -webkit-box-orient: vertical;\n  font-size: 11px;\n  line-height: 1.4;\n  display: -webkit-box;\n  overflow: hidden;\n}\n\n.booster-history-footer {\n  z-index: 3;\n  border-top: 1px solid var(--border);\n  background: var(--background);\n  justify-content: space-between;\n  gap: 8px;\n  padding: 10px 12px;\n  display: flex;\n  position: sticky;\n  bottom: 0;\n}\n\n.booster-history-footer button {\n  border: 1px solid var(--border);\n  background: var(--card);\n  color: var(--foreground);\n  font: inherit;\n  cursor: pointer;\n  border-radius: 7px;\n  padding: 6px 10px;\n  font-size: 11px;\n}\n\n.booster-history-footer button:disabled {\n  opacity: .35;\n  cursor: not-allowed;\n}\n\n.booster-history-close:focus-visible, .booster-history-footer button:focus-visible, .booster-history-list-row:focus-visible, .booster-graph-message:focus-visible {\n  outline: 2px solid var(--ring);\n  outline-offset: 2px;\n}\n\n@media (max-width: 700px) {\n  .booster-archive-flow-graph {\n    width: 100%;\n    box-shadow: none;\n    scrollbar-gutter: auto;\n    border: 0;\n    border-radius: 0;\n    inset: 0;\n  }\n\n  .booster-history-header {\n    padding-right: 16px;\n  }\n\n  .booster-history-state {\n    flex-wrap: wrap;\n  }\n\n  .booster-history-range {\n    text-align: right;\n    flex: 100%;\n  }\n}\n\n.booster-reader {\n  position: relative;\n}\n\n.booster-reader-heading {\n  justify-content: flex-start;\n  min-width: 0;\n}\n\n.booster-reader-heading > div {\n  min-width: 0;\n}\n\n.booster-reader-heading strong {\n  line-height: 1.25;\n  display: block;\n}\n\n.booster-reader > .booster-section-header > .booster-header-actions {\n  flex: none;\n  gap: 6px;\n}\n\n.booster-reader-tools {\n  position: relative;\n}\n\n.booster-reader-tools-menu {\n  z-index: 12;\n  border: 1px solid var(--border);\n  background: var(--popover, var(--card));\n  border-radius: 10px;\n  min-width: 222px;\n  padding: 5px;\n  display: grid;\n  position: absolute;\n  top: calc(100% + 8px);\n  right: 0;\n  box-shadow: 0 12px 30px #00000047;\n}\n\n.booster-reader-tools-menu button {\n  width: 100%;\n  color: var(--foreground);\n  font: inherit;\n  text-align: left;\n  cursor: pointer;\n  background: none;\n  border: 0;\n  border-radius: 7px;\n  align-items: center;\n  gap: 9px;\n  padding: 10px 12px;\n  font-size: 12px;\n  line-height: 1.35;\n  display: flex;\n}\n\n.booster-reader-tools-menu button:hover, .booster-reader-tools-menu button:focus-visible {\n  background: var(--accent);\n}\n\n.booster-maintenance-backdrop {\n  z-index: 18;\n  background: #000000b3;\n  justify-content: center;\n  align-items: center;\n  min-width: 0;\n  padding: clamp(12px, 3vw, 28px);\n  display: flex;\n  position: absolute;\n  inset: 0;\n}\n\n.booster-maintenance-widget {\n  border: 1px solid var(--border);\n  background: var(--background);\n  width: min(100%, 570px);\n  min-height: 0;\n  max-height: min(700px, 100%);\n  color: var(--foreground);\n  font: inherit;\n  border-radius: 14px;\n  flex-direction: column;\n  display: flex;\n  overflow: hidden;\n  box-shadow: 0 24px 70px #00000059;\n}\n\n.booster-maintenance-heading {\n  border-bottom: 1px solid var(--border);\n  flex: none;\n  justify-content: space-between;\n  align-items: center;\n  gap: 14px;\n  padding: 15px 18px;\n  display: flex;\n}\n\n.booster-maintenance-title {\n  align-items: center;\n  gap: 11px;\n  min-width: 0;\n  display: flex;\n}\n\n.booster-maintenance-title > div {\n  min-width: 0;\n}\n\n.booster-maintenance-title h2 {\n  margin: 0;\n  font-size: 16px;\n  font-weight: 650;\n  line-height: 1.35;\n}\n\n.booster-maintenance-title p {\n  color: var(--muted-foreground);\n  margin: 3px 0 0;\n  font-size: 11px;\n}\n\n.booster-maintenance-content {\n  overscroll-behavior: contain;\n  scrollbar-gutter: stable;\n  align-content: start;\n  gap: 14px;\n  min-height: 0;\n  padding: 16px 18px;\n  display: grid;\n  overflow: hidden auto;\n}\n\n.booster-maintenance-stats {\n  grid-template-columns: repeat(3, minmax(0, 1fr));\n  gap: 8px;\n  display: grid;\n}\n\n.booster-maintenance-stats > div {\n  border: 1px solid var(--border);\n  background: var(--muted);\n  border-radius: 9px;\n  gap: 5px;\n  min-width: 0;\n  padding: 11px;\n  display: grid;\n}\n\n.booster-maintenance-stats span {\n  color: var(--muted-foreground);\n  font-size: 10px;\n  line-height: 1.4;\n}\n\n.booster-maintenance-stats strong {\n  font-variant-numeric: tabular-nums;\n  font-size: 20px;\n  font-weight: 650;\n}\n\n.booster-maintenance-section {\n  border: 1px solid var(--border);\n  border-radius: 10px;\n  gap: 11px;\n  min-width: 0;\n  padding: 15px;\n  display: grid;\n}\n\n.booster-maintenance-section-title {\n  align-items: center;\n  gap: 9px;\n  display: flex;\n}\n\n.booster-maintenance-section h3 {\n  margin: 0;\n  font-size: 13px;\n  font-weight: 650;\n}\n\n.booster-maintenance-section p, .booster-maintenance-result p, .booster-maintenance-progress p {\n  color: var(--muted-foreground);\n  overflow-wrap: anywhere;\n  margin: 0;\n  font-size: 12px;\n  line-height: 1.5;\n}\n\n.booster-maintenance-section .booster-maintenance-warning {\n  color: var(--foreground);\n  border-left: 2px solid #d97706;\n  padding-left: 10px;\n}\n\n.booster-maintenance-widget .booster-maintenance-check {\n  min-width: 0;\n  color: var(--muted-foreground);\n  cursor: pointer;\n  align-items: flex-start;\n  gap: 10px;\n  font-size: 11px;\n  line-height: 1.5;\n  display: flex;\n}\n\n.booster-maintenance-widget .booster-maintenance-check input {\n  width: 16px;\n  height: 16px;\n  min-height: 16px;\n  accent-color: var(--primary);\n  flex: 0 0 16px;\n  margin: 1px 0 0;\n  padding: 0;\n}\n\n.booster-maintenance-actions {\n  flex-wrap: wrap;\n  gap: 8px;\n  display: flex;\n}\n\n.booster-maintenance-actions button {\n  flex: 170px;\n  min-width: 0;\n}\n\n.booster-maintenance-actions button small {\n  opacity: .8;\n  font-size: 10px;\n  display: block;\n}\n\n.booster-maintenance-section > button {\n  justify-self: start;\n  max-width: 100%;\n}\n\n.booster-maintenance-loading, .booster-maintenance-progress, .booster-maintenance-result {\n  border: 1px solid var(--border);\n  border-radius: 9px;\n  align-items: flex-start;\n  gap: 10px;\n  min-width: 0;\n  padding: 12px;\n  font-size: 12px;\n  line-height: 1.5;\n  display: flex;\n}\n\n.booster-maintenance-result svg, .booster-maintenance-progress svg {\n  flex: none;\n}\n\n.booster-maintenance-result strong, .booster-maintenance-progress strong {\n  margin-bottom: 3px;\n  font-size: 12px;\n  display: block;\n}\n\n.booster-maintenance-error {\n  color: var(--foreground);\n  overflow-wrap: anywhere;\n  border: 1px solid #c2410c;\n  border-radius: 8px;\n  margin: 0;\n  padding: 10px;\n  font-size: 12px;\n}\n\n.booster-maintenance-footer {\n  border-top: 1px solid var(--border);\n  flex: none;\n  justify-content: flex-end;\n  gap: 8px;\n  padding: 12px 18px;\n  display: flex;\n}\n\n@media (max-width: 620px) {\n  .booster-maintenance-backdrop {\n    padding: 8px;\n  }\n\n  .booster-maintenance-heading, .booster-maintenance-content {\n    padding: 12px;\n  }\n\n  .booster-maintenance-stats strong {\n    font-size: 17px;\n  }\n\n  .booster-maintenance-stats > div {\n    padding: 8px;\n  }\n\n  .booster-reader > .booster-section-header {\n    padding: 8px 10px;\n  }\n}\n\n.booster-maintenance-owner-list {\n  gap: 8px;\n  max-height: 290px;\n  display: grid;\n  overflow-y: auto;\n}\n\n.booster-maintenance-owner-row {\n  border: 1px solid var(--border);\n  cursor: pointer;\n  border-radius: 8px;\n  align-items: flex-start;\n  gap: 10px;\n  padding: 10px;\n  display: flex;\n}\n\n.booster-maintenance-owner-row > input[type="checkbox"] {\n  width: 16px;\n  height: 16px;\n  accent-color: var(--primary);\n  flex: 0 0 16px;\n  margin: 2px 0 0;\n  padding: 0;\n}\n\n.booster-maintenance-owner-description {\n  gap: 4px;\n  min-width: 0;\n  display: grid;\n}\n\n.booster-maintenance-owner-description > strong {\n  overflow-wrap: anywhere;\n  font-size: 12px;\n}\n\n.booster-maintenance-owner-description > span, .booster-maintenance-owner-caution {\n  color: var(--muted-foreground);\n  font-size: 11px;\n  line-height: 1.45;\n}\n\n.booster-maintenance-owner-description details {\n  color: var(--muted-foreground);\n  font-size: 11px;\n}\n\n.booster-maintenance-owner-description summary {\n  cursor: pointer;\n}\n\n.booster-maintenance-owner-description code {\n  overflow-wrap: anywhere;\n  margin-top: 5px;\n  font: 10px / 1.4 ui-monospace, monospace;\n  display: block;\n}\n\n.booster-maintenance-owner-description small {\n  margin-top: 6px;\n  display: block;\n}\n\n.booster-maintenance-link {\n  color: var(--foreground);\n  font: inherit;\n  cursor: pointer;\n  background: none;\n  border: 0;\n  justify-self: start;\n  padding: 0;\n  font-size: 11px;\n  text-decoration: underline;\n}\n\n.booster-maintenance-link:disabled {\n  opacity: .5;\n  cursor: not-allowed;\n}\n\n.booster-export-disclosure {\n  border: 1px solid var(--border);\n  border-radius: 8px;\n  padding: 10px 12px;\n  font-size: 12px;\n}\n\n.booster-export-disclosure > summary {\n  cursor: pointer;\n  font-weight: 600;\n}\n\n.booster-export-disclosure > summary small {\n  color: var(--muted-foreground);\n  margin-inline-start: 8px;\n  font-weight: 400;\n}\n\n.booster-export-disclosure[open] > section, .booster-export-disclosure[open] > label, .booster-export-disclosure[open] > p {\n  margin-block-start: 12px;\n}\n\n.booster-maintenance-backup-tools > summary {\n  cursor: pointer;\n  font-weight: 600;\n}\n\n.booster-maintenance-backup-tools > p {\n  margin-block: 10px;\n}\n\n.booster-maintenance-backup-restore {\n  gap: 12px;\n  margin-block-start: 14px;\n  display: grid;\n}\n\n.booster-maintenance-backup-restore > label {\n  gap: 8px;\n  display: grid;\n}\n\n.booster-maintenance-backup-restore input[type="file"] {\n  max-width: 100%;\n}\n\n.booster-control-embedded {\n  box-shadow: none;\n  background: none;\n  border: 0;\n  width: 100%;\n  max-width: none;\n}\n\n.booster-control-embedded > .booster-settings-layout {\n  min-height: 0;\n  max-height: none;\n}\n\n@property --tw-rotate-x {\n  syntax: "*";\n  inherits: false\n}\n\n@property --tw-rotate-y {\n  syntax: "*";\n  inherits: false\n}\n\n@property --tw-rotate-z {\n  syntax: "*";\n  inherits: false\n}\n\n@property --tw-skew-x {\n  syntax: "*";\n  inherits: false\n}\n\n@property --tw-skew-y {\n  syntax: "*";\n  inherits: false\n}\n\n@property --tw-border-style {\n  syntax: "*";\n  inherits: false;\n  initial-value: solid;\n}\n\n@property --tw-leading {\n  syntax: "*";\n  inherits: false\n}\n\n@property --tw-font-weight {\n  syntax: "*";\n  inherits: false\n}\n\n@property --tw-ordinal {\n  syntax: "*";\n  inherits: false\n}\n\n@property --tw-slashed-zero {\n  syntax: "*";\n  inherits: false\n}\n\n@property --tw-numeric-figure {\n  syntax: "*";\n  inherits: false\n}\n\n@property --tw-numeric-spacing {\n  syntax: "*";\n  inherits: false\n}\n\n@property --tw-numeric-fraction {\n  syntax: "*";\n  inherits: false\n}\n\n@property --tw-shadow {\n  syntax: "*";\n  inherits: false;\n  initial-value: 0 0 #0000;\n}\n\n@property --tw-shadow-color {\n  syntax: "*";\n  inherits: false\n}\n\n@property --tw-shadow-alpha {\n  syntax: "<percentage>";\n  inherits: false;\n  initial-value: 100%;\n}\n\n@property --tw-inset-shadow {\n  syntax: "*";\n  inherits: false;\n  initial-value: 0 0 #0000;\n}\n\n@property --tw-inset-shadow-color {\n  syntax: "*";\n  inherits: false\n}\n\n@property --tw-inset-shadow-alpha {\n  syntax: "<percentage>";\n  inherits: false;\n  initial-value: 100%;\n}\n\n@property --tw-ring-color {\n  syntax: "*";\n  inherits: false\n}\n\n@property --tw-ring-shadow {\n  syntax: "*";\n  inherits: false;\n  initial-value: 0 0 #0000;\n}\n\n@property --tw-inset-ring-color {\n  syntax: "*";\n  inherits: false\n}\n\n@property --tw-inset-ring-shadow {\n  syntax: "*";\n  inherits: false;\n  initial-value: 0 0 #0000;\n}\n\n@property --tw-ring-inset {\n  syntax: "*";\n  inherits: false\n}\n\n@property --tw-ring-offset-width {\n  syntax: "<length>";\n  inherits: false;\n  initial-value: 0;\n}\n\n@property --tw-ring-offset-color {\n  syntax: "*";\n  inherits: false;\n  initial-value: #fff;\n}\n\n@property --tw-ring-offset-shadow {\n  syntax: "*";\n  inherits: false;\n  initial-value: 0 0 #0000;\n}\n\n@property --tw-outline-style {\n  syntax: "*";\n  inherits: false;\n  initial-value: solid;\n}\n\n@property --tw-blur {\n  syntax: "*";\n  inherits: false\n}\n\n@property --tw-brightness {\n  syntax: "*";\n  inherits: false\n}\n\n@property --tw-contrast {\n  syntax: "*";\n  inherits: false\n}\n\n@property --tw-grayscale {\n  syntax: "*";\n  inherits: false\n}\n\n@property --tw-hue-rotate {\n  syntax: "*";\n  inherits: false\n}\n\n@property --tw-invert {\n  syntax: "*";\n  inherits: false\n}\n\n@property --tw-opacity {\n  syntax: "*";\n  inherits: false\n}\n\n@property --tw-saturate {\n  syntax: "*";\n  inherits: false\n}\n\n@property --tw-sepia {\n  syntax: "*";\n  inherits: false\n}\n\n@property --tw-drop-shadow {\n  syntax: "*";\n  inherits: false\n}\n\n@property --tw-drop-shadow-color {\n  syntax: "*";\n  inherits: false\n}\n\n@property --tw-drop-shadow-alpha {\n  syntax: "<percentage>";\n  inherits: false;\n  initial-value: 100%;\n}\n\n@property --tw-drop-shadow-size {\n  syntax: "*";\n  inherits: false\n}\n';
  let sharedSheet;
  let constructedSheetsUnavailable = false;
  function boosterStyleSheet() {
    if (constructedSheetsUnavailable) return void 0;
    if (sharedSheet) return sharedSheet;
    if (typeof CSSStyleSheet !== "function" || typeof CSSStyleSheet.prototype.replaceSync !== "function") {
      constructedSheetsUnavailable = true;
      return void 0;
    }
    try {
      const sheet = new CSSStyleSheet();
      sheet.replaceSync(styles);
      sharedSheet = sheet;
      return sheet;
    } catch {
      constructedSheetsUnavailable = true;
      return void 0;
    }
  }
  function installBoosterShadowStyles(shadow) {
    const sheet = boosterStyleSheet();
    if (sheet && "adoptedStyleSheets" in shadow) {
      if (!shadow.adoptedStyleSheets.includes(sheet))
        shadow.adoptedStyleSheets = [...shadow.adoptedStyleSheets, sheet];
      return;
    }
    const style = document.createElement("style");
    style.textContent = styles;
    shadow.append(style);
  }
  // @__NO_SIDE_EFFECTS__
  function makeMap(str) {
    const map = /* @__PURE__ */ Object.create(null);
    for (const key of str.split(",")) map[key] = 1;
    return (val) => val in map;
  }
  const EMPTY_OBJ = {};
  const EMPTY_ARR = [];
  const NOOP = () => {
  };
  const NO = () => false;
  const isOn = (key) => key.charCodeAt(0) === 111 && key.charCodeAt(1) === 110 && // uppercase letter
  (key.charCodeAt(2) > 122 || key.charCodeAt(2) < 97);
  const isModelListener = (key) => key.startsWith("onUpdate:");
  const extend = Object.assign;
  const remove = (arr, el) => {
    const i = arr.indexOf(el);
    if (i > -1) {
      arr.splice(i, 1);
    }
  };
  const hasOwnProperty$1 = Object.prototype.hasOwnProperty;
  const hasOwn = (val, key) => hasOwnProperty$1.call(val, key);
  const isArray = Array.isArray;
  const isMap = (val) => toTypeString(val) === "[object Map]";
  const isSet = (val) => toTypeString(val) === "[object Set]";
  const isDate = (val) => toTypeString(val) === "[object Date]";
  const isFunction = (val) => typeof val === "function";
  const isString = (val) => typeof val === "string";
  const isSymbol = (val) => typeof val === "symbol";
  const isObject = (val) => val !== null && typeof val === "object";
  const isPromise = (val) => {
    return (isObject(val) || isFunction(val)) && isFunction(val.then) && isFunction(val.catch);
  };
  const objectToString = Object.prototype.toString;
  const toTypeString = (value) => objectToString.call(value);
  const toRawType = (value) => {
    return toTypeString(value).slice(8, -1);
  };
  const isPlainObject = (val) => toTypeString(val) === "[object Object]";
  const isIntegerKey = (key) => isString(key) && key !== "NaN" && key[0] !== "-" && "" + parseInt(key, 10) === key;
  const isReservedProp = /* @__PURE__ */ makeMap(
    // the leading comma is intentional so empty string "" is also included
    ",key,ref,ref_for,ref_key,onVnodeBeforeMount,onVnodeMounted,onVnodeBeforeUpdate,onVnodeUpdated,onVnodeBeforeUnmount,onVnodeUnmounted"
  );
  const cacheStringFunction = (fn) => {
    const cache = /* @__PURE__ */ Object.create(null);
    return ((str) => {
      const hit = cache[str];
      return hit || (cache[str] = fn(str));
    });
  };
  const camelizeRE = /-\w/g;
  const camelize = cacheStringFunction(
    (str) => {
      return str.replace(camelizeRE, (c) => c.slice(1).toUpperCase());
    }
  );
  const hyphenateRE = /\B([A-Z])/g;
  const hyphenate = cacheStringFunction(
    (str) => str.replace(hyphenateRE, "-$1").toLowerCase()
  );
  const capitalize = cacheStringFunction((str) => {
    return str.charAt(0).toUpperCase() + str.slice(1);
  });
  const toHandlerKey = cacheStringFunction(
    (str) => {
      const s = str ? `on${capitalize(str)}` : ``;
      return s;
    }
  );
  const hasChanged = (value, oldValue) => !Object.is(value, oldValue);
  const invokeArrayFns = (fns, ...arg) => {
    for (let i = 0; i < fns.length; i++) {
      fns[i](...arg);
    }
  };
  const def = (obj, key, value, writable = false) => {
    Object.defineProperty(obj, key, {
      configurable: true,
      enumerable: false,
      writable,
      value
    });
  };
  const looseToNumber = (val) => {
    const n = parseFloat(val);
    return isNaN(n) ? val : n;
  };
  let _globalThis;
  const getGlobalThis = () => {
    return _globalThis || (_globalThis = typeof globalThis !== "undefined" ? globalThis : typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : typeof global !== "undefined" ? global : {});
  };
  function normalizeStyle(value) {
    if (isArray(value)) {
      const res = {};
      for (let i = 0; i < value.length; i++) {
        const item = value[i];
        const normalized = isString(item) ? parseStringStyle(item) : normalizeStyle(item);
        if (normalized) {
          for (const key in normalized) {
            res[key] = normalized[key];
          }
        }
      }
      return res;
    } else if (isString(value) || isObject(value)) {
      return value;
    }
  }
  const listDelimiterRE = /;(?![^(]*\))/g;
  const propertyDelimiterRE = /:([^]+)/;
  const styleCommentRE = /"(?:[^"\\]|\\[^])*"|'(?:[^'\\]|\\[^])*'|\\[^]|\/\*[^]*?\*\//g;
  function parseStringStyle(cssText) {
    const ret = {};
    cssText.replace(styleCommentRE, (match) => match.startsWith("/*") ? "" : match).split(listDelimiterRE).forEach((item) => {
      if (item) {
        const tmp = item.split(propertyDelimiterRE);
        tmp.length > 1 && (ret[tmp[0].trim()] = tmp[1].trim());
      }
    });
    return ret;
  }
  function normalizeClass(value) {
    let res = "";
    if (isString(value)) {
      res = value;
    } else if (isArray(value)) {
      for (let i = 0; i < value.length; i++) {
        const normalized = normalizeClass(value[i]);
        if (normalized) {
          res += normalized + " ";
        }
      }
    } else if (isObject(value)) {
      for (const name in value) {
        if (value[name]) {
          res += name + " ";
        }
      }
    }
    return res.trim();
  }
  const specialBooleanAttrs = `itemscope,allowfullscreen,formnovalidate,ismap,nomodule,novalidate,readonly`;
  const isSpecialBooleanAttr = /* @__PURE__ */ makeMap(specialBooleanAttrs);
  function includeBooleanAttr(value) {
    return !!value || value === "";
  }
  function looseCompareArrays(a, b, seen) {
    if (a.length !== b.length) return false;
    let equal = true;
    for (let i = 0; equal && i < a.length; i++) {
      equal = looseEqual(a[i], b[i], seen);
    }
    return equal;
  }
  function looseCompareCollections(a, b, seen) {
    if (a.size !== b.size) return false;
    const candidates = Array.from(b);
    const matched = new Uint8Array(candidates.length);
    for (const item of a) {
      let index = -1;
      for (let i = 0; i < candidates.length; i++) {
        if (!matched[i] && looseEqual(item, candidates[i], seen)) {
          index = i;
          break;
        }
      }
      if (index < 0) return false;
      matched[index] = 1;
    }
    return true;
  }
  function looseCompareObjects(a, b, seen) {
    let aValidType = isMap(a);
    let bValidType = isMap(b);
    if (aValidType || bValidType) {
      return aValidType && bValidType ? looseCompareCollections(a, b, seen) : false;
    }
    aValidType = isSet(a);
    bValidType = isSet(b);
    if (aValidType || bValidType) {
      return aValidType && bValidType ? looseCompareCollections(a, b, seen) : false;
    }
    const aKeysCount = Object.keys(a).length;
    const bKeysCount = Object.keys(b).length;
    if (aKeysCount !== bKeysCount) {
      return false;
    }
    for (const key in a) {
      const aHasKey = a.hasOwnProperty(key);
      const bHasKey = b.hasOwnProperty(key);
      if (aHasKey && !bHasKey || !aHasKey && bHasKey || !looseEqual(a[key], b[key], seen)) {
        return false;
      }
    }
    return String(a) === String(b);
  }
  function looseCompareNested(a, b, seen, compare) {
    if (!seen) {
      seen = [/* @__PURE__ */ new Map(), /* @__PURE__ */ new Map()];
    }
    const [seenA, seenB] = seen;
    if (seenA.has(a) || seenB.has(b)) {
      return seenA.get(a) === b && seenB.get(b) === a;
    }
    seenA.set(a, b);
    seenB.set(b, a);
    const equal = compare(a, b, seen);
    seenA.delete(a);
    seenB.delete(b);
    return equal;
  }
  function looseEqual(a, b, seen) {
    if (a === b) return true;
    let aValidType = isDate(a);
    let bValidType = isDate(b);
    if (aValidType || bValidType) {
      return aValidType && bValidType ? a.getTime() === b.getTime() : false;
    }
    aValidType = isSymbol(a);
    bValidType = isSymbol(b);
    if (aValidType || bValidType) {
      return a === b;
    }
    aValidType = isArray(a);
    bValidType = isArray(b);
    if (aValidType || bValidType) {
      return aValidType && bValidType ? looseCompareNested(a, b, seen, looseCompareArrays) : false;
    }
    aValidType = isObject(a);
    bValidType = isObject(b);
    if (aValidType || bValidType) {
      if (!aValidType || !bValidType) {
        return false;
      }
      return looseCompareNested(a, b, seen, looseCompareObjects);
    }
    return String(a) === String(b);
  }
  function looseIndexOf(arr, val) {
    return arr.findIndex((item) => looseEqual(item, val));
  }
  const isRef$1 = (val) => {
    return !!(val && val["__v_isRef"] === true);
  };
  const toDisplayString = (val) => {
    return isString(val) ? val : val == null ? "" : isArray(val) || isObject(val) && (val.toString === objectToString || !isFunction(val.toString)) ? isRef$1(val) ? toDisplayString(val.value) : JSON.stringify(val, replacer, 2) : String(val);
  };
  const replacer = (_key, val) => {
    if (isRef$1(val)) {
      return replacer(_key, val.value);
    } else if (isMap(val)) {
      return {
        [`Map(${val.size})`]: [...val.entries()].reduce(
          (entries, [key, val2], i) => {
            entries[stringifySymbol(key, i) + " =>"] = val2;
            return entries;
          },
          {}
        )
      };
    } else if (isSet(val)) {
      return {
        [`Set(${val.size})`]: [...val.values()].map((v) => stringifySymbol(v))
      };
    } else if (isSymbol(val)) {
      return stringifySymbol(val);
    } else if (isObject(val) && !isArray(val) && !isPlainObject(val)) {
      return String(val);
    }
    return val;
  };
  const stringifySymbol = (v, i = "") => {
    var _a;
    return (
      // Symbol.description in es2019+ so we need to cast here to pass
      // the lib: es2016 check
      isSymbol(v) ? `Symbol(${(_a = v.description) != null ? _a : i})` : v
    );
  };
  let activeEffectScope;
  class EffectScope {
    // TODO isolatedDeclarations "__v_skip"
    constructor(detached = false) {
      this.detached = detached;
      this._active = true;
      this._on = 0;
      this.effects = [];
      this.cleanups = [];
      this._isPaused = false;
      this._warnOnRun = true;
      this.__v_skip = true;
      if (!detached && activeEffectScope) {
        if (activeEffectScope.active) {
          this.parent = activeEffectScope;
          this.index = (activeEffectScope.scopes || (activeEffectScope.scopes = [])).push(
            this
          ) - 1;
        } else {
          this._active = false;
          this._warnOnRun = false;
        }
      }
    }
    get active() {
      return this._active;
    }
    pause() {
      if (this._active) {
        this._isPaused = true;
        let i, l;
        if (this.scopes) {
          const scopes = this.scopes.slice();
          for (i = 0, l = scopes.length; i < l; i++) {
            scopes[i].pause();
          }
        }
        for (i = 0, l = this.effects.length; i < l; i++) {
          this.effects[i].pause();
        }
      }
    }
    /**
     * Resumes the effect scope, including all child scopes and effects.
     */
    resume() {
      if (this._active) {
        if (this._isPaused) {
          this._isPaused = false;
          let i, l;
          if (this.scopes) {
            const scopes = this.scopes.slice();
            for (i = 0, l = scopes.length; i < l; i++) {
              scopes[i].resume();
            }
          }
          const effects = this.effects.slice();
          for (i = 0, l = effects.length; i < l; i++) {
            effects[i].resume();
          }
        }
      }
    }
    run(fn) {
      if (this._active) {
        const currentEffectScope = activeEffectScope;
        try {
          activeEffectScope = this;
          return fn();
        } finally {
          activeEffectScope = currentEffectScope;
        }
      }
    }
    /**
     * This should only be called on non-detached scopes
     * @internal
     */
    on() {
      if (++this._on === 1) {
        this.prevScope = activeEffectScope;
        activeEffectScope = this;
      }
    }
    /**
     * This should only be called on non-detached scopes
     * @internal
     */
    off() {
      if (this._on > 0 && --this._on === 0) {
        if (activeEffectScope === this) {
          activeEffectScope = this.prevScope;
        } else {
          let current = activeEffectScope;
          while (current) {
            if (current.prevScope === this) {
              current.prevScope = this.prevScope;
              break;
            }
            current = current.prevScope;
          }
        }
        this.prevScope = void 0;
      }
    }
    stop(fromParent) {
      if (this._active) {
        this._active = false;
        let i, l;
        for (i = 0, l = this.effects.length; i < l; i++) {
          this.effects[i].stop();
        }
        this.effects.length = 0;
        for (i = 0, l = this.cleanups.length; i < l; i++) {
          this.cleanups[i]();
        }
        this.cleanups.length = 0;
        if (this.scopes) {
          const scopes = this.scopes.slice();
          for (i = 0, l = scopes.length; i < l; i++) {
            scopes[i].stop(true);
          }
          this.scopes.length = 0;
        }
        if (!this.detached && this.parent && !fromParent) {
          const last = this.parent.scopes.pop();
          if (last && last !== this) {
            this.parent.scopes[this.index] = last;
            last.index = this.index;
          }
        }
        this.parent = void 0;
      }
    }
  }
  function getCurrentScope() {
    return activeEffectScope;
  }
  let activeSub;
  const pausedQueueEffects = /* @__PURE__ */ new WeakSet();
  class ReactiveEffect {
    constructor(fn) {
      this.fn = fn;
      this.deps = void 0;
      this.depsTail = void 0;
      this.flags = 1 | 4;
      this.next = void 0;
      this.cleanup = void 0;
      this.scheduler = void 0;
      if (activeEffectScope) {
        if (activeEffectScope.active) {
          activeEffectScope.effects.push(this);
        } else {
          this.flags &= -2;
        }
      }
    }
    pause() {
      this.flags |= 64;
    }
    resume() {
      if (this.flags & 64) {
        this.flags &= -65;
        if (pausedQueueEffects.has(this)) {
          pausedQueueEffects.delete(this);
          this.trigger();
        }
      }
    }
    /**
     * @internal
     */
    notify() {
      if (this.flags & 2 && !(this.flags & 32)) {
        return;
      }
      if (!(this.flags & 8)) {
        batch(this);
      }
    }
    run() {
      if (!(this.flags & 1)) {
        return this.fn();
      }
      this.flags |= 2;
      cleanupEffect(this);
      prepareDeps(this);
      const prevEffect = activeSub;
      const prevShouldTrack = shouldTrack;
      activeSub = this;
      shouldTrack = true;
      try {
        return this.fn();
      } finally {
        cleanupDeps(this);
        activeSub = prevEffect;
        shouldTrack = prevShouldTrack;
        this.flags &= -3;
      }
    }
    stop() {
      if (this.flags & 1) {
        for (let link = this.deps; link; link = link.nextDep) {
          removeSub(link);
        }
        this.deps = this.depsTail = void 0;
        cleanupEffect(this);
        this.onStop && this.onStop();
        this.flags &= -2;
      }
    }
    trigger() {
      if (this.flags & 64) {
        pausedQueueEffects.add(this);
      } else if (this.scheduler) {
        this.scheduler();
      } else {
        this.runIfDirty();
      }
    }
    /**
     * @internal
     */
    runIfDirty() {
      if (isDirty(this)) {
        this.run();
      }
    }
    get dirty() {
      return isDirty(this);
    }
  }
  let batchDepth = 0;
  let batchedSub;
  let batchedComputed;
  function batch(sub, isComputed = false) {
    sub.flags |= 8;
    if (isComputed) {
      sub.next = batchedComputed;
      batchedComputed = sub;
      return;
    }
    sub.next = batchedSub;
    batchedSub = sub;
  }
  function startBatch() {
    batchDepth++;
  }
  function endBatch() {
    if (--batchDepth > 0) {
      return;
    }
    if (batchedComputed) {
      let e = batchedComputed;
      batchedComputed = void 0;
      while (e) {
        const next = e.next;
        e.next = void 0;
        e.flags &= -9;
        e = next;
      }
    }
    let error;
    while (batchedSub) {
      let e = batchedSub;
      batchedSub = void 0;
      while (e) {
        const next = e.next;
        e.next = void 0;
        e.flags &= -9;
        if (e.flags & 1) {
          try {
            ;
            e.trigger();
          } catch (err) {
            if (!error) error = err;
          }
        }
        e = next;
      }
    }
    if (error) throw error;
  }
  function prepareDeps(sub) {
    for (let link = sub.deps; link; link = link.nextDep) {
      link.version = -1;
      link.prevActiveLink = link.dep.activeLink;
      link.dep.activeLink = link;
    }
  }
  function cleanupDeps(sub) {
    let head;
    let tail = sub.depsTail;
    let link = tail;
    while (link) {
      const prev = link.prevDep;
      if (link.version === -1) {
        if (link === tail) tail = prev;
        removeSub(link);
        removeDep(link);
      } else {
        head = link;
      }
      link.dep.activeLink = link.prevActiveLink;
      link.prevActiveLink = void 0;
      link = prev;
    }
    sub.deps = head;
    sub.depsTail = tail;
  }
  function isDirty(sub) {
    for (let link = sub.deps; link; link = link.nextDep) {
      if (link.dep.version !== link.version || link.dep.computed && (refreshComputed(link.dep.computed) || link.dep.version !== link.version)) {
        return true;
      }
    }
    if (sub._dirty) {
      return true;
    }
    return false;
  }
  function refreshComputed(computed2) {
    if (computed2.flags & 4 && !(computed2.flags & 16)) {
      return;
    }
    computed2.flags &= -17;
    if (computed2.globalVersion === globalVersion) {
      return;
    }
    computed2.globalVersion = globalVersion;
    if (!computed2.isSSR && computed2.flags & 128 && (!computed2.deps && !computed2._dirty || !isDirty(computed2))) {
      return;
    }
    computed2.flags |= 2;
    const dep = computed2.dep;
    const prevSub = activeSub;
    const prevShouldTrack = shouldTrack;
    activeSub = computed2;
    shouldTrack = true;
    try {
      prepareDeps(computed2);
      const value = computed2.fn(computed2._value);
      if (dep.version === 0 || hasChanged(value, computed2._value)) {
        computed2.flags |= 128;
        computed2._value = value;
        dep.version++;
      }
    } catch (err) {
      dep.version++;
      throw err;
    } finally {
      activeSub = prevSub;
      shouldTrack = prevShouldTrack;
      cleanupDeps(computed2);
      computed2.flags &= -3;
    }
  }
  function removeSub(link, soft = false) {
    const { dep, prevSub, nextSub } = link;
    if (prevSub) {
      prevSub.nextSub = nextSub;
      link.prevSub = void 0;
    }
    if (nextSub) {
      nextSub.prevSub = prevSub;
      link.nextSub = void 0;
    }
    if (dep.subs === link) {
      dep.subs = prevSub;
      if (!prevSub && dep.computed) {
        dep.computed.flags &= -5;
        for (let l = dep.computed.deps; l; l = l.nextDep) {
          removeSub(l, true);
        }
      }
    }
    if (!soft && !--dep.sc && dep.map) {
      dep.map.delete(dep.key);
    }
  }
  function removeDep(link) {
    const { prevDep, nextDep } = link;
    if (prevDep) {
      prevDep.nextDep = nextDep;
      link.prevDep = void 0;
    }
    if (nextDep) {
      nextDep.prevDep = prevDep;
      link.nextDep = void 0;
    }
  }
  let shouldTrack = true;
  const trackStack = [];
  function pauseTracking() {
    trackStack.push(shouldTrack);
    shouldTrack = false;
  }
  function resetTracking() {
    const last = trackStack.pop();
    shouldTrack = last === void 0 ? true : last;
  }
  function cleanupEffect(e) {
    const { cleanup } = e;
    e.cleanup = void 0;
    if (cleanup) {
      const prevSub = activeSub;
      activeSub = void 0;
      try {
        cleanup();
      } finally {
        activeSub = prevSub;
      }
    }
  }
  let globalVersion = 0;
  class Link {
    constructor(sub, dep) {
      this.sub = sub;
      this.dep = dep;
      this.version = dep.version;
      this.nextDep = this.prevDep = this.nextSub = this.prevSub = this.prevActiveLink = void 0;
    }
  }
  class Dep {
    // TODO isolatedDeclarations "__v_skip"
    constructor(computed2) {
      this.computed = computed2;
      this.version = 0;
      this.activeLink = void 0;
      this.subs = void 0;
      this.map = void 0;
      this.key = void 0;
      this.sc = 0;
      this.__v_skip = true;
    }
    track(debugInfo) {
      if (!activeSub || !shouldTrack || activeSub === this.computed) {
        return;
      }
      let link = this.activeLink;
      if (link === void 0 || link.sub !== activeSub) {
        link = this.activeLink = new Link(activeSub, this);
        if (!activeSub.deps) {
          activeSub.deps = activeSub.depsTail = link;
        } else {
          link.prevDep = activeSub.depsTail;
          activeSub.depsTail.nextDep = link;
          activeSub.depsTail = link;
        }
        addSub(link);
      } else if (link.version === -1) {
        link.version = this.version;
        if (link.nextDep) {
          const next = link.nextDep;
          next.prevDep = link.prevDep;
          if (link.prevDep) {
            link.prevDep.nextDep = next;
          }
          link.prevDep = activeSub.depsTail;
          link.nextDep = void 0;
          activeSub.depsTail.nextDep = link;
          activeSub.depsTail = link;
          if (activeSub.deps === link) {
            activeSub.deps = next;
          }
        }
      }
      return link;
    }
    trigger(debugInfo) {
      this.version++;
      globalVersion++;
      this.notify(debugInfo);
    }
    notify(debugInfo) {
      startBatch();
      try {
        if (false) ;
        for (let link = this.subs; link; link = link.prevSub) {
          if (link.sub.notify()) {
            ;
            link.sub.dep.notify();
          }
        }
      } finally {
        endBatch();
      }
    }
  }
  function addSub(link) {
    link.dep.sc++;
    if (link.sub.flags & 4) {
      const computed2 = link.dep.computed;
      if (computed2 && !link.dep.subs) {
        computed2.flags |= 4 | 16;
        for (let l = computed2.deps; l; l = l.nextDep) {
          addSub(l);
        }
      }
      const currentTail = link.dep.subs;
      if (currentTail !== link) {
        link.prevSub = currentTail;
        if (currentTail) currentTail.nextSub = link;
      }
      link.dep.subs = link;
    }
  }
  const targetMap = /* @__PURE__ */ new WeakMap();
  const ITERATE_KEY = /* @__PURE__ */ Symbol(
    ""
  );
  const MAP_KEY_ITERATE_KEY = /* @__PURE__ */ Symbol(
    ""
  );
  const ARRAY_ITERATE_KEY = /* @__PURE__ */ Symbol(
    ""
  );
  function track(target, type, key) {
    if (shouldTrack && activeSub) {
      let depsMap = targetMap.get(target);
      if (!depsMap) {
        targetMap.set(target, depsMap = /* @__PURE__ */ new Map());
      }
      let dep = depsMap.get(key);
      if (!dep) {
        depsMap.set(key, dep = new Dep());
        dep.map = depsMap;
        dep.key = key;
      }
      {
        dep.track();
      }
    }
  }
  function trigger(target, type, key, newValue, oldValue, oldTarget) {
    const depsMap = targetMap.get(target);
    if (!depsMap) {
      globalVersion++;
      return;
    }
    const run = (dep) => {
      if (dep) {
        {
          dep.trigger();
        }
      }
    };
    startBatch();
    if (type === "clear") {
      depsMap.forEach(run);
    } else {
      const targetIsArray = isArray(target);
      const isArrayIndex = targetIsArray && isIntegerKey(key);
      if (targetIsArray && key === "length") {
        const newLength = Number(newValue);
        depsMap.forEach((dep, key2) => {
          if (key2 === "length" || key2 === ARRAY_ITERATE_KEY || !isSymbol(key2) && key2 >= newLength) {
            run(dep);
          }
        });
      } else {
        if (key !== void 0 || depsMap.has(void 0)) {
          run(depsMap.get(key));
        }
        if (isArrayIndex) {
          run(depsMap.get(ARRAY_ITERATE_KEY));
        }
        switch (type) {
          case "add":
            if (!targetIsArray) {
              run(depsMap.get(ITERATE_KEY));
              if (isMap(target)) {
                run(depsMap.get(MAP_KEY_ITERATE_KEY));
              }
            } else if (isArrayIndex) {
              run(depsMap.get("length"));
            }
            break;
          case "delete":
            if (!targetIsArray) {
              run(depsMap.get(ITERATE_KEY));
              if (isMap(target)) {
                run(depsMap.get(MAP_KEY_ITERATE_KEY));
              }
            }
            break;
          case "set":
            if (isMap(target)) {
              run(depsMap.get(ITERATE_KEY));
            }
            break;
        }
      }
    }
    endBatch();
  }
  function reactiveReadArray(array) {
    const raw = /* @__PURE__ */ toRaw(array);
    if (raw === array) return raw;
    track(raw, "iterate", ARRAY_ITERATE_KEY);
    if (/* @__PURE__ */ isShallow(array)) return raw;
    if (!/* @__PURE__ */ isReadonly(array)) return raw.map(toReactive);
    return /* @__PURE__ */ isReactive(array) ? raw.map((item) => toReadonly(toReactive(item))) : raw.map(toReadonly);
  }
  function shallowReadArray(arr) {
    track(arr = /* @__PURE__ */ toRaw(arr), "iterate", ARRAY_ITERATE_KEY);
    return arr;
  }
  function toWrapped(target, item) {
    if (/* @__PURE__ */ isReadonly(target)) {
      return /* @__PURE__ */ isReactive(target) ? toReadonly(toReactive(item)) : toReadonly(item);
    }
    return toReactive(item);
  }
  const arrayInstrumentations = {
    __proto__: null,
    [Symbol.iterator]() {
      return iterator(this, Symbol.iterator, (item) => toWrapped(this, item));
    },
    concat(...args) {
      return reactiveReadArray(this).concat(
        ...args.map((x) => isArray(x) ? reactiveReadArray(x) : x)
      );
    },
    entries() {
      return iterator(this, "entries", (value) => {
        value[1] = toWrapped(this, value[1]);
        return value;
      });
    },
    every(fn, thisArg) {
      return apply(this, "every", fn, thisArg, void 0, arguments);
    },
    filter(fn, thisArg) {
      return apply(
        this,
        "filter",
        fn,
        thisArg,
        (v) => v.map((item) => toWrapped(this, item)),
        arguments
      );
    },
    find(fn, thisArg) {
      return apply(
        this,
        "find",
        fn,
        thisArg,
        (item) => toWrapped(this, item),
        arguments
      );
    },
    findIndex(fn, thisArg) {
      return apply(this, "findIndex", fn, thisArg, void 0, arguments);
    },
    findLast(fn, thisArg) {
      return apply(
        this,
        "findLast",
        fn,
        thisArg,
        (item) => toWrapped(this, item),
        arguments
      );
    },
    findLastIndex(fn, thisArg) {
      return apply(this, "findLastIndex", fn, thisArg, void 0, arguments);
    },
    // flat, flatMap could benefit from ARRAY_ITERATE but are not straight-forward to implement
    forEach(fn, thisArg) {
      return apply(this, "forEach", fn, thisArg, void 0, arguments);
    },
    includes(...args) {
      return searchProxy(this, "includes", args);
    },
    indexOf(...args) {
      return searchProxy(this, "indexOf", args);
    },
    join(separator) {
      return reactiveReadArray(this).join(separator);
    },
    // keys() iterator only reads `length`, no optimization required
    lastIndexOf(...args) {
      return searchProxy(this, "lastIndexOf", args);
    },
    map(fn, thisArg) {
      return apply(this, "map", fn, thisArg, void 0, arguments);
    },
    pop() {
      return noTracking(this, "pop");
    },
    push(...args) {
      return noTracking(this, "push", args);
    },
    reduce(fn, ...args) {
      return reduce(this, "reduce", fn, args);
    },
    reduceRight(fn, ...args) {
      return reduce(this, "reduceRight", fn, args);
    },
    shift() {
      return noTracking(this, "shift");
    },
    // slice could use ARRAY_ITERATE but also seems to beg for range tracking
    some(fn, thisArg) {
      return apply(this, "some", fn, thisArg, void 0, arguments);
    },
    splice(...args) {
      return noTracking(this, "splice", args);
    },
    toReversed() {
      return reactiveReadArray(this).toReversed();
    },
    toSorted(comparer) {
      return reactiveReadArray(this).toSorted(comparer);
    },
    toSpliced(...args) {
      return reactiveReadArray(this).toSpliced(...args);
    },
    unshift(...args) {
      return noTracking(this, "unshift", args);
    },
    values() {
      return iterator(this, "values", (item) => toWrapped(this, item));
    }
  };
  function iterator(self2, method, wrapValue) {
    const arr = shallowReadArray(self2);
    const iter = arr[method]();
    if (arr !== self2 && !/* @__PURE__ */ isShallow(self2)) {
      iter._next = iter.next;
      iter.next = () => {
        const result = iter._next();
        if (!result.done) {
          result.value = wrapValue(result.value);
        }
        return result;
      };
    }
    return iter;
  }
  const arrayProto = Array.prototype;
  function apply(self2, method, fn, thisArg, wrappedRetFn, args) {
    const arr = shallowReadArray(self2);
    const needsWrap = arr !== self2 && !/* @__PURE__ */ isShallow(self2);
    const methodFn = arr[method];
    if (methodFn !== arrayProto[method]) {
      const result2 = methodFn.apply(self2, args);
      return needsWrap ? toReactive(result2) : result2;
    }
    let wrappedFn = fn;
    if (arr !== self2) {
      if (needsWrap) {
        wrappedFn = function(item, index) {
          return fn.call(this, toWrapped(self2, item), index, self2);
        };
      } else if (fn.length > 2) {
        wrappedFn = function(item, index) {
          return fn.call(this, item, index, self2);
        };
      }
    }
    const result = methodFn.call(arr, wrappedFn, thisArg);
    return needsWrap && wrappedRetFn ? wrappedRetFn(result) : result;
  }
  function reduce(self2, method, fn, args) {
    const arr = shallowReadArray(self2);
    const needsWrap = arr !== self2 && !/* @__PURE__ */ isShallow(self2);
    let wrappedFn = fn;
    let wrapInitialAccumulator = false;
    if (arr !== self2) {
      if (needsWrap) {
        wrapInitialAccumulator = args.length === 0;
        wrappedFn = function(acc, item, index) {
          if (wrapInitialAccumulator) {
            wrapInitialAccumulator = false;
            acc = toWrapped(self2, acc);
          }
          return fn.call(this, acc, toWrapped(self2, item), index, self2);
        };
      } else if (fn.length > 3) {
        wrappedFn = function(acc, item, index) {
          return fn.call(this, acc, item, index, self2);
        };
      }
    }
    const result = arr[method](wrappedFn, ...args);
    return wrapInitialAccumulator ? toWrapped(self2, result) : result;
  }
  function searchProxy(self2, method, args) {
    const arr = /* @__PURE__ */ toRaw(self2);
    track(arr, "iterate", ARRAY_ITERATE_KEY);
    const res = arr[method](...args);
    if ((res === -1 || res === false) && /* @__PURE__ */ isProxy(args[0])) {
      args[0] = /* @__PURE__ */ toRaw(args[0]);
      return arr[method](...args);
    }
    return res;
  }
  function noTracking(self2, method, args = []) {
    pauseTracking();
    startBatch();
    const res = (/* @__PURE__ */ toRaw(self2))[method].apply(self2, args);
    endBatch();
    resetTracking();
    return res;
  }
  const isNonTrackableKeys = /* @__PURE__ */ makeMap(`__proto__,__v_isRef,__isVue`);
  const builtInSymbols = new Set(
    /* @__PURE__ */ Object.getOwnPropertyNames(Symbol).filter((key) => key !== "arguments" && key !== "caller").map((key) => Symbol[key]).filter(isSymbol)
  );
  function hasOwnProperty(key) {
    if (!isSymbol(key)) key = String(key);
    const obj = /* @__PURE__ */ toRaw(this);
    track(obj, "has", key);
    return obj.hasOwnProperty(key);
  }
  class BaseReactiveHandler {
    constructor(_isReadonly = false, _isShallow = false) {
      this._isReadonly = _isReadonly;
      this._isShallow = _isShallow;
    }
    get(target, key, receiver) {
      if (key === "__v_skip") return target["__v_skip"];
      const isReadonly2 = this._isReadonly, isShallow2 = this._isShallow;
      if (key === "__v_isReactive") {
        return !isReadonly2;
      } else if (key === "__v_isReadonly") {
        return isReadonly2;
      } else if (key === "__v_isShallow") {
        return isShallow2;
      } else if (key === "__v_raw") {
        if (receiver === (isReadonly2 ? isShallow2 ? shallowReadonlyMap : readonlyMap : isShallow2 ? shallowReactiveMap : reactiveMap).get(target) || // receiver is not the reactive proxy, but has the same prototype
        // this means the receiver is a user proxy of the reactive proxy
        Object.getPrototypeOf(target) === Object.getPrototypeOf(receiver)) {
          return target;
        }
        return;
      }
      const targetIsArray = isArray(target);
      if (!isReadonly2) {
        let fn;
        if (targetIsArray && (fn = arrayInstrumentations[key])) {
          return fn;
        }
        if (key === "hasOwnProperty") {
          return hasOwnProperty;
        }
      }
      const res = Reflect.get(
        target,
        key,
        // if this is a proxy wrapping a ref, return methods using the raw ref
        // as receiver so that we don't have to call `toRaw` on the ref in all
        // its class methods
        /* @__PURE__ */ isRef(target) ? target : receiver
      );
      if (isSymbol(key) ? builtInSymbols.has(key) : isNonTrackableKeys(key)) {
        return res;
      }
      if (!isReadonly2) {
        track(target, "get", key);
      }
      if (isShallow2) {
        return res;
      }
      if (/* @__PURE__ */ isRef(res)) {
        const value = targetIsArray && isIntegerKey(key) ? res : res.value;
        return isReadonly2 && isObject(value) ? /* @__PURE__ */ readonly(value) : value;
      }
      if (isObject(res)) {
        return isReadonly2 ? /* @__PURE__ */ readonly(res) : /* @__PURE__ */ reactive(res);
      }
      return res;
    }
  }
  class MutableReactiveHandler extends BaseReactiveHandler {
    constructor(isShallow2 = false) {
      super(false, isShallow2);
    }
    set(target, key, value, receiver) {
      let oldValue = target[key];
      const isArrayWithIntegerKey = isArray(target) && isIntegerKey(key);
      if (!this._isShallow) {
        const isOldValueReadonly = /* @__PURE__ */ isReadonly(oldValue);
        if (!/* @__PURE__ */ isShallow(value) && !/* @__PURE__ */ isReadonly(value)) {
          oldValue = /* @__PURE__ */ toRaw(oldValue);
          value = /* @__PURE__ */ toRaw(value);
        }
        if (!isArrayWithIntegerKey && /* @__PURE__ */ isRef(oldValue) && !/* @__PURE__ */ isRef(value)) {
          if (isOldValueReadonly) {
            return true;
          } else {
            oldValue.value = value;
            return true;
          }
        }
      }
      const hadKey = isArrayWithIntegerKey ? Number(key) < target.length : hasOwn(target, key);
      const result = Reflect.set(
        target,
        key,
        value,
        /* @__PURE__ */ isRef(target) ? target : receiver
      );
      if (target === /* @__PURE__ */ toRaw(receiver) && result) {
        if (!hadKey) {
          trigger(target, "add", key, value);
        } else if (hasChanged(value, oldValue)) {
          trigger(target, "set", key, value);
        }
      }
      return result;
    }
    deleteProperty(target, key) {
      const hadKey = hasOwn(target, key);
      target[key];
      const result = Reflect.deleteProperty(target, key);
      if (result && hadKey) {
        trigger(target, "delete", key, void 0);
      }
      return result;
    }
    has(target, key) {
      const result = Reflect.has(target, key);
      if (!isSymbol(key) || !builtInSymbols.has(key)) {
        track(target, "has", key);
      }
      return result;
    }
    ownKeys(target) {
      track(
        target,
        "iterate",
        isArray(target) ? "length" : ITERATE_KEY
      );
      return Reflect.ownKeys(target);
    }
  }
  class ReadonlyReactiveHandler extends BaseReactiveHandler {
    constructor(isShallow2 = false) {
      super(true, isShallow2);
    }
    set(target, key) {
      return true;
    }
    deleteProperty(target, key) {
      return true;
    }
  }
  const mutableHandlers = /* @__PURE__ */ new MutableReactiveHandler();
  const readonlyHandlers = /* @__PURE__ */ new ReadonlyReactiveHandler();
  const shallowReactiveHandlers = /* @__PURE__ */ new MutableReactiveHandler(true);
  const shallowReadonlyHandlers = /* @__PURE__ */ new ReadonlyReactiveHandler(true);
  const toShallow = (value) => value;
  const getProto = (v) => Reflect.getPrototypeOf(v);
  function createIterableMethod(method, isReadonly2, isShallow2) {
    return function(...args) {
      const target = this["__v_raw"];
      const rawTarget = /* @__PURE__ */ toRaw(target);
      const targetIsMap = isMap(rawTarget);
      const isPair = method === "entries" || method === Symbol.iterator && targetIsMap;
      const isKeyOnly = method === "keys" && targetIsMap;
      const innerIterator = target[method](...args);
      const wrap = isShallow2 ? toShallow : isReadonly2 ? toReadonly : toReactive;
      !isReadonly2 && track(
        rawTarget,
        "iterate",
        isKeyOnly ? MAP_KEY_ITERATE_KEY : ITERATE_KEY
      );
      return extend(
        // inheriting all iterator properties
        Object.create(innerIterator),
        {
          // iterator protocol
          next() {
            const { value, done } = innerIterator.next();
            return done ? { value, done } : {
              value: isPair ? [wrap(value[0]), wrap(value[1])] : wrap(value),
              done
            };
          }
        }
      );
    };
  }
  function createReadonlyMethod(type) {
    return function(...args) {
      return type === "delete" ? false : type === "clear" ? void 0 : this;
    };
  }
  function createInstrumentations(readonly2, shallow) {
    const instrumentations = {
      get(key) {
        const target = this["__v_raw"];
        const rawTarget = /* @__PURE__ */ toRaw(target);
        const rawKey = /* @__PURE__ */ toRaw(key);
        if (!readonly2) {
          if (hasChanged(key, rawKey)) {
            track(rawTarget, "get", key);
          }
          track(rawTarget, "get", rawKey);
        }
        const { has } = getProto(rawTarget);
        const wrap = shallow ? toShallow : readonly2 ? toReadonly : toReactive;
        if (has.call(rawTarget, key)) {
          return wrap(target.get(key));
        } else if (has.call(rawTarget, rawKey)) {
          return wrap(target.get(rawKey));
        } else if (target !== rawTarget) {
          target.get(key);
        }
      },
      get size() {
        const target = this["__v_raw"];
        !readonly2 && track(/* @__PURE__ */ toRaw(target), "iterate", ITERATE_KEY);
        return target.size;
      },
      has(key) {
        const target = this["__v_raw"];
        const rawTarget = /* @__PURE__ */ toRaw(target);
        const rawKey = /* @__PURE__ */ toRaw(key);
        if (!readonly2) {
          if (hasChanged(key, rawKey)) {
            track(rawTarget, "has", key);
          }
          track(rawTarget, "has", rawKey);
        }
        return key === rawKey ? target.has(key) : target.has(key) || target.has(rawKey);
      },
      forEach(callback, thisArg) {
        const observed = this;
        const target = observed["__v_raw"];
        const rawTarget = /* @__PURE__ */ toRaw(target);
        const wrap = shallow ? toShallow : readonly2 ? toReadonly : toReactive;
        !readonly2 && track(rawTarget, "iterate", ITERATE_KEY);
        return target.forEach((value, key) => {
          return callback.call(thisArg, wrap(value), wrap(key), observed);
        });
      }
    };
    extend(
      instrumentations,
      readonly2 ? {
        add: createReadonlyMethod("add"),
        set: createReadonlyMethod("set"),
        delete: createReadonlyMethod("delete"),
        clear: createReadonlyMethod("clear")
      } : {
        add(value) {
          const target = /* @__PURE__ */ toRaw(this);
          const proto = getProto(target);
          const rawValue = /* @__PURE__ */ toRaw(value);
          const valueToAdd = !shallow && !/* @__PURE__ */ isShallow(value) && !/* @__PURE__ */ isReadonly(value) ? rawValue : value;
          const hadKey = proto.has.call(target, valueToAdd) || hasChanged(value, valueToAdd) && proto.has.call(target, value) || hasChanged(rawValue, valueToAdd) && proto.has.call(target, rawValue);
          if (!hadKey) {
            target.add(valueToAdd);
            trigger(target, "add", valueToAdd, valueToAdd);
          }
          return this;
        },
        set(key, value) {
          if (!shallow && !/* @__PURE__ */ isShallow(value) && !/* @__PURE__ */ isReadonly(value)) {
            value = /* @__PURE__ */ toRaw(value);
          }
          const target = /* @__PURE__ */ toRaw(this);
          const { has, get } = getProto(target);
          let hadKey = has.call(target, key);
          if (!hadKey) {
            key = /* @__PURE__ */ toRaw(key);
            hadKey = has.call(target, key);
          }
          const oldValue = get.call(target, key);
          target.set(key, value);
          if (!hadKey) {
            trigger(target, "add", key, value);
          } else if (hasChanged(value, oldValue)) {
            trigger(target, "set", key, value);
          }
          return this;
        },
        delete(key) {
          const target = /* @__PURE__ */ toRaw(this);
          const { has, get } = getProto(target);
          let hadKey = has.call(target, key);
          if (!hadKey) {
            key = /* @__PURE__ */ toRaw(key);
            hadKey = has.call(target, key);
          }
          get ? get.call(target, key) : void 0;
          const result = target.delete(key);
          if (hadKey) {
            trigger(target, "delete", key, void 0);
          }
          return result;
        },
        clear() {
          const target = /* @__PURE__ */ toRaw(this);
          const hadItems = target.size !== 0;
          const result = target.clear();
          if (hadItems) {
            trigger(
              target,
              "clear",
              void 0,
              void 0
            );
          }
          return result;
        }
      }
    );
    const iteratorMethods = [
      "keys",
      "values",
      "entries",
      Symbol.iterator
    ];
    iteratorMethods.forEach((method) => {
      instrumentations[method] = createIterableMethod(method, readonly2, shallow);
    });
    return instrumentations;
  }
  function createInstrumentationGetter(isReadonly2, shallow) {
    const instrumentations = createInstrumentations(isReadonly2, shallow);
    return (target, key, receiver) => {
      if (key === "__v_isReactive") {
        return !isReadonly2;
      } else if (key === "__v_isReadonly") {
        return isReadonly2;
      } else if (key === "__v_raw") {
        return target;
      }
      return Reflect.get(
        hasOwn(instrumentations, key) && key in target ? instrumentations : target,
        key,
        receiver
      );
    };
  }
  const mutableCollectionHandlers = {
    get: /* @__PURE__ */ createInstrumentationGetter(false, false)
  };
  const shallowCollectionHandlers = {
    get: /* @__PURE__ */ createInstrumentationGetter(false, true)
  };
  const readonlyCollectionHandlers = {
    get: /* @__PURE__ */ createInstrumentationGetter(true, false)
  };
  const shallowReadonlyCollectionHandlers = {
    get: /* @__PURE__ */ createInstrumentationGetter(true, true)
  };
  const reactiveMap = /* @__PURE__ */ new WeakMap();
  const shallowReactiveMap = /* @__PURE__ */ new WeakMap();
  const readonlyMap = /* @__PURE__ */ new WeakMap();
  const shallowReadonlyMap = /* @__PURE__ */ new WeakMap();
  function targetTypeMap(rawType) {
    switch (rawType) {
      case "Object":
      case "Array":
        return 1;
      case "Map":
      case "Set":
      case "WeakMap":
      case "WeakSet":
        return 2;
      default:
        return 0;
    }
  }
  // @__NO_SIDE_EFFECTS__
  function reactive(target) {
    if (/* @__PURE__ */ isReadonly(target)) {
      return target;
    }
    return createReactiveObject(
      target,
      false,
      mutableHandlers,
      mutableCollectionHandlers,
      reactiveMap
    );
  }
  // @__NO_SIDE_EFFECTS__
  function shallowReactive(target) {
    return createReactiveObject(
      target,
      false,
      shallowReactiveHandlers,
      shallowCollectionHandlers,
      shallowReactiveMap
    );
  }
  // @__NO_SIDE_EFFECTS__
  function readonly(target) {
    return createReactiveObject(
      target,
      true,
      readonlyHandlers,
      readonlyCollectionHandlers,
      readonlyMap
    );
  }
  // @__NO_SIDE_EFFECTS__
  function shallowReadonly(target) {
    return createReactiveObject(
      target,
      true,
      shallowReadonlyHandlers,
      shallowReadonlyCollectionHandlers,
      shallowReadonlyMap
    );
  }
  function createReactiveObject(target, isReadonly2, baseHandlers, collectionHandlers, proxyMap) {
    if (!isObject(target)) {
      return target;
    }
    if (target["__v_raw"] && !(isReadonly2 && target["__v_isReactive"])) {
      return target;
    }
    if (target["__v_skip"] || !Object.isExtensible(target)) {
      return target;
    }
    const existingProxy = proxyMap.get(target);
    if (existingProxy) {
      return existingProxy;
    }
    const targetType = targetTypeMap(toRawType(target));
    if (targetType === 0) {
      return target;
    }
    const proxy = new Proxy(
      target,
      targetType === 2 ? collectionHandlers : baseHandlers
    );
    proxyMap.set(target, proxy);
    return proxy;
  }
  // @__NO_SIDE_EFFECTS__
  function isReactive(value) {
    if (/* @__PURE__ */ isReadonly(value)) {
      return /* @__PURE__ */ isReactive(value["__v_raw"]);
    }
    return !!(value && value["__v_isReactive"]);
  }
  // @__NO_SIDE_EFFECTS__
  function isReadonly(value) {
    return !!(value && value["__v_isReadonly"]);
  }
  // @__NO_SIDE_EFFECTS__
  function isShallow(value) {
    return !!(value && value["__v_isShallow"]);
  }
  // @__NO_SIDE_EFFECTS__
  function isProxy(value) {
    return value ? !!value["__v_raw"] : false;
  }
  // @__NO_SIDE_EFFECTS__
  function toRaw(observed) {
    const raw = observed && observed["__v_raw"];
    return raw ? /* @__PURE__ */ toRaw(raw) : observed;
  }
  function markRaw(value) {
    if (!hasOwn(value, "__v_skip") && Object.isExtensible(value)) {
      def(value, "__v_skip", true);
    }
    return value;
  }
  const toReactive = (value) => isObject(value) ? /* @__PURE__ */ reactive(value) : value;
  const toReadonly = (value) => isObject(value) ? /* @__PURE__ */ readonly(value) : value;
  // @__NO_SIDE_EFFECTS__
  function isRef(r2) {
    return r2 ? r2["__v_isRef"] === true : false;
  }
  // @__NO_SIDE_EFFECTS__
  function ref(value) {
    return createRef(value, false);
  }
  function createRef(rawValue, shallow) {
    if (/* @__PURE__ */ isRef(rawValue)) {
      return rawValue;
    }
    return new RefImpl(rawValue, shallow);
  }
  class RefImpl {
    constructor(value, isShallow2) {
      this.dep = new Dep();
      this["__v_isRef"] = true;
      this["__v_isShallow"] = false;
      this._rawValue = isShallow2 ? value : /* @__PURE__ */ toRaw(value);
      this._value = isShallow2 ? value : toReactive(value);
      this["__v_isShallow"] = isShallow2;
    }
    get value() {
      {
        this.dep.track();
      }
      return this._value;
    }
    set value(newValue) {
      const oldValue = this._rawValue;
      const useDirectValue = this["__v_isShallow"] || /* @__PURE__ */ isShallow(newValue) || /* @__PURE__ */ isReadonly(newValue);
      newValue = useDirectValue ? newValue : /* @__PURE__ */ toRaw(newValue);
      if (hasChanged(newValue, oldValue)) {
        this._rawValue = newValue;
        this._value = useDirectValue ? newValue : toReactive(newValue);
        {
          this.dep.trigger();
        }
      }
    }
  }
  function unref(ref2) {
    return /* @__PURE__ */ isRef(ref2) ? ref2.value : ref2;
  }
  const shallowUnwrapHandlers = {
    get: (target, key, receiver) => key === "__v_raw" ? target : unref(Reflect.get(target, key, receiver)),
    set: (target, key, value, receiver) => {
      const oldValue = target[key];
      if (/* @__PURE__ */ isRef(oldValue) && !/* @__PURE__ */ isRef(value)) {
        oldValue.value = value;
        return true;
      } else {
        return Reflect.set(target, key, value, receiver);
      }
    }
  };
  function proxyRefs(objectWithRefs) {
    return /* @__PURE__ */ isReactive(objectWithRefs) ? objectWithRefs : new Proxy(objectWithRefs, shallowUnwrapHandlers);
  }
  class ComputedRefImpl {
    constructor(fn, setter, isSSR) {
      this.fn = fn;
      this.setter = setter;
      this._value = void 0;
      this.dep = new Dep(this);
      this.__v_isRef = true;
      this.deps = void 0;
      this.depsTail = void 0;
      this.flags = 16;
      this.globalVersion = globalVersion - 1;
      this.next = void 0;
      this.effect = this;
      this["__v_isReadonly"] = !setter;
      this.isSSR = isSSR;
    }
    /**
     * @internal
     */
    notify() {
      this.flags |= 16;
      if (!(this.flags & 8) && // avoid infinite self recursion
      activeSub !== this) {
        batch(this, true);
        return true;
      }
    }
    get value() {
      const link = this.dep.track();
      refreshComputed(this);
      if (link) {
        link.version = this.dep.version;
      }
      return this._value;
    }
    set value(newValue) {
      if (this.setter) {
        this.setter(newValue);
      }
    }
  }
  // @__NO_SIDE_EFFECTS__
  function computed$1(getterOrOptions, debugOptions, isSSR = false) {
    let getter;
    let setter;
    if (isFunction(getterOrOptions)) {
      getter = getterOrOptions;
    } else {
      getter = getterOrOptions.get;
      setter = getterOrOptions.set;
    }
    const cRef = new ComputedRefImpl(getter, setter, isSSR);
    return cRef;
  }
  const INITIAL_WATCHER_VALUE = {};
  const cleanupMap = /* @__PURE__ */ new WeakMap();
  let activeWatcher = void 0;
  function onWatcherCleanup(cleanupFn, failSilently = false, owner = activeWatcher) {
    if (owner) {
      let cleanups = cleanupMap.get(owner);
      if (!cleanups) cleanupMap.set(owner, cleanups = []);
      cleanups.push(cleanupFn);
    }
  }
  function watch$1(source, cb, options = EMPTY_OBJ) {
    const { immediate, deep, once, scheduler, augmentJob, call } = options;
    const reactiveGetter = (source2) => {
      if (deep) return source2;
      if (/* @__PURE__ */ isShallow(source2) || deep === false || deep === 0)
        return traverse(source2, 1);
      return traverse(source2);
    };
    let effect2;
    let getter;
    let cleanup;
    let boundCleanup;
    let forceTrigger = false;
    let isMultiSource = false;
    if (/* @__PURE__ */ isRef(source)) {
      getter = () => source.value;
      forceTrigger = /* @__PURE__ */ isShallow(source);
    } else if (/* @__PURE__ */ isReactive(source)) {
      getter = () => reactiveGetter(source);
      forceTrigger = true;
    } else if (isArray(source)) {
      isMultiSource = true;
      forceTrigger = source.some((s) => /* @__PURE__ */ isReactive(s) || /* @__PURE__ */ isShallow(s));
      getter = () => source.map((s) => {
        if (/* @__PURE__ */ isRef(s)) {
          return s.value;
        } else if (/* @__PURE__ */ isReactive(s)) {
          return reactiveGetter(s);
        } else if (isFunction(s)) {
          return call ? call(s, 2) : s();
        } else ;
      });
    } else if (isFunction(source)) {
      if (cb) {
        getter = call ? () => call(source, 2) : source;
      } else {
        getter = () => {
          if (cleanup) {
            pauseTracking();
            try {
              cleanup();
            } finally {
              resetTracking();
            }
          }
          const currentEffect = activeWatcher;
          activeWatcher = effect2;
          try {
            return call ? call(source, 3, [boundCleanup]) : source(boundCleanup);
          } finally {
            activeWatcher = currentEffect;
          }
        };
      }
    } else {
      getter = NOOP;
    }
    if (cb && deep) {
      const baseGetter = getter;
      const depth = deep === true ? Infinity : deep;
      getter = () => traverse(baseGetter(), depth);
    }
    const scope = getCurrentScope();
    const watchHandle = () => {
      effect2.stop();
      if (scope && scope.active) {
        remove(scope.effects, effect2);
      }
    };
    if (once && cb) {
      const _cb = cb;
      cb = (...args) => {
        const res = _cb(...args);
        watchHandle();
        return res;
      };
    }
    let oldValue = isMultiSource ? new Array(source.length).fill(INITIAL_WATCHER_VALUE) : INITIAL_WATCHER_VALUE;
    const job = (immediateFirstRun) => {
      if (!(effect2.flags & 1) || !effect2.dirty && !immediateFirstRun) {
        return;
      }
      if (cb) {
        const newValue = effect2.run();
        if (immediateFirstRun || deep || forceTrigger || (isMultiSource ? newValue.some((v, i) => hasChanged(v, oldValue[i])) : hasChanged(newValue, oldValue))) {
          if (cleanup) {
            cleanup();
          }
          const currentWatcher = activeWatcher;
          activeWatcher = effect2;
          try {
            const args = [
              newValue,
              // pass undefined as the old value when it's changed for the first time
              oldValue === INITIAL_WATCHER_VALUE ? void 0 : isMultiSource && oldValue[0] === INITIAL_WATCHER_VALUE ? [] : oldValue,
              boundCleanup
            ];
            oldValue = newValue;
            call ? call(cb, 3, args) : (
              // @ts-expect-error
              cb(...args)
            );
          } finally {
            activeWatcher = currentWatcher;
          }
        }
      } else {
        effect2.run();
      }
    };
    if (augmentJob) {
      augmentJob(job);
    }
    effect2 = new ReactiveEffect(getter);
    effect2.scheduler = scheduler ? () => scheduler(job, false) : job;
    boundCleanup = (fn) => onWatcherCleanup(fn, false, effect2);
    cleanup = effect2.onStop = () => {
      const cleanups = cleanupMap.get(effect2);
      if (cleanups) {
        if (call) {
          call(cleanups, 4);
        } else {
          for (const cleanup2 of cleanups) cleanup2();
        }
        cleanupMap.delete(effect2);
      }
    };
    if (cb) {
      if (immediate) {
        job(true);
      } else {
        oldValue = effect2.run();
      }
    } else if (scheduler) {
      scheduler(job.bind(null, true), true);
    } else {
      effect2.run();
    }
    watchHandle.pause = effect2.pause.bind(effect2);
    watchHandle.resume = effect2.resume.bind(effect2);
    watchHandle.stop = watchHandle;
    return watchHandle;
  }
  function traverse(value, depth = Infinity, seen) {
    if (depth <= 0 || !isObject(value) || value["__v_skip"]) {
      return value;
    }
    seen = seen || /* @__PURE__ */ new Map();
    if ((seen.get(value) || 0) >= depth) {
      return value;
    }
    seen.set(value, depth);
    depth--;
    if (/* @__PURE__ */ isRef(value)) {
      traverse(value.value, depth, seen);
    } else if (isArray(value)) {
      for (let i = 0; i < value.length; i++) {
        traverse(value[i], depth, seen);
      }
    } else if (isSet(value) || isMap(value)) {
      value.forEach((v) => {
        traverse(v, depth, seen);
      });
    } else if (isPlainObject(value)) {
      for (const key in value) {
        traverse(value[key], depth, seen);
      }
      for (const key of Object.getOwnPropertySymbols(value)) {
        if (Object.prototype.propertyIsEnumerable.call(value, key)) {
          traverse(value[key], depth, seen);
        }
      }
    }
    return value;
  }
  const stack = [];
  let isWarning = false;
  function warn$1(msg, ...args) {
    if (isWarning) return;
    isWarning = true;
    pauseTracking();
    const instance = stack.length ? stack[stack.length - 1].component : null;
    const appWarnHandler = instance && instance.appContext.config.warnHandler;
    const trace = getComponentTrace();
    if (appWarnHandler) {
      callWithErrorHandling(
        appWarnHandler,
        instance,
        11,
        [
          // eslint-disable-next-line no-restricted-syntax
          msg + args.map((a) => {
            var _a, _b;
            return (_b = (_a = a.toString) == null ? void 0 : _a.call(a)) != null ? _b : JSON.stringify(a);
          }).join(""),
          instance && instance.proxy,
          trace.map(
            ({ vnode }) => `at <${formatComponentName(instance, vnode.type)}>`
          ).join("\n"),
          trace
        ]
      );
    } else {
      const warnArgs = [`[Vue warn]: ${msg}`, ...args];
      if (trace.length && // avoid spamming console during tests
      true) {
        warnArgs.push(`
`, ...formatTrace(trace));
      }
      console.warn(...warnArgs);
    }
    resetTracking();
    isWarning = false;
  }
  function getComponentTrace() {
    let currentVNode = stack[stack.length - 1];
    if (!currentVNode) {
      return [];
    }
    const normalizedStack = [];
    while (currentVNode) {
      const last = normalizedStack[0];
      if (last && last.vnode === currentVNode) {
        last.recurseCount++;
      } else {
        normalizedStack.push({
          vnode: currentVNode,
          recurseCount: 0
        });
      }
      const parentInstance = currentVNode.component && currentVNode.component.parent;
      currentVNode = parentInstance && parentInstance.vnode;
    }
    return normalizedStack;
  }
  function formatTrace(trace) {
    const logs = [];
    trace.forEach((entry, i) => {
      logs.push(...i === 0 ? [] : [`
`], ...formatTraceEntry(entry));
    });
    return logs;
  }
  function formatTraceEntry({ vnode, recurseCount }) {
    const postfix = recurseCount > 0 ? `... (${recurseCount} recursive calls)` : ``;
    const isRoot = vnode.component ? vnode.component.parent == null : false;
    const open = ` at <${formatComponentName(
      vnode.component,
      vnode.type,
      isRoot
    )}`;
    const close = `>` + postfix;
    return vnode.props ? [open, ...formatProps(vnode.props), close] : [open + close];
  }
  function formatProps(props) {
    const res = [];
    const keys = Object.keys(props);
    keys.slice(0, 3).forEach((key) => {
      res.push(...formatProp(key, props[key]));
    });
    if (keys.length > 3) {
      res.push(` ...`);
    }
    return res;
  }
  function formatProp(key, value, raw) {
    if (isString(value)) {
      value = JSON.stringify(value);
      return raw ? value : [`${key}=${value}`];
    } else if (typeof value === "number" || typeof value === "boolean" || value == null) {
      return raw ? value : [`${key}=${value}`];
    } else if (/* @__PURE__ */ isRef(value)) {
      value = formatProp(key, /* @__PURE__ */ toRaw(value.value), true);
      return raw ? value : [`${key}=Ref<`, value, `>`];
    } else if (isFunction(value)) {
      return [`${key}=fn${value.name ? `<${value.name}>` : ``}`];
    } else {
      value = /* @__PURE__ */ toRaw(value);
      return raw ? value : [`${key}=`, value];
    }
  }
  function callWithErrorHandling(fn, instance, type, args) {
    try {
      return args ? fn(...args) : fn();
    } catch (err) {
      handleError(err, instance, type);
    }
  }
  function callWithAsyncErrorHandling(fn, instance, type, args) {
    if (isFunction(fn)) {
      const res = callWithErrorHandling(fn, instance, type, args);
      if (res && isPromise(res)) {
        res.catch((err) => {
          handleError(err, instance, type);
        });
      }
      return res;
    }
    if (isArray(fn)) {
      const values = [];
      for (let i = 0; i < fn.length; i++) {
        values.push(callWithAsyncErrorHandling(fn[i], instance, type, args));
      }
      return values;
    }
  }
  function handleError(err, instance, type, throwInDev = true) {
    const contextVNode = instance ? instance.vnode : null;
    const { errorHandler, throwUnhandledErrorInProduction } = instance && instance.appContext.config || EMPTY_OBJ;
    if (instance) {
      let cur = instance.parent;
      const exposedInstance = instance.proxy;
      const errorInfo = `https://vuejs.org/error-reference/#runtime-${type}`;
      while (cur) {
        const errorCapturedHooks = cur.ec;
        if (errorCapturedHooks) {
          for (let i = 0; i < errorCapturedHooks.length; i++) {
            if (errorCapturedHooks[i](err, exposedInstance, errorInfo) === false) {
              return;
            }
          }
        }
        cur = cur.parent;
      }
      if (errorHandler) {
        pauseTracking();
        callWithErrorHandling(errorHandler, null, 10, [
          err,
          exposedInstance,
          errorInfo
        ]);
        resetTracking();
        return;
      }
    }
    logError(err, type, contextVNode, throwInDev, throwUnhandledErrorInProduction);
  }
  function logError(err, type, contextVNode, throwInDev = true, throwInProd = false) {
    if (throwInProd) {
      throw err;
    } else {
      console.error(err);
    }
  }
  const queue = [];
  let flushIndex = -1;
  const pendingPostFlushCbs = [];
  let activePostFlushCbs = null;
  let postFlushIndex = 0;
  const resolvedPromise = /* @__PURE__ */ Promise.resolve();
  let currentFlushPromise = null;
  function nextTick(fn) {
    const p2 = currentFlushPromise || resolvedPromise;
    return fn ? p2.then(this ? fn.bind(this) : fn) : p2;
  }
  function findInsertionIndex(id) {
    let start = flushIndex + 1;
    let end = queue.length;
    while (start < end) {
      const middle = start + end >>> 1;
      const middleJob = queue[middle];
      const middleJobId = getId(middleJob);
      if (middleJobId < id || middleJobId === id && middleJob.flags & 2) {
        start = middle + 1;
      } else {
        end = middle;
      }
    }
    return start;
  }
  function queueJob(job) {
    if (!(job.flags & 1)) {
      const jobId = getId(job);
      const lastJob = queue[queue.length - 1];
      if (!lastJob || // fast path when the job id is larger than the tail
      !(job.flags & 2) && jobId >= getId(lastJob)) {
        queue.push(job);
      } else {
        queue.splice(findInsertionIndex(jobId), 0, job);
      }
      job.flags |= 1;
      queueFlush();
    }
  }
  function queueFlush() {
    if (!currentFlushPromise) {
      currentFlushPromise = resolvedPromise.then(flushJobs);
    }
  }
  function queuePostFlushCb(cb) {
    if (!isArray(cb)) {
      if (activePostFlushCbs && cb.id === -1) {
        activePostFlushCbs.splice(postFlushIndex + 1, 0, cb);
      } else if (!(cb.flags & 1)) {
        pendingPostFlushCbs.push(cb);
        cb.flags |= 1;
      }
    } else {
      for (let i = 0; i < cb.length; i++) {
        pendingPostFlushCbs.push(cb[i]);
      }
    }
    queueFlush();
  }
  function flushPreFlushCbs(instance, seen, i = flushIndex + 1) {
    for (; i < queue.length; i++) {
      const cb = queue[i];
      if (cb && cb.flags & 2) {
        if (instance && cb.id !== instance.uid) {
          continue;
        }
        queue.splice(i, 1);
        i--;
        if (cb.flags & 4) {
          cb.flags &= -2;
        }
        cb();
        if (!(cb.flags & 4)) {
          cb.flags &= -2;
        }
      }
    }
  }
  function flushPostFlushCbs(seen) {
    if (pendingPostFlushCbs.length) {
      const deduped = [...new Set(pendingPostFlushCbs)].sort(
        (a, b) => getId(a) - getId(b)
      );
      pendingPostFlushCbs.length = 0;
      if (activePostFlushCbs) {
        for (let i = 0; i < deduped.length; i++) {
          activePostFlushCbs.push(deduped[i]);
        }
        return;
      }
      activePostFlushCbs = deduped;
      for (postFlushIndex = 0; postFlushIndex < activePostFlushCbs.length; postFlushIndex++) {
        const cb = activePostFlushCbs[postFlushIndex];
        if (cb.flags & 4) {
          cb.flags &= -2;
        }
        if (!(cb.flags & 8)) cb();
        cb.flags &= -2;
      }
      activePostFlushCbs = null;
      postFlushIndex = 0;
    }
  }
  const getId = (job) => job.id == null ? job.flags & 2 ? -1 : Infinity : job.id;
  function flushJobs(seen) {
    try {
      for (flushIndex = 0; flushIndex < queue.length; flushIndex++) {
        const job = queue[flushIndex];
        if (job && !(job.flags & 8)) {
          if (false) ;
          if (job.flags & 4) {
            job.flags &= ~1;
          }
          callWithErrorHandling(
            job,
            job.i,
            job.i ? 15 : 14
          );
          if (!(job.flags & 4)) {
            job.flags &= ~1;
          }
        }
      }
    } finally {
      for (; flushIndex < queue.length; flushIndex++) {
        const job = queue[flushIndex];
        if (job) {
          job.flags &= -2;
        }
      }
      flushIndex = -1;
      queue.length = 0;
      flushPostFlushCbs();
      currentFlushPromise = null;
      if (queue.length || pendingPostFlushCbs.length) {
        flushJobs();
      }
    }
  }
  let currentRenderingInstance = null;
  let currentScopeId = null;
  function setCurrentRenderingInstance(instance) {
    const prev = currentRenderingInstance;
    currentRenderingInstance = instance;
    currentScopeId = instance && instance.type.__scopeId || null;
    return prev;
  }
  function withCtx(fn, ctx = currentRenderingInstance, isNonScopedSlot) {
    if (!ctx) return fn;
    if (fn._n) {
      return fn;
    }
    const renderFnWithContext = (...args) => {
      if (renderFnWithContext._d) {
        setBlockTracking(-1);
      }
      const prevInstance = setCurrentRenderingInstance(ctx);
      const prevStackSize = blockStack.length;
      let res;
      try {
        res = fn(...args);
      } finally {
        for (let i = blockStack.length; i > prevStackSize; i--) closeBlock();
        setCurrentRenderingInstance(prevInstance);
        if (renderFnWithContext._d) {
          setBlockTracking(1);
        }
      }
      return res;
    };
    renderFnWithContext._n = true;
    renderFnWithContext._c = true;
    renderFnWithContext._d = true;
    return renderFnWithContext;
  }
  function withDirectives(vnode, directives) {
    if (currentRenderingInstance === null) {
      return vnode;
    }
    const instance = getComponentPublicInstance(currentRenderingInstance);
    const bindings = vnode.dirs || (vnode.dirs = []);
    for (let i = 0; i < directives.length; i++) {
      let [dir, value, arg, modifiers = EMPTY_OBJ] = directives[i];
      if (dir) {
        if (isFunction(dir)) {
          dir = {
            mounted: dir,
            updated: dir
          };
        }
        if (dir.deep) {
          traverse(value);
        }
        bindings.push({
          dir,
          instance,
          value,
          oldValue: void 0,
          arg,
          modifiers
        });
      }
    }
    return vnode;
  }
  function invokeDirectiveHook(vnode, prevVNode, instance, name) {
    const bindings = vnode.dirs;
    const oldBindings = prevVNode && prevVNode.dirs;
    for (let i = 0; i < bindings.length; i++) {
      const binding = bindings[i];
      if (oldBindings) {
        binding.oldValue = oldBindings[i].value;
      }
      let hook = binding.dir[name];
      if (hook) {
        pauseTracking();
        callWithAsyncErrorHandling(hook, instance, 8, [
          vnode.el,
          binding,
          vnode,
          prevVNode
        ]);
        resetTracking();
      }
    }
  }
  function provide(key, value) {
    if (currentInstance) {
      let provides = currentInstance.provides;
      const parentProvides = currentInstance.parent && currentInstance.parent.provides;
      if (parentProvides === provides) {
        provides = currentInstance.provides = Object.create(parentProvides);
      }
      provides[key] = value;
    }
  }
  function inject(key, defaultValue, treatDefaultAsFactory = false) {
    const instance = getCurrentInstance();
    if (instance || currentApp) {
      let provides = currentApp ? currentApp._context.provides : instance ? instance.parent == null || instance.ce ? instance.vnode.appContext && instance.vnode.appContext.provides : instance.parent.provides : void 0;
      if (provides && key in provides) {
        return provides[key];
      } else if (arguments.length > 1) {
        return treatDefaultAsFactory && isFunction(defaultValue) ? defaultValue.call(instance && instance.proxy) : defaultValue;
      } else ;
    }
  }
  const ssrContextKey = /* @__PURE__ */ Symbol.for("v-scx");
  const useSSRContext = () => {
    {
      const ctx = inject(ssrContextKey);
      return ctx;
    }
  };
  function watch(source, cb, options) {
    return doWatch(source, cb, options);
  }
  function doWatch(source, cb, options = EMPTY_OBJ) {
    const { immediate, deep, flush, once } = options;
    const baseWatchOptions = extend({}, options);
    const runsImmediately = cb && immediate || !cb && flush !== "post";
    let ssrCleanup;
    if (isInSSRComponentSetup) {
      if (flush === "sync") {
        const ctx = useSSRContext();
        ssrCleanup = ctx.__watcherHandles || (ctx.__watcherHandles = []);
      } else if (!runsImmediately) {
        const watchStopHandle = () => {
        };
        watchStopHandle.stop = NOOP;
        watchStopHandle.resume = NOOP;
        watchStopHandle.pause = NOOP;
        return watchStopHandle;
      }
    }
    const instance = currentInstance;
    baseWatchOptions.call = (fn, type, args) => callWithAsyncErrorHandling(fn, instance, type, args);
    let isPre = false;
    if (flush === "post") {
      baseWatchOptions.scheduler = (job) => {
        queuePostRenderEffect(job, instance && instance.suspense);
      };
    } else if (flush !== "sync") {
      isPre = true;
      baseWatchOptions.scheduler = (job, isFirstRun) => {
        if (isFirstRun) {
          job();
        } else {
          queueJob(job);
        }
      };
    }
    baseWatchOptions.augmentJob = (job) => {
      if (cb) {
        job.flags |= 4;
      }
      if (isPre) {
        job.flags |= 2;
        if (instance) {
          job.id = instance.uid;
          job.i = instance;
        }
      }
    };
    const watchHandle = watch$1(source, cb, baseWatchOptions);
    if (isInSSRComponentSetup) {
      if (ssrCleanup) {
        ssrCleanup.push(watchHandle);
      } else if (runsImmediately) {
        watchHandle();
      }
    }
    return watchHandle;
  }
  function instanceWatch(source, value, options) {
    const publicThis = this.proxy;
    const getter = isString(source) ? source.includes(".") ? createPathGetter(publicThis, source) : () => publicThis[source] : source.bind(publicThis, publicThis);
    let cb;
    if (isFunction(value)) {
      cb = value;
    } else {
      cb = value.handler;
      options = value;
    }
    const reset = setCurrentInstance(this);
    const res = doWatch(getter, cb.bind(publicThis), options);
    reset();
    return res;
  }
  function createPathGetter(ctx, path) {
    const segments = path.split(".");
    return () => {
      let cur = ctx;
      for (let i = 0; i < segments.length && cur; i++) {
        cur = cur[segments[i]];
      }
      return cur;
    };
  }
  const TeleportEndKey = /* @__PURE__ */ Symbol("_vte");
  const isTeleport = (type) => type.__isTeleport;
  const leaveCbKey = /* @__PURE__ */ Symbol("_leaveCb");
  function findNonCommentChild(children) {
    let child = children[0];
    if (children.length > 1) {
      for (const c of children) {
        if (c.type !== Comment) {
          child = c;
          break;
        }
      }
    }
    return child;
  }
  function getInnerChild$1(vnode) {
    if (!isKeepAlive(vnode)) {
      if (isTeleport(vnode.type) && vnode.children) {
        return findNonCommentChild(vnode.children);
      }
      return vnode;
    }
    if (vnode.component) {
      return vnode.component.subTree;
    }
    const { shapeFlag, children } = vnode;
    if (children) {
      if (shapeFlag & 16) {
        return children[0];
      }
      if (shapeFlag & 32 && isFunction(children.default)) {
        return children.default();
      }
    }
  }
  function setTransitionHooks(vnode, hooks) {
    if (vnode.shapeFlag & 6 && vnode.component) {
      vnode.transition = hooks;
      const subTree = vnode.component.subTree;
      setTransitionHooks(
        isTeleport(subTree.type) ? getInnerChild$1(subTree) || subTree : subTree,
        hooks
      );
    } else if (vnode.shapeFlag & 128) {
      vnode.ssContent.transition = hooks.clone(vnode.ssContent);
      vnode.ssFallback.transition = hooks.clone(vnode.ssFallback);
    } else {
      vnode.transition = hooks;
    }
  }
  // @__NO_SIDE_EFFECTS__
  function defineComponent(options, extraOptions) {
    return isFunction(options) ? (
      // #8236: extend call and options.name access are considered side-effects
      // by Rollup, so we have to wrap it in a pure-annotated IIFE.
      /* @__PURE__ */ (() => extend({ name: options.name }, extraOptions, { setup: options }))()
    ) : options;
  }
  function markAsyncBoundary(instance) {
    instance.ids = [instance.ids[0] + instance.ids[2]++ + "-", 0, 0];
  }
  function isTemplateRefKey(refs2, key) {
    let desc;
    return !!((desc = Object.getOwnPropertyDescriptor(refs2, key)) && !desc.configurable);
  }
  const pendingSetRefMap = /* @__PURE__ */ new WeakMap();
  function setRef(rawRef, oldRawRef, parentSuspense, vnode, isUnmount = false) {
    if (isArray(rawRef)) {
      rawRef.forEach(
        (r2, i) => setRef(
          r2,
          oldRawRef && (isArray(oldRawRef) ? oldRawRef[i] : oldRawRef),
          parentSuspense,
          vnode,
          isUnmount
        )
      );
      return;
    }
    if (isAsyncWrapper(vnode) && !isUnmount) {
      if (vnode.shapeFlag & 512 && vnode.type.__asyncResolved && vnode.component.subTree.component) {
        setRef(rawRef, oldRawRef, parentSuspense, vnode.component.subTree);
      }
      return;
    }
    const refValue = vnode.shapeFlag & 4 ? getComponentPublicInstance(vnode.component) : vnode.el;
    const value = isUnmount ? null : refValue;
    const { i: owner, r: ref3 } = rawRef;
    const oldRef = oldRawRef && oldRawRef.r;
    const refs2 = owner.refs === EMPTY_OBJ ? owner.refs = {} : owner.refs;
    const setupState = owner.setupState;
    const rawSetupState = /* @__PURE__ */ toRaw(setupState);
    const canSetSetupRef = setupState === EMPTY_OBJ ? NO : (key) => {
      if (isTemplateRefKey(refs2, key)) {
        return false;
      }
      return hasOwn(rawSetupState, key);
    };
    const canSetRef = (ref22, key) => {
      if (key && isTemplateRefKey(refs2, key)) {
        return false;
      }
      return true;
    };
    if (oldRef != null && oldRef !== ref3) {
      invalidatePendingSetRef(oldRawRef);
      if (isString(oldRef)) {
        refs2[oldRef] = null;
        if (canSetSetupRef(oldRef)) {
          setupState[oldRef] = null;
        }
      } else if (/* @__PURE__ */ isRef(oldRef)) {
        const oldRawRefAtom = oldRawRef;
        if (canSetRef(oldRef, oldRawRefAtom.k)) {
          oldRef.value = null;
        }
        if (oldRawRefAtom.k) refs2[oldRawRefAtom.k] = null;
      }
    }
    if (isFunction(ref3)) {
      callWithErrorHandling(ref3, owner, 12, [value, refs2]);
    } else {
      const _isString = isString(ref3);
      const _isRef = /* @__PURE__ */ isRef(ref3);
      if (_isString || _isRef) {
        const doSet = () => {
          if (rawRef.f) {
            const existing = _isString ? canSetSetupRef(ref3) ? setupState[ref3] : refs2[ref3] : canSetRef() || !rawRef.k ? ref3.value : refs2[rawRef.k];
            if (isUnmount) {
              isArray(existing) && remove(existing, refValue);
            } else {
              if (!isArray(existing)) {
                if (_isString) {
                  refs2[ref3] = [refValue];
                  if (canSetSetupRef(ref3)) {
                    setupState[ref3] = refs2[ref3];
                  }
                } else {
                  const newVal = [refValue];
                  if (canSetRef(ref3, rawRef.k)) {
                    ref3.value = newVal;
                  }
                  if (rawRef.k) refs2[rawRef.k] = newVal;
                }
              } else if (!existing.includes(refValue)) {
                existing.push(refValue);
              }
            }
          } else if (_isString) {
            refs2[ref3] = value;
            if (canSetSetupRef(ref3)) {
              setupState[ref3] = value;
            }
          } else if (_isRef) {
            if (canSetRef(ref3, rawRef.k)) {
              ref3.value = value;
            }
            if (rawRef.k) refs2[rawRef.k] = value;
          } else ;
        };
        if (value) {
          const job = () => {
            doSet();
            pendingSetRefMap.delete(rawRef);
          };
          job.id = -1;
          pendingSetRefMap.set(rawRef, job);
          queuePostRenderEffect(job, parentSuspense);
        } else {
          invalidatePendingSetRef(rawRef);
          doSet();
        }
      }
    }
  }
  function invalidatePendingSetRef(rawRef) {
    const pendingSetRef = pendingSetRefMap.get(rawRef);
    if (pendingSetRef) {
      pendingSetRef.flags |= 8;
      pendingSetRefMap.delete(rawRef);
    }
  }
  getGlobalThis().requestIdleCallback || ((cb) => setTimeout(cb, 1));
  getGlobalThis().cancelIdleCallback || ((id) => clearTimeout(id));
  const isAsyncWrapper = (i) => !!i.type.__asyncLoader;
  const isKeepAlive = (vnode) => vnode.type.__isKeepAlive;
  function onActivated(hook, target) {
    registerKeepAliveHook(hook, "a", target);
  }
  function onDeactivated(hook, target) {
    registerKeepAliveHook(hook, "da", target);
  }
  function registerKeepAliveHook(hook, type, target = currentInstance) {
    const wrappedHook = hook.__wdc || (hook.__wdc = () => {
      let current = target;
      while (current) {
        if (current.isDeactivated) {
          return;
        }
        current = current.parent;
      }
      return hook();
    });
    injectHook(type, wrappedHook, target);
    if (target) {
      let current = target.parent;
      while (current && current.parent) {
        if (isKeepAlive(current.parent.vnode)) {
          injectToKeepAliveRoot(wrappedHook, type, target, current);
        }
        current = current.parent;
      }
    }
  }
  function injectToKeepAliveRoot(hook, type, target, keepAliveRoot) {
    const injected = injectHook(
      type,
      hook,
      keepAliveRoot,
      true
      /* prepend */
    );
    onUnmounted(() => {
      remove(keepAliveRoot[type], injected);
    }, target);
  }
  function injectHook(type, hook, target = currentInstance, prepend = false) {
    if (target) {
      const hooks = target[type] || (target[type] = []);
      const wrappedHook = hook.__weh || (hook.__weh = (...args) => {
        pauseTracking();
        const reset = setCurrentInstance(target);
        const res = callWithAsyncErrorHandling(hook, target, type, args);
        reset();
        resetTracking();
        return res;
      });
      if (prepend) {
        hooks.unshift(wrappedHook);
      } else {
        hooks.push(wrappedHook);
      }
      return wrappedHook;
    }
  }
  const createHook = (lifecycle) => (hook, target = currentInstance) => {
    if (!isInSSRComponentSetup || lifecycle === "sp") {
      injectHook(lifecycle, (...args) => hook(...args), target);
    }
  };
  const onBeforeMount = createHook("bm");
  const onMounted = createHook("m");
  const onBeforeUpdate = createHook(
    "bu"
  );
  const onUpdated = createHook("u");
  const onBeforeUnmount = createHook(
    "bum"
  );
  const onUnmounted = createHook("um");
  const onServerPrefetch = createHook(
    "sp"
  );
  const onRenderTriggered = createHook("rtg");
  const onRenderTracked = createHook("rtc");
  function onErrorCaptured(hook, target = currentInstance) {
    injectHook("ec", hook, target);
  }
  const NULL_DYNAMIC_COMPONENT = /* @__PURE__ */ Symbol.for("v-ndc");
  function renderList(source, renderItem, cache, index) {
    let ret;
    const cached = cache;
    const sourceIsArray = isArray(source);
    if (sourceIsArray || isString(source)) {
      const sourceIsReactiveArray = sourceIsArray && /* @__PURE__ */ isReactive(source);
      let needsWrap = false;
      let isReadonlySource = false;
      if (sourceIsReactiveArray) {
        needsWrap = !/* @__PURE__ */ isShallow(source);
        isReadonlySource = /* @__PURE__ */ isReadonly(source);
        source = shallowReadArray(source);
      }
      ret = new Array(source.length);
      for (let i = 0, l = source.length; i < l; i++) {
        ret[i] = renderItem(
          needsWrap ? isReadonlySource ? toReadonly(toReactive(source[i])) : toReactive(source[i]) : source[i],
          i,
          void 0,
          cached
        );
      }
    } else if (typeof source === "number") {
      {
        ret = new Array(source);
        for (let i = 0; i < source; i++) {
          ret[i] = renderItem(i + 1, i, void 0, cached);
        }
      }
    } else if (isObject(source)) {
      if (source[Symbol.iterator]) {
        ret = Array.from(
          source,
          (item, i) => renderItem(item, i, void 0, cached)
        );
      } else {
        const keys = Object.keys(source);
        ret = new Array(keys.length);
        for (let i = 0, l = keys.length; i < l; i++) {
          const key = keys[i];
          ret[i] = renderItem(source[key], key, i, cached);
        }
      }
    } else {
      ret = [];
    }
    return ret;
  }
  function renderSlot(slots, name, props, fallback, noSlotted, branchKey) {
    if (props == null) props = {};
    if (currentRenderingInstance.ce || currentRenderingInstance.parent && isAsyncWrapper(currentRenderingInstance.parent) && currentRenderingInstance.parent.ce) {
      const slotProps = props;
      const hasProps = Object.keys(slotProps).length > 0;
      return openBlock(), createBlock(
        Fragment,
        null,
        [createVNode("slot", slotProps, fallback)],
        hasProps ? -2 : 64
      );
    }
    let slot = slots[name];
    if (slot && slot._c) {
      slot._d = false;
    }
    const prevStackSize = blockStack.length;
    openBlock();
    let rendered;
    try {
      const validSlotContent = slot && ensureValidVNode(slot(props));
      const slotKey = props.key || branchKey || // slot content array of a dynamic conditional slot may have a branch
      // key attached in the `createSlots` helper, respect that
      validSlotContent && validSlotContent.key;
      rendered = createBlock(
        Fragment,
        {
          key: (slotKey && !isSymbol(slotKey) ? slotKey : `_${name}`) + // #7256 force differentiate fallback content from actual content
          (!validSlotContent && fallback ? "_fb" : "")
        },
        validSlotContent || (fallback ? fallback() : []),
        validSlotContent && slots._ === 1 ? 64 : -2
      );
    } catch (err) {
      for (let i = blockStack.length; i > prevStackSize; i--) closeBlock();
      throw err;
    } finally {
      if (slot && slot._c) {
        slot._d = true;
      }
    }
    if (rendered.scopeId) {
      rendered.slotScopeIds = [rendered.scopeId + "-s"];
    }
    return rendered;
  }
  function ensureValidVNode(vnodes) {
    return vnodes.some((child) => {
      if (!isVNode(child)) return true;
      if (child.type === Comment) return false;
      if (child.type === Fragment && !ensureValidVNode(child.children))
        return false;
      return true;
    }) ? vnodes : null;
  }
  const getPublicInstance = (i) => {
    if (!i) return null;
    if (isStatefulComponent(i)) return getComponentPublicInstance(i);
    return getPublicInstance(i.parent);
  };
  const publicPropertiesMap = (
    // Move PURE marker to new line to workaround compiler discarding it
    // due to type annotation
    /* @__PURE__ */ extend(/* @__PURE__ */ Object.create(null), {
      $: (i) => i,
      $el: (i) => i.vnode.el,
      $data: (i) => i.data,
      $props: (i) => i.props,
      $attrs: (i) => i.attrs,
      $slots: (i) => i.slots,
      $refs: (i) => i.refs,
      $parent: (i) => getPublicInstance(i.parent),
      $root: (i) => getPublicInstance(i.root),
      $host: (i) => i.ce,
      $emit: (i) => i.emit,
      $options: (i) => resolveMergedOptions(i),
      $forceUpdate: (i) => i.f || (i.f = () => {
        queueJob(i.update);
      }),
      $nextTick: (i) => i.n || (i.n = nextTick.bind(i.proxy)),
      $watch: (i) => instanceWatch.bind(i)
    })
  );
  const hasSetupBinding = (state, key) => state !== EMPTY_OBJ && !state.__isScriptSetup && hasOwn(state, key);
  const PublicInstanceProxyHandlers = {
    get({ _: instance }, key) {
      if (key === "__v_skip") {
        return true;
      }
      const { ctx, setupState, data, props, accessCache, type, appContext } = instance;
      if (key[0] !== "$") {
        const n = accessCache[key];
        if (n !== void 0) {
          switch (n) {
            case 1:
              return setupState[key];
            case 2:
              return data[key];
            case 4:
              return ctx[key];
            case 3:
              return props[key];
          }
        } else if (hasSetupBinding(setupState, key)) {
          accessCache[key] = 1;
          return setupState[key];
        } else if (data !== EMPTY_OBJ && hasOwn(data, key)) {
          accessCache[key] = 2;
          return data[key];
        } else if (hasOwn(props, key)) {
          accessCache[key] = 3;
          return props[key];
        } else if (ctx !== EMPTY_OBJ && hasOwn(ctx, key)) {
          accessCache[key] = 4;
          return ctx[key];
        } else if (shouldCacheAccess) {
          accessCache[key] = 0;
        }
      }
      const publicGetter = publicPropertiesMap[key];
      let cssModule, globalProperties;
      if (publicGetter) {
        if (key === "$attrs") {
          track(instance.attrs, "get", "");
        }
        return publicGetter(instance);
      } else if (
        // css module (injected by vue-loader)
        (cssModule = type.__cssModules) && (cssModule = cssModule[key])
      ) {
        return cssModule;
      } else if (ctx !== EMPTY_OBJ && hasOwn(ctx, key)) {
        accessCache[key] = 4;
        return ctx[key];
      } else if (
        // global properties
        globalProperties = appContext.config.globalProperties, hasOwn(globalProperties, key)
      ) {
        {
          return globalProperties[key];
        }
      } else ;
    },
    set({ _: instance }, key, value) {
      const { data, setupState, ctx } = instance;
      if (hasSetupBinding(setupState, key)) {
        setupState[key] = value;
        return true;
      } else if (data !== EMPTY_OBJ && hasOwn(data, key)) {
        data[key] = value;
        return true;
      } else if (hasOwn(instance.props, key)) {
        return false;
      }
      if (key[0] === "$" && key.slice(1) in instance) {
        return false;
      } else {
        {
          ctx[key] = value;
        }
      }
      return true;
    },
    has({
      _: { data, setupState, accessCache, ctx, appContext, props, type }
    }, key) {
      let cssModules;
      return !!(accessCache[key] || data !== EMPTY_OBJ && key[0] !== "$" && hasOwn(data, key) || hasSetupBinding(setupState, key) || hasOwn(props, key) || hasOwn(ctx, key) || hasOwn(publicPropertiesMap, key) || hasOwn(appContext.config.globalProperties, key) || (cssModules = type.__cssModules) && cssModules[key]);
    },
    defineProperty(target, key, descriptor) {
      if (descriptor.get != null) {
        target._.accessCache[key] = 0;
      } else if (hasOwn(descriptor, "value")) {
        this.set(target, key, descriptor.value, null);
      }
      return Reflect.defineProperty(target, key, descriptor);
    }
  };
  function normalizePropsOrEmits(props) {
    return isArray(props) ? props.reduce(
      (normalized, p2) => (normalized[p2] = null, normalized),
      {}
    ) : props;
  }
  let shouldCacheAccess = true;
  function applyOptions(instance) {
    const options = resolveMergedOptions(instance);
    const publicThis = instance.proxy;
    const ctx = instance.ctx;
    shouldCacheAccess = false;
    if (options.beforeCreate) {
      callHook(options.beforeCreate, instance, "bc");
    }
    const {
      // state
      data: dataOptions,
      computed: computedOptions,
      methods,
      watch: watchOptions,
      provide: provideOptions,
      inject: injectOptions,
      // lifecycle
      created,
      beforeMount,
      mounted,
      beforeUpdate,
      updated,
      activated,
      deactivated,
      beforeDestroy,
      beforeUnmount,
      destroyed,
      unmounted,
      render,
      renderTracked,
      renderTriggered,
      errorCaptured,
      serverPrefetch,
      // public API
      expose,
      inheritAttrs,
      // assets
      components,
      directives,
      filters
    } = options;
    const checkDuplicateProperties = null;
    if (injectOptions) {
      resolveInjections(injectOptions, ctx, checkDuplicateProperties);
    }
    if (methods) {
      for (const key in methods) {
        const methodHandler = methods[key];
        if (isFunction(methodHandler)) {
          {
            ctx[key] = methodHandler.bind(publicThis);
          }
        }
      }
    }
    if (dataOptions) {
      const data = dataOptions.call(publicThis, publicThis);
      if (!isObject(data)) ;
      else {
        instance.data = /* @__PURE__ */ reactive(data);
      }
    }
    shouldCacheAccess = true;
    if (computedOptions) {
      for (const key in computedOptions) {
        const opt = computedOptions[key];
        const get = isFunction(opt) ? opt.bind(publicThis, publicThis) : isFunction(opt.get) ? opt.get.bind(publicThis, publicThis) : NOOP;
        const set = !isFunction(opt) && isFunction(opt.set) ? opt.set.bind(publicThis) : NOOP;
        const c = computed({
          get,
          set
        });
        Object.defineProperty(ctx, key, {
          enumerable: true,
          configurable: true,
          get: () => c.value,
          set: (v) => c.value = v
        });
      }
    }
    if (watchOptions) {
      for (const key in watchOptions) {
        createWatcher(watchOptions[key], ctx, publicThis, key);
      }
    }
    if (provideOptions) {
      const provides = isFunction(provideOptions) ? provideOptions.call(publicThis) : provideOptions;
      Reflect.ownKeys(provides).forEach((key) => {
        provide(key, provides[key]);
      });
    }
    if (created) {
      callHook(created, instance, "c");
    }
    function registerLifecycleHook(register, hook) {
      if (isArray(hook)) {
        hook.forEach((_hook) => register(_hook.bind(publicThis)));
      } else if (hook) {
        register(hook.bind(publicThis));
      }
    }
    registerLifecycleHook(onBeforeMount, beforeMount);
    registerLifecycleHook(onMounted, mounted);
    registerLifecycleHook(onBeforeUpdate, beforeUpdate);
    registerLifecycleHook(onUpdated, updated);
    registerLifecycleHook(onActivated, activated);
    registerLifecycleHook(onDeactivated, deactivated);
    registerLifecycleHook(onErrorCaptured, errorCaptured);
    registerLifecycleHook(onRenderTracked, renderTracked);
    registerLifecycleHook(onRenderTriggered, renderTriggered);
    registerLifecycleHook(onBeforeUnmount, beforeUnmount);
    registerLifecycleHook(onUnmounted, unmounted);
    registerLifecycleHook(onServerPrefetch, serverPrefetch);
    if (isArray(expose)) {
      if (expose.length) {
        const exposed = instance.exposed || (instance.exposed = {});
        expose.forEach((key) => {
          Object.defineProperty(exposed, key, {
            get: () => publicThis[key],
            set: (val) => publicThis[key] = val,
            enumerable: true
          });
        });
      } else if (!instance.exposed) {
        instance.exposed = {};
      }
    }
    if (render && instance.render === NOOP) {
      instance.render = render;
    }
    if (inheritAttrs != null) {
      instance.inheritAttrs = inheritAttrs;
    }
    if (components) instance.components = components;
    if (directives) instance.directives = directives;
    if (serverPrefetch) {
      markAsyncBoundary(instance);
    }
  }
  function resolveInjections(injectOptions, ctx, checkDuplicateProperties = NOOP) {
    if (isArray(injectOptions)) {
      injectOptions = normalizeInject(injectOptions);
    }
    for (const key in injectOptions) {
      const opt = injectOptions[key];
      let injected;
      if (isObject(opt)) {
        if ("default" in opt) {
          injected = inject(
            opt.from || key,
            opt.default,
            true
          );
        } else {
          injected = inject(opt.from || key);
        }
      } else {
        injected = inject(opt);
      }
      if (/* @__PURE__ */ isRef(injected)) {
        Object.defineProperty(ctx, key, {
          enumerable: true,
          configurable: true,
          get: () => injected.value,
          set: (v) => injected.value = v
        });
      } else {
        ctx[key] = injected;
      }
    }
  }
  function callHook(hook, instance, type) {
    callWithAsyncErrorHandling(
      isArray(hook) ? hook.map((h2) => h2.bind(instance.proxy)) : hook.bind(instance.proxy),
      instance,
      type
    );
  }
  function createWatcher(raw, ctx, publicThis, key) {
    let getter = key.includes(".") ? createPathGetter(publicThis, key) : () => publicThis[key];
    if (isString(raw)) {
      const handler = ctx[raw];
      if (isFunction(handler)) {
        {
          watch(getter, handler);
        }
      }
    } else if (isFunction(raw)) {
      {
        watch(getter, raw.bind(publicThis));
      }
    } else if (isObject(raw)) {
      if (isArray(raw)) {
        raw.forEach((r2) => createWatcher(r2, ctx, publicThis, key));
      } else {
        const handler = isFunction(raw.handler) ? raw.handler.bind(publicThis) : ctx[raw.handler];
        if (isFunction(handler)) {
          watch(getter, handler, raw);
        }
      }
    } else ;
  }
  function resolveMergedOptions(instance) {
    const base = instance.type;
    const { mixins, extends: extendsOptions } = base;
    const {
      mixins: globalMixins,
      optionsCache: cache,
      config: { optionMergeStrategies }
    } = instance.appContext;
    const cached = cache.get(base);
    let resolved;
    if (cached) {
      resolved = cached;
    } else if (!globalMixins.length && !mixins && !extendsOptions) {
      {
        resolved = base;
      }
    } else {
      resolved = {};
      if (globalMixins.length) {
        globalMixins.forEach(
          (m) => mergeOptions(resolved, m, optionMergeStrategies, true)
        );
      }
      mergeOptions(resolved, base, optionMergeStrategies);
    }
    if (isObject(base)) {
      cache.set(base, resolved);
    }
    return resolved;
  }
  function mergeOptions(to, from, strats, asMixin = false) {
    const { mixins, extends: extendsOptions } = from;
    if (extendsOptions) {
      mergeOptions(to, extendsOptions, strats, true);
    }
    if (mixins) {
      mixins.forEach(
        (m) => mergeOptions(to, m, strats, true)
      );
    }
    for (const key in from) {
      if (asMixin && key === "expose") ;
      else {
        const strat = internalOptionMergeStrats[key] || strats && strats[key];
        to[key] = strat ? strat(to[key], from[key]) : from[key];
      }
    }
    return to;
  }
  const internalOptionMergeStrats = {
    data: mergeDataFn,
    props: mergeEmitsOrPropsOptions,
    emits: mergeEmitsOrPropsOptions,
    // objects
    methods: mergeObjectOptions,
    computed: mergeObjectOptions,
    // lifecycle
    beforeCreate: mergeAsArray,
    created: mergeAsArray,
    beforeMount: mergeAsArray,
    mounted: mergeAsArray,
    beforeUpdate: mergeAsArray,
    updated: mergeAsArray,
    beforeDestroy: mergeAsArray,
    beforeUnmount: mergeAsArray,
    destroyed: mergeAsArray,
    unmounted: mergeAsArray,
    activated: mergeAsArray,
    deactivated: mergeAsArray,
    errorCaptured: mergeAsArray,
    serverPrefetch: mergeAsArray,
    // assets
    components: mergeObjectOptions,
    directives: mergeObjectOptions,
    // watch
    watch: mergeWatchOptions,
    // provide / inject
    provide: mergeDataFn,
    inject: mergeInject
  };
  function mergeDataFn(to, from) {
    if (!from) {
      return to;
    }
    if (!to) {
      return from;
    }
    return function mergedDataFn() {
      return extend(
        isFunction(to) ? to.call(this, this) : to,
        isFunction(from) ? from.call(this, this) : from
      );
    };
  }
  function mergeInject(to, from) {
    return mergeObjectOptions(normalizeInject(to), normalizeInject(from));
  }
  function normalizeInject(raw) {
    if (isArray(raw)) {
      const res = {};
      for (let i = 0; i < raw.length; i++) {
        res[raw[i]] = raw[i];
      }
      return res;
    }
    return raw;
  }
  function mergeAsArray(to, from) {
    return to ? [...new Set([].concat(to, from))] : from;
  }
  function mergeObjectOptions(to, from) {
    return to ? extend(/* @__PURE__ */ Object.create(null), to, from) : from;
  }
  function mergeEmitsOrPropsOptions(to, from) {
    if (to) {
      if (isArray(to) && isArray(from)) {
        return [.../* @__PURE__ */ new Set([...to, ...from])];
      }
      return extend(
        /* @__PURE__ */ Object.create(null),
        normalizePropsOrEmits(to),
        normalizePropsOrEmits(from != null ? from : {})
      );
    } else {
      return from;
    }
  }
  function mergeWatchOptions(to, from) {
    if (!to) return from;
    if (!from) return to;
    const merged = extend(/* @__PURE__ */ Object.create(null), to);
    for (const key in from) {
      merged[key] = mergeAsArray(to[key], from[key]);
    }
    return merged;
  }
  function createAppContext() {
    return {
      app: null,
      config: {
        isNativeTag: NO,
        performance: false,
        globalProperties: {},
        optionMergeStrategies: {},
        errorHandler: void 0,
        warnHandler: void 0,
        compilerOptions: {}
      },
      mixins: [],
      components: {},
      directives: {},
      provides: /* @__PURE__ */ Object.create(null),
      optionsCache: /* @__PURE__ */ new WeakMap(),
      propsCache: /* @__PURE__ */ new WeakMap(),
      emitsCache: /* @__PURE__ */ new WeakMap()
    };
  }
  let uid$1 = 0;
  function createAppAPI(render, hydrate) {
    return function createApp2(rootComponent, rootProps = null) {
      if (!isFunction(rootComponent)) {
        rootComponent = extend({}, rootComponent);
      }
      if (rootProps != null && !isObject(rootProps)) {
        rootProps = null;
      }
      const context = createAppContext();
      const installedPlugins = /* @__PURE__ */ new WeakSet();
      const pluginCleanupFns = [];
      let isMounted = false;
      const app = context.app = {
        _uid: uid$1++,
        _component: rootComponent,
        _props: rootProps,
        _container: null,
        _context: context,
        _instance: null,
        version,
        get config() {
          return context.config;
        },
        set config(v) {
        },
        use(plugin, ...options) {
          if (installedPlugins.has(plugin)) ;
          else if (plugin && isFunction(plugin.install)) {
            installedPlugins.add(plugin);
            plugin.install(app, ...options);
          } else if (isFunction(plugin)) {
            installedPlugins.add(plugin);
            plugin(app, ...options);
          } else ;
          return app;
        },
        mixin(mixin) {
          {
            if (!context.mixins.includes(mixin)) {
              context.mixins.push(mixin);
            }
          }
          return app;
        },
        component(name, component) {
          if (!component) {
            return context.components[name];
          }
          context.components[name] = component;
          return app;
        },
        directive(name, directive) {
          if (!directive) {
            return context.directives[name];
          }
          context.directives[name] = directive;
          return app;
        },
        mount(rootContainer, isHydrate, namespace) {
          if (!isMounted) {
            const vnode = app._ceVNode || createVNode(rootComponent, rootProps);
            vnode.appContext = context;
            if (namespace === true) {
              namespace = "svg";
            } else if (namespace === false) {
              namespace = void 0;
            }
            {
              render(vnode, rootContainer, namespace);
            }
            isMounted = true;
            app._container = rootContainer;
            rootContainer.__vue_app__ = app;
            return getComponentPublicInstance(vnode.component);
          }
        },
        onUnmount(cleanupFn) {
          pluginCleanupFns.push(cleanupFn);
        },
        unmount() {
          if (isMounted) {
            callWithAsyncErrorHandling(
              pluginCleanupFns,
              app._instance,
              16
            );
            render(null, app._container);
            delete app._container.__vue_app__;
          }
        },
        provide(key, value) {
          context.provides[key] = value;
          return app;
        },
        runWithContext(fn) {
          const lastApp = currentApp;
          currentApp = app;
          try {
            return fn();
          } finally {
            currentApp = lastApp;
          }
        }
      };
      return app;
    };
  }
  let currentApp = null;
  const getModelModifiers = (props, modelName) => {
    return modelName === "modelValue" || modelName === "model-value" ? props.modelModifiers : props[`${modelName}Modifiers`] || props[`${camelize(modelName)}Modifiers`] || props[`${hyphenate(modelName)}Modifiers`];
  };
  function emit(instance, event, ...rawArgs) {
    if (instance.isUnmounted) return;
    const props = instance.vnode.props || EMPTY_OBJ;
    let args = rawArgs;
    const isModelListener2 = event.startsWith("update:");
    const modifiers = isModelListener2 && getModelModifiers(props, event.slice(7));
    if (modifiers) {
      if (modifiers.trim) {
        args = rawArgs.map((a) => isString(a) ? a.trim() : a);
      }
      if (modifiers.number) {
        args = args.map(looseToNumber);
      }
    }
    let handlerName;
    let handler = props[handlerName = toHandlerKey(event)] || // also try camelCase event handler (#2249)
    props[handlerName = toHandlerKey(camelize(event))];
    if (!handler && isModelListener2) {
      handler = props[handlerName = toHandlerKey(hyphenate(event))];
    }
    if (handler) {
      callWithAsyncErrorHandling(
        handler,
        instance,
        6,
        args
      );
    }
    const onceHandler = props[handlerName + `Once`];
    if (onceHandler) {
      if (!instance.emitted) {
        instance.emitted = {};
      } else if (instance.emitted[handlerName]) {
        return;
      }
      instance.emitted[handlerName] = true;
      callWithAsyncErrorHandling(
        onceHandler,
        instance,
        6,
        args
      );
    }
  }
  const mixinEmitsCache = /* @__PURE__ */ new WeakMap();
  function normalizeEmitsOptions(comp, appContext, asMixin = false) {
    const cache = asMixin ? mixinEmitsCache : appContext.emitsCache;
    const cached = cache.get(comp);
    if (cached !== void 0) {
      return cached;
    }
    const raw = comp.emits;
    let normalized = {};
    let hasExtends = false;
    if (!isFunction(comp)) {
      const extendEmits = (raw2) => {
        const normalizedFromExtend = normalizeEmitsOptions(raw2, appContext, true);
        if (normalizedFromExtend) {
          hasExtends = true;
          extend(normalized, normalizedFromExtend);
        }
      };
      if (!asMixin && appContext.mixins.length) {
        appContext.mixins.forEach(extendEmits);
      }
      if (comp.extends) {
        extendEmits(comp.extends);
      }
      if (comp.mixins) {
        comp.mixins.forEach(extendEmits);
      }
    }
    if (!raw && !hasExtends) {
      if (isObject(comp)) {
        cache.set(comp, null);
      }
      return null;
    }
    if (isArray(raw)) {
      raw.forEach((key) => normalized[key] = null);
    } else {
      extend(normalized, raw);
    }
    if (isObject(comp)) {
      cache.set(comp, normalized);
    }
    return normalized;
  }
  function isEmitListener(options, key) {
    if (!options || !isOn(key)) {
      return false;
    }
    key = key.slice(2);
    key = key === "Once" ? key : key.replace(/Once$/, "");
    return hasOwn(options, key[0].toLowerCase() + key.slice(1)) || hasOwn(options, hyphenate(key)) || hasOwn(options, key);
  }
  function markAttrsAccessed() {
  }
  function renderComponentRoot(instance) {
    const {
      type: Component,
      vnode,
      proxy,
      withProxy,
      propsOptions: [propsOptions],
      slots,
      attrs,
      emit: emit2,
      render,
      renderCache,
      props,
      data,
      setupState,
      ctx,
      inheritAttrs
    } = instance;
    const prev = setCurrentRenderingInstance(instance);
    let result;
    let fallthroughAttrs;
    try {
      if (vnode.shapeFlag & 4) {
        const proxyToUse = withProxy || proxy;
        const thisProxy = false ? new Proxy(proxyToUse, {
          get(target, key, receiver) {
            warn$1(
              `Property '${String(
                key
              )}' was accessed via 'this'. Avoid using 'this' in templates.`
            );
            return Reflect.get(target, key, receiver);
          }
        }) : proxyToUse;
        result = normalizeVNode(
          render.call(
            thisProxy,
            proxyToUse,
            renderCache,
            false ? /* @__PURE__ */ shallowReadonly(props) : props,
            setupState,
            data,
            ctx
          )
        );
        fallthroughAttrs = attrs;
      } else {
        const render2 = Component;
        if (false) ;
        result = normalizeVNode(
          render2.length > 1 ? render2(
            false ? /* @__PURE__ */ shallowReadonly(props) : props,
            false ? {
              get attrs() {
                markAttrsAccessed();
                return /* @__PURE__ */ shallowReadonly(attrs);
              },
              slots,
              emit: emit2
            } : { attrs, slots, emit: emit2 }
          ) : render2(
            false ? /* @__PURE__ */ shallowReadonly(props) : props,
            null
          )
        );
        fallthroughAttrs = Component.props ? attrs : getFunctionalFallthrough(attrs);
      }
    } catch (err) {
      blockStack.length = 0;
      handleError(err, instance, 1);
      result = createVNode(Comment);
    }
    let root = result;
    if (fallthroughAttrs && inheritAttrs !== false) {
      const keys = Object.keys(fallthroughAttrs);
      const { shapeFlag } = root;
      if (keys.length) {
        if (shapeFlag & (1 | 6)) {
          if (propsOptions && keys.some(isModelListener)) {
            fallthroughAttrs = filterModelListeners(
              fallthroughAttrs,
              propsOptions
            );
          }
          root = cloneVNode(root, fallthroughAttrs, false, true);
        }
      }
    }
    if (vnode.dirs) {
      root = cloneVNode(root, null, false, true);
      root.dirs = root.dirs ? root.dirs.concat(vnode.dirs) : vnode.dirs;
    }
    if (vnode.transition) {
      const child = isTeleport(root.type) ? getInnerChild$1(root) || root : root;
      setTransitionHooks(child, vnode.transition);
    }
    {
      result = root;
    }
    setCurrentRenderingInstance(prev);
    return result;
  }
  const getFunctionalFallthrough = (attrs) => {
    let res;
    for (const key in attrs) {
      if (key === "class" || key === "style" || isOn(key)) {
        (res || (res = {}))[key] = attrs[key];
      }
    }
    return res;
  };
  const filterModelListeners = (attrs, props) => {
    const res = {};
    for (const key in attrs) {
      if (!isModelListener(key) || !(key.slice(9) in props)) {
        res[key] = attrs[key];
      }
    }
    return res;
  };
  function shouldUpdateComponent(prevVNode, nextVNode, optimized) {
    const { props: prevProps, children: prevChildren, component } = prevVNode;
    const { props: nextProps, children: nextChildren, patchFlag } = nextVNode;
    const emits = component.emitsOptions;
    if (nextVNode.dirs || nextVNode.transition) {
      return true;
    }
    if (optimized && patchFlag >= 0) {
      if (patchFlag & 1024) {
        return true;
      }
      if (patchFlag & 16) {
        if (!prevProps) {
          return !!nextProps;
        }
        return hasPropsChanged(prevProps, nextProps, emits);
      } else if (patchFlag & 8) {
        const dynamicProps = nextVNode.dynamicProps;
        for (let i = 0; i < dynamicProps.length; i++) {
          const key = dynamicProps[i];
          if (hasPropValueChanged(nextProps, prevProps, key) && !isEmitListener(emits, key)) {
            return true;
          }
        }
      }
    } else {
      if (prevChildren || nextChildren) {
        if (!nextChildren || !nextChildren.$stable) {
          return true;
        }
      }
      if (prevProps === nextProps) {
        return false;
      }
      if (!prevProps) {
        return !!nextProps;
      }
      if (!nextProps) {
        return true;
      }
      return hasPropsChanged(prevProps, nextProps, emits);
    }
    return false;
  }
  function hasPropsChanged(prevProps, nextProps, emitsOptions) {
    const nextKeys = Object.keys(nextProps);
    if (nextKeys.length !== Object.keys(prevProps).length) {
      return true;
    }
    for (let i = 0; i < nextKeys.length; i++) {
      const key = nextKeys[i];
      if (hasPropValueChanged(nextProps, prevProps, key) && !isEmitListener(emitsOptions, key)) {
        return true;
      }
    }
    return false;
  }
  function hasPropValueChanged(nextProps, prevProps, key) {
    const nextProp = nextProps[key];
    const prevProp = prevProps[key];
    if (key === "style" && isObject(nextProp) && isObject(prevProp)) {
      return !looseEqual(nextProp, prevProp);
    }
    return nextProp !== prevProp;
  }
  function updateHOCHostEl({ vnode, parent, suspense }, el) {
    while (parent) {
      const root = parent.subTree;
      if (root.suspense && root.suspense.activeBranch === vnode) {
        root.suspense.vnode.el = root.el = el;
        vnode = root;
      }
      if (root === vnode) {
        (vnode = parent.vnode).el = el;
        parent = parent.parent;
      } else {
        break;
      }
    }
    if (suspense && suspense.activeBranch === vnode) {
      suspense.vnode.el = el;
    }
  }
  const internalObjectProto = {};
  const createInternalObject = () => Object.create(internalObjectProto);
  const isInternalObject = (obj) => Object.getPrototypeOf(obj) === internalObjectProto;
  function initProps(instance, rawProps, isStateful, isSSR = false) {
    const props = {};
    const attrs = createInternalObject();
    instance.propsDefaults = /* @__PURE__ */ Object.create(null);
    setFullProps(instance, rawProps, props, attrs);
    for (const key in instance.propsOptions[0]) {
      if (!(key in props)) {
        props[key] = void 0;
      }
    }
    if (isStateful) {
      instance.props = isSSR ? props : /* @__PURE__ */ shallowReactive(props);
    } else {
      if (!instance.type.props) {
        instance.props = attrs;
      } else {
        instance.props = props;
      }
    }
    instance.attrs = attrs;
  }
  function updateProps(instance, rawProps, rawPrevProps, optimized) {
    const {
      props,
      attrs,
      vnode: { patchFlag }
    } = instance;
    const rawCurrentProps = /* @__PURE__ */ toRaw(props);
    const [options] = instance.propsOptions;
    let hasAttrsChanged = false;
    if (
      // always force full diff in dev
      // - #1942 if hmr is enabled with sfc component
      // - vite#872 non-sfc component used by sfc component
      (optimized || patchFlag > 0) && !(patchFlag & 16)
    ) {
      if (patchFlag & 8) {
        const propsToUpdate = instance.vnode.dynamicProps;
        for (let i = 0; i < propsToUpdate.length; i++) {
          let key = propsToUpdate[i];
          if (isEmitListener(instance.emitsOptions, key)) {
            continue;
          }
          const value = rawProps[key];
          if (options) {
            if (hasOwn(attrs, key)) {
              if (value !== attrs[key]) {
                attrs[key] = value;
                hasAttrsChanged = true;
              }
            } else {
              const camelizedKey = camelize(key);
              props[camelizedKey] = resolvePropValue(
                options,
                rawCurrentProps,
                camelizedKey,
                value,
                instance,
                false
              );
            }
          } else {
            if (value !== attrs[key]) {
              attrs[key] = value;
              hasAttrsChanged = true;
            }
          }
        }
      }
    } else {
      if (setFullProps(instance, rawProps, props, attrs)) {
        hasAttrsChanged = true;
      }
      let kebabKey;
      for (const key in rawCurrentProps) {
        if (!rawProps || // for camelCase
        !hasOwn(rawProps, key) && // it's possible the original props was passed in as kebab-case
        // and converted to camelCase (#955)
        ((kebabKey = hyphenate(key)) === key || !hasOwn(rawProps, kebabKey))) {
          if (options) {
            if (rawPrevProps && // for camelCase
            (rawPrevProps[key] !== void 0 || // for kebab-case
            rawPrevProps[kebabKey] !== void 0)) {
              props[key] = resolvePropValue(
                options,
                rawCurrentProps,
                key,
                void 0,
                instance,
                true
              );
            }
          } else {
            delete props[key];
          }
        }
      }
      if (attrs !== rawCurrentProps) {
        for (const key in attrs) {
          if (!rawProps || !hasOwn(rawProps, key) && true) {
            delete attrs[key];
            hasAttrsChanged = true;
          }
        }
      }
    }
    if (hasAttrsChanged) {
      trigger(instance.attrs, "set", "");
    }
  }
  function setFullProps(instance, rawProps, props, attrs) {
    const [options, needCastKeys] = instance.propsOptions;
    let hasAttrsChanged = false;
    let rawCastValues;
    if (rawProps) {
      for (let key in rawProps) {
        if (isReservedProp(key)) {
          continue;
        }
        const value = rawProps[key];
        let camelKey;
        if (options && hasOwn(options, camelKey = camelize(key))) {
          if (!needCastKeys || !needCastKeys.includes(camelKey)) {
            props[camelKey] = value;
          } else {
            (rawCastValues || (rawCastValues = {}))[camelKey] = value;
          }
        } else if (!isEmitListener(instance.emitsOptions, key)) {
          if (!(key in attrs) || value !== attrs[key]) {
            attrs[key] = value;
            hasAttrsChanged = true;
          }
        }
      }
    }
    if (needCastKeys) {
      const rawCurrentProps = /* @__PURE__ */ toRaw(props);
      const castValues = rawCastValues || EMPTY_OBJ;
      for (let i = 0; i < needCastKeys.length; i++) {
        const key = needCastKeys[i];
        props[key] = resolvePropValue(
          options,
          rawCurrentProps,
          key,
          castValues[key],
          instance,
          !hasOwn(castValues, key)
        );
      }
    }
    return hasAttrsChanged;
  }
  function resolvePropValue(options, props, key, value, instance, isAbsent) {
    const opt = options[key];
    if (opt != null) {
      const hasDefault = hasOwn(opt, "default");
      if (hasDefault && value === void 0) {
        const defaultValue = opt.default;
        if (opt.type !== Function && !opt.skipFactory && isFunction(defaultValue)) {
          const { propsDefaults } = instance;
          if (key in propsDefaults) {
            value = propsDefaults[key];
          } else {
            const reset = setCurrentInstance(instance);
            value = propsDefaults[key] = defaultValue.call(
              null,
              props
            );
            reset();
          }
        } else {
          value = defaultValue;
        }
        if (instance.ce) {
          instance.ce._setProp(key, value);
        }
      }
      if (opt[
        0
        /* shouldCast */
      ]) {
        if (isAbsent && !hasDefault) {
          value = false;
        } else if (opt[
          1
          /* shouldCastTrue */
        ] && (value === "" || value === hyphenate(key))) {
          value = true;
        }
      }
    }
    return value;
  }
  const mixinPropsCache = /* @__PURE__ */ new WeakMap();
  function normalizePropsOptions(comp, appContext, asMixin = false) {
    const cache = asMixin ? mixinPropsCache : appContext.propsCache;
    const cached = cache.get(comp);
    if (cached) {
      return cached;
    }
    const raw = comp.props;
    const normalized = {};
    const needCastKeys = [];
    let hasExtends = false;
    if (!isFunction(comp)) {
      const extendProps = (raw2) => {
        hasExtends = true;
        const [props, keys] = normalizePropsOptions(raw2, appContext, true);
        extend(normalized, props);
        if (keys) needCastKeys.push(...keys);
      };
      if (!asMixin && appContext.mixins.length) {
        appContext.mixins.forEach(extendProps);
      }
      if (comp.extends) {
        extendProps(comp.extends);
      }
      if (comp.mixins) {
        comp.mixins.forEach(extendProps);
      }
    }
    if (!raw && !hasExtends) {
      if (isObject(comp)) {
        cache.set(comp, EMPTY_ARR);
      }
      return EMPTY_ARR;
    }
    if (isArray(raw)) {
      for (let i = 0; i < raw.length; i++) {
        const normalizedKey = camelize(raw[i]);
        if (validatePropName(normalizedKey)) {
          normalized[normalizedKey] = EMPTY_OBJ;
        }
      }
    } else if (raw) {
      for (const key in raw) {
        const normalizedKey = camelize(key);
        if (validatePropName(normalizedKey)) {
          const opt = raw[key];
          const prop = normalized[normalizedKey] = isArray(opt) || isFunction(opt) ? { type: opt } : extend({}, opt);
          const propType = prop.type;
          let shouldCast = false;
          let shouldCastTrue = true;
          if (isArray(propType)) {
            for (let index = 0; index < propType.length; ++index) {
              const type = propType[index];
              const typeName = isFunction(type) && type.name;
              if (typeName === "Boolean") {
                shouldCast = true;
                break;
              } else if (typeName === "String") {
                shouldCastTrue = false;
              }
            }
          } else {
            shouldCast = isFunction(propType) && propType.name === "Boolean";
          }
          prop[
            0
            /* shouldCast */
          ] = shouldCast;
          prop[
            1
            /* shouldCastTrue */
          ] = shouldCastTrue;
          if (shouldCast || hasOwn(prop, "default")) {
            needCastKeys.push(normalizedKey);
          }
        }
      }
    }
    const res = [normalized, needCastKeys];
    if (isObject(comp)) {
      cache.set(comp, res);
    }
    return res;
  }
  function validatePropName(key) {
    if (key[0] !== "$" && !isReservedProp(key)) {
      return true;
    }
    return false;
  }
  const isInternalKey = (key) => key === "_" || key === "_ctx" || key === "$stable";
  const normalizeSlotValue = (value) => isArray(value) ? value.map(normalizeVNode) : [normalizeVNode(value)];
  const normalizeSlot = (key, rawSlot, ctx) => {
    if (rawSlot._n) {
      return rawSlot;
    }
    const normalized = withCtx((...args) => {
      if (false) ;
      return normalizeSlotValue(rawSlot(...args));
    }, ctx);
    normalized._c = false;
    return normalized;
  };
  const normalizeObjectSlots = (rawSlots, slots, instance) => {
    const ctx = rawSlots._ctx;
    for (const key in rawSlots) {
      if (isInternalKey(key)) continue;
      const value = rawSlots[key];
      if (isFunction(value)) {
        slots[key] = normalizeSlot(key, value, ctx);
      } else if (value != null) {
        const normalized = normalizeSlotValue(value);
        slots[key] = () => normalized;
      }
    }
  };
  const normalizeVNodeSlots = (instance, children) => {
    const normalized = normalizeSlotValue(children);
    instance.slots.default = () => normalized;
  };
  const assignSlots = (slots, children, optimized) => {
    for (const key in children) {
      if (optimized || !isInternalKey(key)) {
        slots[key] = children[key];
      }
    }
  };
  const initSlots = (instance, children, optimized) => {
    const slots = instance.slots = createInternalObject();
    if (instance.vnode.shapeFlag & 32) {
      const type = children._;
      if (type) {
        assignSlots(slots, children, optimized);
        if (optimized) {
          def(slots, "_", type, true);
        }
      } else {
        normalizeObjectSlots(children, slots);
      }
    } else if (children) {
      normalizeVNodeSlots(instance, children);
    }
  };
  const updateSlots = (instance, children, optimized) => {
    const { vnode, slots } = instance;
    let needDeletionCheck = true;
    let deletionComparisonTarget = EMPTY_OBJ;
    if (vnode.shapeFlag & 32) {
      const type = children._;
      if (type) {
        if (optimized && type === 1) {
          needDeletionCheck = false;
        } else {
          assignSlots(slots, children, optimized);
        }
      } else {
        needDeletionCheck = !children.$stable;
        normalizeObjectSlots(children, slots);
      }
      deletionComparisonTarget = children;
    } else if (children) {
      normalizeVNodeSlots(instance, children);
      deletionComparisonTarget = { default: 1 };
    }
    if (needDeletionCheck) {
      for (const key in slots) {
        if (!isInternalKey(key) && deletionComparisonTarget[key] == null) {
          delete slots[key];
        }
      }
    }
  };
  const queuePostRenderEffect = queueEffectWithSuspense;
  function createRenderer(options) {
    return baseCreateRenderer(options);
  }
  function baseCreateRenderer(options, createHydrationFns) {
    const target = getGlobalThis();
    target.__VUE__ = true;
    const {
      insert: hostInsert,
      remove: hostRemove,
      patchProp: hostPatchProp,
      createElement: hostCreateElement,
      createText: hostCreateText,
      createComment: hostCreateComment,
      setText: hostSetText,
      setElementText: hostSetElementText,
      parentNode: hostParentNode,
      nextSibling: hostNextSibling,
      setScopeId: hostSetScopeId = NOOP,
      insertStaticContent: hostInsertStaticContent
    } = options;
    const patch = (n1, n2, container, anchor = null, parentComponent = null, parentSuspense = null, namespace = void 0, slotScopeIds = null, optimized = !!n2.dynamicChildren) => {
      if (n1 === n2) {
        return;
      }
      if (n1 && !isSameVNodeType(n1, n2)) {
        anchor = getNextHostNode(n1);
        unmount(n1, parentComponent, parentSuspense, true);
        n1 = null;
      }
      if (n2.patchFlag === -2) {
        optimized = false;
        n2.dynamicChildren = null;
      }
      if (n2.dynamicChildren && n1 && n1.dynamicChildren && n1.dynamicChildren.hasOnce) {
        if (n2.dynamicChildren === EMPTY_ARR) {
          n2.dynamicChildren = [];
        }
        n2.dynamicChildren.hasOnce = true;
      }
      const { type, ref: ref3, shapeFlag } = n2;
      switch (type) {
        case Text:
          processText(n1, n2, container, anchor);
          break;
        case Comment:
          processCommentNode(n1, n2, container, anchor);
          break;
        case Static:
          if (n1 == null) {
            mountStaticNode(n2, container, anchor, namespace);
          }
          break;
        case Fragment:
          processFragment(
            n1,
            n2,
            container,
            anchor,
            parentComponent,
            parentSuspense,
            namespace,
            slotScopeIds,
            optimized
          );
          break;
        default:
          if (shapeFlag & 1) {
            processElement(
              n1,
              n2,
              container,
              anchor,
              parentComponent,
              parentSuspense,
              namespace,
              slotScopeIds,
              optimized
            );
          } else if (shapeFlag & 6) {
            processComponent(
              n1,
              n2,
              container,
              anchor,
              parentComponent,
              parentSuspense,
              namespace,
              slotScopeIds,
              optimized
            );
          } else if (shapeFlag & 64) {
            type.process(
              n1,
              n2,
              container,
              anchor,
              parentComponent,
              parentSuspense,
              namespace,
              slotScopeIds,
              optimized,
              internals
            );
          } else if (shapeFlag & 128) {
            type.process(
              n1,
              n2,
              container,
              anchor,
              parentComponent,
              parentSuspense,
              namespace,
              slotScopeIds,
              optimized,
              internals
            );
          } else ;
      }
      if (ref3 != null && parentComponent) {
        setRef(ref3, n1 && n1.ref, parentSuspense, n2 || n1, !n2);
      } else if (ref3 == null && n1 && n1.ref != null) {
        setRef(n1.ref, null, parentSuspense, n1, true);
      }
    };
    const processText = (n1, n2, container, anchor) => {
      if (n1 == null) {
        hostInsert(
          n2.el = hostCreateText(n2.children),
          container,
          anchor
        );
      } else {
        const el = n2.el = n1.el;
        if (n2.children !== n1.children) {
          hostSetText(el, n2.children);
        }
      }
    };
    const processCommentNode = (n1, n2, container, anchor) => {
      if (n1 == null) {
        hostInsert(
          n2.el = hostCreateComment(n2.children || ""),
          container,
          anchor
        );
      } else {
        n2.el = n1.el;
      }
    };
    const mountStaticNode = (n2, container, anchor, namespace) => {
      [n2.el, n2.anchor] = hostInsertStaticContent(
        n2.children,
        container,
        anchor,
        namespace,
        n2.el,
        n2.anchor
      );
    };
    const moveStaticNode = ({ el, anchor }, container, nextSibling) => {
      let next;
      while (el && el !== anchor) {
        next = hostNextSibling(el);
        hostInsert(el, container, nextSibling);
        el = next;
      }
      hostInsert(anchor, container, nextSibling);
    };
    const removeStaticNode = ({ el, anchor }) => {
      let next;
      while (el && el !== anchor) {
        next = hostNextSibling(el);
        hostRemove(el);
        el = next;
      }
      hostRemove(anchor);
    };
    const processElement = (n1, n2, container, anchor, parentComponent, parentSuspense, namespace, slotScopeIds, optimized) => {
      if (n2.type === "svg") {
        namespace = "svg";
      } else if (n2.type === "math") {
        namespace = "mathml";
      }
      if (n1 == null) {
        mountElement(
          n2,
          container,
          anchor,
          parentComponent,
          parentSuspense,
          namespace,
          slotScopeIds,
          optimized
        );
      } else {
        const customElement = n1.el && n1.el._isVueCE ? n1.el : null;
        try {
          if (customElement) {
            customElement._beginPatch();
          }
          patchElement(
            n1,
            n2,
            parentComponent,
            parentSuspense,
            namespace,
            slotScopeIds,
            optimized
          );
        } finally {
          if (customElement) {
            customElement._endPatch();
          }
        }
      }
    };
    const mountElement = (vnode, container, anchor, parentComponent, parentSuspense, namespace, slotScopeIds, optimized) => {
      let el;
      let vnodeHook;
      const { props, shapeFlag, transition, dirs } = vnode;
      el = vnode.el = hostCreateElement(
        vnode.type,
        namespace,
        props && props.is,
        props
      );
      if (shapeFlag & 8) {
        hostSetElementText(el, vnode.children);
      } else if (shapeFlag & 16) {
        mountChildren(
          vnode.children,
          el,
          null,
          parentComponent,
          parentSuspense,
          resolveChildrenNamespace(vnode, namespace),
          slotScopeIds,
          optimized
        );
      }
      if (dirs) {
        invokeDirectiveHook(vnode, null, parentComponent, "created");
      }
      setScopeId(el, vnode, vnode.scopeId, slotScopeIds, parentComponent);
      if (props) {
        for (const key in props) {
          if (key !== "value" && !isReservedProp(key)) {
            hostPatchProp(el, key, null, props[key], namespace, parentComponent);
          }
        }
        if ("value" in props) {
          hostPatchProp(el, "value", null, props.value, namespace);
        }
        if (vnodeHook = props.onVnodeBeforeMount) {
          invokeVNodeHook(vnodeHook, parentComponent, vnode);
        }
      }
      if (dirs) {
        invokeDirectiveHook(vnode, null, parentComponent, "beforeMount");
      }
      const needCallTransitionHooks = needTransition(parentSuspense, transition);
      if (needCallTransitionHooks) {
        transition.beforeEnter(el);
      }
      hostInsert(el, container, anchor);
      if ((vnodeHook = props && props.onVnodeMounted) || needCallTransitionHooks || dirs) {
        queuePostRenderEffect(() => {
          try {
            vnodeHook && invokeVNodeHook(vnodeHook, parentComponent, vnode);
            needCallTransitionHooks && transition.enter(el);
            dirs && invokeDirectiveHook(vnode, null, parentComponent, "mounted");
          } finally {
          }
        }, parentSuspense);
      }
    };
    const setScopeId = (el, vnode, scopeId, slotScopeIds, parentComponent) => {
      if (scopeId) {
        hostSetScopeId(el, scopeId);
      }
      if (slotScopeIds) {
        for (let i = 0; i < slotScopeIds.length; i++) {
          hostSetScopeId(el, slotScopeIds[i]);
        }
      }
      if (parentComponent) {
        let subTree = parentComponent.subTree;
        if (vnode === subTree || isSuspense(subTree.type) && (subTree.ssContent === vnode || subTree.ssFallback === vnode)) {
          const parentVNode = parentComponent.vnode;
          setScopeId(
            el,
            parentVNode,
            parentVNode.scopeId,
            parentVNode.slotScopeIds,
            parentComponent.parent
          );
        }
      }
    };
    const mountChildren = (children, container, anchor, parentComponent, parentSuspense, namespace, slotScopeIds, optimized, start = 0) => {
      for (let i = start; i < children.length; i++) {
        const child = children[i] = optimized ? cloneIfMounted(children[i]) : normalizeVNode(children[i]);
        patch(
          null,
          child,
          container,
          anchor,
          parentComponent,
          parentSuspense,
          namespace,
          slotScopeIds,
          optimized
        );
      }
    };
    const patchElement = (n1, n2, parentComponent, parentSuspense, namespace, slotScopeIds, optimized) => {
      const el = n2.el = n1.el;
      let { patchFlag, dynamicChildren, dirs } = n2;
      patchFlag |= n1.patchFlag & 16;
      const oldProps = n1.props || EMPTY_OBJ;
      const newProps = n2.props || EMPTY_OBJ;
      let vnodeHook;
      parentComponent && toggleRecurse(parentComponent, false);
      if (vnodeHook = newProps.onVnodeBeforeUpdate) {
        invokeVNodeHook(vnodeHook, parentComponent, n2, n1);
      }
      if (dirs) {
        invokeDirectiveHook(n2, n1, parentComponent, "beforeUpdate");
      }
      parentComponent && toggleRecurse(parentComponent, true);
      if (
        // #6385 the old vnode may be a user-wrapped non-isomorphic block
        // Force full diff when block metadata is unstable.
        dynamicChildren && (!n1.dynamicChildren || n1.dynamicChildren.length !== dynamicChildren.length)
      ) {
        patchFlag = 0;
        optimized = false;
        dynamicChildren = null;
      }
      if (oldProps.innerHTML && newProps.innerHTML == null || oldProps.textContent && newProps.textContent == null) {
        hostSetElementText(el, "");
      }
      if (dynamicChildren) {
        patchBlockChildren(
          n1.dynamicChildren,
          dynamicChildren,
          el,
          parentComponent,
          parentSuspense,
          resolveChildrenNamespace(n2, namespace),
          slotScopeIds
        );
      } else if (!optimized) {
        patchChildren(
          n1,
          n2,
          el,
          null,
          parentComponent,
          parentSuspense,
          resolveChildrenNamespace(n2, namespace),
          slotScopeIds,
          false
        );
      }
      if (patchFlag > 0) {
        if (patchFlag & 16) {
          patchProps(el, oldProps, newProps, parentComponent, namespace);
        } else {
          if (patchFlag & 2) {
            if (oldProps.class !== newProps.class) {
              hostPatchProp(el, "class", null, newProps.class, namespace);
            }
          }
          if (patchFlag & 4) {
            hostPatchProp(el, "style", oldProps.style, newProps.style, namespace);
          }
          if (patchFlag & 8) {
            const propsToUpdate = n2.dynamicProps;
            for (let i = 0; i < propsToUpdate.length; i++) {
              const key = propsToUpdate[i];
              const prev = oldProps[key];
              const next = newProps[key];
              if (next !== prev || key === "value") {
                hostPatchProp(el, key, prev, next, namespace, parentComponent);
              }
            }
          }
        }
        if (patchFlag & 1) {
          if (n1.children !== n2.children) {
            hostSetElementText(el, n2.children);
          }
        }
      } else if (!optimized && dynamicChildren == null) {
        patchProps(el, oldProps, newProps, parentComponent, namespace);
      }
      if ((vnodeHook = newProps.onVnodeUpdated) || dirs) {
        queuePostRenderEffect(() => {
          vnodeHook && invokeVNodeHook(vnodeHook, parentComponent, n2, n1);
          dirs && invokeDirectiveHook(n2, n1, parentComponent, "updated");
        }, parentSuspense);
      }
    };
    const patchBlockChildren = (oldChildren, newChildren, fallbackContainer, parentComponent, parentSuspense, namespace, slotScopeIds) => {
      for (let i = 0; i < newChildren.length; i++) {
        const oldVNode = oldChildren[i];
        const newVNode = newChildren[i];
        const container = (
          // oldVNode may be an errored async setup() component inside Suspense
          // which will not have a mounted element
          oldVNode.el && // - In the case of a Fragment, we need to provide the actual parent
          // of the Fragment itself so it can move its children.
          (oldVNode.type === Fragment || // - In the case of different nodes, there is going to be a replacement
          // which also requires the correct parent container
          !isSameVNodeType(oldVNode, newVNode) || // - In the case of a component, it could contain anything.
          oldVNode.shapeFlag & (6 | 64 | 128)) ? hostParentNode(oldVNode.el) : (
            // In other cases, the parent container is not actually used so we
            // just pass the block element here to avoid a DOM parentNode call.
            fallbackContainer
          )
        );
        patch(
          oldVNode,
          newVNode,
          container,
          null,
          parentComponent,
          parentSuspense,
          namespace,
          slotScopeIds,
          true
        );
      }
    };
    const patchProps = (el, oldProps, newProps, parentComponent, namespace) => {
      if (oldProps !== newProps) {
        if (oldProps !== EMPTY_OBJ) {
          for (const key in oldProps) {
            if (!isReservedProp(key) && !(key in newProps)) {
              hostPatchProp(
                el,
                key,
                oldProps[key],
                null,
                namespace,
                parentComponent
              );
            }
          }
        }
        for (const key in newProps) {
          if (isReservedProp(key)) continue;
          const next = newProps[key];
          const prev = oldProps[key];
          if (next !== prev && key !== "value") {
            hostPatchProp(el, key, prev, next, namespace, parentComponent);
          }
        }
        if ("value" in newProps) {
          hostPatchProp(el, "value", oldProps.value, newProps.value, namespace);
        }
      }
    };
    const processFragment = (n1, n2, container, anchor, parentComponent, parentSuspense, namespace, slotScopeIds, optimized) => {
      const fragmentStartAnchor = n2.el = n1 ? n1.el : hostCreateText("");
      const fragmentEndAnchor = n2.anchor = n1 ? n1.anchor : hostCreateText("");
      let { patchFlag, dynamicChildren, slotScopeIds: fragmentSlotScopeIds } = n2;
      if (fragmentSlotScopeIds) {
        slotScopeIds = slotScopeIds ? slotScopeIds.concat(fragmentSlotScopeIds) : fragmentSlotScopeIds;
      }
      if (n1 == null) {
        hostInsert(fragmentStartAnchor, container, anchor);
        hostInsert(fragmentEndAnchor, container, anchor);
        mountChildren(
          // #10007
          // such fragment like `<></>` will be compiled into
          // a fragment which doesn't have a children.
          // In this case fallback to an empty array
          n2.children || [],
          container,
          fragmentEndAnchor,
          parentComponent,
          parentSuspense,
          namespace,
          slotScopeIds,
          optimized
        );
      } else {
        if (patchFlag > 0 && patchFlag & 64 && dynamicChildren && // #2715 the previous fragment could've been a BAILed one as a result
        // of renderSlot() with no valid children
        n1.dynamicChildren && n1.dynamicChildren.length === dynamicChildren.length) {
          patchBlockChildren(
            n1.dynamicChildren,
            dynamicChildren,
            container,
            parentComponent,
            parentSuspense,
            namespace,
            slotScopeIds
          );
          if (
            // #2080 if the stable fragment has a key, it's a <template v-for> that may
            //  get moved around. Make sure all root level vnodes inherit el.
            // #2134 or if it's a component root, it may also get moved around
            // as the component is being moved.
            n2.key != null || parentComponent && n2 === parentComponent.subTree
          ) {
            traverseStaticChildren(
              n1,
              n2,
              true
              /* shallow */
            );
          }
        } else {
          patchChildren(
            n1,
            n2,
            container,
            fragmentEndAnchor,
            parentComponent,
            parentSuspense,
            namespace,
            slotScopeIds,
            optimized
          );
        }
      }
    };
    const processComponent = (n1, n2, container, anchor, parentComponent, parentSuspense, namespace, slotScopeIds, optimized) => {
      n2.slotScopeIds = slotScopeIds;
      if (n1 == null) {
        if (n2.shapeFlag & 512) {
          parentComponent.ctx.activate(
            n2,
            container,
            anchor,
            namespace,
            optimized
          );
        } else {
          mountComponent(
            n2,
            container,
            anchor,
            parentComponent,
            parentSuspense,
            namespace,
            optimized
          );
        }
      } else {
        updateComponent(n1, n2, optimized);
      }
    };
    const mountComponent = (initialVNode, container, anchor, parentComponent, parentSuspense, namespace, optimized) => {
      const instance = initialVNode.component = createComponentInstance(
        initialVNode,
        parentComponent,
        parentSuspense
      );
      if (isKeepAlive(initialVNode)) {
        instance.ctx.renderer = internals;
      }
      {
        setupComponent(instance, false, optimized);
      }
      if (instance.asyncDep) {
        parentSuspense && parentSuspense.registerDep(instance, setupRenderEffect, optimized);
        if (!initialVNode.el) {
          const placeholder = instance.subTree = createVNode(Comment);
          processCommentNode(null, placeholder, container, anchor);
          initialVNode.placeholder = placeholder.el;
        }
      } else {
        setupRenderEffect(
          instance,
          initialVNode,
          container,
          anchor,
          parentSuspense,
          namespace,
          optimized
        );
      }
    };
    const updateComponent = (n1, n2, optimized) => {
      const instance = n2.component = n1.component;
      if (shouldUpdateComponent(n1, n2, optimized)) {
        if (instance.asyncDep && !instance.asyncResolved) {
          n2.el = n1.el;
          updateComponentPreRender(instance, n2, optimized);
          return;
        } else {
          instance.next = n2;
          instance.update();
        }
      } else {
        n2.el = n1.el;
        instance.vnode = n2;
      }
    };
    const setupRenderEffect = (instance, initialVNode, container, anchor, parentSuspense, namespace, optimized) => {
      const componentUpdateFn = () => {
        if (!instance.isMounted) {
          let vnodeHook;
          const { el, props } = initialVNode;
          const { bm, m, parent, root, type } = instance;
          const isAsyncWrapperVNode = isAsyncWrapper(initialVNode);
          toggleRecurse(instance, false);
          if (bm) {
            invokeArrayFns(bm);
          }
          if (!isAsyncWrapperVNode && (vnodeHook = props && props.onVnodeBeforeMount)) {
            invokeVNodeHook(vnodeHook, parent, initialVNode);
          }
          toggleRecurse(instance, true);
          {
            if (root.ce && root.ce._hasShadowRoot()) {
              root.ce._injectChildStyle(
                type,
                instance.parent ? instance.parent.type : void 0
              );
            }
            const subTree = instance.subTree = renderComponentRoot(instance);
            patch(
              null,
              subTree,
              container,
              anchor,
              instance,
              parentSuspense,
              namespace
            );
            initialVNode.el = subTree.el;
          }
          if (m) {
            queuePostRenderEffect(m, parentSuspense);
          }
          if (!isAsyncWrapperVNode && (vnodeHook = props && props.onVnodeMounted)) {
            const scopedInitialVNode = initialVNode;
            queuePostRenderEffect(
              () => invokeVNodeHook(vnodeHook, parent, scopedInitialVNode),
              parentSuspense
            );
          }
          if (initialVNode.shapeFlag & 256 || parent && isAsyncWrapper(parent.vnode) && parent.vnode.shapeFlag & 256) {
            instance.a && queuePostRenderEffect(instance.a, parentSuspense);
          }
          instance.isMounted = true;
          initialVNode = container = anchor = null;
        } else {
          let { next, bu, u, parent, vnode } = instance;
          {
            const nonHydratedAsyncRoot = locateNonHydratedAsyncRoot(instance);
            if (nonHydratedAsyncRoot) {
              if (next) {
                next.el = vnode.el;
                updateComponentPreRender(instance, next, optimized);
              }
              nonHydratedAsyncRoot.asyncDep.then(() => {
                queuePostRenderEffect(() => {
                  if (!instance.isUnmounted) update();
                }, parentSuspense);
              });
              return;
            }
          }
          let originNext = next;
          let vnodeHook;
          toggleRecurse(instance, false);
          if (next) {
            next.el = vnode.el;
            updateComponentPreRender(instance, next, optimized);
          } else {
            next = vnode;
          }
          if (bu) {
            invokeArrayFns(bu);
          }
          if (vnodeHook = next.props && next.props.onVnodeBeforeUpdate) {
            invokeVNodeHook(vnodeHook, parent, next, vnode);
          }
          toggleRecurse(instance, true);
          const nextTree = renderComponentRoot(instance);
          const prevTree = instance.subTree;
          instance.subTree = nextTree;
          patch(
            prevTree,
            nextTree,
            // parent may have changed if it's in a teleport
            hostParentNode(prevTree.el),
            // anchor may have changed if it's in a fragment
            getNextHostNode(prevTree),
            instance,
            parentSuspense,
            namespace
          );
          next.el = nextTree.el;
          if (originNext === null) {
            updateHOCHostEl(instance, nextTree.el);
          }
          if (u) {
            queuePostRenderEffect(u, parentSuspense);
          }
          if (vnodeHook = next.props && next.props.onVnodeUpdated) {
            queuePostRenderEffect(
              () => invokeVNodeHook(vnodeHook, parent, next, vnode),
              parentSuspense
            );
          }
        }
      };
      instance.scope.on();
      const effect2 = instance.effect = new ReactiveEffect(componentUpdateFn);
      instance.scope.off();
      const update = instance.update = effect2.run.bind(effect2);
      const job = instance.job = effect2.runIfDirty.bind(effect2);
      job.i = instance;
      job.id = instance.uid;
      effect2.scheduler = () => queueJob(job);
      toggleRecurse(instance, true);
      update();
    };
    const updateComponentPreRender = (instance, nextVNode, optimized) => {
      nextVNode.component = instance;
      const prevProps = instance.vnode.props;
      instance.vnode = nextVNode;
      instance.next = null;
      updateProps(instance, nextVNode.props, prevProps, optimized);
      updateSlots(instance, nextVNode.children, optimized);
      pauseTracking();
      flushPreFlushCbs(instance);
      resetTracking();
    };
    const patchChildren = (n1, n2, container, anchor, parentComponent, parentSuspense, namespace, slotScopeIds, optimized = false) => {
      const c1 = n1 && n1.children;
      const prevShapeFlag = n1 ? n1.shapeFlag : 0;
      const c2 = n2.children;
      const { patchFlag, shapeFlag } = n2;
      if (patchFlag > 0) {
        if (patchFlag & 128) {
          patchKeyedChildren(
            c1,
            c2,
            container,
            anchor,
            parentComponent,
            parentSuspense,
            namespace,
            slotScopeIds,
            optimized
          );
          return;
        } else if (patchFlag & 256) {
          patchUnkeyedChildren(
            c1,
            c2,
            container,
            anchor,
            parentComponent,
            parentSuspense,
            namespace,
            slotScopeIds,
            optimized
          );
          return;
        }
      }
      if (shapeFlag & 8) {
        if (prevShapeFlag & 16) {
          unmountChildren(c1, parentComponent, parentSuspense);
        }
        if (c2 !== c1) {
          hostSetElementText(container, c2);
        }
      } else {
        if (prevShapeFlag & 16) {
          if (shapeFlag & 16) {
            patchKeyedChildren(
              c1,
              c2,
              container,
              anchor,
              parentComponent,
              parentSuspense,
              namespace,
              slotScopeIds,
              optimized
            );
          } else {
            unmountChildren(c1, parentComponent, parentSuspense, true);
          }
        } else {
          if (prevShapeFlag & 8) {
            hostSetElementText(container, "");
          }
          if (shapeFlag & 16) {
            mountChildren(
              c2,
              container,
              anchor,
              parentComponent,
              parentSuspense,
              namespace,
              slotScopeIds,
              optimized
            );
          }
        }
      }
    };
    const patchUnkeyedChildren = (c1, c2, container, anchor, parentComponent, parentSuspense, namespace, slotScopeIds, optimized) => {
      c1 = c1 || EMPTY_ARR;
      c2 = c2 || EMPTY_ARR;
      const oldLength = c1.length;
      const newLength = c2.length;
      const commonLength = Math.min(oldLength, newLength);
      let i;
      for (i = 0; i < commonLength; i++) {
        const nextChild = c2[i] = optimized ? cloneIfMounted(c2[i]) : normalizeVNode(c2[i]);
        patch(
          c1[i],
          nextChild,
          container,
          null,
          parentComponent,
          parentSuspense,
          namespace,
          slotScopeIds,
          optimized
        );
      }
      if (oldLength > newLength) {
        unmountChildren(
          c1,
          parentComponent,
          parentSuspense,
          true,
          false,
          commonLength
        );
      } else {
        mountChildren(
          c2,
          container,
          anchor,
          parentComponent,
          parentSuspense,
          namespace,
          slotScopeIds,
          optimized,
          commonLength
        );
      }
    };
    const patchKeyedChildren = (c1, c2, container, parentAnchor, parentComponent, parentSuspense, namespace, slotScopeIds, optimized) => {
      let i = 0;
      const l2 = c2.length;
      let e1 = c1.length - 1;
      let e2 = l2 - 1;
      while (i <= e1 && i <= e2) {
        const n1 = c1[i];
        const n2 = c2[i] = optimized ? cloneIfMounted(c2[i]) : normalizeVNode(c2[i]);
        if (isSameVNodeType(n1, n2)) {
          patch(
            n1,
            n2,
            container,
            null,
            parentComponent,
            parentSuspense,
            namespace,
            slotScopeIds,
            optimized
          );
        } else {
          break;
        }
        i++;
      }
      while (i <= e1 && i <= e2) {
        const n1 = c1[e1];
        const n2 = c2[e2] = optimized ? cloneIfMounted(c2[e2]) : normalizeVNode(c2[e2]);
        if (isSameVNodeType(n1, n2)) {
          patch(
            n1,
            n2,
            container,
            null,
            parentComponent,
            parentSuspense,
            namespace,
            slotScopeIds,
            optimized
          );
        } else {
          break;
        }
        e1--;
        e2--;
      }
      if (i > e1) {
        if (i <= e2) {
          const nextPos = e2 + 1;
          const anchor = nextPos < l2 ? c2[nextPos].el : parentAnchor;
          while (i <= e2) {
            patch(
              null,
              c2[i] = optimized ? cloneIfMounted(c2[i]) : normalizeVNode(c2[i]),
              container,
              anchor,
              parentComponent,
              parentSuspense,
              namespace,
              slotScopeIds,
              optimized
            );
            i++;
          }
        }
      } else if (i > e2) {
        while (i <= e1) {
          unmount(c1[i], parentComponent, parentSuspense, true);
          i++;
        }
      } else {
        const s1 = i;
        const s2 = i;
        const keyToNewIndexMap = /* @__PURE__ */ new Map();
        for (i = s2; i <= e2; i++) {
          const nextChild = c2[i] = optimized ? cloneIfMounted(c2[i]) : normalizeVNode(c2[i]);
          if (nextChild.key != null) {
            keyToNewIndexMap.set(nextChild.key, i);
          }
        }
        let j;
        let patched = 0;
        const toBePatched = e2 - s2 + 1;
        let moved = false;
        let maxNewIndexSoFar = 0;
        const newIndexToOldIndexMap = new Array(toBePatched);
        for (i = 0; i < toBePatched; i++) newIndexToOldIndexMap[i] = 0;
        for (i = s1; i <= e1; i++) {
          const prevChild = c1[i];
          if (patched >= toBePatched) {
            unmount(prevChild, parentComponent, parentSuspense, true);
            continue;
          }
          let newIndex;
          if (prevChild.key != null) {
            newIndex = keyToNewIndexMap.get(prevChild.key);
          } else {
            for (j = s2; j <= e2; j++) {
              if (newIndexToOldIndexMap[j - s2] === 0 && isSameVNodeType(prevChild, c2[j])) {
                newIndex = j;
                break;
              }
            }
          }
          if (newIndex === void 0) {
            unmount(prevChild, parentComponent, parentSuspense, true);
          } else {
            newIndexToOldIndexMap[newIndex - s2] = i + 1;
            if (newIndex >= maxNewIndexSoFar) {
              maxNewIndexSoFar = newIndex;
            } else {
              moved = true;
            }
            patch(
              prevChild,
              c2[newIndex],
              container,
              null,
              parentComponent,
              parentSuspense,
              namespace,
              slotScopeIds,
              optimized
            );
            patched++;
          }
        }
        const increasingNewIndexSequence = moved ? getSequence(newIndexToOldIndexMap) : EMPTY_ARR;
        j = increasingNewIndexSequence.length - 1;
        for (i = toBePatched - 1; i >= 0; i--) {
          const nextIndex = s2 + i;
          const nextChild = c2[nextIndex];
          const anchorVNode = c2[nextIndex + 1];
          const anchor = nextIndex + 1 < l2 ? (
            // #13559, #14173 fallback to el placeholder for unresolved async component
            anchorVNode.el || resolveAsyncComponentPlaceholder(anchorVNode)
          ) : parentAnchor;
          if (newIndexToOldIndexMap[i] === 0) {
            patch(
              null,
              nextChild,
              container,
              anchor,
              parentComponent,
              parentSuspense,
              namespace,
              slotScopeIds,
              optimized
            );
          } else if (moved) {
            if (j < 0 || i !== increasingNewIndexSequence[j]) {
              move(nextChild, container, anchor, 2);
            } else {
              j--;
            }
          }
        }
      }
    };
    const move = (vnode, container, anchor, moveType, parentSuspense = null) => {
      const { el, type, transition, children, shapeFlag } = vnode;
      if (shapeFlag & 6) {
        move(vnode.component.subTree, container, anchor, moveType);
        return;
      }
      if (shapeFlag & 128) {
        vnode.suspense.move(container, anchor, moveType);
        return;
      }
      if (shapeFlag & 64) {
        type.move(vnode, container, anchor, internals);
        return;
      }
      if (type === Fragment) {
        hostInsert(el, container, anchor);
        for (let i = 0; i < children.length; i++) {
          move(children[i], container, anchor, moveType);
        }
        hostInsert(vnode.anchor, container, anchor);
        return;
      }
      if (type === Static) {
        moveStaticNode(vnode, container, anchor);
        return;
      }
      const needTransition2 = moveType !== 2 && shapeFlag & 1 && transition;
      if (needTransition2) {
        if (moveType === 0) {
          if (transition.persisted && !el[leaveCbKey]) {
            hostInsert(el, container, anchor);
          } else {
            transition.beforeEnter(el);
            hostInsert(el, container, anchor);
            queuePostRenderEffect(() => transition.enter(el), parentSuspense);
          }
        } else {
          const { leave, delayLeave, afterLeave } = transition;
          const remove22 = () => {
            if (vnode.ctx.isUnmounted) {
              hostRemove(el);
            } else {
              hostInsert(el, container, anchor);
            }
          };
          const performLeave = () => {
            const wasLeaving = el._isLeaving || !!el[leaveCbKey];
            if (el._isLeaving) {
              el[leaveCbKey](
                true
                /* cancelled */
              );
            }
            if (transition.persisted && !wasLeaving) {
              remove22();
            } else {
              leave(el, () => {
                remove22();
                afterLeave && afterLeave();
              });
            }
          };
          if (delayLeave) {
            delayLeave(el, remove22, performLeave);
          } else {
            performLeave();
          }
        }
      } else {
        hostInsert(el, container, anchor);
      }
    };
    const unmount = (vnode, parentComponent, parentSuspense, doRemove = false, optimized = false) => {
      const {
        type,
        props,
        ref: ref3,
        children,
        dynamicChildren,
        shapeFlag,
        patchFlag,
        dirs,
        cacheIndex,
        memo
      } = vnode;
      if (patchFlag === -2 || dynamicChildren && dynamicChildren.hasOnce) {
        optimized = false;
      }
      if (ref3 != null) {
        pauseTracking();
        setRef(ref3, null, parentSuspense, vnode, true);
        resetTracking();
      }
      if (cacheIndex != null && (!vnode.ctx || vnode.ctx === parentComponent)) {
        parentComponent.renderCache[cacheIndex] = void 0;
      }
      if (shapeFlag & 256) {
        parentComponent.ctx.deactivate(vnode);
        return;
      }
      const shouldInvokeDirs = shapeFlag & 1 && dirs;
      const shouldInvokeVnodeHook = !isAsyncWrapper(vnode);
      let vnodeHook;
      if (shouldInvokeVnodeHook && (vnodeHook = props && props.onVnodeBeforeUnmount)) {
        invokeVNodeHook(vnodeHook, parentComponent, vnode);
      }
      if (shapeFlag & 6) {
        unmountComponent(vnode.component, parentSuspense, doRemove);
      } else {
        if (shapeFlag & 128) {
          vnode.suspense.unmount(parentSuspense, doRemove);
          return;
        }
        if (shouldInvokeDirs) {
          invokeDirectiveHook(vnode, null, parentComponent, "beforeUnmount");
        }
        if (shapeFlag & 64) {
          vnode.type.remove(
            vnode,
            parentComponent,
            parentSuspense,
            internals,
            doRemove
          );
        } else if (dynamicChildren && // #5154
        // when v-once is used inside a block, setBlockTracking(-1) marks the
        // parent block with hasOnce: true
        // so that it doesn't take the fast path during unmount - otherwise
        // components nested in v-once are never unmounted.
        !dynamicChildren.hasOnce && // #1153: fast path should not be taken for non-stable (v-for) fragments
        (type !== Fragment || patchFlag > 0 && patchFlag & 64)) {
          unmountChildren(
            dynamicChildren,
            parentComponent,
            parentSuspense,
            false,
            true
          );
        } else if (type === Fragment && patchFlag & (128 | 256) || !optimized && shapeFlag & 16) {
          unmountChildren(children, parentComponent, parentSuspense);
        }
        if (doRemove) {
          remove2(vnode);
        }
      }
      const shouldInvalidateMemo = memo != null && cacheIndex == null;
      if (shouldInvokeVnodeHook && (vnodeHook = props && props.onVnodeUnmounted) || shouldInvokeDirs || shouldInvalidateMemo) {
        queuePostRenderEffect(() => {
          vnodeHook && invokeVNodeHook(vnodeHook, parentComponent, vnode);
          shouldInvokeDirs && invokeDirectiveHook(vnode, null, parentComponent, "unmounted");
          if (shouldInvalidateMemo) {
            vnode.el = null;
          }
        }, parentSuspense);
      }
    };
    const remove2 = (vnode) => {
      const { type, el, anchor, transition } = vnode;
      if (type === Fragment) {
        {
          removeFragment(el, anchor);
        }
        return;
      }
      if (type === Static) {
        removeStaticNode(vnode);
        if (transition && !transition.persisted && transition.afterLeave) {
          transition.afterLeave();
        }
        return;
      }
      const performRemove = () => {
        hostRemove(el);
        if (transition && !transition.persisted && transition.afterLeave) {
          transition.afterLeave();
        }
      };
      if (vnode.shapeFlag & 1 && transition && !transition.persisted) {
        const { leave, delayLeave } = transition;
        const performLeave = () => leave(el, performRemove);
        if (delayLeave) {
          delayLeave(vnode.el, performRemove, performLeave);
        } else {
          performLeave();
        }
      } else {
        performRemove();
      }
    };
    const removeFragment = (cur, end) => {
      let next;
      while (cur !== end) {
        next = hostNextSibling(cur);
        hostRemove(cur);
        cur = next;
      }
      hostRemove(end);
    };
    const unmountComponent = (instance, parentSuspense, doRemove) => {
      const { bum, scope, job, subTree, um, m, a } = instance;
      invalidateMount(m);
      invalidateMount(a);
      if (bum) {
        invokeArrayFns(bum);
      }
      scope.stop();
      if (job) {
        job.flags |= 8;
        unmount(subTree, instance, parentSuspense, doRemove);
      } else if (instance.vnode.el && subTree) {
        subTree.transition = instance.vnode.transition;
        unmount(subTree, instance, parentSuspense, doRemove);
      }
      if (um) {
        queuePostRenderEffect(um, parentSuspense);
      }
      queuePostRenderEffect(() => {
        instance.isUnmounted = true;
      }, parentSuspense);
    };
    const unmountChildren = (children, parentComponent, parentSuspense, doRemove = false, optimized = false, start = 0) => {
      for (let i = start; i < children.length; i++) {
        unmount(children[i], parentComponent, parentSuspense, doRemove, optimized);
      }
    };
    const getNextHostNode = (vnode) => {
      if (vnode.shapeFlag & 6) {
        return getNextHostNode(vnode.component.subTree);
      }
      if (vnode.shapeFlag & 128) {
        return vnode.suspense.next();
      }
      const el = hostNextSibling(vnode.anchor || vnode.el);
      const teleportEnd = el && el[TeleportEndKey];
      return teleportEnd ? hostNextSibling(teleportEnd) : el;
    };
    let isFlushing = false;
    const render = (vnode, container, namespace) => {
      let instance;
      if (vnode == null) {
        if (container._vnode) {
          unmount(container._vnode, null, null, true);
          instance = container._vnode.component;
        }
      } else {
        patch(
          container._vnode || null,
          vnode,
          container,
          null,
          null,
          null,
          namespace
        );
      }
      container._vnode = vnode;
      if (!isFlushing) {
        isFlushing = true;
        flushPreFlushCbs(instance);
        flushPostFlushCbs();
        isFlushing = false;
      }
    };
    const internals = {
      p: patch,
      um: unmount,
      m: move,
      r: remove2,
      mt: mountComponent,
      mc: mountChildren,
      pc: patchChildren,
      pbc: patchBlockChildren,
      n: getNextHostNode,
      o: options
    };
    let hydrate;
    return {
      render,
      hydrate,
      createApp: createAppAPI(render)
    };
  }
  function resolveChildrenNamespace({ type, props }, currentNamespace) {
    return currentNamespace === "svg" && type === "foreignObject" || currentNamespace === "mathml" && type === "annotation-xml" && props && props.encoding && props.encoding.includes("html") ? void 0 : currentNamespace;
  }
  function toggleRecurse({ effect: effect2, job }, allowed) {
    if (allowed) {
      effect2.flags |= 32;
      job.flags |= 4;
    } else {
      effect2.flags &= -33;
      job.flags &= -5;
    }
  }
  function needTransition(parentSuspense, transition) {
    return (!parentSuspense || parentSuspense && !parentSuspense.pendingBranch) && transition && !transition.persisted;
  }
  function traverseStaticChildren(n1, n2, shallow = false) {
    const ch1 = n1.children;
    const ch2 = n2.children;
    if (isArray(ch1) && isArray(ch2)) {
      for (let i = 0; i < ch1.length; i++) {
        const c1 = ch1[i];
        let c2 = ch2[i];
        if (c2.shapeFlag & 1 && !c2.dynamicChildren) {
          if (c2.patchFlag <= 0 || c2.patchFlag === 32) {
            c2 = ch2[i] = cloneIfMounted(ch2[i]);
            c2.el = c1.el;
          }
          if (!shallow && c2.patchFlag !== -2)
            traverseStaticChildren(c1, c2);
        }
        if (c2.type === Text) {
          if (c2.patchFlag === -1) {
            c2 = ch2[i] = cloneIfMounted(c2);
          }
          c2.el = c1.el;
        }
        if (c2.type === Comment && !c2.el) {
          c2.el = c1.el;
        }
      }
    }
  }
  function getSequence(arr) {
    const p2 = arr.slice();
    const result = [0];
    let i, j, u, v, c;
    const len = arr.length;
    for (i = 0; i < len; i++) {
      const arrI = arr[i];
      if (arrI !== 0) {
        j = result[result.length - 1];
        if (arr[j] < arrI) {
          p2[i] = j;
          result.push(i);
          continue;
        }
        u = 0;
        v = result.length - 1;
        while (u < v) {
          c = u + v >> 1;
          if (arr[result[c]] < arrI) {
            u = c + 1;
          } else {
            v = c;
          }
        }
        if (arrI < arr[result[u]]) {
          if (u > 0) {
            p2[i] = result[u - 1];
          }
          result[u] = i;
        }
      }
    }
    u = result.length;
    v = result[u - 1];
    while (u-- > 0) {
      result[u] = v;
      v = p2[v];
    }
    return result;
  }
  function locateNonHydratedAsyncRoot(instance) {
    const subComponent = instance.subTree.component;
    if (subComponent) {
      if (subComponent.asyncDep && !subComponent.asyncResolved) {
        return subComponent;
      } else {
        return locateNonHydratedAsyncRoot(subComponent);
      }
    }
  }
  function invalidateMount(hooks) {
    if (hooks) {
      for (let i = 0; i < hooks.length; i++)
        hooks[i].flags |= 8;
    }
  }
  function resolveAsyncComponentPlaceholder(anchorVnode) {
    if (anchorVnode.placeholder) {
      return anchorVnode.placeholder;
    }
    const instance = anchorVnode.component;
    if (instance) {
      return resolveAsyncComponentPlaceholder(instance.subTree);
    }
    return null;
  }
  const isSuspense = (type) => type.__isSuspense;
  function queueEffectWithSuspense(fn, suspense) {
    if (suspense && suspense.pendingBranch) {
      if (isArray(fn)) {
        suspense.effects.push(...fn);
      } else {
        suspense.effects.push(fn);
      }
    } else {
      queuePostFlushCb(fn);
    }
  }
  const Fragment = /* @__PURE__ */ Symbol.for("v-fgt");
  const Text = /* @__PURE__ */ Symbol.for("v-txt");
  const Comment = /* @__PURE__ */ Symbol.for("v-cmt");
  const Static = /* @__PURE__ */ Symbol.for("v-stc");
  const blockStack = [];
  let currentBlock = null;
  function openBlock(disableTracking = false) {
    blockStack.push(currentBlock = disableTracking ? null : []);
  }
  function closeBlock() {
    blockStack.pop();
    currentBlock = blockStack[blockStack.length - 1] || null;
  }
  let isBlockTreeEnabled = 1;
  function setBlockTracking(value, inVOnce = false) {
    isBlockTreeEnabled += value;
    if (value < 0 && currentBlock && inVOnce) {
      currentBlock.hasOnce = true;
    }
  }
  function setupBlock(vnode) {
    vnode.dynamicChildren = isBlockTreeEnabled > 0 ? currentBlock || EMPTY_ARR : null;
    closeBlock();
    if (isBlockTreeEnabled > 0 && currentBlock) {
      currentBlock.push(vnode);
    }
    return vnode;
  }
  function createElementBlock(type, props, children, patchFlag, dynamicProps, shapeFlag) {
    return setupBlock(
      createBaseVNode(
        type,
        props,
        children,
        patchFlag,
        dynamicProps,
        shapeFlag,
        true
      )
    );
  }
  function createBlock(type, props, children, patchFlag, dynamicProps) {
    return setupBlock(
      createVNode(
        type,
        props,
        children,
        patchFlag,
        dynamicProps,
        true
      )
    );
  }
  function isVNode(value) {
    return value ? value.__v_isVNode === true : false;
  }
  function isSameVNodeType(n1, n2) {
    return n1.type === n2.type && n1.key === n2.key;
  }
  const normalizeKey = ({ key }) => key != null ? key : null;
  const normalizeRef = ({
    ref: ref3,
    ref_key,
    ref_for
  }) => {
    if (typeof ref3 === "number") {
      ref3 = "" + ref3;
    }
    return ref3 != null ? isString(ref3) || /* @__PURE__ */ isRef(ref3) || isFunction(ref3) ? { i: currentRenderingInstance, r: ref3, k: ref_key, f: !!ref_for } : ref3 : null;
  };
  function createBaseVNode(type, props = null, children = null, patchFlag = 0, dynamicProps = null, shapeFlag = type === Fragment ? 0 : 1, isBlockNode = false, needFullChildrenNormalization = false) {
    const vnode = {
      __v_isVNode: true,
      __v_skip: true,
      type,
      props,
      key: props && normalizeKey(props),
      ref: props && normalizeRef(props),
      scopeId: currentScopeId,
      slotScopeIds: null,
      children,
      component: null,
      suspense: null,
      ssContent: null,
      ssFallback: null,
      dirs: null,
      transition: null,
      el: null,
      anchor: null,
      target: null,
      targetStart: null,
      targetAnchor: null,
      staticCount: 0,
      shapeFlag,
      patchFlag,
      dynamicProps,
      dynamicChildren: null,
      appContext: null,
      ctx: currentRenderingInstance
    };
    if (needFullChildrenNormalization) {
      normalizeChildren(vnode, children);
      if (shapeFlag & 128) {
        type.normalize(vnode);
      }
    } else if (children) {
      vnode.shapeFlag |= isString(children) ? 8 : 16;
    }
    if (isBlockTreeEnabled > 0 && // avoid a block node from tracking itself
    !isBlockNode && // has current parent block
    currentBlock && // presence of a patch flag indicates this node needs patching on updates.
    // component nodes also should always be patched, because even if the
    // component doesn't need to update, it needs to persist the instance on to
    // the next vnode so that it can be properly unmounted later.
    (vnode.patchFlag > 0 || shapeFlag & 6) && // the EVENTS flag is only for hydration and if it is the only flag, the
    // vnode should not be considered dynamic due to handler caching.
    vnode.patchFlag !== 32) {
      currentBlock.push(vnode);
    }
    return vnode;
  }
  const createVNode = _createVNode;
  function _createVNode(type, props = null, children = null, patchFlag = 0, dynamicProps = null, isBlockNode = false) {
    if (!type || type === NULL_DYNAMIC_COMPONENT) {
      type = Comment;
    }
    if (isVNode(type)) {
      const cloned = cloneVNode(
        type,
        props,
        true
        /* mergeRef: true */
      );
      if (children) {
        normalizeChildren(cloned, children);
      }
      if (isBlockTreeEnabled > 0 && !isBlockNode && currentBlock) {
        if (cloned.shapeFlag & 6) {
          currentBlock[currentBlock.indexOf(type)] = cloned;
        } else {
          currentBlock.push(cloned);
        }
      }
      cloned.patchFlag = -2;
      return cloned;
    }
    if (isClassComponent(type)) {
      type = type.__vccOpts;
    }
    if (props) {
      props = guardReactiveProps(props);
      let { class: klass, style } = props;
      if (klass && !isString(klass)) {
        props.class = normalizeClass(klass);
      }
      if (isObject(style)) {
        if (/* @__PURE__ */ isProxy(style) && !isArray(style)) {
          style = extend({}, style);
        }
        props.style = normalizeStyle(style);
      }
    }
    const shapeFlag = isString(type) ? 1 : isSuspense(type) ? 128 : isTeleport(type) ? 64 : isObject(type) ? 4 : isFunction(type) ? 2 : 0;
    return createBaseVNode(
      type,
      props,
      children,
      patchFlag,
      dynamicProps,
      shapeFlag,
      isBlockNode,
      true
    );
  }
  function guardReactiveProps(props) {
    if (!props) return null;
    return /* @__PURE__ */ isProxy(props) || isInternalObject(props) ? extend({}, props) : props;
  }
  function cloneVNode(vnode, extraProps, mergeRef = false, cloneTransition = false) {
    const { props, ref: ref3, patchFlag, children, transition } = vnode;
    const mergedProps = extraProps ? mergeProps(props || {}, extraProps) : props;
    const cloned = {
      __v_isVNode: true,
      __v_skip: true,
      type: vnode.type,
      props: mergedProps,
      key: mergedProps && normalizeKey(mergedProps),
      ref: extraProps && extraProps.ref ? (
        // #2078 in the case of <component :is="vnode" ref="extra"/>
        // if the vnode itself already has a ref, cloneVNode will need to merge
        // the refs so the single vnode can be set on multiple refs
        mergeRef && ref3 ? isArray(ref3) ? ref3.concat(normalizeRef(extraProps)) : [ref3, normalizeRef(extraProps)] : normalizeRef(extraProps)
      ) : ref3,
      scopeId: vnode.scopeId,
      slotScopeIds: vnode.slotScopeIds,
      children,
      target: vnode.target,
      targetStart: vnode.targetStart,
      targetAnchor: vnode.targetAnchor,
      staticCount: vnode.staticCount,
      shapeFlag: vnode.shapeFlag,
      // if the vnode is cloned with extra props, we can no longer assume its
      // existing patch flag to be reliable and need to add the FULL_PROPS flag.
      // note: preserve flag for fragments since they use the flag for children
      // fast paths only.
      patchFlag: extraProps && vnode.type !== Fragment ? patchFlag === -1 ? 16 : patchFlag | 16 : patchFlag,
      dynamicProps: vnode.dynamicProps,
      dynamicChildren: vnode.dynamicChildren,
      appContext: vnode.appContext,
      dirs: vnode.dirs,
      transition,
      // These should technically only be non-null on mounted VNodes. However,
      // they *should* be copied for kept-alive vnodes. So we just always copy
      // them since them being non-null during a mount doesn't affect the logic as
      // they will simply be overwritten.
      component: vnode.component,
      suspense: vnode.suspense,
      ssContent: vnode.ssContent && cloneVNode(vnode.ssContent),
      ssFallback: vnode.ssFallback && cloneVNode(vnode.ssFallback),
      placeholder: vnode.placeholder,
      el: vnode.el,
      anchor: vnode.anchor,
      ctx: vnode.ctx,
      ce: vnode.ce,
      cacheIndex: vnode.cacheIndex
    };
    if (transition && cloneTransition) {
      setTransitionHooks(
        cloned,
        transition.clone(cloned)
      );
    }
    return cloned;
  }
  function createTextVNode(text = " ", flag = 0) {
    return createVNode(Text, null, text, flag);
  }
  function createCommentVNode(text = "", asBlock = false) {
    return asBlock ? (openBlock(), createBlock(Comment, null, text)) : createVNode(Comment, null, text);
  }
  function normalizeVNode(child) {
    if (child == null || typeof child === "boolean") {
      return createVNode(Comment);
    } else if (isArray(child)) {
      return createVNode(
        Fragment,
        null,
        // #3666, avoid reference pollution when reusing vnode
        child.slice()
      );
    } else if (isVNode(child)) {
      return cloneIfMounted(child);
    } else {
      return createVNode(Text, null, String(child));
    }
  }
  function cloneIfMounted(child) {
    return child.el === null && child.patchFlag !== -1 || child.memo ? child : cloneVNode(child);
  }
  function normalizeChildren(vnode, children) {
    let type = 0;
    const { shapeFlag } = vnode;
    if (children == null) {
      children = null;
    } else if (isArray(children)) {
      type = 16;
    } else if (typeof children === "object") {
      if (shapeFlag & (1 | 64)) {
        const slot = children.default;
        if (slot) {
          slot._c && (slot._d = false);
          normalizeChildren(vnode, slot());
          slot._c && (slot._d = true);
        }
        return;
      } else {
        type = 32;
        const slotFlag = children._;
        if (!slotFlag && !isInternalObject(children)) {
          children._ctx = currentRenderingInstance;
        } else if (slotFlag === 3 && currentRenderingInstance) {
          if (currentRenderingInstance.slots._ === 1) {
            children._ = 1;
          } else {
            children._ = 2;
            vnode.patchFlag |= 1024;
          }
        }
      }
    } else if (isFunction(children)) {
      if (shapeFlag & (1 | 64)) {
        normalizeChildren(vnode, { default: children });
        return;
      }
      children = { default: children, _ctx: currentRenderingInstance };
      type = 32;
    } else {
      children = String(children);
      if (shapeFlag & 64) {
        type = 16;
        children = [createTextVNode(children)];
      } else {
        type = 8;
      }
    }
    vnode.children = children;
    vnode.shapeFlag |= type;
  }
  function mergeProps(...args) {
    const ret = {};
    for (let i = 0; i < args.length; i++) {
      const toMerge = args[i];
      for (const key in toMerge) {
        if (key === "class") {
          if (ret.class !== toMerge.class) {
            ret.class = normalizeClass([ret.class, toMerge.class]);
          }
        } else if (key === "style") {
          ret.style = normalizeStyle([ret.style, toMerge.style]);
        } else if (isOn(key)) {
          const existing = ret[key];
          const incoming = toMerge[key];
          if (incoming && existing !== incoming && !(isArray(existing) && existing.includes(incoming))) {
            ret[key] = existing ? [].concat(existing, incoming) : incoming;
          } else if (incoming == null && existing == null && // mergeProps({ 'onUpdate:modelValue': undefined }) should not retain
          // the model listener.
          !isModelListener(key)) {
            ret[key] = incoming;
          }
        } else if (key !== "") {
          ret[key] = toMerge[key];
        }
      }
    }
    return ret;
  }
  function invokeVNodeHook(hook, instance, vnode, prevVNode = null) {
    callWithAsyncErrorHandling(hook, instance, 7, [
      vnode,
      prevVNode
    ]);
  }
  const emptyAppContext = createAppContext();
  let uid = 0;
  function createComponentInstance(vnode, parent, suspense) {
    const type = vnode.type;
    const appContext = (parent ? parent.appContext : vnode.appContext) || emptyAppContext;
    const instance = {
      uid: uid++,
      vnode,
      type,
      parent,
      appContext,
      root: null,
      // to be immediately set
      next: null,
      subTree: null,
      // will be set synchronously right after creation
      effect: null,
      update: null,
      // will be set synchronously right after creation
      job: null,
      scope: new EffectScope(
        true
        /* detached */
      ),
      render: null,
      proxy: null,
      exposed: null,
      exposeProxy: null,
      withProxy: null,
      provides: parent ? parent.provides : Object.create(appContext.provides),
      ids: parent ? parent.ids : ["", 0, 0],
      accessCache: null,
      renderCache: [],
      // local resolved assets
      components: null,
      directives: null,
      // resolved props and emits options
      propsOptions: normalizePropsOptions(type, appContext),
      emitsOptions: normalizeEmitsOptions(type, appContext),
      // emit
      emit: null,
      // to be set immediately
      emitted: null,
      // props default value
      propsDefaults: EMPTY_OBJ,
      // inheritAttrs
      inheritAttrs: type.inheritAttrs,
      // state
      ctx: EMPTY_OBJ,
      data: EMPTY_OBJ,
      props: EMPTY_OBJ,
      attrs: EMPTY_OBJ,
      slots: EMPTY_OBJ,
      refs: EMPTY_OBJ,
      setupState: EMPTY_OBJ,
      setupContext: null,
      // suspense related
      suspense,
      suspenseId: suspense ? suspense.pendingId : 0,
      asyncDep: null,
      asyncResolved: false,
      // lifecycle hooks
      // not using enums here because it results in computed properties
      isMounted: false,
      isUnmounted: false,
      isDeactivated: false,
      bc: null,
      c: null,
      bm: null,
      m: null,
      bu: null,
      u: null,
      um: null,
      bum: null,
      da: null,
      a: null,
      rtg: null,
      rtc: null,
      ec: null,
      sp: null
    };
    {
      instance.ctx = { _: instance };
    }
    instance.root = parent ? parent.root : instance;
    instance.emit = emit.bind(null, instance);
    if (vnode.ce) {
      vnode.ce(instance);
    }
    return instance;
  }
  let currentInstance = null;
  const getCurrentInstance = () => currentInstance || currentRenderingInstance;
  let internalSetCurrentInstance;
  let setInSSRSetupState;
  {
    const g = getGlobalThis();
    const registerGlobalSetter = (key, setter) => {
      let setters;
      if (!(setters = g[key])) setters = g[key] = [];
      setters.push(setter);
      return (v) => {
        if (setters.length > 1) setters.forEach((set) => set(v));
        else setters[0](v);
      };
    };
    internalSetCurrentInstance = registerGlobalSetter(
      `__VUE_INSTANCE_SETTERS__`,
      (v) => currentInstance = v
    );
    setInSSRSetupState = registerGlobalSetter(
      `__VUE_SSR_SETTERS__`,
      (v) => isInSSRComponentSetup = v
    );
  }
  const setCurrentInstance = (instance) => {
    const prev = currentInstance;
    internalSetCurrentInstance(instance);
    instance.scope.on();
    return () => {
      instance.scope.off();
      internalSetCurrentInstance(prev);
    };
  };
  const unsetCurrentInstance = () => {
    currentInstance && currentInstance.scope.off();
    internalSetCurrentInstance(null);
  };
  function isStatefulComponent(instance) {
    return instance.vnode.shapeFlag & 4;
  }
  let isInSSRComponentSetup = false;
  function setupComponent(instance, isSSR = false, optimized = false) {
    isSSR && setInSSRSetupState(isSSR);
    const { props, children } = instance.vnode;
    const isStateful = isStatefulComponent(instance);
    initProps(instance, props, isStateful, isSSR);
    initSlots(instance, children, optimized || isSSR);
    const setupResult = isStateful ? setupStatefulComponent(instance, isSSR) : void 0;
    isSSR && setInSSRSetupState(false);
    return setupResult;
  }
  function setupStatefulComponent(instance, isSSR) {
    const Component = instance.type;
    instance.accessCache = /* @__PURE__ */ Object.create(null);
    instance.proxy = new Proxy(instance.ctx, PublicInstanceProxyHandlers);
    const { setup } = Component;
    if (setup) {
      pauseTracking();
      const setupContext = instance.setupContext = setup.length > 1 ? createSetupContext(instance) : null;
      const reset = setCurrentInstance(instance);
      const setupResult = callWithErrorHandling(
        setup,
        instance,
        0,
        [
          instance.props,
          setupContext
        ]
      );
      const isAsyncSetup = isPromise(setupResult);
      resetTracking();
      reset();
      if ((isAsyncSetup || instance.sp) && !isAsyncWrapper(instance)) {
        markAsyncBoundary(instance);
      }
      if (isAsyncSetup) {
        setupResult.then(unsetCurrentInstance, unsetCurrentInstance);
        if (isSSR) {
          return setupResult.then((resolvedResult) => {
            setInSSRSetupState(true);
            try {
              handleSetupResult(instance, resolvedResult, isSSR);
            } finally {
              setInSSRSetupState(false);
            }
          }).catch((e) => {
            handleError(e, instance, 0);
          });
        } else {
          instance.asyncDep = setupResult;
        }
      } else {
        handleSetupResult(instance, setupResult);
      }
    } else {
      finishComponentSetup(instance);
    }
  }
  function handleSetupResult(instance, setupResult, isSSR) {
    if (isFunction(setupResult)) {
      if (instance.type.__ssrInlineRender) {
        instance.ssrRender = setupResult;
      } else {
        instance.render = setupResult;
      }
    } else if (isObject(setupResult)) {
      instance.setupState = proxyRefs(setupResult);
    } else ;
    finishComponentSetup(instance);
  }
  function finishComponentSetup(instance, isSSR, skipOptions) {
    const Component = instance.type;
    if (!instance.render) {
      instance.render = Component.render || NOOP;
    }
    {
      const reset = setCurrentInstance(instance);
      pauseTracking();
      try {
        applyOptions(instance);
      } finally {
        resetTracking();
        reset();
      }
    }
  }
  const attrsProxyHandlers = {
    get(target, key) {
      track(target, "get", "");
      return target[key];
    }
  };
  function createSetupContext(instance) {
    const expose = (exposed) => {
      instance.exposed = exposed || {};
    };
    {
      return {
        attrs: new Proxy(instance.attrs, attrsProxyHandlers),
        slots: instance.slots,
        emit: instance.emit,
        expose
      };
    }
  }
  function getComponentPublicInstance(instance) {
    if (instance.exposed) {
      return instance.exposeProxy || (instance.exposeProxy = new Proxy(proxyRefs(markRaw(instance.exposed)), {
        get(target, key) {
          if (key in target) {
            return target[key];
          } else if (key in publicPropertiesMap) {
            return publicPropertiesMap[key](instance);
          }
        },
        has(target, key) {
          return key in target || key in publicPropertiesMap;
        }
      }));
    } else {
      return instance.proxy;
    }
  }
  const classifyRE = /(?:^|[-_])\w/g;
  const classify = (str) => str.replace(classifyRE, (c) => c.toUpperCase()).replace(/[-_]/g, "");
  function getComponentName(Component, includeInferred = true) {
    return isFunction(Component) ? Component.displayName || Component.name : Component.name || includeInferred && Component.__name;
  }
  function formatComponentName(instance, Component, isRoot = false) {
    let name = getComponentName(Component);
    if (!name && Component.__file) {
      const match = Component.__file.match(/([^/\\]+)\.\w+$/);
      if (match) {
        name = match[1];
      }
    }
    if (!name && instance) {
      const inferFromRegistry = (registry) => {
        for (const key in registry) {
          if (registry[key] === Component) {
            return key;
          }
        }
      };
      name = inferFromRegistry(instance.components) || instance.parent && inferFromRegistry(
        instance.parent.type.components
      ) || inferFromRegistry(instance.appContext.components);
    }
    return name ? classify(name) : isRoot ? `App` : `Anonymous`;
  }
  function isClassComponent(value) {
    return isFunction(value) && "__vccOpts" in value;
  }
  const computed = (getterOrOptions, debugOptions) => {
    const c = /* @__PURE__ */ computed$1(getterOrOptions, debugOptions, isInSSRComponentSetup);
    return c;
  };
  function h(type, propsOrChildren, children) {
    try {
      setBlockTracking(-1);
      const l = arguments.length;
      if (l === 2) {
        if (isObject(propsOrChildren) && !isArray(propsOrChildren)) {
          if (isVNode(propsOrChildren)) {
            return createVNode(type, null, [propsOrChildren]);
          }
          return createVNode(type, propsOrChildren);
        } else {
          return createVNode(type, null, propsOrChildren);
        }
      } else {
        if (l > 3) {
          children = Array.prototype.slice.call(arguments, 2);
        } else if (l === 3 && isVNode(children)) {
          children = [children];
        }
        return createVNode(type, propsOrChildren, children);
      }
    } finally {
      setBlockTracking(1);
    }
  }
  const version = "3.5.43";
  let policy = void 0;
  const tt = typeof window !== "undefined" && window.trustedTypes;
  if (tt) {
    try {
      policy = /* @__PURE__ */ tt.createPolicy("vue", {
        createHTML: (val) => val
      });
    } catch (e) {
    }
  }
  const unsafeToTrustedHTML = policy ? (val) => policy.createHTML(val) : (val) => val;
  const svgNS = "http://www.w3.org/2000/svg";
  const mathmlNS = "http://www.w3.org/1998/Math/MathML";
  const doc = typeof document !== "undefined" ? document : null;
  const templateContainer = doc && /* @__PURE__ */ doc.createElement("template");
  const nodeOps = {
    insert: (child, parent, anchor) => {
      parent.insertBefore(child, anchor || null);
    },
    remove: (child) => {
      const parent = child.parentNode;
      if (parent) {
        parent.removeChild(child);
      }
    },
    createElement: (tag2, namespace, is, props) => {
      const el = namespace === "svg" ? doc.createElementNS(svgNS, tag2) : namespace === "mathml" ? doc.createElementNS(mathmlNS, tag2) : is ? doc.createElement(tag2, { is }) : doc.createElement(tag2);
      if (tag2 === "select" && props && props.multiple != null) {
        el.setAttribute("multiple", props.multiple);
      }
      return el;
    },
    createText: (text) => doc.createTextNode(text),
    createComment: (text) => doc.createComment(text),
    setText: (node, text) => {
      node.nodeValue = text;
    },
    setElementText: (el, text) => {
      el.textContent = text;
    },
    parentNode: (node) => node.parentNode,
    nextSibling: (node) => node.nextSibling,
    querySelector: (selector) => doc.querySelector(selector),
    setScopeId(el, id) {
      el.setAttribute(id, "");
    },
    // __UNSAFE__
    // Reason: innerHTML.
    // Static content here can only come from compiled templates.
    // As long as the user only uses trusted templates, this is safe.
    insertStaticContent(content, parent, anchor, namespace, start, end) {
      const before = anchor ? anchor.previousSibling : parent.lastChild;
      if (start && (start === end || start.nextSibling)) {
        while (true) {
          parent.insertBefore(start.cloneNode(true), anchor);
          if (start === end || !(start = start.nextSibling)) break;
        }
      } else {
        templateContainer.innerHTML = unsafeToTrustedHTML(
          namespace === "svg" ? `<svg>${content}</svg>` : namespace === "mathml" ? `<math>${content}</math>` : content
        );
        const template2 = templateContainer.content;
        if (namespace === "svg" || namespace === "mathml") {
          const wrapper = template2.firstChild;
          while (wrapper.firstChild) {
            template2.appendChild(wrapper.firstChild);
          }
          template2.removeChild(wrapper);
        }
        parent.insertBefore(template2, anchor);
      }
      return [
        // first
        before ? before.nextSibling : parent.firstChild,
        // last
        anchor ? anchor.previousSibling : parent.lastChild
      ];
    }
  };
  const vtcKey = /* @__PURE__ */ Symbol("_vtc");
  function patchClass(el, value, isSVG) {
    const transitionClasses = el[vtcKey];
    if (transitionClasses) {
      value = (value ? [value, ...transitionClasses] : [...transitionClasses]).join(" ");
    }
    if (value == null) {
      el.removeAttribute("class");
    } else if (isSVG) {
      el.setAttribute("class", value);
    } else {
      el.className = value;
    }
  }
  const vShowOriginalDisplay = /* @__PURE__ */ Symbol("_vod");
  const vShowHidden = /* @__PURE__ */ Symbol("_vsh");
  const CSS_VAR_TEXT = /* @__PURE__ */ Symbol("");
  const displayRE = /(?:^|;)\s*display\s*:/;
  function patchStyle(el, prev, next) {
    const style = el.style;
    const isCssString = isString(next);
    let hasControlledDisplay = false;
    if (next && !isCssString) {
      if (prev) {
        if (!isString(prev)) {
          for (const key in prev) {
            if (next[key] == null) {
              setStyle(style, key, "");
            }
          }
        } else {
          for (const prevStyle of prev.split(";")) {
            const key = prevStyle.slice(0, prevStyle.indexOf(":")).trim();
            if (next[key] == null) {
              setStyle(style, key, "");
            }
          }
        }
      }
      for (const key in next) {
        if (key === "display") {
          hasControlledDisplay = true;
        }
        const value = next[key];
        if (value != null) {
          if (!shouldPreserveTextareaResizeStyle(
            el,
            key,
            !isString(prev) && prev ? prev[key] : void 0,
            value
          )) {
            setStyle(style, key, value);
          }
        } else {
          setStyle(style, key, "");
        }
      }
    } else {
      if (isCssString) {
        if (prev !== next) {
          const cssVarText = style[CSS_VAR_TEXT];
          if (cssVarText) {
            next += ";" + cssVarText;
          }
          style.cssText = next;
          hasControlledDisplay = displayRE.test(next);
        }
      } else if (prev) {
        el.removeAttribute("style");
      }
    }
    if (vShowOriginalDisplay in el) {
      el[vShowOriginalDisplay] = hasControlledDisplay ? style.display : "";
      if (el[vShowHidden]) {
        style.display = "none";
      }
    }
  }
  const importantRE = /\s*!important$/;
  function setStyle(style, name, val) {
    if (isArray(val)) {
      val.forEach((v) => setStyle(style, name, v));
    } else {
      if (val == null) val = "";
      if (name.startsWith("--")) {
        if (importantRE.test(val)) {
          style.setProperty(name, val.replace(importantRE, ""), "important");
        } else {
          style.setProperty(name, val);
        }
      } else {
        const prefixed = autoPrefix(style, name);
        if (importantRE.test(val)) {
          style.setProperty(
            hyphenate(prefixed),
            val.replace(importantRE, ""),
            "important"
          );
        } else {
          style[prefixed] = val;
        }
      }
    }
  }
  const prefixes = ["Webkit", "Moz", "ms"];
  const prefixCache = {};
  function autoPrefix(style, rawName) {
    const cached = prefixCache[rawName];
    if (cached) {
      return cached;
    }
    let name = camelize(rawName);
    if (name !== "filter" && name in style) {
      return prefixCache[rawName] = name;
    }
    name = capitalize(name);
    for (let i = 0; i < prefixes.length; i++) {
      const prefixed = prefixes[i] + name;
      if (prefixed in style) {
        return prefixCache[rawName] = prefixed;
      }
    }
    return rawName;
  }
  function shouldPreserveTextareaResizeStyle(el, key, prev, next) {
    return el.tagName === "TEXTAREA" && (key === "width" || key === "height") && isString(next) && prev === next;
  }
  const xlinkNS = "http://www.w3.org/1999/xlink";
  function patchAttr(el, key, value, isSVG, instance, isBoolean = isSpecialBooleanAttr(key)) {
    if (isSVG && key.startsWith("xlink:")) {
      if (value == null) {
        el.removeAttributeNS(xlinkNS, key.slice(6, key.length));
      } else {
        el.setAttributeNS(xlinkNS, key, value);
      }
    } else {
      if (value == null || isBoolean && !includeBooleanAttr(value)) {
        el.removeAttribute(key);
      } else {
        el.setAttribute(
          key,
          isBoolean ? "" : isSymbol(value) ? String(value) : value
        );
      }
    }
  }
  function patchDOMProp(el, key, value, parentComponent, attrName) {
    if (key === "innerHTML" || key === "textContent") {
      if (value != null) {
        el[key] = key === "innerHTML" ? unsafeToTrustedHTML(value) : value;
      }
      return;
    }
    const tag2 = el.tagName;
    if (key === "value" && tag2 !== "PROGRESS" && // custom elements may use _value internally
    !tag2.includes("-")) {
      const oldValue = tag2 === "OPTION" ? el.getAttribute("value") || "" : el.value;
      const newValue = value == null ? (
        // #11647: value should be set as empty string for null and undefined,
        // but <input type="checkbox"> should be set as 'on'.
        el.type === "checkbox" ? "on" : ""
      ) : String(value);
      if (oldValue !== newValue || !("_value" in el)) {
        el.value = newValue;
      }
      if (value == null) {
        el.removeAttribute(key);
      }
      el._value = value;
      return;
    }
    let needRemove = false;
    if (value === "" || value == null) {
      const type = typeof el[key];
      if (type === "boolean") {
        value = includeBooleanAttr(value);
      } else if (value == null && type === "string") {
        value = "";
        needRemove = true;
      } else if (type === "number") {
        value = 0;
        needRemove = true;
      }
    }
    try {
      el[key] = value;
    } catch (e) {
    }
    needRemove && el.removeAttribute(attrName || key);
  }
  function addEventListener(el, event, handler, options) {
    el.addEventListener(event, handler, options);
  }
  function removeEventListener(el, event, handler, options) {
    el.removeEventListener(event, handler, options);
  }
  const veiKey = /* @__PURE__ */ Symbol("_vei");
  function patchEvent(el, rawName, prevValue, nextValue, instance = null) {
    const invokers = el[veiKey] || (el[veiKey] = {});
    const existingInvoker = invokers[rawName];
    if (nextValue && existingInvoker) {
      existingInvoker.value = nextValue;
    } else {
      const [name, options] = parseName(rawName);
      if (nextValue) {
        const invoker = invokers[rawName] = createInvoker(
          nextValue,
          instance
        );
        addEventListener(el, name, invoker, options);
      } else if (existingInvoker) {
        removeEventListener(el, name, existingInvoker, options);
        invokers[rawName] = void 0;
      }
    }
  }
  const optionsModifierRE = /(Once|Passive|Capture)$/;
  const optionsModifierEventRE = /^on:?(?:Once|Passive|Capture)$/;
  function parseName(name) {
    let options;
    let m;
    while ((m = name.match(optionsModifierRE)) && !optionsModifierEventRE.test(name)) {
      if (!options) options = {};
      name = name.slice(0, name.length - m[1].length);
      options[m[1].toLowerCase()] = true;
    }
    const event = name[2] === ":" ? name.slice(3) : hyphenate(name.slice(2));
    return [event, options];
  }
  let cachedNow = 0;
  const p = /* @__PURE__ */ Promise.resolve();
  const getNow = () => cachedNow || (p.then(() => cachedNow = 0), cachedNow = Date.now());
  function createInvoker(initialValue, instance) {
    const invoker = (e) => {
      if (!e._vts) {
        e._vts = Date.now();
      } else if (e._vts <= invoker.attached) {
        return;
      }
      const value = invoker.value;
      if (isArray(value)) {
        const originalStop = e.stopImmediatePropagation;
        e.stopImmediatePropagation = () => {
          originalStop.call(e);
          e._stopped = true;
        };
        const handlers = value.slice();
        const args = [e];
        for (let i = 0; i < handlers.length; i++) {
          if (e._stopped) {
            break;
          }
          const handler = handlers[i];
          if (handler) {
            callWithAsyncErrorHandling(
              handler,
              instance,
              5,
              args
            );
          }
        }
      } else {
        callWithAsyncErrorHandling(
          value,
          instance,
          5,
          [e]
        );
      }
    };
    invoker.value = initialValue;
    invoker.attached = getNow();
    return invoker;
  }
  const isNativeOn = (key) => key.charCodeAt(0) === 111 && key.charCodeAt(1) === 110 && // lowercase letter
  key.charCodeAt(2) > 96 && key.charCodeAt(2) < 123;
  const patchProp = (el, key, prevValue, nextValue, namespace, parentComponent) => {
    const isSVG = namespace === "svg";
    if (key === "class") {
      patchClass(el, nextValue, isSVG);
    } else if (key === "style") {
      patchStyle(el, prevValue, nextValue);
    } else if (isOn(key)) {
      if (!isModelListener(key)) {
        patchEvent(el, key, prevValue, nextValue, parentComponent);
      }
    } else if (key[0] === "." ? (key = key.slice(1), true) : key[0] === "^" ? (key = key.slice(1), false) : shouldSetAsProp(el, key, nextValue, isSVG)) {
      patchDOMProp(el, key, nextValue);
      if (!el.tagName.includes("-") && (key === "value" || key === "checked" || key === "selected")) {
        patchAttr(el, key, nextValue, isSVG, parentComponent, key !== "value");
      }
    } else if (
      // #11081 force set props for possible async custom element
      el._isVueCE && // #12408 check if it's declared prop or it's async custom element
      (shouldSetAsPropForVueCE(el, key) || // @ts-expect-error _def is private
      el._def.__asyncLoader && (/[A-Z]/.test(key) || !isString(nextValue)))
    ) {
      patchDOMProp(el, camelize(key), nextValue, parentComponent, key);
    } else {
      if (key === "true-value") {
        el._trueValue = nextValue;
      } else if (key === "false-value") {
        el._falseValue = nextValue;
      }
      patchAttr(el, key, nextValue, isSVG);
    }
  };
  function shouldSetAsProp(el, key, value, isSVG) {
    if (isSVG) {
      if (key === "innerHTML" || key === "textContent") {
        return true;
      }
      if (key in el && isNativeOn(key) && isFunction(value)) {
        return true;
      }
      return false;
    }
    if (key === "spellcheck" || key === "draggable" || key === "translate" || key === "autocorrect") {
      return false;
    }
    if (key === "sandbox" && el.tagName === "IFRAME") {
      return false;
    }
    if (key === "form") {
      return false;
    }
    if (key === "list" && el.tagName === "INPUT") {
      return false;
    }
    if (key === "type" && el.tagName === "TEXTAREA") {
      return false;
    }
    if (key === "width" || key === "height") {
      const tag2 = el.tagName;
      if (tag2 === "IMG" || tag2 === "VIDEO" || tag2 === "CANVAS" || tag2 === "SOURCE") {
        return false;
      }
    }
    if (isNativeOn(key) && isString(value)) {
      return false;
    }
    return key in el;
  }
  function shouldSetAsPropForVueCE(el, key) {
    const props = (
      // @ts-expect-error _def is private
      el._def.props
    );
    if (!props) {
      return false;
    }
    const camelKey = camelize(key);
    return Array.isArray(props) ? props.some((prop) => camelize(prop) === camelKey) : Object.keys(props).some((prop) => camelize(prop) === camelKey);
  }
  const getModelAssigner = (vnode) => {
    const fn = vnode.props["onUpdate:modelValue"] || false;
    return isArray(fn) ? (value) => invokeArrayFns(fn, value) : fn;
  };
  function onCompositionStart(e) {
    e.target.composing = true;
  }
  function onCompositionEnd(e) {
    const target = e.target;
    if (target.composing) {
      target.composing = false;
      target.dispatchEvent(new Event("input"));
    }
  }
  const assignKey = /* @__PURE__ */ Symbol("_assign");
  const initialValueKey = /* @__PURE__ */ Symbol("_initialValue");
  function castValue(value, trim, number) {
    if (trim) value = value.trim();
    if (number) value = looseToNumber(value);
    return value;
  }
  const vModelText = {
    created(el, { modifiers: { lazy, trim, number } }, vnode) {
      if (el.parentNode) {
        if (el.type === "text") {
          el[initialValueKey] = el.defaultValue.replace(/[\r\n]/g, "");
        } else if (el.type === "textarea") {
          el[initialValueKey] = el.defaultValue.replace(/\r\n?/g, "\n");
        }
      }
      el[assignKey] = getModelAssigner(vnode);
      const castToNumber = number || vnode.props && vnode.props.type === "number";
      addEventListener(el, lazy ? "change" : "input", (e) => {
        if (e.target.composing) return;
        el[assignKey](castValue(el.value, trim, castToNumber));
      });
      if (trim || castToNumber) {
        addEventListener(el, "change", () => {
          el.value = castValue(el.value, trim, castToNumber);
        });
      }
      if (!lazy) {
        addEventListener(el, "compositionstart", onCompositionStart);
        addEventListener(el, "compositionend", onCompositionEnd);
        addEventListener(el, "change", onCompositionEnd);
      }
    },
    // set value on mounted so it's after min/max for type="range"
    mounted(el, { value, modifiers: { trim, number } }) {
      const newValue = value == null ? "" : value;
      const initialValue = el[initialValueKey];
      delete el[initialValueKey];
      if (initialValue !== void 0 && (el.type === "text" || el.type === "textarea") && el.value !== initialValue) {
        el[assignKey](castValue(el.value, trim, number));
      } else {
        el.value = newValue;
      }
    },
    beforeUpdate(el, { value, oldValue, modifiers: { lazy, trim, number } }, vnode) {
      el[assignKey] = getModelAssigner(vnode);
      if (el.composing) return;
      const elValue = (number || el.type === "number") && !/^0\d/.test(el.value) ? looseToNumber(el.value) : el.value;
      const newValue = value == null ? "" : value;
      if (elValue === newValue) {
        return;
      }
      const rootNode = el.getRootNode();
      if ((rootNode instanceof Document || rootNode instanceof ShadowRoot) && rootNode.activeElement === el && el.type !== "range") {
        if (lazy && value === oldValue) {
          return;
        }
        if (trim && el.value.trim() === newValue) {
          return;
        }
      }
      el.value = newValue;
    }
  };
  const vModelCheckbox = {
    // #4096 array checkboxes need to be deep traversed
    deep: true,
    created(el, _, vnode) {
      el[assignKey] = getModelAssigner(vnode);
      addEventListener(el, "change", () => {
        const modelValue = el._modelValue;
        const elementValue = getValue(el);
        const checked = el.checked;
        const assign = el[assignKey];
        if (isArray(modelValue)) {
          const index = looseIndexOf(modelValue, elementValue);
          const found = index !== -1;
          if (checked && !found) {
            assign(modelValue.concat(elementValue));
          } else if (!checked && found) {
            const filtered = [...modelValue];
            filtered.splice(index, 1);
            assign(filtered);
          }
        } else if (isSet(modelValue)) {
          const cloned = new Set(modelValue);
          if (checked) {
            cloned.add(elementValue);
          } else {
            cloned.delete(elementValue);
          }
          assign(cloned);
        } else {
          assign(getCheckboxValue(el, checked));
        }
      });
    },
    // set initial checked on mount to wait for true-value/false-value
    mounted: setChecked,
    beforeUpdate(el, binding, vnode) {
      el[assignKey] = getModelAssigner(vnode);
      setChecked(el, binding, vnode);
    }
  };
  function setChecked(el, { value, oldValue }, vnode) {
    el._modelValue = value;
    let checked;
    if (isArray(value)) {
      checked = looseIndexOf(value, vnode.props.value) > -1;
    } else if (isSet(value)) {
      checked = value.has(vnode.props.value);
    } else {
      if (value === oldValue) return;
      checked = looseEqual(value, getCheckboxValue(el, true));
    }
    if (el.checked !== checked) {
      el.checked = checked;
    }
  }
  const vModelSelect = {
    // <select multiple> value need to be deep traversed
    deep: true,
    created(el, { value, modifiers: { number } }, vnode) {
      el._modelValue = value;
      addEventListener(el, "change", () => {
        const selectedVal = Array.prototype.filter.call(el.options, (o) => o.selected).map(
          (o) => number ? looseToNumber(getValue(o)) : getValue(o)
        );
        const multiple = el.multiple;
        const assignedValue = multiple ? isSet(el._modelValue) ? new Set(selectedVal) : selectedVal : selectedVal[0];
        const pending = el._pendingValue = [
          multiple,
          multiple ? isArray(assignedValue) ? selectedVal.slice() : selectedVal : assignedValue
        ];
        try {
          el[assignKey](assignedValue);
        } finally {
          nextTick(() => {
            if (el._pendingValue === pending) {
              el._pendingValue = void 0;
            }
          });
        }
      });
      el[assignKey] = getModelAssigner(vnode);
    },
    // set value in mounted & updated because <select> relies on its children
    // <option>s.
    mounted(el, { value }) {
      setSelected(el, value);
    },
    beforeUpdate(el, { value }, vnode) {
      el._modelValue = value;
      el[assignKey] = getModelAssigner(vnode);
    },
    updated(el, { value }) {
      const pending = el._pendingValue;
      el._pendingValue = void 0;
      if (!pending || pending[0] !== el.multiple || !isSameSelectValue(value, pending[1], pending[0])) {
        setSelected(el, value);
      }
    }
  };
  function isSameSelectValue(value, assignedValue, multiple) {
    if (!multiple) return looseEqual(value, assignedValue);
    if (isArray(value)) return looseEqual(value, assignedValue);
    if (isSet(value)) {
      if (value.size !== assignedValue.length) return false;
      for (const item of assignedValue) {
        if (!value.has(item)) return false;
      }
      return true;
    }
    return false;
  }
  function setSelected(el, value) {
    const isMultiple = el.multiple;
    const isArrayValue = isArray(value);
    if (isMultiple && !isArrayValue && !isSet(value)) {
      return;
    }
    for (let i = 0, l = el.options.length; i < l; i++) {
      const option = el.options[i];
      const optionValue = getValue(option);
      if (isMultiple) {
        if (isArrayValue) {
          const optionType = typeof optionValue;
          if (optionType === "string" || optionType === "number") {
            option.selected = value.some((v) => String(v) === String(optionValue));
          } else {
            option.selected = looseIndexOf(value, optionValue) > -1;
          }
        } else {
          option.selected = value.has(optionValue);
        }
      } else if (looseEqual(getValue(option), value)) {
        if (el.selectedIndex !== i) el.selectedIndex = i;
        return;
      }
    }
    if (!isMultiple && el.selectedIndex !== -1) {
      el.selectedIndex = -1;
    }
  }
  function getValue(el) {
    return "_value" in el ? el._value : el.value;
  }
  function getCheckboxValue(el, checked) {
    const key = checked ? "_trueValue" : "_falseValue";
    return key in el ? el[key] : checked;
  }
  const systemModifiers = ["ctrl", "shift", "alt", "meta"];
  const modifierGuards = {
    stop: (e) => e.stopPropagation(),
    prevent: (e) => e.preventDefault(),
    self: (e) => e.target !== e.currentTarget,
    ctrl: (e) => !e.ctrlKey,
    shift: (e) => !e.shiftKey,
    alt: (e) => !e.altKey,
    meta: (e) => !e.metaKey,
    left: (e) => "button" in e && e.button !== 0,
    middle: (e) => "button" in e && e.button !== 1,
    right: (e) => "button" in e && e.button !== 2,
    exact: (e, modifiers) => systemModifiers.some((m) => e[`${m}Key`] && !modifiers.includes(m))
  };
  const withModifiers = (fn, modifiers) => {
    if (!fn) return fn;
    const cache = fn._withMods || (fn._withMods = {});
    const cacheKey = modifiers.join(".");
    return cache[cacheKey] || (cache[cacheKey] = ((event, ...args) => {
      for (let i = 0; i < modifiers.length; i++) {
        const guard = modifierGuards[modifiers[i]];
        if (guard && guard(event, modifiers)) return;
      }
      return fn(event, ...args);
    }));
  };
  const rendererOptions = /* @__PURE__ */ extend({ patchProp }, nodeOps);
  let renderer;
  function ensureRenderer() {
    return renderer || (renderer = createRenderer(rendererOptions));
  }
  const createApp = ((...args) => {
    const app = ensureRenderer().createApp(...args);
    const { mount } = app;
    app.mount = (containerOrSelector) => {
      const container = normalizeContainer(containerOrSelector);
      if (!container) return;
      const component = app._component;
      if (!isFunction(component) && !component.render && !component.template) {
        component.template = container.innerHTML;
      }
      if (container.nodeType === 1) {
        container.textContent = "";
      }
      const proxy = mount(container, false, resolveRootNamespace(container));
      if (container instanceof Element) {
        container.removeAttribute("v-cloak");
        container.setAttribute("data-v-app", "");
      }
      return proxy;
    };
    return app;
  });
  function resolveRootNamespace(container) {
    if (container instanceof SVGElement) {
      return "svg";
    }
    if (typeof MathMLElement === "function" && container instanceof MathMLElement) {
      return "mathml";
    }
  }
  function normalizeContainer(container) {
    if (isString(container)) {
      const res = document.querySelector(container);
      return res;
    }
    return container;
  }
  function instanceScope() {
    return "chatgpt-booster:dev";
  }
  function scopedIdentity(base, scope, legacyOwner) {
    if (legacyOwner && scope === legacyOwner)
      return base;
    if (!/^(vk-booster|chatgpt-booster|all-in-one):(dev|prod)$/.test(scope))
      throw new Error("Unsupported Booster instance scope");
    return base + ":" + scope;
  }
  function instanceKey(base, legacyOwner) {
    return scopedIdentity(base, instanceScope(), legacyOwner);
  }
  instanceKey("koba:open-feature");
  instanceKey("koba:close-shell");
  function normalizeExportOverride(value) {
    if (!value || typeof value !== "object" || Array.isArray(value)) return {};
    const input = value;
    const result = {};
    if (typeof input.format === "string" && /^[a-z0-9][a-z0-9._-]{0,63}$/i.test(input.format.trim()))
      result.format = input.format.trim();
    if (input.level === "conversation" || input.level === "custom" || input.level === "full")
      result.level = input.level;
    if (input.packaging === "none" || input.packaging === "zip" || input.packaging === "gzip")
      result.packaging = input.packaging;
    for (const field of [
      "reasoning",
      "tools",
      "internal",
      "reasoningRecap",
      "reasoningFull",
      "toolCalls",
      "toolResults",
      "toolSourceContent",
      "modelEvidence",
      "dictationEditEvidence",
      "sourceRevisions",
      "attachmentMetadata",
      "images",
      "files"
    ])
      if (typeof input[field] === "boolean") result[field] = input[field];
    return result;
  }
  function normalizeExportOverrides(value) {
    const incoming = value && typeof value === "object" && !Array.isArray(value) ? value : {};
    const parse = (source) => {
      if (!source || typeof source !== "object" || Array.isArray(source)) return {};
      const accepted = [];
      for (const [key, override] of Object.entries(source)) {
        try {
          const identity = JSON.parse(key);
          if (!Array.isArray(identity) || identity.length !== 2 || identity.some((part) => typeof part !== "string" || !part || part.trim() !== part))
            continue;
          const normalized = normalizeExportOverride(override);
          if (Object.keys(normalized).length) accepted.push([key, normalized]);
        } catch {
        }
      }
      return Object.fromEntries(accepted);
    };
    return { projects: parse(incoming.projects), conversations: parse(incoming.conversations) };
  }
  const DEFAULT_CAPTURE_RULE = {
    enabled: false,
    reasoning: true,
    tools: true,
    internal: true
  };
  const DEFAULT_EXPORT_OPTIONS = {
    format: "markdown",
    packaging: "none",
    level: "conversation",
    reasoning: true,
    tools: true,
    internal: false,
    reasoningRecap: true,
    reasoningFull: true,
    toolCalls: true,
    toolResults: true,
    toolSourceContent: false,
    modelEvidence: true,
    dictationEditEvidence: false,
    sourceRevisions: false,
    attachmentMetadata: false,
    images: false,
    files: false
  };
  function captureRuleFor(settings, conversationId, projectId) {
    return settings.conversations[conversationId] ?? (projectId ? settings.projects[projectId] : void 0) ?? settings.defaultRule;
  }
  instanceKey("chatgpt-booster:archive-updated", "chatgpt-booster:prod");
  instanceKey("chatgpt-booster:archive-contract-error", "chatgpt-booster:prod");
  instanceKey("chatgpt-booster:open-archive", "chatgpt-booster:prod");
  instanceKey("chatgpt-booster:open-capture-settings", "chatgpt-booster:prod");
  instanceKey("chatgpt-booster:history-loader-state", "chatgpt-booster:prod");
  instanceKey("chatgpt-booster:history-loader-start", "chatgpt-booster:prod");
  instanceKey("chatgpt-booster:history-loader-stop", "chatgpt-booster:prod");
  function normalizeCaptureRule(value) {
    return {
      enabled: value?.enabled === true,
      reasoning: typeof value?.reasoning === "boolean" ? value.reasoning : true,
      tools: typeof value?.tools === "boolean" ? value.tools : true,
      internal: typeof value?.internal === "boolean" ? value.internal : true
    };
  }
  function normalizeExportOptions(value) {
    return {
      format: typeof value?.format === "string" && /^[a-z0-9][a-z0-9._-]{0,63}$/i.test(value.format.trim()) ? value.format.trim() : DEFAULT_EXPORT_OPTIONS.format,
      level: value?.level === "custom" || value?.level === "full" ? value.level : "conversation",
      packaging: value?.packaging === "zip" || value?.packaging === "gzip" ? value.packaging : "none",
      reasoning: typeof value?.reasoning === "boolean" ? value.reasoning : true,
      tools: typeof value?.tools === "boolean" ? value.tools : true,
      internal: value?.internal === true,
      reasoningRecap: value?.reasoningRecap !== false,
      reasoningFull: value?.reasoningFull !== false,
      toolCalls: value?.toolCalls !== false,
      toolResults: value?.toolResults !== false,
      toolSourceContent: value?.toolSourceContent === true,
      modelEvidence: value?.modelEvidence !== false,
      dictationEditEvidence: value?.dictationEditEvidence === true,
      sourceRevisions: value?.sourceRevisions === true,
      attachmentMetadata: value?.attachmentMetadata === true,
      images: value?.images === true,
      files: value?.files === true
    };
  }
  const EMPTY_TRANSPORT_COUNTERS = {
    requestsSent: 0,
    responsesReceived: 0,
    messagesSent: 0,
    messagesReceived: 0,
    errors: 0,
    lastEventAt: null
  };
  function clampRatio(value, fallback = 0.65) {
    return typeof value === "number" && Number.isFinite(value) ? Math.max(0, Math.min(1, value)) : fallback;
  }
  const SETTINGS_SCHEMA_VERSION = 8;
  function clampWindowRatio(value, fallback, min, max) {
    return typeof value === "number" && Number.isFinite(value) ? Math.max(min, Math.min(max, value)) : fallback;
  }
  const DEFAULT_SETTINGS = {
    schemaVersion: SETTINGS_SCHEMA_VERSION,
    enabled: true,
    language: "auto",
    features: {
      messageMetadata: true,
      activityIndicator: true,
      toolInspector: true,
      requestTimer: true
    },
    historyLoader: {
      speedPxPerSecond: 2600,
      burstDurationMs: 650,
      pauseMs: 90
    },
    alerts: {
      responseCompleteSound: false,
      longRunningSound: false,
      longRunningThresholdMs: 12e4
    },
    monitoring: {
      intervalMs: 500
    },
    launcher: {
      x: null,
      y: null,
      side: "right",
      heightRatio: 0.65
    },
    observer: {
      enabled: false,
      captureBodies: false,
      maxBodyChars: 2048
    },
    telemetry: {
      enabled: false,
      endpoint: ""
    },
    archive: { defaultRule: { ...DEFAULT_CAPTURE_RULE }, projects: {}, conversations: {} },
    export: { ...DEFAULT_EXPORT_OPTIONS },
    exportOverrides: { projects: {}, conversations: {} },
    ui: {
      archiveStart: "latest",
      activeSection: "modules",
      telemetryExpanded: true,
      archiveWindow: {
        xRatio: 0.08,
        yRatio: 0.08,
        widthRatio: 0.72,
        heightRatio: 0.82,
        minimizedSide: "right",
        minimizedHeightRatio: 0.45
      }
    }
  };
  function normalizeSettings(value) {
    const incomingSchema = value?.schemaVersion ?? 0;
    return {
      ...DEFAULT_SETTINGS,
      ...value,
      schemaVersion: SETTINGS_SCHEMA_VERSION,
      language: value?.language ?? DEFAULT_SETTINGS.language,
      features: {
        ...DEFAULT_SETTINGS.features,
        ...value?.features
      },
      historyLoader: {
        speedPxPerSecond: clampWindowRatio(
          value?.historyLoader?.speedPxPerSecond,
          DEFAULT_SETTINGS.historyLoader.speedPxPerSecond,
          600,
          6e3
        ),
        burstDurationMs: clampWindowRatio(
          value?.historyLoader?.burstDurationMs,
          DEFAULT_SETTINGS.historyLoader.burstDurationMs,
          180,
          1600
        ),
        pauseMs: clampWindowRatio(
          value?.historyLoader?.pauseMs,
          DEFAULT_SETTINGS.historyLoader.pauseMs,
          20,
          1200
        )
      },
      alerts: {
        responseCompleteSound: value?.alerts?.responseCompleteSound ?? DEFAULT_SETTINGS.alerts.responseCompleteSound,
        longRunningSound: value?.alerts?.longRunningSound ?? DEFAULT_SETTINGS.alerts.longRunningSound,
        longRunningThresholdMs: clampWindowRatio(
          value?.alerts?.longRunningThresholdMs,
          DEFAULT_SETTINGS.alerts.longRunningThresholdMs,
          15e3,
          30 * 6e4
        )
      },
      monitoring: {
        intervalMs: clampWindowRatio(
          value?.monitoring?.intervalMs,
          DEFAULT_SETTINGS.monitoring.intervalMs,
          100,
          1e4
        )
      },
      launcher: {
        ...DEFAULT_SETTINGS.launcher,
        // Schema < 3 stored absolute viewport pixels. They are resolution-specific,
        // so migration intentionally discards them instead of pretending they are portable.
        x: null,
        y: null,
        side: incomingSchema >= 3 && value?.launcher?.side === "left" ? "left" : DEFAULT_SETTINGS.launcher.side,
        heightRatio: incomingSchema >= 3 ? clampRatio(value?.launcher?.heightRatio) : DEFAULT_SETTINGS.launcher.heightRatio
      },
      observer: {
        ...DEFAULT_SETTINGS.observer,
        ...value?.observer,
        enabled: incomingSchema >= 5 ? value?.observer?.enabled ?? DEFAULT_SETTINGS.observer.enabled : value && (value.observer?.captureBodies === true || value.telemetry?.enabled === true) ? value.observer?.enabled ?? true : false
      },
      telemetry: {
        ...DEFAULT_SETTINGS.telemetry,
        ...value?.telemetry,
        endpoint: incomingSchema < 2 ? DEFAULT_SETTINGS.telemetry.endpoint : value?.telemetry?.endpoint ?? DEFAULT_SETTINGS.telemetry.endpoint
      },
      archive: {
        defaultRule: normalizeCaptureRule(value?.archive?.defaultRule),
        projects: mergeCaptureRules({}, value?.archive?.projects),
        conversations: mergeCaptureRules({}, value?.archive?.conversations)
      },
      export: normalizeExportOptions(value?.export),
      exportOverrides: normalizeExportOverrides(value?.exportOverrides),
      ui: {
        ...DEFAULT_SETTINGS.ui,
        ...value?.ui,
        archiveStart: value?.ui?.archiveStart === "first" ? "first" : "latest",
        archiveWindow: {
          ...DEFAULT_SETTINGS.ui.archiveWindow,
          ...value?.ui?.archiveWindow,
          xRatio: clampWindowRatio(
            value?.ui?.archiveWindow?.xRatio,
            DEFAULT_SETTINGS.ui.archiveWindow.xRatio,
            0,
            0.95
          ),
          yRatio: clampWindowRatio(
            value?.ui?.archiveWindow?.yRatio,
            DEFAULT_SETTINGS.ui.archiveWindow.yRatio,
            0,
            0.95
          ),
          widthRatio: clampWindowRatio(
            value?.ui?.archiveWindow?.widthRatio,
            DEFAULT_SETTINGS.ui.archiveWindow.widthRatio,
            0.32,
            0.96
          ),
          heightRatio: clampWindowRatio(
            value?.ui?.archiveWindow?.heightRatio,
            DEFAULT_SETTINGS.ui.archiveWindow.heightRatio,
            0.4,
            0.96
          ),
          minimizedSide: value?.ui?.archiveWindow?.minimizedSide === "left" ? "left" : "right",
          minimizedHeightRatio: clampRatio(value?.ui?.archiveWindow?.minimizedHeightRatio)
        }
      }
    };
  }
  function snapshotSettings(value) {
    const normalized = normalizeSettings(value);
    return {
      schemaVersion: SETTINGS_SCHEMA_VERSION,
      enabled: normalized.enabled,
      language: normalized.language,
      features: {
        messageMetadata: normalized.features.messageMetadata,
        activityIndicator: normalized.features.activityIndicator,
        toolInspector: normalized.features.toolInspector,
        requestTimer: normalized.features.requestTimer
      },
      historyLoader: { ...normalized.historyLoader },
      alerts: { ...normalized.alerts },
      monitoring: { ...normalized.monitoring },
      launcher: {
        x: normalized.launcher.x,
        y: normalized.launcher.y,
        side: normalized.launcher.side,
        heightRatio: normalized.launcher.heightRatio
      },
      observer: {
        enabled: normalized.observer.enabled,
        captureBodies: normalized.observer.captureBodies,
        maxBodyChars: normalized.observer.maxBodyChars
      },
      telemetry: {
        enabled: normalized.telemetry.enabled,
        endpoint: normalized.telemetry.endpoint
      },
      archive: {
        defaultRule: { ...normalized.archive.defaultRule },
        projects: Object.fromEntries(
          Object.entries(normalized.archive.projects).map(([id, rule]) => [id, { ...rule }])
        ),
        conversations: Object.fromEntries(
          Object.entries(normalized.archive.conversations).map(([id, rule]) => [id, { ...rule }])
        )
      },
      export: { ...normalized.export },
      exportOverrides: {
        projects: Object.fromEntries(
          Object.entries(normalized.exportOverrides.projects).map(([key, value2]) => [
            key,
            { ...value2 }
          ])
        ),
        conversations: Object.fromEntries(
          Object.entries(normalized.exportOverrides.conversations).map(([key, value2]) => [
            key,
            { ...value2 }
          ])
        )
      },
      ui: {
        archiveStart: normalized.ui.archiveStart,
        activeSection: normalized.ui.activeSection,
        telemetryExpanded: normalized.ui.telemetryExpanded,
        archiveWindow: { ...normalized.ui.archiveWindow }
      }
    };
  }
  function mergeExportOverrides(current, patch) {
    if (!patch) return current;
    const merge = (previous, incoming) => {
      const result = { ...previous };
      for (const [key, update] of Object.entries(incoming ?? {})) {
        if (update === null) delete result[key];
        else result[key] = { ...previous[key], ...update };
      }
      return result;
    };
    return normalizeExportOverrides({
      projects: merge(current.projects, patch.projects),
      conversations: merge(current.conversations, patch.conversations)
    });
  }
  function mergeSettings(current, patch) {
    const normalized = normalizeSettings(current);
    return normalizeSettings({
      ...normalized,
      ...patch,
      features: {
        ...normalized.features,
        ...patch.features
      },
      historyLoader: {
        ...normalized.historyLoader,
        ...patch.historyLoader
      },
      alerts: {
        ...normalized.alerts,
        ...patch.alerts
      },
      monitoring: {
        ...normalized.monitoring,
        ...patch.monitoring
      },
      launcher: {
        ...normalized.launcher,
        ...patch.launcher
      },
      observer: {
        ...normalized.observer,
        ...patch.observer
      },
      telemetry: {
        ...normalized.telemetry,
        ...patch.telemetry
      },
      archive: {
        defaultRule: { ...normalized.archive.defaultRule, ...patch.archive?.defaultRule },
        projects: mergeCaptureRules(normalized.archive.projects, patch.archive?.projects),
        conversations: mergeCaptureRules(
          normalized.archive.conversations,
          patch.archive?.conversations
        )
      },
      export: { ...normalized.export, ...patch.export },
      exportOverrides: mergeExportOverrides(normalized.exportOverrides, patch.exportOverrides),
      ui: {
        ...normalized.ui,
        ...patch.ui,
        archiveWindow: {
          ...normalized.ui.archiveWindow,
          ...patch.ui?.archiveWindow
        }
      }
    });
  }
  instanceKey("chatgpt-booster:open-settings", "chatgpt-booster:prod");
  function mergeCaptureRules(current, patch) {
    const entries = new Map(Object.entries(current));
    for (const [id, rule] of Object.entries(patch ?? {})) {
      if (rule === null) entries.delete(id);
      else if (rule && typeof rule === "object") entries.set(id, normalizeCaptureRule(rule));
    }
    return Object.fromEntries(entries);
  }
  const BOOSTER_BASE_VERSION = "2.0.3";
  const injectedVersion = "2.0.3".trim();
  const BOOSTER_BUILD_VERSION = injectedVersion || BOOSTER_BASE_VERSION;
  const BOOSTER_VERSION = BOOSTER_BUILD_VERSION;
  const toKebabCase = (string) => string.replace(/([a-z0-9])([A-Z])/g, "$1-$2").toLowerCase();
  const toCamelCase = (string) => string.replace(
    /^([A-Z])|[\s-_]+(\w)/g,
    (match, p1, p2) => p2 ? p2.toUpperCase() : p1.toLowerCase()
  );
  const toPascalCase = (string) => {
    const camelCase = toCamelCase(string);
    return camelCase.charAt(0).toUpperCase() + camelCase.slice(1);
  };
  const mergeClasses = (...classes) => classes.filter((className, index, array) => {
    return Boolean(className) && className.trim() !== "" && array.indexOf(className) === index;
  }).join(" ").trim();
  const isEmptyString = (value) => value === "";
  var defaultAttributes = {
    xmlns: "http://www.w3.org/2000/svg",
    width: 24,
    height: 24,
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    "stroke-width": 2,
    "stroke-linecap": "round",
    "stroke-linejoin": "round"
  };
  const Icon = ({
    name,
    iconNode,
    absoluteStrokeWidth,
    "absolute-stroke-width": absoluteStrokeWidthKebabCase,
    strokeWidth,
    "stroke-width": strokeWidthKebabCase,
    size = defaultAttributes.width,
    color = defaultAttributes.stroke,
    ...props
  }, { slots }) => {
    return h(
      "svg",
      {
        ...defaultAttributes,
        ...props,
        width: size,
        height: size,
        stroke: color,
        "stroke-width": isEmptyString(absoluteStrokeWidth) || isEmptyString(absoluteStrokeWidthKebabCase) || absoluteStrokeWidth === true || absoluteStrokeWidthKebabCase === true ? Number(strokeWidth || strokeWidthKebabCase || defaultAttributes["stroke-width"]) * 24 / Number(size) : strokeWidth || strokeWidthKebabCase || defaultAttributes["stroke-width"],
        class: mergeClasses(
          "lucide",
          props.class,
          ...name ? [`lucide-${toKebabCase(toPascalCase(name))}-icon`, `lucide-${toKebabCase(name)}`] : ["lucide-icon"]
        )
      },
      [...iconNode.map((child) => h(...child)), ...slots.default ? [slots.default()] : []]
    );
  };
  const createLucideIcon = (iconName, iconNode) => (props, { slots, attrs }) => h(
    Icon,
    {
      ...attrs,
      ...props,
      iconNode,
      name: iconName
    },
    slots
  );
  const ShieldCheck = createLucideIcon("shield-check", [
    [
      "path",
      {
        d: "M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z",
        key: "oel41y"
      }
    ],
    ["path", { d: "m9 12 2 2 4-4", key: "dzmm74" }]
  ]);
  const X = createLucideIcon("x", [
    ["path", { d: "M18 6 6 18", key: "1bl5f8" }],
    ["path", { d: "m6 6 12 12", key: "d8bk6v" }]
  ]);
  const ChevronDown = createLucideIcon("chevron-down", [
    ["path", { d: "m6 9 6 6 6-6", key: "qrunsl" }]
  ]);
  const Wrench = createLucideIcon("wrench", [
    [
      "path",
      {
        d: "M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.106-3.105c.32-.322.863-.22.983.218a6 6 0 0 1-8.259 7.057l-7.91 7.91a1 1 0 0 1-2.999-3l7.91-7.91a6 6 0 0 1 7.057-8.259c.438.12.54.662.219.984z",
        key: "1ngwbx"
      }
    ]
  ]);
  const _hoisted_1$3 = ["aria-label"];
  const _sfc_main$5 = /* @__PURE__ */ defineComponent({
    __name: "ModalSurface",
    props: {
      label: {},
      wide: { type: Boolean }
    },
    emits: ["close"],
    setup(__props, { emit: __emit }) {
      const props = __props;
      const emit2 = __emit;
      const root = /* @__PURE__ */ ref();
      let restore = null;
      function key(event) {
        if (event.key === "Escape") {
          event.stopPropagation();
          event.preventDefault();
          emit2("close");
          return;
        }
        if (event.key !== "Tab" || !root.value) return;
        const items = [...root.value.querySelectorAll('button:not(:disabled),input:not(:disabled),select:not(:disabled),textarea:not(:disabled),[tabindex="0"]')].filter((item) => item.getClientRects().length);
        const first = items[0], last = items.at(-1);
        const active = root.value.getRootNode().activeElement;
        if (!first || !last) {
          event.preventDefault();
          root.value.focus();
          return;
        }
        if (event.shiftKey && (active === first || active === root.value)) {
          event.preventDefault();
          last.focus();
        } else if (!event.shiftKey && (active === last || active === root.value)) {
          event.preventDefault();
          first.focus();
        }
      }
      onMounted(async () => {
        const shadow = root.value?.getRootNode();
        restore = shadow?.activeElement;
        await nextTick();
        root.value?.focus();
      });
      onBeforeUnmount(() => {
        if (restore?.isConnected) restore.focus();
      });
      return (_ctx, _cache) => {
        return openBlock(), createElementBlock("div", {
          class: "booster-modal-backdrop",
          onClick: _cache[0] || (_cache[0] = withModifiers(($event) => emit2("close"), ["self"]))
        }, [
          createBaseVNode("section", {
            ref_key: "root",
            ref: root,
            tabindex: "-1",
            role: "dialog",
            "aria-modal": "true",
            "aria-label": props.label,
            class: normalizeClass(["booster-dialog", { "booster-dialog-wide": __props.wide }]),
            onKeydown: key
          }, [
            renderSlot(_ctx.$slots, "default")
          ], 42, _hoisted_1$3)
        ]);
      };
    }
  });
  const Clock3 = createLucideIcon("clock-3", [
    ["path", { d: "M12 6v6h4", key: "135r8i" }],
    ["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }]
  ]);
  var lib = {};
  var gitgraph = {};
  var branch = {};
  var branchUserApi = {};
  var commit = {};
  var tag = {};
  var template = {};
  var utils = {};
  var orientation = {};
  var hasRequiredOrientation;
  function requireOrientation() {
    if (hasRequiredOrientation) return orientation;
    hasRequiredOrientation = 1;
    (function(exports) {
      Object.defineProperty(exports, "__esModule", { value: true });
      (function(Orientation) {
        Orientation["VerticalReverse"] = "vertical-reverse";
        Orientation["Horizontal"] = "horizontal";
        Orientation["HorizontalReverse"] = "horizontal-reverse";
      })(exports.Orientation || (exports.Orientation = {}));
    })(orientation);
    return orientation;
  }
  var hasRequiredUtils;
  function requireUtils() {
    if (hasRequiredUtils) return utils;
    hasRequiredUtils = 1;
    Object.defineProperty(utils, "__esModule", { value: true });
    const orientation_1 = requireOrientation();
    function booleanOptionOr(value, defaultValue) {
      return typeof value === "boolean" ? value : defaultValue;
    }
    utils.booleanOptionOr = booleanOptionOr;
    function numberOptionOr(value, defaultValue) {
      return typeof value === "number" ? value : defaultValue;
    }
    utils.numberOptionOr = numberOptionOr;
    function pick(obj, paths) {
      return Object.assign({}, paths.reduce((mem, key) => Object.assign({}, mem, { [key]: obj[key] }), {}));
    }
    utils.pick = pick;
    function debug(commits, paths) {
      console.log(JSON.stringify(commits.map((commit2) => pick(commit2, paths)), null, 2));
    }
    utils.debug = debug;
    function isUndefined(obj) {
      return obj === void 0;
    }
    utils.isUndefined = isUndefined;
    function withoutUndefinedKeys(obj = {}) {
      return Object.keys(obj).reduce((mem, key) => isUndefined(obj[key]) ? mem : Object.assign({}, mem, { [key]: obj[key] }), {});
    }
    utils.withoutUndefinedKeys = withoutUndefinedKeys;
    function arrowSvgPath(graph, parent, commit2) {
      const commitRadius = commit2.style.dot.size;
      const size = graph.template.arrow.size;
      const h2 = commitRadius + graph.template.arrow.offset;
      const delta = Math.PI / 7;
      const alpha = getAlpha(graph, parent, commit2);
      const x1 = h2 * Math.cos(alpha);
      const y1 = h2 * Math.sin(alpha);
      const x2 = (h2 + size) * Math.cos(alpha - delta);
      const y2 = (h2 + size) * Math.sin(alpha - delta);
      const x3 = (h2 + size / 2) * Math.cos(alpha);
      const y3 = (h2 + size / 2) * Math.sin(alpha);
      const x4 = (h2 + size) * Math.cos(alpha + delta);
      const y4 = (h2 + size) * Math.sin(alpha + delta);
      return `M${x1},${y1} L${x2},${y2} Q${x3},${y3} ${x4},${y4} L${x4},${y4}`;
    }
    utils.arrowSvgPath = arrowSvgPath;
    function getAlpha(graph, parent, commit2) {
      const deltaX = parent.x - commit2.x;
      const deltaY = parent.y - commit2.y;
      const commitSpacing = graph.template.commit.spacing;
      let alphaY;
      let alphaX;
      switch (graph.orientation) {
        case orientation_1.Orientation.Horizontal:
          alphaY = deltaY;
          alphaX = -commitSpacing;
          break;
        case orientation_1.Orientation.HorizontalReverse:
          alphaY = deltaY;
          alphaX = commitSpacing;
          break;
        case orientation_1.Orientation.VerticalReverse:
          alphaY = -commitSpacing;
          alphaX = deltaX;
          break;
        default:
          alphaY = commitSpacing;
          alphaX = deltaX;
          break;
      }
      if (graph.isVertical) {
        if (Math.abs(deltaY) > commitSpacing)
          alphaX = 0;
      } else {
        if (Math.abs(deltaX) > commitSpacing)
          alphaY = 0;
      }
      if (graph.reverseArrow) {
        alphaY *= -1;
        alphaX *= -1;
      }
      return Math.atan2(alphaY, alphaX);
    }
    return utils;
  }
  var hasRequiredTemplate;
  function requireTemplate() {
    if (hasRequiredTemplate) return template;
    hasRequiredTemplate = 1;
    (function(exports) {
      Object.defineProperty(exports, "__esModule", { value: true });
      const utils_1 = requireUtils();
      var MergeStyle;
      (function(MergeStyle2) {
        MergeStyle2["Bezier"] = "bezier";
        MergeStyle2["Straight"] = "straight";
      })(MergeStyle || (MergeStyle = {}));
      exports.MergeStyle = MergeStyle;
      exports.DEFAULT_FONT = "normal 12pt Calibri";
      class Template {
        constructor(options) {
          options.branch = options.branch || {};
          options.branch.label = options.branch.label || {};
          options.arrow = options.arrow || {};
          options.commit = options.commit || {};
          options.commit.dot = options.commit.dot || {};
          options.commit.message = options.commit.message || {};
          this.colors = options.colors || ["#000000"];
          this.branch = {
            color: options.branch.color,
            lineWidth: options.branch.lineWidth || 2,
            mergeStyle: options.branch.mergeStyle || MergeStyle.Bezier,
            spacing: utils_1.numberOptionOr(options.branch.spacing, 20),
            label: {
              display: utils_1.booleanOptionOr(options.branch.label.display, true),
              color: options.branch.label.color || options.commit.color,
              strokeColor: options.branch.label.strokeColor || options.commit.color,
              bgColor: options.branch.label.bgColor || "white",
              font: options.branch.label.font || options.commit.message.font || exports.DEFAULT_FONT,
              borderRadius: utils_1.numberOptionOr(options.branch.label.borderRadius, 10)
            }
          };
          this.arrow = {
            size: options.arrow.size || null,
            color: options.arrow.color || null,
            offset: options.arrow.offset || 2
          };
          this.commit = {
            color: options.commit.color,
            spacing: utils_1.numberOptionOr(options.commit.spacing, 25),
            hasTooltipInCompactMode: utils_1.booleanOptionOr(options.commit.hasTooltipInCompactMode, true),
            dot: {
              color: options.commit.dot.color || options.commit.color,
              size: options.commit.dot.size || 3,
              strokeWidth: utils_1.numberOptionOr(options.commit.dot.strokeWidth, 0),
              strokeColor: options.commit.dot.strokeColor,
              font: options.commit.dot.font || options.commit.message.font || "normal 10pt Calibri"
            },
            message: {
              display: utils_1.booleanOptionOr(options.commit.message.display, true),
              displayAuthor: utils_1.booleanOptionOr(options.commit.message.displayAuthor, true),
              displayHash: utils_1.booleanOptionOr(options.commit.message.displayHash, true),
              color: options.commit.message.color || options.commit.color,
              font: options.commit.message.font || exports.DEFAULT_FONT
            }
          };
          this.tag = options.tag || {};
        }
      }
      exports.Template = Template;
      const blackArrowTemplate = new Template({
        colors: ["#6963FF", "#47E8D4", "#6BDB52", "#E84BA5", "#FFA657"],
        branch: {
          color: "#000000",
          lineWidth: 4,
          spacing: 50,
          mergeStyle: MergeStyle.Straight
        },
        commit: {
          spacing: 60,
          dot: {
            size: 16,
            strokeColor: "#000000",
            strokeWidth: 4
          },
          message: {
            color: "black"
          }
        },
        arrow: {
          size: 16,
          offset: -1.5
        }
      });
      exports.blackArrowTemplate = blackArrowTemplate;
      const metroTemplate = new Template({
        colors: ["#979797", "#008fb5", "#f1c109"],
        branch: {
          lineWidth: 10,
          spacing: 50
        },
        commit: {
          spacing: 80,
          dot: {
            size: 14
          },
          message: {
            font: "normal 14pt Arial"
          }
        }
      });
      exports.metroTemplate = metroTemplate;
      var TemplateName;
      (function(TemplateName2) {
        TemplateName2["Metro"] = "metro";
        TemplateName2["BlackArrow"] = "blackarrow";
      })(TemplateName || (TemplateName = {}));
      exports.TemplateName = TemplateName;
      function templateExtend(selectedTemplate, options) {
        const template2 = getTemplate(selectedTemplate);
        if (!options.branch)
          options.branch = {};
        if (!options.commit)
          options.commit = {};
        return {
          colors: options.colors || template2.colors,
          arrow: Object.assign({}, template2.arrow, options.arrow),
          branch: Object.assign({}, template2.branch, options.branch, { label: Object.assign({}, template2.branch.label, options.branch.label) }),
          commit: Object.assign({}, template2.commit, options.commit, { dot: Object.assign({}, template2.commit.dot, options.commit.dot), message: Object.assign({}, template2.commit.message, options.commit.message) }),
          tag: Object.assign({}, template2.tag, options.tag)
        };
      }
      exports.templateExtend = templateExtend;
      function getTemplate(template2) {
        if (!template2)
          return metroTemplate;
        if (typeof template2 === "string") {
          return {
            [TemplateName.BlackArrow]: blackArrowTemplate,
            [TemplateName.Metro]: metroTemplate
          }[template2];
        }
        return template2;
      }
      exports.getTemplate = getTemplate;
    })(template);
    return template;
  }
  var hasRequiredTag;
  function requireTag() {
    if (hasRequiredTag) return tag;
    hasRequiredTag = 1;
    Object.defineProperty(tag, "__esModule", { value: true });
    const template_1 = requireTemplate();
    const utils_1 = requireUtils();
    class Tag {
      constructor(name, style, render, commitStyle) {
        this.name = name;
        this.tagStyle = style;
        this.commitStyle = commitStyle;
        this.render = render;
      }
      /**
       * Style
       */
      get style() {
        return {
          strokeColor: this.tagStyle.strokeColor || this.commitStyle.color,
          bgColor: this.tagStyle.bgColor || this.commitStyle.color,
          color: this.tagStyle.color || "white",
          font: this.tagStyle.font || this.commitStyle.message.font || template_1.DEFAULT_FONT,
          borderRadius: utils_1.numberOptionOr(this.tagStyle.borderRadius, 10),
          pointerWidth: utils_1.numberOptionOr(this.tagStyle.pointerWidth, 12)
        };
      }
    }
    tag.Tag = Tag;
    return tag;
  }
  var hasRequiredCommit;
  function requireCommit() {
    if (hasRequiredCommit) return commit;
    hasRequiredCommit = 1;
    Object.defineProperty(commit, "__esModule", { value: true });
    const tag_1 = requireTag();
    const getRandomHash = () => (Math.random().toString(16).substring(3) + Math.random().toString(16).substring(3) + Math.random().toString(16).substring(3) + Math.random().toString(16).substring(3)).substring(0, 40);
    class Commit {
      constructor(options) {
        this.refs = [];
        this.x = 0;
        this.y = 0;
        let name, email;
        try {
          [, name, email] = options.author.match(/(.*) <(.*)>/);
        } catch (e) {
          [name, email] = [options.author, ""];
        }
        this.author = { name, email, timestamp: Date.now() };
        this.committer = { name, email, timestamp: Date.now() };
        this.subject = options.subject;
        this.body = options.body || "";
        this.hash = options.hash || getRandomHash();
        this.hashAbbrev = this.hash.substring(0, 7);
        this.parents = options.parents ? options.parents : [];
        this.parentsAbbrev = this.parents.map((commit2) => commit2.substring(0, 7));
        this.style = Object.assign({}, options.style, { message: Object.assign({}, options.style.message), dot: Object.assign({}, options.style.dot) });
        this.dotText = options.dotText;
        this.onClick = () => options.onClick ? options.onClick(this) : void 0;
        this.onMessageClick = () => options.onMessageClick ? options.onMessageClick(this) : void 0;
        this.onMouseOver = () => options.onMouseOver ? options.onMouseOver(this) : void 0;
        this.onMouseOut = () => options.onMouseOut ? options.onMouseOut(this) : void 0;
        this.renderDot = options.renderDot;
        this.renderMessage = options.renderMessage;
        this.renderTooltip = options.renderTooltip;
      }
      /**
       * Message
       */
      get message() {
        let message = "";
        if (this.style.message.displayHash) {
          message += `${this.hashAbbrev} `;
        }
        message += this.subject;
        if (this.style.message.displayAuthor) {
          message += ` - ${this.author.name} <${this.author.email}>`;
        }
        return message;
      }
      /**
       * Branch that should be rendered
       */
      get branchToDisplay() {
        return this.branches ? this.branches[0] : "";
      }
      setRefs(refs2) {
        this.refs = refs2.getNames(this.hash);
        return this;
      }
      setTags(tags, getTagStyle, getTagRender) {
        this.tags = tags.getNames(this.hash).map((name) => new tag_1.Tag(name, getTagStyle(name), getTagRender(name), this.style));
        return this;
      }
      setBranches(branches) {
        this.branches = branches;
        return this;
      }
      setPosition({ x, y }) {
        this.x = x;
        this.y = y;
        return this;
      }
      withDefaultColor(color) {
        const newStyle = Object.assign({}, this.style, { dot: Object.assign({}, this.style.dot), message: Object.assign({}, this.style.message) });
        if (!newStyle.color)
          newStyle.color = color;
        if (!newStyle.dot.color)
          newStyle.dot.color = color;
        if (!newStyle.message.color)
          newStyle.message.color = color;
        const commit2 = this.cloneCommit();
        commit2.style = newStyle;
        return commit2;
      }
      /**
       * Ideally, we want Commit to be a [Value Object](https://martinfowler.com/bliki/ValueObject.html).
       * We started with a mutable class. So we'll refactor that little by little.
       * This private function is a helper to create a new Commit from existing one.
       */
      cloneCommit() {
        const commit2 = new Commit({
          author: `${this.author.name} <${this.author.email}>`,
          subject: this.subject,
          style: this.style,
          body: this.body,
          hash: this.hash,
          parents: this.parents,
          dotText: this.dotText,
          onClick: this.onClick,
          onMessageClick: this.onMessageClick,
          onMouseOver: this.onMouseOver,
          onMouseOut: this.onMouseOut,
          renderDot: this.renderDot,
          renderMessage: this.renderMessage,
          renderTooltip: this.renderTooltip
        });
        commit2.refs = this.refs;
        commit2.branches = this.branches;
        commit2.tags = this.tags;
        commit2.x = this.x;
        commit2.y = this.y;
        return commit2;
      }
    }
    commit.Commit = Commit;
    return commit;
  }
  var hasRequiredBranchUserApi;
  function requireBranchUserApi() {
    if (hasRequiredBranchUserApi) return branchUserApi;
    hasRequiredBranchUserApi = 1;
    var __rest = branchUserApi && branchUserApi.__rest || function(s, e) {
      var t = {};
      for (var p2 in s) if (Object.prototype.hasOwnProperty.call(s, p2) && e.indexOf(p2) < 0)
        t[p2] = s[p2];
      if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p2 = Object.getOwnPropertySymbols(s); i < p2.length; i++) {
          if (e.indexOf(p2[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p2[i]))
            t[p2[i]] = s[p2[i]];
        }
      return t;
    };
    Object.defineProperty(branchUserApi, "__esModule", { value: true });
    const commit_1 = requireCommit();
    const branch_1 = requireBranch();
    const utils_1 = requireUtils();
    class BranchUserApi {
      // tslint:enable:variable-name
      constructor(branch2, graph, onGraphUpdate) {
        this._branch = branch2;
        this.name = branch2.name;
        this._graph = graph;
        this._onGraphUpdate = onGraphUpdate;
      }
      branch(args) {
        if (this._branch.isDeleted() && !this._isReferenced()) {
          throw new Error(`Cannot branch from the deleted branch "${this.name}"`);
        }
        const options = typeof args === "string" ? { name: args } : args;
        options.from = this;
        return this._graph.createBranch(options).getUserApi();
      }
      commit(options) {
        if (this._branch.isDeleted() && !this._isReferenced()) {
          throw new Error(`Cannot commit on the deleted branch "${this.name}"`);
        }
        if (typeof options === "string")
          options = { subject: options };
        if (!options)
          options = {};
        this._commitWithParents(options, []);
        this._onGraphUpdate();
        return this;
      }
      /**
       * Delete the branch (as `git branch -d`)
       */
      delete() {
        if (this._graph.refs.getCommit("HEAD") === this._graph.refs.getCommit(this.name)) {
          throw new Error(`Cannot delete the checked out branch "${this.name}"`);
        }
        const branchCommits = (function* (graph, branch2) {
          const lookupCommit = (graph2, commitHash) => {
            return graph2.commits.find(({ hash }) => hash === commitHash);
          };
          let currentCommit = lookupCommit(graph, graph.refs.getCommit(branch2.name));
          while (currentCommit && currentCommit.hash !== branch2.parentCommitHash) {
            yield currentCommit;
            currentCommit = lookupCommit(graph, currentCommit.parents[0]);
          }
          return;
        })(this._graph, this._branch);
        [...branchCommits].forEach((commit2) => {
          commit2.refs = commit2.refs.filter((branchName) => branchName !== this.name);
        });
        this._graph.refs.delete(this.name);
        this._graph.branches.delete(this.name);
        this._branch = branch_1.createDeletedBranch(this._graph, this._branch.style, () => {
        });
        this._onGraphUpdate();
        return this;
      }
      merge(...args) {
        if (this._branch.isDeleted() && !this._isReferenced()) {
          throw new Error(`Cannot merge to the deleted branch "${this.name}"`);
        }
        let options = args[0];
        if (!isBranchMergeOptions(options)) {
          options = {
            branch: args[0],
            fastForward: false,
            commitOptions: { subject: args[1] }
          };
        }
        const { branch: branch2, fastForward, commitOptions } = options;
        const branchName = typeof branch2 === "string" ? branch2 : branch2.name;
        const branchLastCommitHash = this._graph.refs.getCommit(branchName);
        if (!branchLastCommitHash) {
          throw new Error(`The branch called "${branchName}" is unknown`);
        }
        let canFastForward = false;
        if (fastForward) {
          const lastCommitHash = this._graph.refs.getCommit(this._branch.name);
          if (lastCommitHash) {
            canFastForward = this._areCommitsConnected(lastCommitHash, branchLastCommitHash);
          }
        }
        if (fastForward && canFastForward) {
          this._fastForwardTo(branchLastCommitHash);
        } else {
          this._commitWithParents(Object.assign({}, commitOptions, { subject: commitOptions && commitOptions.subject || `Merge branch ${branchName}` }), [branchLastCommitHash]);
        }
        this._onGraphUpdate();
        return this;
      }
      tag(options) {
        if (this._branch.isDeleted() && !this._isReferenced()) {
          throw new Error(`Cannot tag on the deleted branch "${this.name}"`);
        }
        if (typeof options === "string") {
          this._graph.getUserApi().tag({ name: options, ref: this._branch.name });
        } else {
          this._graph.getUserApi().tag(Object.assign({}, options, { ref: this._branch.name }));
        }
        return this;
      }
      /**
       * Checkout onto this branch and update "HEAD" in refs
       */
      checkout() {
        if (this._branch.isDeleted() && !this._isReferenced()) {
          throw new Error(`Cannot checkout the deleted branch "${this.name}"`);
        }
        const target = this._branch;
        const headCommit = this._graph.refs.getCommit(target.name);
        this._graph.currentBranch = target;
        if (headCommit) {
          this._graph.refs.set("HEAD", headCommit);
        }
        return this;
      }
      // tslint:disable:variable-name - Prefix `_` = explicitly private for JS users
      _commitWithParents(options, parents) {
        const parentOnSameBranch = this._graph.refs.getCommit(this._branch.name);
        if (parentOnSameBranch) {
          parents.unshift(parentOnSameBranch);
        } else if (this._branch.parentCommitHash) {
          parents.unshift(this._branch.parentCommitHash);
        }
        const { tag: tag2 } = options, commitOptions = __rest(options, ["tag"]);
        const commit2 = new commit_1.Commit(Object.assign({ hash: this._graph.generateCommitHash(), author: this._branch.commitDefaultOptions.author || this._graph.author, subject: this._branch.commitDefaultOptions.subject || this._graph.commitMessage }, commitOptions, { parents, style: this._getCommitStyle(options.style) }));
        if (parentOnSameBranch) {
          const parentRefs = this._graph.refs.getNames(parentOnSameBranch);
          parentRefs.forEach((ref2) => this._graph.refs.set(ref2, commit2.hash));
        } else {
          this._graph.refs.set(this._branch.name, commit2.hash);
        }
        this._graph.commits.push(commit2);
        this.checkout();
        if (tag2)
          this.tag(tag2);
      }
      _areCommitsConnected(parentCommitHash, childCommitHash) {
        const childCommit = this._graph.commits.find(({ hash }) => childCommitHash === hash);
        if (!childCommit)
          return false;
        const isFirstCommitOfGraph = childCommit.parents.length === 0;
        if (isFirstCommitOfGraph)
          return false;
        if (childCommit.parents.includes(parentCommitHash)) {
          return true;
        }
        return childCommit.parents.some((directParentHash) => this._areCommitsConnected(parentCommitHash, directParentHash));
      }
      _fastForwardTo(commitHash) {
        this._graph.refs.set(this._branch.name, commitHash);
      }
      _getCommitStyle(style = {}) {
        return Object.assign({}, utils_1.withoutUndefinedKeys(this._graph.template.commit), utils_1.withoutUndefinedKeys(this._branch.commitDefaultOptions.style), style, { message: Object.assign({}, utils_1.withoutUndefinedKeys(this._graph.template.commit.message), utils_1.withoutUndefinedKeys(this._branch.commitDefaultOptions.style.message), style.message, utils_1.withoutUndefinedKeys({
          display: this._graph.shouldDisplayCommitMessage && void 0
        })), dot: Object.assign({}, utils_1.withoutUndefinedKeys(this._graph.template.commit.dot), utils_1.withoutUndefinedKeys(this._branch.commitDefaultOptions.style.dot), style.dot) });
      }
      _isReferenced() {
        return this._graph.branches.has(this.name) || this._graph.refs.hasName(this.name) || this._graph.commits.reduce((allNames, { refs: refs2 }) => [...allNames, ...refs2], []).includes(this.name);
      }
    }
    branchUserApi.BranchUserApi = BranchUserApi;
    function isBranchMergeOptions(options) {
      return typeof options === "object" && !(options instanceof BranchUserApi);
    }
    return branchUserApi;
  }
  var hasRequiredBranch;
  function requireBranch() {
    if (hasRequiredBranch) return branch;
    hasRequiredBranch = 1;
    Object.defineProperty(branch, "__esModule", { value: true });
    const branch_user_api_1 = requireBranchUserApi();
    const DELETED_BRANCH_NAME = "";
    branch.DELETED_BRANCH_NAME = DELETED_BRANCH_NAME;
    class Branch {
      constructor(options) {
        this.gitgraph = options.gitgraph;
        this.name = options.name;
        this.style = options.style;
        this.parentCommitHash = options.parentCommitHash;
        this.commitDefaultOptions = options.commitDefaultOptions || { style: {} };
        this.onGraphUpdate = options.onGraphUpdate;
        this.renderLabel = options.renderLabel;
      }
      /**
       * Return the API to manipulate Gitgraph branch as a user.
       */
      getUserApi() {
        return new branch_user_api_1.BranchUserApi(this, this.gitgraph, this.onGraphUpdate);
      }
      /**
       * Return true if branch was deleted.
       */
      isDeleted() {
        return this.name === DELETED_BRANCH_NAME;
      }
    }
    branch.Branch = Branch;
    function createDeletedBranch(gitgraph2, style, onGraphUpdate) {
      return new Branch({
        name: DELETED_BRANCH_NAME,
        gitgraph: gitgraph2,
        style,
        onGraphUpdate
      });
    }
    branch.createDeletedBranch = createDeletedBranch;
    return branch;
  }
  var graphRows = {};
  var mode = {};
  var hasRequiredMode;
  function requireMode() {
    if (hasRequiredMode) return mode;
    hasRequiredMode = 1;
    Object.defineProperty(mode, "__esModule", { value: true });
    var Mode;
    (function(Mode2) {
      Mode2["Compact"] = "compact";
    })(Mode || (Mode = {}));
    mode.Mode = Mode;
    return mode;
  }
  var compact = {};
  var regular = {};
  var hasRequiredRegular;
  function requireRegular() {
    if (hasRequiredRegular) return regular;
    hasRequiredRegular = 1;
    Object.defineProperty(regular, "__esModule", { value: true });
    class RegularGraphRows {
      constructor(commits) {
        this.rows = /* @__PURE__ */ new Map();
        this.maxRowCache = void 0;
        this.computeRowsFromCommits(commits);
      }
      getRowOf(commitHash) {
        return this.rows.get(commitHash) || 0;
      }
      getMaxRow() {
        if (this.maxRowCache === void 0) {
          this.maxRowCache = uniq(Array.from(this.rows.values())).length - 1;
        }
        return this.maxRowCache;
      }
      computeRowsFromCommits(commits) {
        commits.forEach((commit2, i) => {
          this.rows.set(commit2.hash, i);
        });
        this.maxRowCache = void 0;
      }
    }
    regular.RegularGraphRows = RegularGraphRows;
    function uniq(array) {
      const set = /* @__PURE__ */ new Set();
      array.forEach((value) => set.add(value));
      return Array.from(set);
    }
    return regular;
  }
  var hasRequiredCompact;
  function requireCompact() {
    if (hasRequiredCompact) return compact;
    hasRequiredCompact = 1;
    Object.defineProperty(compact, "__esModule", { value: true });
    const regular_1 = requireRegular();
    class CompactGraphRows extends regular_1.RegularGraphRows {
      computeRowsFromCommits(commits) {
        commits.forEach((commit2, i) => {
          let newRow = i;
          const isFirstCommit = i === 0;
          if (!isFirstCommit) {
            const parentRow = this.getRowOf(commit2.parents[0]);
            const historyParent = commits[i - 1];
            newRow = Math.max(parentRow + 1, this.getRowOf(historyParent.hash));
            const isMergeCommit = commit2.parents.length > 1;
            if (isMergeCommit) {
              const mergeTargetParentRow = this.getRowOf(commit2.parents[1]);
              if (parentRow < mergeTargetParentRow)
                newRow++;
            }
          }
          this.rows.set(commit2.hash, newRow);
        });
      }
    }
    compact.CompactGraphRows = CompactGraphRows;
    return compact;
  }
  var hasRequiredGraphRows;
  function requireGraphRows() {
    if (hasRequiredGraphRows) return graphRows;
    hasRequiredGraphRows = 1;
    Object.defineProperty(graphRows, "__esModule", { value: true });
    const mode_1 = requireMode();
    const compact_1 = requireCompact();
    const regular_1 = requireRegular();
    graphRows.GraphRows = regular_1.RegularGraphRows;
    function createGraphRows(mode2, commits) {
      return mode2 === mode_1.Mode.Compact ? new compact_1.CompactGraphRows(commits) : new regular_1.RegularGraphRows(commits);
    }
    graphRows.createGraphRows = createGraphRows;
    return graphRows;
  }
  var branchesOrder = {};
  var hasRequiredBranchesOrder;
  function requireBranchesOrder() {
    if (hasRequiredBranchesOrder) return branchesOrder;
    hasRequiredBranchesOrder = 1;
    Object.defineProperty(branchesOrder, "__esModule", { value: true });
    class BranchesOrder {
      constructor(commits, colors, compareFunction) {
        this.branches = /* @__PURE__ */ new Set();
        this.colors = colors;
        commits.forEach((commit2) => this.branches.add(commit2.branchToDisplay));
        if (compareFunction) {
          this.branches = new Set(Array.from(this.branches).sort(compareFunction));
        }
      }
      /**
       * Return the order of the given branch name.
       *
       * @param branchName Name of the branch
       */
      get(branchName) {
        return Array.from(this.branches).findIndex((branch2) => branch2 === branchName);
      }
      /**
       * Return the color of the given branch.
       *
       * @param branchName Name of the branch
       */
      getColorOf(branchName) {
        return this.colors[this.get(branchName) % this.colors.length];
      }
    }
    branchesOrder.BranchesOrder = BranchesOrder;
    return branchesOrder;
  }
  var refs = {};
  var hasRequiredRefs;
  function requireRefs() {
    if (hasRequiredRefs) return refs;
    hasRequiredRefs = 1;
    Object.defineProperty(refs, "__esModule", { value: true });
    class Refs {
      constructor() {
        this.commitPerName = /* @__PURE__ */ new Map();
        this.namesPerCommit = /* @__PURE__ */ new Map();
      }
      /**
       * Set a new reference to a commit hash.
       *
       * @param name Name of the ref (ex: "master", "v1.0")
       * @param commitHash Commit hash
       */
      set(name, commitHash) {
        const prevCommitHash = this.commitPerName.get(name);
        if (prevCommitHash) {
          this.removeNameFrom(prevCommitHash, name);
        }
        this.addNameTo(commitHash, name);
        this.addCommitTo(name, commitHash);
        return this;
      }
      /**
       * Delete a reference
       *
       * @param name Name of the reference
       */
      delete(name) {
        if (this.hasName(name)) {
          this.removeNameFrom(this.getCommit(name), name);
          this.commitPerName.delete(name);
        }
        return this;
      }
      /**
       * Get the commit hash associated with the given reference name.
       *
       * @param name Name of the ref
       */
      getCommit(name) {
        return this.commitPerName.get(name);
      }
      /**
       * Get the list of reference names associated with given commit hash.
       *
       * @param commitHash Commit hash
       */
      getNames(commitHash) {
        return this.namesPerCommit.get(commitHash) || [];
      }
      /**
       * Get all reference names known.
       */
      getAllNames() {
        return Array.from(this.commitPerName.keys());
      }
      /**
       * Returns true if given commit hash is referenced.
       *
       * @param commitHash Commit hash
       */
      hasCommit(commitHash) {
        return this.namesPerCommit.has(commitHash);
      }
      /**
       * Returns true if given reference name exists.
       *
       * @param name Name of the ref
       */
      hasName(name) {
        return this.commitPerName.has(name);
      }
      removeNameFrom(commitHash, nameToRemove) {
        const names = this.namesPerCommit.get(commitHash) || [];
        this.namesPerCommit.set(commitHash, names.filter((name) => name !== nameToRemove));
      }
      addNameTo(commitHash, nameToAdd) {
        const prevNames = this.namesPerCommit.get(commitHash) || [];
        this.namesPerCommit.set(commitHash, [...prevNames, nameToAdd]);
      }
      addCommitTo(name, commitHashToAdd) {
        this.commitPerName.set(name, commitHashToAdd);
      }
    }
    refs.Refs = Refs;
    return refs;
  }
  var branchesPaths = {};
  var hasRequiredBranchesPaths;
  function requireBranchesPaths() {
    if (hasRequiredBranchesPaths) return branchesPaths;
    hasRequiredBranchesPaths = 1;
    Object.defineProperty(branchesPaths, "__esModule", { value: true });
    const utils_1 = requireUtils();
    class BranchesPathsCalculator {
      constructor(commits, branches, commitSpacing, isGraphVertical, isGraphReverse, createDeletedBranch) {
        this.branchesPaths = /* @__PURE__ */ new Map();
        this.commits = commits;
        this.branches = branches;
        this.commitSpacing = commitSpacing;
        this.isGraphVertical = isGraphVertical;
        this.isGraphReverse = isGraphReverse;
        this.createDeletedBranch = createDeletedBranch;
      }
      /**
       * Compute branches paths for graph.
       */
      execute() {
        this.fromCommits();
        this.withMergeCommits();
        return this.smoothBranchesPaths();
      }
      /**
       * Initialize branches paths from calculator's commits.
       */
      fromCommits() {
        this.commits.forEach((commit2) => {
          let branch2 = this.branches.get(commit2.branchToDisplay);
          if (!branch2) {
            branch2 = this.getDeletedBranchInPath() || this.createDeletedBranch();
          }
          const path = [];
          const existingBranchPath = this.branchesPaths.get(branch2);
          const firstParentCommit = this.commits.find(({ hash }) => hash === commit2.parents[0]);
          if (existingBranchPath) {
            path.push(...existingBranchPath);
          } else if (firstParentCommit) {
            path.push({ x: firstParentCommit.x, y: firstParentCommit.y });
          }
          path.push({ x: commit2.x, y: commit2.y });
          this.branchesPaths.set(branch2, path);
        });
      }
      /**
       * Insert merge commits points into `branchesPaths`.
       *
       * @example
       *     // Before
       *     [
       *       { x: 0, y: 640 },
       *       { x: 50, y: 560 }
       *     ]
       *
       *     // After
       *     [
       *       { x: 0, y: 640 },
       *       { x: 50, y: 560 },
       *       { x: 50, y: 560, mergeCommit: true }
       *     ]
       */
      withMergeCommits() {
        const mergeCommits = this.commits.filter(({ parents }) => parents.length > 1);
        mergeCommits.forEach((mergeCommit) => {
          const parentOnOriginBranch = this.commits.find(({ hash }) => {
            return hash === mergeCommit.parents[1];
          });
          if (!parentOnOriginBranch)
            return;
          const originBranchName = parentOnOriginBranch.branches ? parentOnOriginBranch.branches[0] : "";
          let branch2 = this.branches.get(originBranchName);
          if (!branch2) {
            branch2 = this.getDeletedBranchInPath();
            if (!branch2) {
              return;
            }
          }
          const lastPoints = [...this.branchesPaths.get(branch2) || []];
          this.branchesPaths.set(branch2, [
            ...lastPoints,
            { x: mergeCommit.x, y: mergeCommit.y, mergeCommit: true }
          ]);
        });
      }
      /**
       * Retrieve deleted branch from calculator's branches paths.
       */
      getDeletedBranchInPath() {
        return Array.from(this.branchesPaths.keys()).find((branch2) => branch2.isDeleted());
      }
      /**
       * Smooth all paths by putting points on each row.
       */
      smoothBranchesPaths() {
        const branchesPaths2 = /* @__PURE__ */ new Map();
        this.branchesPaths.forEach((points, branch2) => {
          if (points.length <= 1) {
            branchesPaths2.set(branch2, [points]);
            return;
          }
          if (this.isGraphVertical) {
            points = points.sort((a, b) => a.y > b.y ? -1 : 1);
          } else {
            points = points.sort((a, b) => a.x > b.x ? 1 : -1);
          }
          if (this.isGraphReverse) {
            points = points.reverse();
          }
          const paths = points.reduce((mem, point, i) => {
            if (point.mergeCommit) {
              mem[mem.length - 1].push(utils_1.pick(point, ["x", "y"]));
              let j = i - 1;
              let previousPoint = points[j];
              while (j >= 0 && previousPoint.mergeCommit) {
                j--;
                previousPoint = points[j];
              }
              if (j >= 0) {
                mem.push([previousPoint]);
              }
            } else {
              mem[mem.length - 1].push(point);
            }
            return mem;
          }, [[]]);
          if (this.isGraphReverse) {
            paths.forEach((path) => path.reverse());
          }
          if (this.isGraphVertical) {
            paths.forEach((subPath) => {
              if (subPath.length <= 1)
                return;
              const firstPoint = subPath[0];
              const lastPoint = subPath[subPath.length - 1];
              const column = subPath[1].x;
              const branchSize = Math.round(Math.abs(firstPoint.y - lastPoint.y) / this.commitSpacing) - 1;
              const branchPoints = branchSize > 0 ? new Array(branchSize).fill(0).map((_, i) => ({
                x: column,
                y: subPath[0].y - this.commitSpacing * (i + 1)
              })) : [];
              const lastSubPaths = branchesPaths2.get(branch2) || [];
              branchesPaths2.set(branch2, [
                ...lastSubPaths,
                [firstPoint, ...branchPoints, lastPoint]
              ]);
            });
          } else {
            paths.forEach((subPath) => {
              if (subPath.length <= 1)
                return;
              const firstPoint = subPath[0];
              const lastPoint = subPath[subPath.length - 1];
              const column = subPath[1].y;
              const branchSize = Math.round(Math.abs(firstPoint.x - lastPoint.x) / this.commitSpacing) - 1;
              const branchPoints = branchSize > 0 ? new Array(branchSize).fill(0).map((_, i) => ({
                y: column,
                x: subPath[0].x + this.commitSpacing * (i + 1)
              })) : [];
              const lastSubPaths = branchesPaths2.get(branch2) || [];
              branchesPaths2.set(branch2, [
                ...lastSubPaths,
                [firstPoint, ...branchPoints, lastPoint]
              ]);
            });
          }
        });
        return branchesPaths2;
      }
    }
    branchesPaths.BranchesPathsCalculator = BranchesPathsCalculator;
    function toSvgPath(coordinates, isBezier, isVertical) {
      return coordinates.map((path) => "M" + path.map(({ x, y }, i, points) => {
        if (isBezier && points.length > 1 && (i === 1 || i === points.length - 1)) {
          const previous = points[i - 1];
          if (isVertical) {
            const middleY = (previous.y + y) / 2;
            return `C ${previous.x} ${middleY} ${x} ${middleY} ${x} ${y}`;
          } else {
            const middleX = (previous.x + x) / 2;
            return `C ${middleX} ${previous.y} ${middleX} ${y} ${x} ${y}`;
          }
        }
        return `L ${x} ${y}`;
      }).join(" ").slice(1)).join(" ");
    }
    branchesPaths.toSvgPath = toSvgPath;
    return branchesPaths;
  }
  var gitgraphUserApi = {};
  var hasRequiredGitgraphUserApi;
  function requireGitgraphUserApi() {
    if (hasRequiredGitgraphUserApi) return gitgraphUserApi;
    hasRequiredGitgraphUserApi = 1;
    Object.defineProperty(gitgraphUserApi, "__esModule", { value: true });
    const commit_1 = requireCommit();
    const branch_1 = requireBranch();
    const refs_1 = requireRefs();
    class GitgraphUserApi {
      // tslint:enable:variable-name
      constructor(graph, onGraphUpdate) {
        this._graph = graph;
        this._onGraphUpdate = onGraphUpdate;
      }
      /**
       * Clear everything (as `rm -rf .git && git init`).
       */
      clear() {
        this._graph.refs = new refs_1.Refs();
        this._graph.tags = new refs_1.Refs();
        this._graph.commits = [];
        this._graph.branches = /* @__PURE__ */ new Map();
        this._graph.currentBranch = this._graph.createBranch("master");
        this._onGraphUpdate();
        return this;
      }
      commit(options) {
        this._graph.currentBranch.getUserApi().commit(options);
        return this;
      }
      branch(args) {
        return this._graph.createBranch(args).getUserApi();
      }
      tag(...args) {
        let name;
        let ref2;
        let style;
        let render;
        if (typeof args[0] === "string") {
          name = args[0];
          ref2 = args[1];
        } else {
          name = args[0].name;
          ref2 = args[0].ref;
          style = args[0].style;
          render = args[0].render;
        }
        if (!ref2) {
          const head = this._graph.refs.getCommit("HEAD");
          if (!head)
            return this;
          ref2 = head;
        }
        let commitHash;
        if (this._graph.refs.hasCommit(ref2)) {
          commitHash = ref2;
        }
        if (this._graph.refs.hasName(ref2)) {
          commitHash = this._graph.refs.getCommit(ref2);
        }
        if (!commitHash) {
          throw new Error(`The ref "${ref2}" does not exist`);
        }
        this._graph.tags.set(name, commitHash);
        this._graph.tagStyles[name] = style;
        this._graph.tagRenders[name] = render;
        this._onGraphUpdate();
        return this;
      }
      /**
       * Import a JSON.
       *
       * Data can't be typed since it comes from a JSON.
       * We validate input format and throw early if something is invalid.
       *
       * @experimental
       * @param data JSON from `git2json` output
       */
      import(data) {
        const invalidData = new Error("Only `git2json` format is supported for imported data.");
        if (!Array.isArray(data)) {
          throw invalidData;
        }
        const areDataValid = data.every((options) => {
          return typeof options === "object" && typeof options.author === "object" && Array.isArray(options.refs);
        });
        if (!areDataValid) {
          throw invalidData;
        }
        const commitOptionsList = data.map((options) => Object.assign({}, options, { style: Object.assign({}, this._graph.template.commit, { message: Object.assign({}, this._graph.template.commit.message, { display: this._graph.shouldDisplayCommitMessage }) }), author: `${options.author.name} <${options.author.email}>` })).reverse();
        this.clear();
        this._graph.commits = commitOptionsList.map((options) => new commit_1.Commit(options));
        commitOptionsList.forEach(({ refs: refs2, hash }) => {
          if (!refs2)
            return;
          if (!hash)
            return;
          const TAG_PREFIX = "tag: ";
          const tags = refs2.map((ref2) => ref2.split(TAG_PREFIX)).map(([_, tag2]) => tag2).filter((tag2) => typeof tag2 === "string");
          tags.forEach((tag2) => this._graph.tags.set(tag2, hash));
          refs2.filter((ref2) => !ref2.startsWith(TAG_PREFIX)).forEach((ref2) => this._graph.refs.set(ref2, hash));
        });
        const branches = this._getBranches();
        this._graph.commits.map((commit2) => this._withBranches(branches, commit2)).reduce((mem, commit2) => {
          if (!commit2.branches)
            return mem;
          commit2.branches.forEach((branch2) => mem.add(branch2));
          return mem;
        }, /* @__PURE__ */ new Set()).forEach((branch2) => this.branch(branch2));
        this._onGraphUpdate();
        return this;
      }
      // tslint:disable:variable-name - Prefix `_` = explicitly private for JS users
      // TODO: get rid of these duplicated private methods.
      //
      // These belong to Gitgraph. It is duplicated because of `import()`.
      // `import()` should use regular user API instead.
      _withBranches(branches, commit2) {
        let commitBranches = Array.from((branches.get(commit2.hash) || /* @__PURE__ */ new Set()).values());
        if (commitBranches.length === 0) {
          commitBranches = [branch_1.DELETED_BRANCH_NAME];
        }
        return commit2.setBranches(commitBranches);
      }
      _getBranches() {
        const result = /* @__PURE__ */ new Map();
        const queue2 = [];
        const branches = this._graph.refs.getAllNames().filter((name) => name !== "HEAD");
        branches.forEach((branch2) => {
          const commitHash = this._graph.refs.getCommit(branch2);
          if (commitHash) {
            queue2.push(commitHash);
          }
          while (queue2.length > 0) {
            const currentHash = queue2.pop();
            const current = this._graph.commits.find(({ hash }) => hash === currentHash);
            const prevBranches = result.get(currentHash) || /* @__PURE__ */ new Set();
            prevBranches.add(branch2);
            result.set(currentHash, prevBranches);
            if (current && current.parents && current.parents.length > 0) {
              queue2.push(current.parents[0]);
            }
          }
        });
        return result;
      }
    }
    gitgraphUserApi.GitgraphUserApi = GitgraphUserApi;
    return gitgraphUserApi;
  }
  var hasRequiredGitgraph;
  function requireGitgraph() {
    if (hasRequiredGitgraph) return gitgraph;
    hasRequiredGitgraph = 1;
    Object.defineProperty(gitgraph, "__esModule", { value: true });
    const branch_1 = requireBranch();
    const graph_rows_1 = requireGraphRows();
    const mode_1 = requireMode();
    const branches_order_1 = requireBranchesOrder();
    const template_1 = requireTemplate();
    const refs_1 = requireRefs();
    const branches_paths_1 = requireBranchesPaths();
    const utils_1 = requireUtils();
    const orientation_1 = requireOrientation();
    const gitgraph_user_api_1 = requireGitgraphUserApi();
    class GitgraphCore {
      constructor(options = {}) {
        this.refs = new refs_1.Refs();
        this.tags = new refs_1.Refs();
        this.tagStyles = {};
        this.tagRenders = {};
        this.commits = [];
        this.branches = /* @__PURE__ */ new Map();
        this.listeners = [];
        this.nextTimeoutId = null;
        this.template = template_1.getTemplate(options.template);
        this.currentBranch = this.createBranch("master");
        this.orientation = options.orientation;
        this.reverseArrow = utils_1.booleanOptionOr(options.reverseArrow, false);
        this.initCommitOffsetX = utils_1.numberOptionOr(options.initCommitOffsetX, 0);
        this.initCommitOffsetY = utils_1.numberOptionOr(options.initCommitOffsetY, 0);
        this.mode = options.mode;
        this.author = options.author || "Sergio Flores <saxo-guy@epic.com>";
        this.commitMessage = options.commitMessage || "He doesn't like George Michael! Boooo!";
        this.generateCommitHash = typeof options.generateCommitHash === "function" ? options.generateCommitHash : () => void 0;
        this.branchesOrderFunction = typeof options.compareBranchesOrder === "function" ? options.compareBranchesOrder : void 0;
        this.branchLabelOnEveryCommit = utils_1.booleanOptionOr(options.branchLabelOnEveryCommit, false);
      }
      get isHorizontal() {
        return this.orientation === orientation_1.Orientation.Horizontal || this.orientation === orientation_1.Orientation.HorizontalReverse;
      }
      get isVertical() {
        return !this.isHorizontal;
      }
      get isReverse() {
        return this.orientation === orientation_1.Orientation.HorizontalReverse || this.orientation === orientation_1.Orientation.VerticalReverse;
      }
      get shouldDisplayCommitMessage() {
        return !this.isHorizontal && this.mode !== mode_1.Mode.Compact;
      }
      /**
       * Return the API to manipulate Gitgraph as a user.
       * Rendering library should give that API to their consumer.
       */
      getUserApi() {
        return new gitgraph_user_api_1.GitgraphUserApi(this, () => this.next());
      }
      /**
       * Add a change listener.
       * It will be called any time the graph have changed (commit, merge…).
       *
       * @param listener A callback to be invoked on every change.
       * @returns A function to remove this change listener.
       */
      subscribe(listener) {
        this.listeners.push(listener);
        let isSubscribed = true;
        return () => {
          if (!isSubscribed)
            return;
          isSubscribed = false;
          const index = this.listeners.indexOf(listener);
          this.listeners.splice(index, 1);
        };
      }
      /**
       * Return all data required for rendering.
       * Rendering libraries will use this to implement their rendering strategy.
       */
      getRenderedData() {
        const commits = this.computeRenderedCommits();
        const branchesPaths2 = this.computeRenderedBranchesPaths(commits);
        const commitMessagesX = this.computeCommitMessagesX(branchesPaths2);
        this.computeBranchesColor(commits, branchesPaths2);
        return { commits, branchesPaths: branchesPaths2, commitMessagesX };
      }
      createBranch(args) {
        const defaultParentBranchName = "HEAD";
        let options = {
          gitgraph: this,
          name: "",
          parentCommitHash: this.refs.getCommit(defaultParentBranchName),
          style: this.template.branch,
          onGraphUpdate: () => this.next()
        };
        if (typeof args === "string") {
          options.name = args;
          options.parentCommitHash = this.refs.getCommit(defaultParentBranchName);
        } else {
          const parentBranchName = args.from ? args.from.name : defaultParentBranchName;
          const parentCommitHash = this.refs.getCommit(parentBranchName) || (this.refs.hasCommit(args.from) ? args.from : void 0);
          args.style = args.style || {};
          options = Object.assign({}, options, args, { parentCommitHash, style: Object.assign({}, options.style, args.style, { label: Object.assign({}, options.style.label, args.style.label) }) });
        }
        const branch2 = new branch_1.Branch(options);
        this.branches.set(branch2.name, branch2);
        return branch2;
      }
      /**
       * Return commits with data for rendering.
       */
      computeRenderedCommits() {
        const branches = this.getBranches();
        const reachableUnassociatedCommits = (() => {
          const unassociatedCommits = new Set(this.commits.reduce((commits, { hash }) => !branches.has(hash) ? [...commits, hash] : commits, []));
          const tipsOfMergedBranches = this.commits.reduce((tipsOfMergedBranches2, commit2) => commit2.parents.length > 1 ? [
            ...tipsOfMergedBranches2,
            ...commit2.parents.slice(1).map((parentHash) => this.commits.find(({ hash }) => parentHash === hash))
          ] : tipsOfMergedBranches2, []);
          const reachableCommits = /* @__PURE__ */ new Set();
          tipsOfMergedBranches.forEach((tip) => {
            let currentCommit = tip;
            while (currentCommit && unassociatedCommits.has(currentCommit.hash)) {
              reachableCommits.add(currentCommit.hash);
              currentCommit = currentCommit.parents.length > 0 ? this.commits.find(({ hash }) => currentCommit.parents[0] === hash) : void 0;
            }
          });
          return reachableCommits;
        })();
        const commitsToRender = this.commits.filter(({ hash }) => branches.has(hash) || reachableUnassociatedCommits.has(hash));
        const commitsWithBranches = commitsToRender.map((commit2) => this.withBranches(branches, commit2));
        const rows = graph_rows_1.createGraphRows(this.mode, commitsToRender);
        const branchesOrder2 = new branches_order_1.BranchesOrder(commitsWithBranches, this.template.colors, this.branchesOrderFunction);
        return commitsWithBranches.map((commit2) => commit2.setRefs(this.refs)).map((commit2) => this.withPosition(rows, branchesOrder2, commit2)).map((commit2) => commit2.withDefaultColor(this.getBranchDefaultColor(branchesOrder2, commit2.branchToDisplay))).map((commit2) => commit2.setTags(this.tags, (name) => Object.assign({}, this.tagStyles[name], this.template.tag), (name) => this.tagRenders[name]));
      }
      /**
       * Return branches paths with all data required for rendering.
       *
       * @param commits List of commits with rendering data computed
       */
      computeRenderedBranchesPaths(commits) {
        return new branches_paths_1.BranchesPathsCalculator(commits, this.branches, this.template.commit.spacing, this.isVertical, this.isReverse, () => branch_1.createDeletedBranch(this, this.template.branch, () => this.next())).execute();
      }
      /**
       * Set branches colors based on branches paths.
       *
       * @param commits List of graph commits
       * @param branchesPaths Branches paths to be rendered
       */
      computeBranchesColor(commits, branchesPaths2) {
        const branchesOrder2 = new branches_order_1.BranchesOrder(commits, this.template.colors, this.branchesOrderFunction);
        Array.from(branchesPaths2).forEach(([branch2]) => {
          branch2.computedColor = branch2.style.color || this.getBranchDefaultColor(branchesOrder2, branch2.name);
        });
      }
      /**
       * Return commit messages X position for rendering.
       *
       * @param branchesPaths Branches paths to be rendered
       */
      computeCommitMessagesX(branchesPaths2) {
        const numberOfColumns = Array.from(branchesPaths2).length;
        return numberOfColumns * this.template.branch.spacing;
      }
      /**
       * Add `branches` property to commit.
       *
       * @param branches All branches mapped by commit hash
       * @param commit Commit
       */
      withBranches(branches, commit2) {
        let commitBranches = Array.from((branches.get(commit2.hash) || /* @__PURE__ */ new Set()).values());
        if (commitBranches.length === 0) {
          commitBranches = [branch_1.DELETED_BRANCH_NAME];
        }
        return commit2.setBranches(commitBranches);
      }
      /**
       * Get all branches from current commits.
       */
      getBranches() {
        const result = /* @__PURE__ */ new Map();
        const queue2 = [];
        const branches = this.refs.getAllNames().filter((name) => name !== "HEAD");
        branches.forEach((branch2) => {
          const commitHash = this.refs.getCommit(branch2);
          if (commitHash) {
            queue2.push(commitHash);
          }
          while (queue2.length > 0) {
            const currentHash = queue2.pop();
            const current = this.commits.find(({ hash }) => hash === currentHash);
            const prevBranches = result.get(currentHash) || /* @__PURE__ */ new Set();
            prevBranches.add(branch2);
            result.set(currentHash, prevBranches);
            if (current && current.parents && current.parents.length > 0) {
              queue2.push(current.parents[0]);
            }
          }
        });
        return result;
      }
      /**
       * Add position to given commit.
       *
       * @param rows Graph rows
       * @param branchesOrder Computed order of branches
       * @param commit Commit to position
       */
      withPosition(rows, branchesOrder2, commit2) {
        const row = rows.getRowOf(commit2.hash);
        const maxRow = rows.getMaxRow();
        const order = branchesOrder2.get(commit2.branchToDisplay);
        switch (this.orientation) {
          default:
            return commit2.setPosition({
              x: this.initCommitOffsetX + this.template.branch.spacing * order,
              y: this.initCommitOffsetY + this.template.commit.spacing * (maxRow - row)
            });
          case orientation_1.Orientation.VerticalReverse:
            return commit2.setPosition({
              x: this.initCommitOffsetX + this.template.branch.spacing * order,
              y: this.initCommitOffsetY + this.template.commit.spacing * row
            });
          case orientation_1.Orientation.Horizontal:
            return commit2.setPosition({
              x: this.initCommitOffsetX + this.template.commit.spacing * row,
              y: this.initCommitOffsetY + this.template.branch.spacing * order
            });
          case orientation_1.Orientation.HorizontalReverse:
            return commit2.setPosition({
              x: this.initCommitOffsetX + this.template.commit.spacing * (maxRow - row),
              y: this.initCommitOffsetY + this.template.branch.spacing * order
            });
        }
      }
      /**
       * Return the default color for given branch.
       *
       * @param branchesOrder Computed order of branches
       * @param branchName Name of the branch
       */
      getBranchDefaultColor(branchesOrder2, branchName) {
        return branchesOrder2.getColorOf(branchName);
      }
      /**
       * Tell each listener something new happened.
       * E.g. a rendering library will know it needs to re-render the graph.
       */
      next() {
        if (this.nextTimeoutId) {
          window.clearTimeout(this.nextTimeoutId);
        }
        this.nextTimeoutId = window.setTimeout(() => {
          this.listeners.forEach((listener) => listener(this.getRenderedData()));
        }, 0);
      }
    }
    gitgraph.GitgraphCore = GitgraphCore;
    return gitgraph;
  }
  var hasRequiredLib;
  function requireLib() {
    if (hasRequiredLib) return lib;
    hasRequiredLib = 1;
    Object.defineProperty(lib, "__esModule", { value: true });
    var gitgraph_1 = requireGitgraph();
    lib.GitgraphCore = gitgraph_1.GitgraphCore;
    var mode_1 = requireMode();
    lib.Mode = mode_1.Mode;
    var gitgraph_user_api_1 = requireGitgraphUserApi();
    lib.GitgraphUserApi = gitgraph_user_api_1.GitgraphUserApi;
    var branch_user_api_1 = requireBranchUserApi();
    lib.BranchUserApi = branch_user_api_1.BranchUserApi;
    var branch_1 = requireBranch();
    lib.Branch = branch_1.Branch;
    var commit_1 = requireCommit();
    lib.Commit = commit_1.Commit;
    var tag_1 = requireTag();
    lib.Tag = tag_1.Tag;
    var refs_1 = requireRefs();
    lib.Refs = refs_1.Refs;
    var template_1 = requireTemplate();
    lib.MergeStyle = template_1.MergeStyle;
    lib.TemplateName = template_1.TemplateName;
    lib.templateExtend = template_1.templateExtend;
    var orientation_1 = requireOrientation();
    lib.Orientation = orientation_1.Orientation;
    var branches_paths_1 = requireBranchesPaths();
    lib.toSvgPath = branches_paths_1.toSvgPath;
    var utils_1 = requireUtils();
    lib.arrowSvgPath = utils_1.arrowSvgPath;
    return lib;
  }
  requireLib();
  const Check = createLucideIcon("check", [["path", { d: "M20 6 9 17l-5-5", key: "1gmf2c" }]]);
  const Copy = createLucideIcon("copy", [
    ["rect", { width: "14", height: "14", x: "8", y: "8", rx: "2", ry: "2", key: "17jyea" }],
    ["path", { d: "M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2", key: "zix9uf" }]
  ]);
  const _hoisted_1$2 = { class: "booster-identity" };
  const _hoisted_2$2 = ["title"];
  const _hoisted_3$2 = ["aria-label", "title"];
  const _hoisted_4$2 = {
    key: 1,
    class: "booster-sr-only",
    role: "status"
  };
  const _sfc_main$4 = /* @__PURE__ */ defineComponent({
    __name: "CopyIdentity",
    props: {
      label: {},
      identifier: {},
      locale: {}
    },
    setup(__props) {
      const props = __props;
      const state = /* @__PURE__ */ ref("copy");
      let timer;
      async function writeClipboard(value) {
        if (navigator.clipboard?.writeText) {
          await navigator.clipboard.writeText(value);
          return;
        }
        const input = document.createElement("textarea");
        input.value = value;
        input.setAttribute("readonly", "");
        input.style.cssText = "position:fixed;opacity:0;pointer-events:none;";
        document.body.append(input);
        input.select();
        const copied = document.execCommand("copy");
        input.remove();
        if (!copied) throw new Error("Clipboard unavailable");
      }
      async function copy() {
        if (!props.identifier) return;
        try {
          await writeClipboard(props.identifier);
          state.value = "copied";
        } catch {
          state.value = "failed";
        }
        clearTimeout(timer);
        timer = setTimeout(() => {
          state.value = "copy";
        }, 2e3);
      }
      onBeforeUnmount(() => clearTimeout(timer));
      return (_ctx, _cache) => {
        return openBlock(), createElementBlock("span", _hoisted_1$2, [
          createBaseVNode("span", {
            class: "booster-identity-label",
            title: __props.label
          }, toDisplayString(__props.label), 9, _hoisted_2$2),
          __props.identifier ? (openBlock(), createElementBlock("button", {
            key: 0,
            type: "button",
            class: "booster-identity-copy",
            "aria-label": unref(translate)(__props.locale, `identity.${state.value}`),
            title: unref(translate)(__props.locale, `identity.${state.value}`),
            onClick: withModifiers(copy, ["stop", "prevent"])
          }, [
            state.value === "copied" ? (openBlock(), createBlock(unref(Check), {
              key: 0,
              class: "size-3"
            })) : (openBlock(), createBlock(unref(Copy), {
              key: 1,
              class: "size-3"
            }))
          ], 8, _hoisted_3$2)) : createCommentVNode("v-if", true),
          state.value !== "copy" ? (openBlock(), createElementBlock(
            "span",
            _hoisted_4$2,
            toDisplayString(unref(translate)(__props.locale, `identity.${state.value}`)),
            1
            /* TEXT */
          )) : createCommentVNode("v-if", true)
        ]);
      };
    }
  });
  function r(e) {
    var t, f, n = "";
    if ("string" == typeof e || "number" == typeof e) n += e;
    else if ("object" == typeof e) if (Array.isArray(e)) {
      var o = e.length;
      for (t = 0; t < o; t++) e[t] && (f = r(e[t])) && (n && (n += " "), n += f);
    } else for (f in e) e[f] && (n && (n += " "), n += f);
    return n;
  }
  function clsx() {
    for (var e, t, f = 0, n = "", o = arguments.length; f < o; f++) (e = arguments[f]) && (t = r(e)) && (n && (n += " "), n += t);
    return n;
  }
  const concatArrays = (array1, array2) => {
    const combinedArray = new Array(array1.length + array2.length);
    for (let i = 0; i < array1.length; i++) {
      combinedArray[i] = array1[i];
    }
    for (let i = 0; i < array2.length; i++) {
      combinedArray[array1.length + i] = array2[i];
    }
    return combinedArray;
  };
  const createClassValidatorObject = (classGroupId, validator) => ({
    classGroupId,
    validator
  });
  const createClassPartObject = (nextPart = /* @__PURE__ */ new Map(), validators = null, classGroupId) => ({
    nextPart,
    validators,
    classGroupId
  });
  const CLASS_PART_SEPARATOR = "-";
  const EMPTY_CONFLICTS = [];
  const ARBITRARY_PROPERTY_PREFIX = "arbitrary..";
  const createClassGroupUtils = (config) => {
    const classMap = createClassMap(config);
    const {
      conflictingClassGroups,
      conflictingClassGroupModifiers
    } = config;
    const getClassGroupId = (className) => {
      if (className.startsWith("[") && className.endsWith("]")) {
        return getGroupIdForArbitraryProperty(className);
      }
      const classParts = className.split(CLASS_PART_SEPARATOR);
      const startIndex = classParts[0] === "" && classParts.length > 1 ? 1 : 0;
      return getGroupRecursive(classParts, startIndex, classMap);
    };
    const getConflictingClassGroupIds = (classGroupId, hasPostfixModifier) => {
      if (hasPostfixModifier) {
        const modifierConflicts = conflictingClassGroupModifiers[classGroupId];
        const baseConflicts = conflictingClassGroups[classGroupId];
        if (modifierConflicts) {
          if (baseConflicts) {
            return concatArrays(baseConflicts, modifierConflicts);
          }
          return modifierConflicts;
        }
        return baseConflicts || EMPTY_CONFLICTS;
      }
      return conflictingClassGroups[classGroupId] || EMPTY_CONFLICTS;
    };
    return {
      getClassGroupId,
      getConflictingClassGroupIds
    };
  };
  const getGroupRecursive = (classParts, startIndex, classPartObject) => {
    const classPathsLength = classParts.length - startIndex;
    if (classPathsLength === 0) {
      return classPartObject.classGroupId;
    }
    const currentClassPart = classParts[startIndex];
    const nextClassPartObject = classPartObject.nextPart.get(currentClassPart);
    if (nextClassPartObject) {
      const result = getGroupRecursive(classParts, startIndex + 1, nextClassPartObject);
      if (result) return result;
    }
    const validators = classPartObject.validators;
    if (validators === null) {
      return void 0;
    }
    const classRest = startIndex === 0 ? classParts.join(CLASS_PART_SEPARATOR) : classParts.slice(startIndex).join(CLASS_PART_SEPARATOR);
    const validatorsLength = validators.length;
    for (let i = 0; i < validatorsLength; i++) {
      const validatorObj = validators[i];
      if (validatorObj.validator(classRest)) {
        return validatorObj.classGroupId;
      }
    }
    return void 0;
  };
  const getGroupIdForArbitraryProperty = (className) => className.slice(1, -1).indexOf(":") === -1 ? void 0 : (() => {
    const content = className.slice(1, -1);
    const colonIndex = content.indexOf(":");
    const property = content.slice(0, colonIndex);
    return property ? ARBITRARY_PROPERTY_PREFIX + property : void 0;
  })();
  const createClassMap = (config) => {
    const {
      theme,
      classGroups
    } = config;
    return processClassGroups(classGroups, theme);
  };
  const processClassGroups = (classGroups, theme) => {
    const classMap = createClassPartObject();
    for (const classGroupId in classGroups) {
      const group = classGroups[classGroupId];
      processClassesRecursively(group, classMap, classGroupId, theme);
    }
    return classMap;
  };
  const processClassesRecursively = (classGroup, classPartObject, classGroupId, theme) => {
    const len = classGroup.length;
    for (let i = 0; i < len; i++) {
      const classDefinition = classGroup[i];
      processClassDefinition(classDefinition, classPartObject, classGroupId, theme);
    }
  };
  const processClassDefinition = (classDefinition, classPartObject, classGroupId, theme) => {
    if (typeof classDefinition === "string") {
      processStringDefinition(classDefinition, classPartObject, classGroupId);
      return;
    }
    if (typeof classDefinition === "function") {
      processFunctionDefinition(classDefinition, classPartObject, classGroupId, theme);
      return;
    }
    processObjectDefinition(classDefinition, classPartObject, classGroupId, theme);
  };
  const processStringDefinition = (classDefinition, classPartObject, classGroupId) => {
    const classPartObjectToEdit = classDefinition === "" ? classPartObject : getPart(classPartObject, classDefinition);
    classPartObjectToEdit.classGroupId = classGroupId;
  };
  const processFunctionDefinition = (classDefinition, classPartObject, classGroupId, theme) => {
    if (isThemeGetter(classDefinition)) {
      processClassesRecursively(classDefinition(theme), classPartObject, classGroupId, theme);
      return;
    }
    if (classPartObject.validators === null) {
      classPartObject.validators = [];
    }
    classPartObject.validators.push(createClassValidatorObject(classGroupId, classDefinition));
  };
  const processObjectDefinition = (classDefinition, classPartObject, classGroupId, theme) => {
    const entries = Object.entries(classDefinition);
    const len = entries.length;
    for (let i = 0; i < len; i++) {
      const [key, value] = entries[i];
      processClassesRecursively(value, getPart(classPartObject, key), classGroupId, theme);
    }
  };
  const getPart = (classPartObject, path) => {
    let current = classPartObject;
    const parts = path.split(CLASS_PART_SEPARATOR);
    const len = parts.length;
    for (let i = 0; i < len; i++) {
      const part = parts[i];
      let next = current.nextPart.get(part);
      if (!next) {
        next = createClassPartObject();
        current.nextPart.set(part, next);
      }
      current = next;
    }
    return current;
  };
  const isThemeGetter = (func) => "isThemeGetter" in func && func.isThemeGetter === true;
  const createLruCache = (maxCacheSize) => {
    if (maxCacheSize < 1) {
      return {
        get: () => void 0,
        set: () => {
        }
      };
    }
    let cacheSize = 0;
    let cache = /* @__PURE__ */ Object.create(null);
    let previousCache = /* @__PURE__ */ Object.create(null);
    const update = (key, value) => {
      cache[key] = value;
      cacheSize++;
      if (cacheSize > maxCacheSize) {
        cacheSize = 0;
        previousCache = cache;
        cache = /* @__PURE__ */ Object.create(null);
      }
    };
    return {
      get(key) {
        let value = cache[key];
        if (value !== void 0) {
          return value;
        }
        if ((value = previousCache[key]) !== void 0) {
          update(key, value);
          return value;
        }
      },
      set(key, value) {
        if (key in cache) {
          cache[key] = value;
        } else {
          update(key, value);
        }
      }
    };
  };
  const IMPORTANT_MODIFIER = "!";
  const MODIFIER_SEPARATOR = ":";
  const EMPTY_MODIFIERS = [];
  const createResultObject = (modifiers, hasImportantModifier, baseClassName, maybePostfixModifierPosition, isExternal) => ({
    modifiers,
    hasImportantModifier,
    baseClassName,
    maybePostfixModifierPosition,
    isExternal
  });
  const createParseClassName = (config) => {
    const {
      prefix,
      experimentalParseClassName
    } = config;
    let parseClassName = (className) => {
      const modifiers = [];
      let bracketDepth = 0;
      let parenDepth = 0;
      let modifierStart = 0;
      let postfixModifierPosition;
      const len = className.length;
      for (let index = 0; index < len; index++) {
        const currentCharacter = className[index];
        if (bracketDepth === 0 && parenDepth === 0) {
          if (currentCharacter === MODIFIER_SEPARATOR) {
            modifiers.push(className.slice(modifierStart, index));
            modifierStart = index + 1;
            continue;
          }
          if (currentCharacter === "/") {
            postfixModifierPosition = index;
            continue;
          }
        }
        if (currentCharacter === "[") bracketDepth++;
        else if (currentCharacter === "]") bracketDepth--;
        else if (currentCharacter === "(") parenDepth++;
        else if (currentCharacter === ")") parenDepth--;
      }
      const baseClassNameWithImportantModifier = modifiers.length === 0 ? className : className.slice(modifierStart);
      let baseClassName = baseClassNameWithImportantModifier;
      let hasImportantModifier = false;
      if (baseClassNameWithImportantModifier.endsWith(IMPORTANT_MODIFIER)) {
        baseClassName = baseClassNameWithImportantModifier.slice(0, -1);
        hasImportantModifier = true;
      } else if (
        /**
         * In Tailwind CSS v3 the important modifier was at the start of the base class name. This is still supported for legacy reasons.
         * @see https://github.com/dcastil/tailwind-merge/issues/513#issuecomment-2614029864
         */
        baseClassNameWithImportantModifier.startsWith(IMPORTANT_MODIFIER)
      ) {
        baseClassName = baseClassNameWithImportantModifier.slice(1);
        hasImportantModifier = true;
      }
      const maybePostfixModifierPosition = postfixModifierPosition && postfixModifierPosition > modifierStart ? postfixModifierPosition - modifierStart : void 0;
      return createResultObject(modifiers, hasImportantModifier, baseClassName, maybePostfixModifierPosition);
    };
    if (prefix) {
      const fullPrefix = prefix + MODIFIER_SEPARATOR;
      const parseClassNameOriginal = parseClassName;
      parseClassName = (className) => className.startsWith(fullPrefix) ? parseClassNameOriginal(className.slice(fullPrefix.length)) : createResultObject(EMPTY_MODIFIERS, false, className, void 0, true);
    }
    if (experimentalParseClassName) {
      const parseClassNameOriginal = parseClassName;
      parseClassName = (className) => experimentalParseClassName({
        className,
        parseClassName: parseClassNameOriginal
      });
    }
    return parseClassName;
  };
  const createSortModifiers = (config) => {
    const modifierWeights = /* @__PURE__ */ new Map();
    config.orderSensitiveModifiers.forEach((mod, index) => {
      modifierWeights.set(mod, 1e6 + index);
    });
    return (modifiers) => {
      const result = [];
      let currentSegment = [];
      for (let i = 0; i < modifiers.length; i++) {
        const modifier = modifiers[i];
        const isArbitrary = modifier[0] === "[";
        const isOrderSensitive = modifierWeights.has(modifier);
        if (isArbitrary || isOrderSensitive) {
          if (currentSegment.length > 0) {
            currentSegment.sort();
            result.push(...currentSegment);
            currentSegment = [];
          }
          result.push(modifier);
        } else {
          currentSegment.push(modifier);
        }
      }
      if (currentSegment.length > 0) {
        currentSegment.sort();
        result.push(...currentSegment);
      }
      return result;
    };
  };
  const createConfigUtils = (config) => ({
    cache: createLruCache(config.cacheSize),
    parseClassName: createParseClassName(config),
    sortModifiers: createSortModifiers(config),
    postfixLookupClassGroupIds: createPostfixLookupClassGroupIds(config),
    ...createClassGroupUtils(config)
  });
  const createPostfixLookupClassGroupIds = (config) => {
    const lookup = /* @__PURE__ */ Object.create(null);
    const classGroupIds = config.postfixLookupClassGroups;
    if (classGroupIds) {
      for (let i = 0; i < classGroupIds.length; i++) {
        lookup[classGroupIds[i]] = true;
      }
    }
    return lookup;
  };
  const SPLIT_CLASSES_REGEX = /\s+/;
  const mergeClassList = (classList, configUtils) => {
    const {
      parseClassName,
      getClassGroupId,
      getConflictingClassGroupIds,
      sortModifiers,
      postfixLookupClassGroupIds
    } = configUtils;
    const classGroupsInConflict = [];
    const classNames = classList.trim().split(SPLIT_CLASSES_REGEX);
    let result = "";
    for (let index = classNames.length - 1; index >= 0; index -= 1) {
      const originalClassName = classNames[index];
      const {
        isExternal,
        modifiers,
        hasImportantModifier,
        baseClassName,
        maybePostfixModifierPosition
      } = parseClassName(originalClassName);
      if (isExternal) {
        result = originalClassName + (result.length > 0 ? " " + result : result);
        continue;
      }
      let hasPostfixModifier = !!maybePostfixModifierPosition;
      let classGroupId;
      if (hasPostfixModifier) {
        const baseClassNameWithoutPostfix = baseClassName.substring(0, maybePostfixModifierPosition);
        classGroupId = getClassGroupId(baseClassNameWithoutPostfix);
        const classGroupIdWithPostfix = classGroupId && postfixLookupClassGroupIds[classGroupId] ? getClassGroupId(baseClassName) : void 0;
        if (classGroupIdWithPostfix && classGroupIdWithPostfix !== classGroupId) {
          classGroupId = classGroupIdWithPostfix;
          hasPostfixModifier = false;
        }
      } else {
        classGroupId = getClassGroupId(baseClassName);
      }
      if (!classGroupId) {
        if (!hasPostfixModifier) {
          result = originalClassName + (result.length > 0 ? " " + result : result);
          continue;
        }
        classGroupId = getClassGroupId(baseClassName);
        if (!classGroupId) {
          result = originalClassName + (result.length > 0 ? " " + result : result);
          continue;
        }
        hasPostfixModifier = false;
      }
      const variantModifier = modifiers.length === 0 ? "" : modifiers.length === 1 ? modifiers[0] : sortModifiers(modifiers).join(":");
      const modifierId = hasImportantModifier ? variantModifier + IMPORTANT_MODIFIER : variantModifier;
      const classId = modifierId + classGroupId;
      if (classGroupsInConflict.indexOf(classId) > -1) {
        continue;
      }
      classGroupsInConflict.push(classId);
      const conflictGroups = getConflictingClassGroupIds(classGroupId, hasPostfixModifier);
      for (let i = 0; i < conflictGroups.length; ++i) {
        const group = conflictGroups[i];
        classGroupsInConflict.push(modifierId + group);
      }
      result = originalClassName + (result.length > 0 ? " " + result : result);
    }
    return result;
  };
  const twJoin = (...classLists) => {
    let index = 0;
    let argument;
    let resolvedValue;
    let string = "";
    while (index < classLists.length) {
      if (argument = classLists[index++]) {
        if (resolvedValue = toValue(argument)) {
          string && (string += " ");
          string += resolvedValue;
        }
      }
    }
    return string;
  };
  const toValue = (mix) => {
    if (typeof mix === "string") {
      return mix;
    }
    let resolvedValue;
    let string = "";
    for (let k = 0; k < mix.length; k++) {
      if (mix[k]) {
        if (resolvedValue = toValue(mix[k])) {
          string && (string += " ");
          string += resolvedValue;
        }
      }
    }
    return string;
  };
  const createTailwindMerge = (createConfigFirst, ...createConfigRest) => {
    let configUtils;
    let cacheGet;
    let cacheSet;
    let functionToCall;
    const initTailwindMerge = (classList) => {
      const config = createConfigRest.reduce((previousConfig, createConfigCurrent) => createConfigCurrent(previousConfig), createConfigFirst());
      configUtils = createConfigUtils(config);
      cacheGet = configUtils.cache.get;
      cacheSet = configUtils.cache.set;
      functionToCall = tailwindMerge;
      return tailwindMerge(classList);
    };
    const tailwindMerge = (classList) => {
      const cachedResult = cacheGet(classList);
      if (cachedResult) {
        return cachedResult;
      }
      const result = mergeClassList(classList, configUtils);
      cacheSet(classList, result);
      return result;
    };
    functionToCall = initTailwindMerge;
    return (...args) => functionToCall(twJoin(...args));
  };
  const fallbackThemeArr = [];
  const fromTheme = (key) => {
    const themeGetter = (theme) => theme[key] || fallbackThemeArr;
    themeGetter.isThemeGetter = true;
    themeGetter.themeKey = key;
    return themeGetter;
  };
  const arbitraryValueRegex = /^\[(?:(\w[\w-]*):)?(.+)\]$/i;
  const arbitraryVariableRegex = /^\((?:(\w[\w-]*):)?(.+)\)$/i;
  const fractionRegex = /^\d+(?:\.\d+)?\/\d+(?:\.\d+)?$/;
  const tshirtUnitRegex = /^(\d+(\.\d+)?)?(xs|sm|md|lg|xl)$/;
  const lengthUnitRegex = /\d+(%|px|r?em|[sdl]?v([hwib]|min|max)|pt|pc|in|cm|mm|cap|ch|ex|r?lh|cq(w|h|i|b|min|max))|\b(calc|min|max|clamp)\(.+\)|^0$/;
  const colorFunctionRegex = /^(rgba?|hsla?|hwb|(ok)?(lab|lch)|color-mix|color|light-dark)\(.+\)$/;
  const shadowRegex = /^(inset_)?-?((\d+)?\.?(\d+)[a-z]+|0)_-?((\d+)?\.?(\d+)[a-z]+|0)/;
  const imageRegex = /^(url|image|image-set|cross-fade|element|(repeating-)?(linear|radial|conic)-gradient)\(.+\)$/;
  const isFraction = (value) => fractionRegex.test(value);
  const isNumber = (value) => !!value && !Number.isNaN(Number(value));
  const isInteger = (value) => !!value && Number.isInteger(Number(value));
  const isPercent = (value) => value.endsWith("%") && isNumber(value.slice(0, -1));
  const isTshirtSize = (value) => tshirtUnitRegex.test(value);
  const isAny = () => true;
  const isLengthOnly = (value) => (
    // `colorFunctionRegex` check is necessary because color functions can have percentages in them which which would be incorrectly classified as lengths.
    // For example, `hsl(0 0% 0%)` would be classified as a length without this check.
    // I could also use lookbehind assertion in `lengthUnitRegex` but that isn't supported widely enough.
    lengthUnitRegex.test(value) && !colorFunctionRegex.test(value)
  );
  const isNever = () => false;
  const isShadow = (value) => shadowRegex.test(value);
  const isImage = (value) => imageRegex.test(value);
  const isAnyNonArbitrary = (value) => !isArbitraryValue(value) && !isArbitraryVariable(value);
  const isNamedContainerQuery = (value) => value.startsWith("@container") && (value[10] === "/" && value[11] !== void 0 || value[11] === "s" && value[16] !== void 0 && value.startsWith("-size/", 10) || value[11] === "n" && value[18] !== void 0 && value.startsWith("-normal/", 10));
  const isArbitrarySize = (value) => getIsArbitraryValue(value, isLabelSize, isNever);
  const isArbitraryValue = (value) => arbitraryValueRegex.test(value);
  const isArbitraryLength = (value) => getIsArbitraryValue(value, isLabelLength, isLengthOnly);
  const isArbitraryNumber = (value) => getIsArbitraryValue(value, isLabelNumber, isNumber);
  const isArbitraryWeight = (value) => getIsArbitraryValue(value, isLabelWeight, isAny);
  const isArbitraryFamilyName = (value) => getIsArbitraryValue(value, isLabelFamilyName, isNever);
  const isArbitraryPosition = (value) => getIsArbitraryValue(value, isLabelPosition, isNever);
  const isArbitraryImage = (value) => getIsArbitraryValue(value, isLabelImage, isImage);
  const isArbitraryShadow = (value) => getIsArbitraryValue(value, isLabelShadow, isShadow);
  const isArbitraryVariable = (value) => arbitraryVariableRegex.test(value);
  const isArbitraryVariableLength = (value) => getIsArbitraryVariable(value, isLabelLength);
  const isArbitraryVariableFamilyName = (value) => getIsArbitraryVariable(value, isLabelFamilyName);
  const isArbitraryVariablePosition = (value) => getIsArbitraryVariable(value, isLabelPosition);
  const isArbitraryVariableSize = (value) => getIsArbitraryVariable(value, isLabelSize);
  const isArbitraryVariableImage = (value) => getIsArbitraryVariable(value, isLabelImage);
  const isArbitraryVariableShadow = (value) => getIsArbitraryVariable(value, isLabelShadow, true);
  const isArbitraryVariableWeight = (value) => getIsArbitraryVariable(value, isLabelWeight, true);
  const getIsArbitraryValue = (value, testLabel, testValue) => {
    const result = arbitraryValueRegex.exec(value);
    if (result) {
      if (result[1]) {
        return testLabel(result[1]);
      }
      return testValue(result[2]);
    }
    return false;
  };
  const getIsArbitraryVariable = (value, testLabel, shouldMatchNoLabel = false) => {
    const result = arbitraryVariableRegex.exec(value);
    if (result) {
      if (result[1]) {
        return testLabel(result[1]);
      }
      return shouldMatchNoLabel;
    }
    return false;
  };
  const isLabelPosition = (label) => label === "position" || label === "percentage";
  const isLabelImage = (label) => label === "image" || label === "url";
  const isLabelSize = (label) => label === "length" || label === "size" || label === "bg-size";
  const isLabelLength = (label) => label === "length";
  const isLabelNumber = (label) => label === "number";
  const isLabelFamilyName = (label) => label === "family-name";
  const isLabelWeight = (label) => label === "number" || label === "weight";
  const isLabelShadow = (label) => label === "shadow";
  const getDefaultConfig = () => {
    const themeColor = fromTheme("color");
    const themeFont = fromTheme("font");
    const themeText = fromTheme("text");
    const themeFontWeight = fromTheme("font-weight");
    const themeTracking = fromTheme("tracking");
    const themeLeading = fromTheme("leading");
    const themeBreakpoint = fromTheme("breakpoint");
    const themeContainer = fromTheme("container");
    const themeSpacing = fromTheme("spacing");
    const themeRadius = fromTheme("radius");
    const themeShadow = fromTheme("shadow");
    const themeInsetShadow = fromTheme("inset-shadow");
    const themeTextShadow = fromTheme("text-shadow");
    const themeDropShadow = fromTheme("drop-shadow");
    const themeBlur = fromTheme("blur");
    const themePerspective = fromTheme("perspective");
    const themeAspect = fromTheme("aspect");
    const themeEase = fromTheme("ease");
    const themeAnimate = fromTheme("animate");
    const scaleBreak = () => ["auto", "avoid", "all", "avoid-page", "page", "left", "right", "column"];
    const scalePosition = () => [
      "center",
      "top",
      "bottom",
      "left",
      "right",
      "top-left",
      // Deprecated since Tailwind CSS v4.1.0, see https://github.com/tailwindlabs/tailwindcss/pull/17378
      "left-top",
      "top-right",
      // Deprecated since Tailwind CSS v4.1.0, see https://github.com/tailwindlabs/tailwindcss/pull/17378
      "right-top",
      "bottom-right",
      // Deprecated since Tailwind CSS v4.1.0, see https://github.com/tailwindlabs/tailwindcss/pull/17378
      "right-bottom",
      "bottom-left",
      // Deprecated since Tailwind CSS v4.1.0, see https://github.com/tailwindlabs/tailwindcss/pull/17378
      "left-bottom"
    ];
    const scalePositionWithArbitrary = () => [...scalePosition(), isArbitraryVariable, isArbitraryValue];
    const scaleOverflow = () => ["auto", "hidden", "clip", "visible", "scroll"];
    const scaleOverscroll = () => ["auto", "contain", "none"];
    const scaleUnambiguousSpacing = () => [isArbitraryVariable, isArbitraryValue, themeSpacing];
    const scaleInset = () => [isFraction, "full", "auto", ...scaleUnambiguousSpacing()];
    const scaleGridTemplateColsRows = () => [isInteger, "none", "subgrid", isArbitraryVariable, isArbitraryValue];
    const scaleGridColRowStartAndEnd = () => ["auto", {
      span: ["full", isInteger, isArbitraryVariable, isArbitraryValue]
    }, isInteger, isArbitraryVariable, isArbitraryValue];
    const scaleGridColRowStartOrEnd = () => [isInteger, "auto", isArbitraryVariable, isArbitraryValue];
    const scaleGridAutoColsRows = () => ["auto", "min", "max", "fr", isArbitraryVariable, isArbitraryValue];
    const scaleAlignPrimaryAxis = () => ["start", "end", "center", "between", "around", "evenly", "stretch", "baseline", "center-safe", "end-safe"];
    const scaleAlignSecondaryAxis = () => ["start", "end", "center", "stretch", "center-safe", "end-safe"];
    const scaleMargin = () => ["auto", ...scaleUnambiguousSpacing()];
    const scaleSizing = () => [isFraction, "auto", "full", "dvw", "dvh", "lvw", "lvh", "svw", "svh", "min", "max", "fit", ...scaleUnambiguousSpacing()];
    const scaleSizingInline = () => [themeContainer, isFraction, "screen", "full", "dvw", "lvw", "svw", "min", "max", "fit", ...scaleUnambiguousSpacing()];
    const scaleSizingBlock = () => [isFraction, "screen", "full", "lh", "dvh", "lvh", "svh", "min", "max", "fit", ...scaleUnambiguousSpacing()];
    const scaleColor = () => [themeColor, isArbitraryVariable, isArbitraryValue];
    const scaleBgPosition = () => [...scalePosition(), isArbitraryVariablePosition, isArbitraryPosition, {
      position: [isArbitraryVariable, isArbitraryValue]
    }];
    const scaleBgRepeat = () => ["no-repeat", {
      repeat: ["", "x", "y", "space", "round"]
    }];
    const scaleBgSize = () => ["auto", "cover", "contain", isArbitraryVariableSize, isArbitrarySize, {
      size: [isArbitraryVariable, isArbitraryValue]
    }];
    const scaleGradientStopPosition = () => [isPercent, isArbitraryVariableLength, isArbitraryLength];
    const scaleRadius = () => [
      // Deprecated since Tailwind CSS v4.0.0
      "",
      "none",
      "full",
      themeRadius,
      isArbitraryVariable,
      isArbitraryValue
    ];
    const scaleBorderWidth = () => ["", isNumber, isArbitraryVariableLength, isArbitraryLength];
    const scaleLineStyle = () => ["solid", "dashed", "dotted", "double"];
    const scaleBlendMode = () => ["normal", "multiply", "screen", "overlay", "darken", "lighten", "color-dodge", "color-burn", "hard-light", "soft-light", "difference", "exclusion", "hue", "saturation", "color", "luminosity"];
    const scaleMaskImagePosition = () => [isNumber, isPercent, isArbitraryVariablePosition, isArbitraryPosition];
    const scaleBlur = () => [
      // Deprecated since Tailwind CSS v4.0.0
      "",
      "none",
      themeBlur,
      isArbitraryVariable,
      isArbitraryValue
    ];
    const scaleRotate = () => ["none", isNumber, isArbitraryVariable, isArbitraryValue];
    const scaleScale = () => ["none", isNumber, isArbitraryVariable, isArbitraryValue];
    const scaleSkew = () => [isNumber, isArbitraryVariable, isArbitraryValue];
    const scaleTranslate = () => [isFraction, "full", ...scaleUnambiguousSpacing()];
    return {
      cacheSize: 500,
      theme: {
        animate: ["spin", "ping", "pulse", "bounce"],
        aspect: ["video"],
        blur: [isTshirtSize],
        breakpoint: [isTshirtSize],
        color: [isAny],
        container: [isTshirtSize],
        "drop-shadow": [isTshirtSize],
        ease: ["in", "out", "in-out"],
        font: [isAnyNonArbitrary],
        "font-weight": ["thin", "extralight", "light", "normal", "medium", "semibold", "bold", "extrabold", "black"],
        "inset-shadow": [isTshirtSize],
        leading: ["none", "tight", "snug", "normal", "relaxed", "loose"],
        perspective: ["dramatic", "near", "normal", "midrange", "distant", "none"],
        radius: [isTshirtSize],
        shadow: [isTshirtSize],
        spacing: ["px", isNumber],
        text: [isTshirtSize],
        "text-shadow": [isTshirtSize],
        tracking: ["tighter", "tight", "normal", "wide", "wider", "widest"]
      },
      classGroups: {
        // --------------
        // --- Layout ---
        // --------------
        /**
         * Aspect Ratio
         * @see https://tailwindcss.com/docs/aspect-ratio
         */
        aspect: [{
          aspect: ["auto", "square", isFraction, isArbitraryValue, isArbitraryVariable, themeAspect]
        }],
        /**
         * Container
         * @see https://tailwindcss.com/docs/container
         * @deprecated since Tailwind CSS v4.0.0
         */
        container: ["container"],
        /**
         * Container Type
         * @see https://tailwindcss.com/docs/responsive-design#container-queries
         */
        "container-type": [{
          "@container": ["", "normal", "size", isArbitraryVariable, isArbitraryValue]
        }],
        /**
         * Container Name
         * @see https://tailwindcss.com/docs/responsive-design#named-containers
         */
        "container-named": [isNamedContainerQuery],
        /**
         * Columns
         * @see https://tailwindcss.com/docs/columns
         */
        columns: [{
          columns: [isNumber, "auto", isArbitraryValue, isArbitraryVariable, themeContainer]
        }],
        /**
         * Break After
         * @see https://tailwindcss.com/docs/break-after
         */
        "break-after": [{
          "break-after": scaleBreak()
        }],
        /**
         * Break Before
         * @see https://tailwindcss.com/docs/break-before
         */
        "break-before": [{
          "break-before": scaleBreak()
        }],
        /**
         * Break Inside
         * @see https://tailwindcss.com/docs/break-inside
         */
        "break-inside": [{
          "break-inside": ["auto", "avoid", "avoid-page", "avoid-column"]
        }],
        /**
         * Box Decoration Break
         * @see https://tailwindcss.com/docs/box-decoration-break
         */
        "box-decoration": [{
          "box-decoration": ["slice", "clone"]
        }],
        /**
         * Box Sizing
         * @see https://tailwindcss.com/docs/box-sizing
         */
        box: [{
          box: ["border", "content"]
        }],
        /**
         * Display
         * @see https://tailwindcss.com/docs/display
         */
        display: ["block", "inline-block", "inline", "flex", "inline-flex", "table", "inline-table", "table-caption", "table-cell", "table-column", "table-column-group", "table-footer-group", "table-header-group", "table-row-group", "table-row", "flow-root", "grid", "inline-grid", "contents", "list-item", "hidden"],
        /**
         * Screen Reader Only
         * @see https://tailwindcss.com/docs/display#screen-reader-only
         */
        sr: ["sr-only", "not-sr-only"],
        /**
         * Floats
         * @see https://tailwindcss.com/docs/float
         */
        float: [{
          float: ["right", "left", "none", "start", "end"]
        }],
        /**
         * Clear
         * @see https://tailwindcss.com/docs/clear
         */
        clear: [{
          clear: ["left", "right", "both", "none", "start", "end"]
        }],
        /**
         * Isolation
         * @see https://tailwindcss.com/docs/isolation
         */
        isolation: ["isolate", "isolation-auto"],
        /**
         * Object Fit
         * @see https://tailwindcss.com/docs/object-fit
         */
        "object-fit": [{
          object: ["contain", "cover", "fill", "none", "scale-down"]
        }],
        /**
         * Object Position
         * @see https://tailwindcss.com/docs/object-position
         */
        "object-position": [{
          object: scalePositionWithArbitrary()
        }],
        /**
         * Overflow
         * @see https://tailwindcss.com/docs/overflow
         */
        overflow: [{
          overflow: scaleOverflow()
        }],
        /**
         * Overflow X
         * @see https://tailwindcss.com/docs/overflow
         */
        "overflow-x": [{
          "overflow-x": scaleOverflow()
        }],
        /**
         * Overflow Y
         * @see https://tailwindcss.com/docs/overflow
         */
        "overflow-y": [{
          "overflow-y": scaleOverflow()
        }],
        /**
         * Overscroll Behavior
         * @see https://tailwindcss.com/docs/overscroll-behavior
         */
        overscroll: [{
          overscroll: scaleOverscroll()
        }],
        /**
         * Overscroll Behavior X
         * @see https://tailwindcss.com/docs/overscroll-behavior
         */
        "overscroll-x": [{
          "overscroll-x": scaleOverscroll()
        }],
        /**
         * Overscroll Behavior Y
         * @see https://tailwindcss.com/docs/overscroll-behavior
         */
        "overscroll-y": [{
          "overscroll-y": scaleOverscroll()
        }],
        /**
         * Position
         * @see https://tailwindcss.com/docs/position
         */
        position: ["static", "fixed", "absolute", "relative", "sticky"],
        /**
         * Inset
         * @see https://tailwindcss.com/docs/top-right-bottom-left
         */
        inset: [{
          inset: scaleInset()
        }],
        /**
         * Inset Inline
         * @see https://tailwindcss.com/docs/top-right-bottom-left
         */
        "inset-x": [{
          "inset-x": scaleInset()
        }],
        /**
         * Inset Block
         * @see https://tailwindcss.com/docs/top-right-bottom-left
         */
        "inset-y": [{
          "inset-y": scaleInset()
        }],
        /**
         * Inset Inline Start
         * @see https://tailwindcss.com/docs/top-right-bottom-left
         * @todo class group will be renamed to `inset-s` in next major release
         */
        start: [{
          "inset-s": scaleInset(),
          /**
           * @deprecated since Tailwind CSS v4.2.0 in favor of `inset-s-*` utilities.
           * @see https://github.com/tailwindlabs/tailwindcss/pull/19613
           */
          start: scaleInset()
        }],
        /**
         * Inset Inline End
         * @see https://tailwindcss.com/docs/top-right-bottom-left
         * @todo class group will be renamed to `inset-e` in next major release
         */
        end: [{
          "inset-e": scaleInset(),
          /**
           * @deprecated since Tailwind CSS v4.2.0 in favor of `inset-e-*` utilities.
           * @see https://github.com/tailwindlabs/tailwindcss/pull/19613
           */
          end: scaleInset()
        }],
        /**
         * Inset Block Start
         * @see https://tailwindcss.com/docs/top-right-bottom-left
         */
        "inset-bs": [{
          "inset-bs": scaleInset()
        }],
        /**
         * Inset Block End
         * @see https://tailwindcss.com/docs/top-right-bottom-left
         */
        "inset-be": [{
          "inset-be": scaleInset()
        }],
        /**
         * Top
         * @see https://tailwindcss.com/docs/top-right-bottom-left
         */
        top: [{
          top: scaleInset()
        }],
        /**
         * Right
         * @see https://tailwindcss.com/docs/top-right-bottom-left
         */
        right: [{
          right: scaleInset()
        }],
        /**
         * Bottom
         * @see https://tailwindcss.com/docs/top-right-bottom-left
         */
        bottom: [{
          bottom: scaleInset()
        }],
        /**
         * Left
         * @see https://tailwindcss.com/docs/top-right-bottom-left
         */
        left: [{
          left: scaleInset()
        }],
        /**
         * Visibility
         * @see https://tailwindcss.com/docs/visibility
         */
        visibility: ["visible", "invisible", "collapse"],
        /**
         * Z-Index
         * @see https://tailwindcss.com/docs/z-index
         */
        z: [{
          z: [isInteger, "auto", isArbitraryVariable, isArbitraryValue]
        }],
        // ------------------------
        // --- Flexbox and Grid ---
        // ------------------------
        /**
         * Flex Basis
         * @see https://tailwindcss.com/docs/flex-basis
         */
        basis: [{
          basis: [isFraction, "full", "auto", themeContainer, ...scaleUnambiguousSpacing()]
        }],
        /**
         * Flex Direction
         * @see https://tailwindcss.com/docs/flex-direction
         */
        "flex-direction": [{
          flex: ["row", "row-reverse", "col", "col-reverse"]
        }],
        /**
         * Flex Wrap
         * @see https://tailwindcss.com/docs/flex-wrap
         */
        "flex-wrap": [{
          flex: ["nowrap", "wrap", "wrap-reverse"]
        }],
        /**
         * Flex
         * @see https://tailwindcss.com/docs/flex
         */
        flex: [{
          flex: [isNumber, isFraction, "auto", "initial", "none", isArbitraryValue]
        }],
        /**
         * Flex Grow
         * @see https://tailwindcss.com/docs/flex-grow
         */
        grow: [{
          grow: ["", isNumber, isArbitraryVariable, isArbitraryValue]
        }],
        /**
         * Flex Shrink
         * @see https://tailwindcss.com/docs/flex-shrink
         */
        shrink: [{
          shrink: ["", isNumber, isArbitraryVariable, isArbitraryValue]
        }],
        /**
         * Order
         * @see https://tailwindcss.com/docs/order
         */
        order: [{
          order: [isInteger, "first", "last", "none", isArbitraryVariable, isArbitraryValue]
        }],
        /**
         * Grid Template Columns
         * @see https://tailwindcss.com/docs/grid-template-columns
         */
        "grid-cols": [{
          "grid-cols": scaleGridTemplateColsRows()
        }],
        /**
         * Grid Column Start / End
         * @see https://tailwindcss.com/docs/grid-column
         */
        "col-start-end": [{
          col: scaleGridColRowStartAndEnd()
        }],
        /**
         * Grid Column Start
         * @see https://tailwindcss.com/docs/grid-column
         */
        "col-start": [{
          "col-start": scaleGridColRowStartOrEnd()
        }],
        /**
         * Grid Column End
         * @see https://tailwindcss.com/docs/grid-column
         */
        "col-end": [{
          "col-end": scaleGridColRowStartOrEnd()
        }],
        /**
         * Grid Template Rows
         * @see https://tailwindcss.com/docs/grid-template-rows
         */
        "grid-rows": [{
          "grid-rows": scaleGridTemplateColsRows()
        }],
        /**
         * Grid Row Start / End
         * @see https://tailwindcss.com/docs/grid-row
         */
        "row-start-end": [{
          row: scaleGridColRowStartAndEnd()
        }],
        /**
         * Grid Row Start
         * @see https://tailwindcss.com/docs/grid-row
         */
        "row-start": [{
          "row-start": scaleGridColRowStartOrEnd()
        }],
        /**
         * Grid Row End
         * @see https://tailwindcss.com/docs/grid-row
         */
        "row-end": [{
          "row-end": scaleGridColRowStartOrEnd()
        }],
        /**
         * Grid Auto Flow
         * @see https://tailwindcss.com/docs/grid-auto-flow
         */
        "grid-flow": [{
          "grid-flow": ["row", "col", "dense", "row-dense", "col-dense"]
        }],
        /**
         * Grid Auto Columns
         * @see https://tailwindcss.com/docs/grid-auto-columns
         */
        "auto-cols": [{
          "auto-cols": scaleGridAutoColsRows()
        }],
        /**
         * Grid Auto Rows
         * @see https://tailwindcss.com/docs/grid-auto-rows
         */
        "auto-rows": [{
          "auto-rows": scaleGridAutoColsRows()
        }],
        /**
         * Gap
         * @see https://tailwindcss.com/docs/gap
         */
        gap: [{
          gap: scaleUnambiguousSpacing()
        }],
        /**
         * Gap X
         * @see https://tailwindcss.com/docs/gap
         */
        "gap-x": [{
          "gap-x": scaleUnambiguousSpacing()
        }],
        /**
         * Gap Y
         * @see https://tailwindcss.com/docs/gap
         */
        "gap-y": [{
          "gap-y": scaleUnambiguousSpacing()
        }],
        /**
         * Justify Content
         * @see https://tailwindcss.com/docs/justify-content
         */
        "justify-content": [{
          justify: [...scaleAlignPrimaryAxis(), "normal"]
        }],
        /**
         * Justify Items
         * @see https://tailwindcss.com/docs/justify-items
         */
        "justify-items": [{
          "justify-items": [...scaleAlignSecondaryAxis(), "normal"]
        }],
        /**
         * Justify Self
         * @see https://tailwindcss.com/docs/justify-self
         */
        "justify-self": [{
          "justify-self": ["auto", ...scaleAlignSecondaryAxis()]
        }],
        /**
         * Align Content
         * @see https://tailwindcss.com/docs/align-content
         */
        "align-content": [{
          content: ["normal", ...scaleAlignPrimaryAxis()]
        }],
        /**
         * Align Items
         * @see https://tailwindcss.com/docs/align-items
         */
        "align-items": [{
          items: [...scaleAlignSecondaryAxis(), {
            baseline: ["", "last"]
          }]
        }],
        /**
         * Align Self
         * @see https://tailwindcss.com/docs/align-self
         */
        "align-self": [{
          self: ["auto", ...scaleAlignSecondaryAxis(), {
            baseline: ["", "last"]
          }]
        }],
        /**
         * Place Content
         * @see https://tailwindcss.com/docs/place-content
         */
        "place-content": [{
          "place-content": scaleAlignPrimaryAxis()
        }],
        /**
         * Place Items
         * @see https://tailwindcss.com/docs/place-items
         */
        "place-items": [{
          "place-items": [...scaleAlignSecondaryAxis(), "baseline"]
        }],
        /**
         * Place Self
         * @see https://tailwindcss.com/docs/place-self
         */
        "place-self": [{
          "place-self": ["auto", ...scaleAlignSecondaryAxis()]
        }],
        // Spacing
        /**
         * Padding
         * @see https://tailwindcss.com/docs/padding
         */
        p: [{
          p: scaleUnambiguousSpacing()
        }],
        /**
         * Padding Inline
         * @see https://tailwindcss.com/docs/padding
         */
        px: [{
          px: scaleUnambiguousSpacing()
        }],
        /**
         * Padding Block
         * @see https://tailwindcss.com/docs/padding
         */
        py: [{
          py: scaleUnambiguousSpacing()
        }],
        /**
         * Padding Inline Start
         * @see https://tailwindcss.com/docs/padding
         */
        ps: [{
          ps: scaleUnambiguousSpacing()
        }],
        /**
         * Padding Inline End
         * @see https://tailwindcss.com/docs/padding
         */
        pe: [{
          pe: scaleUnambiguousSpacing()
        }],
        /**
         * Padding Block Start
         * @see https://tailwindcss.com/docs/padding
         */
        pbs: [{
          pbs: scaleUnambiguousSpacing()
        }],
        /**
         * Padding Block End
         * @see https://tailwindcss.com/docs/padding
         */
        pbe: [{
          pbe: scaleUnambiguousSpacing()
        }],
        /**
         * Padding Top
         * @see https://tailwindcss.com/docs/padding
         */
        pt: [{
          pt: scaleUnambiguousSpacing()
        }],
        /**
         * Padding Right
         * @see https://tailwindcss.com/docs/padding
         */
        pr: [{
          pr: scaleUnambiguousSpacing()
        }],
        /**
         * Padding Bottom
         * @see https://tailwindcss.com/docs/padding
         */
        pb: [{
          pb: scaleUnambiguousSpacing()
        }],
        /**
         * Padding Left
         * @see https://tailwindcss.com/docs/padding
         */
        pl: [{
          pl: scaleUnambiguousSpacing()
        }],
        /**
         * Margin
         * @see https://tailwindcss.com/docs/margin
         */
        m: [{
          m: scaleMargin()
        }],
        /**
         * Margin Inline
         * @see https://tailwindcss.com/docs/margin
         */
        mx: [{
          mx: scaleMargin()
        }],
        /**
         * Margin Block
         * @see https://tailwindcss.com/docs/margin
         */
        my: [{
          my: scaleMargin()
        }],
        /**
         * Margin Inline Start
         * @see https://tailwindcss.com/docs/margin
         */
        ms: [{
          ms: scaleMargin()
        }],
        /**
         * Margin Inline End
         * @see https://tailwindcss.com/docs/margin
         */
        me: [{
          me: scaleMargin()
        }],
        /**
         * Margin Block Start
         * @see https://tailwindcss.com/docs/margin
         */
        mbs: [{
          mbs: scaleMargin()
        }],
        /**
         * Margin Block End
         * @see https://tailwindcss.com/docs/margin
         */
        mbe: [{
          mbe: scaleMargin()
        }],
        /**
         * Margin Top
         * @see https://tailwindcss.com/docs/margin
         */
        mt: [{
          mt: scaleMargin()
        }],
        /**
         * Margin Right
         * @see https://tailwindcss.com/docs/margin
         */
        mr: [{
          mr: scaleMargin()
        }],
        /**
         * Margin Bottom
         * @see https://tailwindcss.com/docs/margin
         */
        mb: [{
          mb: scaleMargin()
        }],
        /**
         * Margin Left
         * @see https://tailwindcss.com/docs/margin
         */
        ml: [{
          ml: scaleMargin()
        }],
        /**
         * Space Between X
         * @see https://tailwindcss.com/docs/margin#adding-space-between-children
         */
        "space-x": [{
          "space-x": scaleUnambiguousSpacing()
        }],
        /**
         * Space Between X Reverse
         * @see https://tailwindcss.com/docs/margin#adding-space-between-children
         */
        "space-x-reverse": ["space-x-reverse"],
        /**
         * Space Between Y
         * @see https://tailwindcss.com/docs/margin#adding-space-between-children
         */
        "space-y": [{
          "space-y": scaleUnambiguousSpacing()
        }],
        /**
         * Space Between Y Reverse
         * @see https://tailwindcss.com/docs/margin#adding-space-between-children
         */
        "space-y-reverse": ["space-y-reverse"],
        // --------------
        // --- Sizing ---
        // --------------
        /**
         * Size
         * @see https://tailwindcss.com/docs/width#setting-both-width-and-height
         */
        size: [{
          size: scaleSizing()
        }],
        /**
         * Inline Size
         * @see https://tailwindcss.com/docs/inline-size
         */
        "inline-size": [{
          inline: ["auto", ...scaleSizingInline()]
        }],
        /**
         * Min-Inline Size
         * @see https://tailwindcss.com/docs/min-inline-size
         */
        "min-inline-size": [{
          "min-inline": ["auto", ...scaleSizingInline()]
        }],
        /**
         * Max-Inline Size
         * @see https://tailwindcss.com/docs/max-inline-size
         */
        "max-inline-size": [{
          "max-inline": ["none", ...scaleSizingInline()]
        }],
        /**
         * Block Size
         * @see https://tailwindcss.com/docs/block-size
         */
        "block-size": [{
          block: ["auto", ...scaleSizingBlock()]
        }],
        /**
         * Min-Block Size
         * @see https://tailwindcss.com/docs/min-block-size
         */
        "min-block-size": [{
          "min-block": ["auto", ...scaleSizingBlock()]
        }],
        /**
         * Max-Block Size
         * @see https://tailwindcss.com/docs/max-block-size
         */
        "max-block-size": [{
          "max-block": ["none", ...scaleSizingBlock()]
        }],
        /**
         * Width
         * @see https://tailwindcss.com/docs/width
         */
        w: [{
          w: [themeContainer, "screen", ...scaleSizing()]
        }],
        /**
         * Min-Width
         * @see https://tailwindcss.com/docs/min-width
         */
        "min-w": [{
          "min-w": [
            themeContainer,
            "screen",
            /** Deprecated. @see https://github.com/tailwindlabs/tailwindcss.com/issues/2027#issuecomment-2620152757 */
            "none",
            ...scaleSizing()
          ]
        }],
        /**
         * Max-Width
         * @see https://tailwindcss.com/docs/max-width
         */
        "max-w": [{
          "max-w": [
            themeContainer,
            "screen",
            "none",
            /** Deprecated since Tailwind CSS v4.0.0. @see https://github.com/tailwindlabs/tailwindcss.com/issues/2027#issuecomment-2620152757 */
            "prose",
            /** Deprecated since Tailwind CSS v4.0.0. @see https://github.com/tailwindlabs/tailwindcss.com/issues/2027#issuecomment-2620152757 */
            {
              screen: [themeBreakpoint]
            },
            ...scaleSizing()
          ]
        }],
        /**
         * Height
         * @see https://tailwindcss.com/docs/height
         */
        h: [{
          h: ["screen", "lh", ...scaleSizing()]
        }],
        /**
         * Min-Height
         * @see https://tailwindcss.com/docs/min-height
         */
        "min-h": [{
          "min-h": ["screen", "lh", "none", ...scaleSizing()]
        }],
        /**
         * Max-Height
         * @see https://tailwindcss.com/docs/max-height
         */
        "max-h": [{
          "max-h": ["screen", "lh", "none", ...scaleSizing()]
        }],
        // ------------------
        // --- Typography ---
        // ------------------
        /**
         * Font Size
         * @see https://tailwindcss.com/docs/font-size
         */
        "font-size": [{
          text: ["base", themeText, isArbitraryVariableLength, isArbitraryLength]
        }],
        /**
         * Font Smoothing
         * @see https://tailwindcss.com/docs/font-smoothing
         */
        "font-smoothing": ["antialiased", "subpixel-antialiased"],
        /**
         * Font Style
         * @see https://tailwindcss.com/docs/font-style
         */
        "font-style": ["italic", "not-italic"],
        /**
         * Font Weight
         * @see https://tailwindcss.com/docs/font-weight
         */
        "font-weight": [{
          font: [themeFontWeight, isArbitraryVariableWeight, isArbitraryWeight]
        }],
        /**
         * Font Stretch
         * @see https://tailwindcss.com/docs/font-stretch
         */
        "font-stretch": [{
          "font-stretch": ["ultra-condensed", "extra-condensed", "condensed", "semi-condensed", "normal", "semi-expanded", "expanded", "extra-expanded", "ultra-expanded", isPercent, isArbitraryValue]
        }],
        /**
         * Font Family
         * @see https://tailwindcss.com/docs/font-family
         */
        "font-family": [{
          font: [isArbitraryVariableFamilyName, isArbitraryFamilyName, themeFont]
        }],
        /**
         * Font Feature Settings
         * @see https://tailwindcss.com/docs/font-feature-settings
         */
        "font-features": [{
          "font-features": [isArbitraryValue]
        }],
        /**
         * Font Variant Numeric
         * @see https://tailwindcss.com/docs/font-variant-numeric
         */
        "fvn-normal": ["normal-nums"],
        /**
         * Font Variant Numeric
         * @see https://tailwindcss.com/docs/font-variant-numeric
         */
        "fvn-ordinal": ["ordinal"],
        /**
         * Font Variant Numeric
         * @see https://tailwindcss.com/docs/font-variant-numeric
         */
        "fvn-slashed-zero": ["slashed-zero"],
        /**
         * Font Variant Numeric
         * @see https://tailwindcss.com/docs/font-variant-numeric
         */
        "fvn-figure": ["lining-nums", "oldstyle-nums"],
        /**
         * Font Variant Numeric
         * @see https://tailwindcss.com/docs/font-variant-numeric
         */
        "fvn-spacing": ["proportional-nums", "tabular-nums"],
        /**
         * Font Variant Numeric
         * @see https://tailwindcss.com/docs/font-variant-numeric
         */
        "fvn-fraction": ["diagonal-fractions", "stacked-fractions"],
        /**
         * Letter Spacing
         * @see https://tailwindcss.com/docs/letter-spacing
         */
        tracking: [{
          tracking: [themeTracking, isArbitraryVariable, isArbitraryValue]
        }],
        /**
         * Line Clamp
         * @see https://tailwindcss.com/docs/line-clamp
         */
        "line-clamp": [{
          "line-clamp": [isNumber, "none", isArbitraryVariable, isArbitraryNumber]
        }],
        /**
         * Line Height
         * @see https://tailwindcss.com/docs/line-height
         */
        leading: [{
          leading: [
            "none",
            /** Deprecated since Tailwind CSS v4.0.0. @see https://github.com/tailwindlabs/tailwindcss.com/issues/2027#issuecomment-2620152757 */
            themeLeading,
            ...scaleUnambiguousSpacing()
          ]
        }],
        /**
         * List Style Image
         * @see https://tailwindcss.com/docs/list-style-image
         */
        "list-image": [{
          "list-image": ["none", isArbitraryVariable, isArbitraryValue]
        }],
        /**
         * List Style Position
         * @see https://tailwindcss.com/docs/list-style-position
         */
        "list-style-position": [{
          list: ["inside", "outside"]
        }],
        /**
         * List Style Type
         * @see https://tailwindcss.com/docs/list-style-type
         */
        "list-style-type": [{
          list: ["disc", "decimal", "none", isArbitraryVariable, isArbitraryValue]
        }],
        /**
         * Text Alignment
         * @see https://tailwindcss.com/docs/text-align
         */
        "text-alignment": [{
          text: ["left", "center", "right", "justify", "start", "end"]
        }],
        /**
         * Placeholder Color
         * @deprecated since Tailwind CSS v3.0.0
         * @see https://v3.tailwindcss.com/docs/placeholder-color
         */
        "placeholder-color": [{
          placeholder: scaleColor()
        }],
        /**
         * Text Color
         * @see https://tailwindcss.com/docs/text-color
         */
        "text-color": [{
          text: scaleColor()
        }],
        /**
         * Text Decoration
         * @see https://tailwindcss.com/docs/text-decoration
         */
        "text-decoration": ["underline", "overline", "line-through", "no-underline"],
        /**
         * Text Decoration Style
         * @see https://tailwindcss.com/docs/text-decoration-style
         */
        "text-decoration-style": [{
          decoration: [...scaleLineStyle(), "wavy"]
        }],
        /**
         * Text Decoration Thickness
         * @see https://tailwindcss.com/docs/text-decoration-thickness
         */
        "text-decoration-thickness": [{
          decoration: [isNumber, "from-font", "auto", isArbitraryVariable, isArbitraryLength]
        }],
        /**
         * Text Decoration Color
         * @see https://tailwindcss.com/docs/text-decoration-color
         */
        "text-decoration-color": [{
          decoration: scaleColor()
        }],
        /**
         * Text Underline Offset
         * @see https://tailwindcss.com/docs/text-underline-offset
         */
        "underline-offset": [{
          "underline-offset": [isNumber, "auto", isArbitraryVariable, isArbitraryValue]
        }],
        /**
         * Text Transform
         * @see https://tailwindcss.com/docs/text-transform
         */
        "text-transform": ["uppercase", "lowercase", "capitalize", "normal-case"],
        /**
         * Text Overflow
         * @see https://tailwindcss.com/docs/text-overflow
         */
        "text-overflow": ["truncate", "text-ellipsis", "text-clip"],
        /**
         * Text Wrap
         * @see https://tailwindcss.com/docs/text-wrap
         */
        "text-wrap": [{
          text: ["wrap", "nowrap", "balance", "pretty"]
        }],
        /**
         * Text Indent
         * @see https://tailwindcss.com/docs/text-indent
         */
        indent: [{
          indent: scaleUnambiguousSpacing()
        }],
        /**
         * Tab Size
         * @see https://tailwindcss.com/docs/tab-size
         */
        "tab-size": [{
          tab: [isInteger, isArbitraryVariable, isArbitraryValue]
        }],
        /**
         * Vertical Alignment
         * @see https://tailwindcss.com/docs/vertical-align
         */
        "vertical-align": [{
          align: ["baseline", "top", "middle", "bottom", "text-top", "text-bottom", "sub", "super", isArbitraryVariable, isArbitraryValue]
        }],
        /**
         * Whitespace
         * @see https://tailwindcss.com/docs/whitespace
         */
        whitespace: [{
          whitespace: ["normal", "nowrap", "pre", "pre-line", "pre-wrap", "break-spaces"]
        }],
        /**
         * Word Break
         * @see https://tailwindcss.com/docs/word-break
         */
        break: [{
          break: ["normal", "words", "all", "keep"]
        }],
        /**
         * Overflow Wrap
         * @see https://tailwindcss.com/docs/overflow-wrap
         */
        wrap: [{
          wrap: ["break-word", "anywhere", "normal"]
        }],
        /**
         * Hyphens
         * @see https://tailwindcss.com/docs/hyphens
         */
        hyphens: [{
          hyphens: ["none", "manual", "auto"]
        }],
        /**
         * Content
         * @see https://tailwindcss.com/docs/content
         */
        content: [{
          content: ["none", isArbitraryVariable, isArbitraryValue]
        }],
        // -------------------
        // --- Backgrounds ---
        // -------------------
        /**
         * Background Attachment
         * @see https://tailwindcss.com/docs/background-attachment
         */
        "bg-attachment": [{
          bg: ["fixed", "local", "scroll"]
        }],
        /**
         * Background Clip
         * @see https://tailwindcss.com/docs/background-clip
         */
        "bg-clip": [{
          "bg-clip": ["border", "padding", "content", "text"]
        }],
        /**
         * Background Origin
         * @see https://tailwindcss.com/docs/background-origin
         */
        "bg-origin": [{
          "bg-origin": ["border", "padding", "content"]
        }],
        /**
         * Background Position
         * @see https://tailwindcss.com/docs/background-position
         */
        "bg-position": [{
          bg: scaleBgPosition()
        }],
        /**
         * Background Repeat
         * @see https://tailwindcss.com/docs/background-repeat
         */
        "bg-repeat": [{
          bg: scaleBgRepeat()
        }],
        /**
         * Background Size
         * @see https://tailwindcss.com/docs/background-size
         */
        "bg-size": [{
          bg: scaleBgSize()
        }],
        /**
         * Background Image
         * @see https://tailwindcss.com/docs/background-image
         */
        "bg-image": [{
          bg: ["none", {
            linear: [{
              to: ["t", "tr", "r", "br", "b", "bl", "l", "tl"]
            }, isInteger, isArbitraryVariable, isArbitraryValue],
            radial: ["", isArbitraryVariable, isArbitraryValue],
            conic: ["", isInteger, isArbitraryVariable, isArbitraryValue]
          }, isArbitraryVariableImage, isArbitraryImage]
        }],
        /**
         * Background Color
         * @see https://tailwindcss.com/docs/background-color
         */
        "bg-color": [{
          bg: scaleColor()
        }],
        /**
         * Gradient Color Stops From Position
         * @see https://tailwindcss.com/docs/gradient-color-stops
         */
        "gradient-from-pos": [{
          from: scaleGradientStopPosition()
        }],
        /**
         * Gradient Color Stops Via Position
         * @see https://tailwindcss.com/docs/gradient-color-stops
         */
        "gradient-via-pos": [{
          via: scaleGradientStopPosition()
        }],
        /**
         * Gradient Color Stops To Position
         * @see https://tailwindcss.com/docs/gradient-color-stops
         */
        "gradient-to-pos": [{
          to: scaleGradientStopPosition()
        }],
        /**
         * Gradient Color Stops From
         * @see https://tailwindcss.com/docs/gradient-color-stops
         */
        "gradient-from": [{
          from: scaleColor()
        }],
        /**
         * Gradient Color Stops Via
         * @see https://tailwindcss.com/docs/gradient-color-stops
         */
        "gradient-via": [{
          via: scaleColor()
        }],
        /**
         * Gradient Color Stops To
         * @see https://tailwindcss.com/docs/gradient-color-stops
         */
        "gradient-to": [{
          to: scaleColor()
        }],
        // ---------------
        // --- Borders ---
        // ---------------
        /**
         * Border Radius
         * @see https://tailwindcss.com/docs/border-radius
         */
        rounded: [{
          rounded: scaleRadius()
        }],
        /**
         * Border Radius Start
         * @see https://tailwindcss.com/docs/border-radius
         */
        "rounded-s": [{
          "rounded-s": scaleRadius()
        }],
        /**
         * Border Radius End
         * @see https://tailwindcss.com/docs/border-radius
         */
        "rounded-e": [{
          "rounded-e": scaleRadius()
        }],
        /**
         * Border Radius Top
         * @see https://tailwindcss.com/docs/border-radius
         */
        "rounded-t": [{
          "rounded-t": scaleRadius()
        }],
        /**
         * Border Radius Right
         * @see https://tailwindcss.com/docs/border-radius
         */
        "rounded-r": [{
          "rounded-r": scaleRadius()
        }],
        /**
         * Border Radius Bottom
         * @see https://tailwindcss.com/docs/border-radius
         */
        "rounded-b": [{
          "rounded-b": scaleRadius()
        }],
        /**
         * Border Radius Left
         * @see https://tailwindcss.com/docs/border-radius
         */
        "rounded-l": [{
          "rounded-l": scaleRadius()
        }],
        /**
         * Border Radius Start Start
         * @see https://tailwindcss.com/docs/border-radius
         */
        "rounded-ss": [{
          "rounded-ss": scaleRadius()
        }],
        /**
         * Border Radius Start End
         * @see https://tailwindcss.com/docs/border-radius
         */
        "rounded-se": [{
          "rounded-se": scaleRadius()
        }],
        /**
         * Border Radius End End
         * @see https://tailwindcss.com/docs/border-radius
         */
        "rounded-ee": [{
          "rounded-ee": scaleRadius()
        }],
        /**
         * Border Radius End Start
         * @see https://tailwindcss.com/docs/border-radius
         */
        "rounded-es": [{
          "rounded-es": scaleRadius()
        }],
        /**
         * Border Radius Top Left
         * @see https://tailwindcss.com/docs/border-radius
         */
        "rounded-tl": [{
          "rounded-tl": scaleRadius()
        }],
        /**
         * Border Radius Top Right
         * @see https://tailwindcss.com/docs/border-radius
         */
        "rounded-tr": [{
          "rounded-tr": scaleRadius()
        }],
        /**
         * Border Radius Bottom Right
         * @see https://tailwindcss.com/docs/border-radius
         */
        "rounded-br": [{
          "rounded-br": scaleRadius()
        }],
        /**
         * Border Radius Bottom Left
         * @see https://tailwindcss.com/docs/border-radius
         */
        "rounded-bl": [{
          "rounded-bl": scaleRadius()
        }],
        /**
         * Border Width
         * @see https://tailwindcss.com/docs/border-width
         */
        "border-w": [{
          border: scaleBorderWidth()
        }],
        /**
         * Border Width Inline
         * @see https://tailwindcss.com/docs/border-width
         */
        "border-w-x": [{
          "border-x": scaleBorderWidth()
        }],
        /**
         * Border Width Block
         * @see https://tailwindcss.com/docs/border-width
         */
        "border-w-y": [{
          "border-y": scaleBorderWidth()
        }],
        /**
         * Border Width Inline Start
         * @see https://tailwindcss.com/docs/border-width
         */
        "border-w-s": [{
          "border-s": scaleBorderWidth()
        }],
        /**
         * Border Width Inline End
         * @see https://tailwindcss.com/docs/border-width
         */
        "border-w-e": [{
          "border-e": scaleBorderWidth()
        }],
        /**
         * Border Width Block Start
         * @see https://tailwindcss.com/docs/border-width
         */
        "border-w-bs": [{
          "border-bs": scaleBorderWidth()
        }],
        /**
         * Border Width Block End
         * @see https://tailwindcss.com/docs/border-width
         */
        "border-w-be": [{
          "border-be": scaleBorderWidth()
        }],
        /**
         * Border Width Top
         * @see https://tailwindcss.com/docs/border-width
         */
        "border-w-t": [{
          "border-t": scaleBorderWidth()
        }],
        /**
         * Border Width Right
         * @see https://tailwindcss.com/docs/border-width
         */
        "border-w-r": [{
          "border-r": scaleBorderWidth()
        }],
        /**
         * Border Width Bottom
         * @see https://tailwindcss.com/docs/border-width
         */
        "border-w-b": [{
          "border-b": scaleBorderWidth()
        }],
        /**
         * Border Width Left
         * @see https://tailwindcss.com/docs/border-width
         */
        "border-w-l": [{
          "border-l": scaleBorderWidth()
        }],
        /**
         * Divide Width X
         * @see https://tailwindcss.com/docs/border-width#between-children
         */
        "divide-x": [{
          "divide-x": scaleBorderWidth()
        }],
        /**
         * Divide Width X Reverse
         * @see https://tailwindcss.com/docs/border-width#between-children
         */
        "divide-x-reverse": ["divide-x-reverse"],
        /**
         * Divide Width Y
         * @see https://tailwindcss.com/docs/border-width#between-children
         */
        "divide-y": [{
          "divide-y": scaleBorderWidth()
        }],
        /**
         * Divide Width Y Reverse
         * @see https://tailwindcss.com/docs/border-width#between-children
         */
        "divide-y-reverse": ["divide-y-reverse"],
        /**
         * Border Style
         * @see https://tailwindcss.com/docs/border-style
         */
        "border-style": [{
          border: [...scaleLineStyle(), "hidden", "none"]
        }],
        /**
         * Divide Style
         * @see https://tailwindcss.com/docs/border-style#setting-the-divider-style
         */
        "divide-style": [{
          divide: [...scaleLineStyle(), "hidden", "none"]
        }],
        /**
         * Border Color
         * @see https://tailwindcss.com/docs/border-color
         */
        "border-color": [{
          border: scaleColor()
        }],
        /**
         * Border Color Inline
         * @see https://tailwindcss.com/docs/border-color
         */
        "border-color-x": [{
          "border-x": scaleColor()
        }],
        /**
         * Border Color Block
         * @see https://tailwindcss.com/docs/border-color
         */
        "border-color-y": [{
          "border-y": scaleColor()
        }],
        /**
         * Border Color Inline Start
         * @see https://tailwindcss.com/docs/border-color
         */
        "border-color-s": [{
          "border-s": scaleColor()
        }],
        /**
         * Border Color Inline End
         * @see https://tailwindcss.com/docs/border-color
         */
        "border-color-e": [{
          "border-e": scaleColor()
        }],
        /**
         * Border Color Block Start
         * @see https://tailwindcss.com/docs/border-color
         */
        "border-color-bs": [{
          "border-bs": scaleColor()
        }],
        /**
         * Border Color Block End
         * @see https://tailwindcss.com/docs/border-color
         */
        "border-color-be": [{
          "border-be": scaleColor()
        }],
        /**
         * Border Color Top
         * @see https://tailwindcss.com/docs/border-color
         */
        "border-color-t": [{
          "border-t": scaleColor()
        }],
        /**
         * Border Color Right
         * @see https://tailwindcss.com/docs/border-color
         */
        "border-color-r": [{
          "border-r": scaleColor()
        }],
        /**
         * Border Color Bottom
         * @see https://tailwindcss.com/docs/border-color
         */
        "border-color-b": [{
          "border-b": scaleColor()
        }],
        /**
         * Border Color Left
         * @see https://tailwindcss.com/docs/border-color
         */
        "border-color-l": [{
          "border-l": scaleColor()
        }],
        /**
         * Divide Color
         * @see https://tailwindcss.com/docs/divide-color
         */
        "divide-color": [{
          divide: scaleColor()
        }],
        /**
         * Outline Style
         * @see https://tailwindcss.com/docs/outline-style
         */
        "outline-style": [{
          outline: [...scaleLineStyle(), "none", "hidden"]
        }],
        /**
         * Outline Offset
         * @see https://tailwindcss.com/docs/outline-offset
         */
        "outline-offset": [{
          "outline-offset": [isNumber, isArbitraryVariable, isArbitraryValue]
        }],
        /**
         * Outline Width
         * @see https://tailwindcss.com/docs/outline-width
         */
        "outline-w": [{
          outline: ["", isNumber, isArbitraryVariableLength, isArbitraryLength]
        }],
        /**
         * Outline Color
         * @see https://tailwindcss.com/docs/outline-color
         */
        "outline-color": [{
          outline: scaleColor()
        }],
        // ---------------
        // --- Effects ---
        // ---------------
        /**
         * Box Shadow
         * @see https://tailwindcss.com/docs/box-shadow
         */
        shadow: [{
          shadow: [
            // Deprecated since Tailwind CSS v4.0.0
            "",
            // Deprecated since Tailwind CSS v4.0.0
            "inner",
            "none",
            themeShadow,
            isArbitraryVariableShadow,
            isArbitraryShadow
          ]
        }],
        /**
         * Box Shadow Color
         * @see https://tailwindcss.com/docs/box-shadow#setting-the-shadow-color
         */
        "shadow-color": [{
          shadow: scaleColor()
        }],
        /**
         * Inset Box Shadow
         * @see https://tailwindcss.com/docs/box-shadow#adding-an-inset-shadow
         */
        "inset-shadow": [{
          "inset-shadow": ["none", themeInsetShadow, isArbitraryVariableShadow, isArbitraryShadow]
        }],
        /**
         * Inset Box Shadow Color
         * @see https://tailwindcss.com/docs/box-shadow#setting-the-inset-shadow-color
         */
        "inset-shadow-color": [{
          "inset-shadow": scaleColor()
        }],
        /**
         * Ring Width
         * @see https://tailwindcss.com/docs/box-shadow#adding-a-ring
         */
        "ring-w": [{
          ring: scaleBorderWidth()
        }],
        /**
         * Ring Width Inset
         * @see https://v3.tailwindcss.com/docs/ring-width#inset-rings
         * @deprecated since Tailwind CSS v4.0.0
         * @see https://github.com/tailwindlabs/tailwindcss/blob/v4.0.0/packages/tailwindcss/src/utilities.ts#L4158
         */
        "ring-w-inset": ["ring-inset"],
        /**
         * Ring Color
         * @see https://tailwindcss.com/docs/box-shadow#setting-the-ring-color
         */
        "ring-color": [{
          ring: scaleColor()
        }],
        /**
         * Ring Offset Width
         * @see https://v3.tailwindcss.com/docs/ring-offset-width
         * @deprecated since Tailwind CSS v4.0.0
         * @see https://github.com/tailwindlabs/tailwindcss/blob/v4.0.0/packages/tailwindcss/src/utilities.ts#L4158
         */
        "ring-offset-w": [{
          "ring-offset": [isNumber, isArbitraryLength]
        }],
        /**
         * Ring Offset Color
         * @see https://v3.tailwindcss.com/docs/ring-offset-color
         * @deprecated since Tailwind CSS v4.0.0
         * @see https://github.com/tailwindlabs/tailwindcss/blob/v4.0.0/packages/tailwindcss/src/utilities.ts#L4158
         */
        "ring-offset-color": [{
          "ring-offset": scaleColor()
        }],
        /**
         * Inset Ring Width
         * @see https://tailwindcss.com/docs/box-shadow#adding-an-inset-ring
         */
        "inset-ring-w": [{
          "inset-ring": scaleBorderWidth()
        }],
        /**
         * Inset Ring Color
         * @see https://tailwindcss.com/docs/box-shadow#setting-the-inset-ring-color
         */
        "inset-ring-color": [{
          "inset-ring": scaleColor()
        }],
        /**
         * Text Shadow
         * @see https://tailwindcss.com/docs/text-shadow
         */
        "text-shadow": [{
          "text-shadow": ["none", themeTextShadow, isArbitraryVariableShadow, isArbitraryShadow]
        }],
        /**
         * Text Shadow Color
         * @see https://tailwindcss.com/docs/text-shadow#setting-the-shadow-color
         */
        "text-shadow-color": [{
          "text-shadow": scaleColor()
        }],
        /**
         * Opacity
         * @see https://tailwindcss.com/docs/opacity
         */
        opacity: [{
          opacity: [isNumber, isArbitraryVariable, isArbitraryValue]
        }],
        /**
         * Mix Blend Mode
         * @see https://tailwindcss.com/docs/mix-blend-mode
         */
        "mix-blend": [{
          "mix-blend": [...scaleBlendMode(), "plus-darker", "plus-lighter"]
        }],
        /**
         * Background Blend Mode
         * @see https://tailwindcss.com/docs/background-blend-mode
         */
        "bg-blend": [{
          "bg-blend": scaleBlendMode()
        }],
        /**
         * Mask Clip
         * @see https://tailwindcss.com/docs/mask-clip
         */
        "mask-clip": [{
          "mask-clip": ["border", "padding", "content", "fill", "stroke", "view"]
        }, "mask-no-clip"],
        /**
         * Mask Composite
         * @see https://tailwindcss.com/docs/mask-composite
         */
        "mask-composite": [{
          mask: ["add", "subtract", "intersect", "exclude"]
        }],
        /**
         * Mask Image
         * @see https://tailwindcss.com/docs/mask-image
         */
        "mask-image-linear-pos": [{
          "mask-linear": [isNumber]
        }],
        "mask-image-linear-from-pos": [{
          "mask-linear-from": scaleMaskImagePosition()
        }],
        "mask-image-linear-to-pos": [{
          "mask-linear-to": scaleMaskImagePosition()
        }],
        "mask-image-linear-from-color": [{
          "mask-linear-from": scaleColor()
        }],
        "mask-image-linear-to-color": [{
          "mask-linear-to": scaleColor()
        }],
        "mask-image-t-from-pos": [{
          "mask-t-from": scaleMaskImagePosition()
        }],
        "mask-image-t-to-pos": [{
          "mask-t-to": scaleMaskImagePosition()
        }],
        "mask-image-t-from-color": [{
          "mask-t-from": scaleColor()
        }],
        "mask-image-t-to-color": [{
          "mask-t-to": scaleColor()
        }],
        "mask-image-r-from-pos": [{
          "mask-r-from": scaleMaskImagePosition()
        }],
        "mask-image-r-to-pos": [{
          "mask-r-to": scaleMaskImagePosition()
        }],
        "mask-image-r-from-color": [{
          "mask-r-from": scaleColor()
        }],
        "mask-image-r-to-color": [{
          "mask-r-to": scaleColor()
        }],
        "mask-image-b-from-pos": [{
          "mask-b-from": scaleMaskImagePosition()
        }],
        "mask-image-b-to-pos": [{
          "mask-b-to": scaleMaskImagePosition()
        }],
        "mask-image-b-from-color": [{
          "mask-b-from": scaleColor()
        }],
        "mask-image-b-to-color": [{
          "mask-b-to": scaleColor()
        }],
        "mask-image-l-from-pos": [{
          "mask-l-from": scaleMaskImagePosition()
        }],
        "mask-image-l-to-pos": [{
          "mask-l-to": scaleMaskImagePosition()
        }],
        "mask-image-l-from-color": [{
          "mask-l-from": scaleColor()
        }],
        "mask-image-l-to-color": [{
          "mask-l-to": scaleColor()
        }],
        "mask-image-x-from-pos": [{
          "mask-x-from": scaleMaskImagePosition()
        }],
        "mask-image-x-to-pos": [{
          "mask-x-to": scaleMaskImagePosition()
        }],
        "mask-image-x-from-color": [{
          "mask-x-from": scaleColor()
        }],
        "mask-image-x-to-color": [{
          "mask-x-to": scaleColor()
        }],
        "mask-image-y-from-pos": [{
          "mask-y-from": scaleMaskImagePosition()
        }],
        "mask-image-y-to-pos": [{
          "mask-y-to": scaleMaskImagePosition()
        }],
        "mask-image-y-from-color": [{
          "mask-y-from": scaleColor()
        }],
        "mask-image-y-to-color": [{
          "mask-y-to": scaleColor()
        }],
        "mask-image-radial": [{
          "mask-radial": [isArbitraryVariable, isArbitraryValue]
        }],
        "mask-image-radial-from-pos": [{
          "mask-radial-from": scaleMaskImagePosition()
        }],
        "mask-image-radial-to-pos": [{
          "mask-radial-to": scaleMaskImagePosition()
        }],
        "mask-image-radial-from-color": [{
          "mask-radial-from": scaleColor()
        }],
        "mask-image-radial-to-color": [{
          "mask-radial-to": scaleColor()
        }],
        "mask-image-radial-shape": [{
          "mask-radial": ["circle", "ellipse"]
        }],
        "mask-image-radial-size": [{
          "mask-radial": [{
            closest: ["side", "corner"],
            farthest: ["side", "corner"]
          }]
        }],
        "mask-image-radial-pos": [{
          "mask-radial-at": scalePosition()
        }],
        "mask-image-conic-pos": [{
          "mask-conic": [isNumber]
        }],
        "mask-image-conic-from-pos": [{
          "mask-conic-from": scaleMaskImagePosition()
        }],
        "mask-image-conic-to-pos": [{
          "mask-conic-to": scaleMaskImagePosition()
        }],
        "mask-image-conic-from-color": [{
          "mask-conic-from": scaleColor()
        }],
        "mask-image-conic-to-color": [{
          "mask-conic-to": scaleColor()
        }],
        /**
         * Mask Mode
         * @see https://tailwindcss.com/docs/mask-mode
         */
        "mask-mode": [{
          mask: ["alpha", "luminance", "match"]
        }],
        /**
         * Mask Origin
         * @see https://tailwindcss.com/docs/mask-origin
         */
        "mask-origin": [{
          "mask-origin": ["border", "padding", "content", "fill", "stroke", "view"]
        }],
        /**
         * Mask Position
         * @see https://tailwindcss.com/docs/mask-position
         */
        "mask-position": [{
          mask: scaleBgPosition()
        }],
        /**
         * Mask Repeat
         * @see https://tailwindcss.com/docs/mask-repeat
         */
        "mask-repeat": [{
          mask: scaleBgRepeat()
        }],
        /**
         * Mask Size
         * @see https://tailwindcss.com/docs/mask-size
         */
        "mask-size": [{
          mask: scaleBgSize()
        }],
        /**
         * Mask Type
         * @see https://tailwindcss.com/docs/mask-type
         */
        "mask-type": [{
          "mask-type": ["alpha", "luminance"]
        }],
        /**
         * Mask Image
         * @see https://tailwindcss.com/docs/mask-image
         */
        "mask-image": [{
          mask: ["none", isArbitraryVariable, isArbitraryValue]
        }],
        // ---------------
        // --- Filters ---
        // ---------------
        /**
         * Filter
         * @see https://tailwindcss.com/docs/filter
         */
        filter: [{
          filter: [
            // Deprecated since Tailwind CSS v3.0.0
            "",
            "none",
            isArbitraryVariable,
            isArbitraryValue
          ]
        }],
        /**
         * Blur
         * @see https://tailwindcss.com/docs/blur
         */
        blur: [{
          blur: scaleBlur()
        }],
        /**
         * Brightness
         * @see https://tailwindcss.com/docs/brightness
         */
        brightness: [{
          brightness: [isNumber, isArbitraryVariable, isArbitraryValue]
        }],
        /**
         * Contrast
         * @see https://tailwindcss.com/docs/contrast
         */
        contrast: [{
          contrast: [isNumber, isArbitraryVariable, isArbitraryValue]
        }],
        /**
         * Drop Shadow
         * @see https://tailwindcss.com/docs/drop-shadow
         */
        "drop-shadow": [{
          "drop-shadow": [
            // Deprecated since Tailwind CSS v4.0.0
            "",
            "none",
            themeDropShadow,
            isArbitraryVariableShadow,
            isArbitraryShadow
          ]
        }],
        /**
         * Drop Shadow Color
         * @see https://tailwindcss.com/docs/filter-drop-shadow#setting-the-shadow-color
         */
        "drop-shadow-color": [{
          "drop-shadow": scaleColor()
        }],
        /**
         * Grayscale
         * @see https://tailwindcss.com/docs/grayscale
         */
        grayscale: [{
          grayscale: ["", isNumber, isArbitraryVariable, isArbitraryValue]
        }],
        /**
         * Hue Rotate
         * @see https://tailwindcss.com/docs/hue-rotate
         */
        "hue-rotate": [{
          "hue-rotate": [isNumber, isArbitraryVariable, isArbitraryValue]
        }],
        /**
         * Invert
         * @see https://tailwindcss.com/docs/invert
         */
        invert: [{
          invert: ["", isNumber, isArbitraryVariable, isArbitraryValue]
        }],
        /**
         * Saturate
         * @see https://tailwindcss.com/docs/saturate
         */
        saturate: [{
          saturate: [isNumber, isArbitraryVariable, isArbitraryValue]
        }],
        /**
         * Sepia
         * @see https://tailwindcss.com/docs/sepia
         */
        sepia: [{
          sepia: ["", isNumber, isArbitraryVariable, isArbitraryValue]
        }],
        /**
         * Backdrop Filter
         * @see https://tailwindcss.com/docs/backdrop-filter
         */
        "backdrop-filter": [{
          "backdrop-filter": [
            // Deprecated since Tailwind CSS v3.0.0
            "",
            "none",
            isArbitraryVariable,
            isArbitraryValue
          ]
        }],
        /**
         * Backdrop Blur
         * @see https://tailwindcss.com/docs/backdrop-blur
         */
        "backdrop-blur": [{
          "backdrop-blur": scaleBlur()
        }],
        /**
         * Backdrop Brightness
         * @see https://tailwindcss.com/docs/backdrop-brightness
         */
        "backdrop-brightness": [{
          "backdrop-brightness": [isNumber, isArbitraryVariable, isArbitraryValue]
        }],
        /**
         * Backdrop Contrast
         * @see https://tailwindcss.com/docs/backdrop-contrast
         */
        "backdrop-contrast": [{
          "backdrop-contrast": [isNumber, isArbitraryVariable, isArbitraryValue]
        }],
        /**
         * Backdrop Grayscale
         * @see https://tailwindcss.com/docs/backdrop-grayscale
         */
        "backdrop-grayscale": [{
          "backdrop-grayscale": ["", isNumber, isArbitraryVariable, isArbitraryValue]
        }],
        /**
         * Backdrop Hue Rotate
         * @see https://tailwindcss.com/docs/backdrop-hue-rotate
         */
        "backdrop-hue-rotate": [{
          "backdrop-hue-rotate": [isNumber, isArbitraryVariable, isArbitraryValue]
        }],
        /**
         * Backdrop Invert
         * @see https://tailwindcss.com/docs/backdrop-invert
         */
        "backdrop-invert": [{
          "backdrop-invert": ["", isNumber, isArbitraryVariable, isArbitraryValue]
        }],
        /**
         * Backdrop Opacity
         * @see https://tailwindcss.com/docs/backdrop-opacity
         */
        "backdrop-opacity": [{
          "backdrop-opacity": [isNumber, isArbitraryVariable, isArbitraryValue]
        }],
        /**
         * Backdrop Saturate
         * @see https://tailwindcss.com/docs/backdrop-saturate
         */
        "backdrop-saturate": [{
          "backdrop-saturate": [isNumber, isArbitraryVariable, isArbitraryValue]
        }],
        /**
         * Backdrop Sepia
         * @see https://tailwindcss.com/docs/backdrop-sepia
         */
        "backdrop-sepia": [{
          "backdrop-sepia": ["", isNumber, isArbitraryVariable, isArbitraryValue]
        }],
        // --------------
        // --- Tables ---
        // --------------
        /**
         * Border Collapse
         * @see https://tailwindcss.com/docs/border-collapse
         */
        "border-collapse": [{
          border: ["collapse", "separate"]
        }],
        /**
         * Border Spacing
         * @see https://tailwindcss.com/docs/border-spacing
         */
        "border-spacing": [{
          "border-spacing": scaleUnambiguousSpacing()
        }],
        /**
         * Border Spacing X
         * @see https://tailwindcss.com/docs/border-spacing
         */
        "border-spacing-x": [{
          "border-spacing-x": scaleUnambiguousSpacing()
        }],
        /**
         * Border Spacing Y
         * @see https://tailwindcss.com/docs/border-spacing
         */
        "border-spacing-y": [{
          "border-spacing-y": scaleUnambiguousSpacing()
        }],
        /**
         * Table Layout
         * @see https://tailwindcss.com/docs/table-layout
         */
        "table-layout": [{
          table: ["auto", "fixed"]
        }],
        /**
         * Caption Side
         * @see https://tailwindcss.com/docs/caption-side
         */
        caption: [{
          caption: ["top", "bottom"]
        }],
        // ---------------------------------
        // --- Transitions and Animation ---
        // ---------------------------------
        /**
         * Transition Property
         * @see https://tailwindcss.com/docs/transition-property
         */
        transition: [{
          transition: ["", "all", "colors", "opacity", "shadow", "transform", "none", isArbitraryVariable, isArbitraryValue]
        }],
        /**
         * Transition Behavior
         * @see https://tailwindcss.com/docs/transition-behavior
         */
        "transition-behavior": [{
          transition: ["normal", "discrete"]
        }],
        /**
         * Transition Duration
         * @see https://tailwindcss.com/docs/transition-duration
         */
        duration: [{
          duration: [isNumber, "initial", isArbitraryVariable, isArbitraryValue]
        }],
        /**
         * Transition Timing Function
         * @see https://tailwindcss.com/docs/transition-timing-function
         */
        ease: [{
          ease: ["linear", "initial", themeEase, isArbitraryVariable, isArbitraryValue]
        }],
        /**
         * Transition Delay
         * @see https://tailwindcss.com/docs/transition-delay
         */
        delay: [{
          delay: [isNumber, isArbitraryVariable, isArbitraryValue]
        }],
        /**
         * Animation
         * @see https://tailwindcss.com/docs/animation
         */
        animate: [{
          animate: ["none", themeAnimate, isArbitraryVariable, isArbitraryValue]
        }],
        // ------------------
        // --- Transforms ---
        // ------------------
        /**
         * Backface Visibility
         * @see https://tailwindcss.com/docs/backface-visibility
         */
        backface: [{
          backface: ["hidden", "visible"]
        }],
        /**
         * Perspective
         * @see https://tailwindcss.com/docs/perspective
         */
        perspective: [{
          perspective: [themePerspective, isArbitraryVariable, isArbitraryValue]
        }],
        /**
         * Perspective Origin
         * @see https://tailwindcss.com/docs/perspective-origin
         */
        "perspective-origin": [{
          "perspective-origin": scalePositionWithArbitrary()
        }],
        /**
         * Rotate
         * @see https://tailwindcss.com/docs/rotate
         */
        rotate: [{
          rotate: scaleRotate()
        }],
        /**
         * Rotate X
         * @see https://tailwindcss.com/docs/rotate
         */
        "rotate-x": [{
          "rotate-x": scaleRotate()
        }],
        /**
         * Rotate Y
         * @see https://tailwindcss.com/docs/rotate
         */
        "rotate-y": [{
          "rotate-y": scaleRotate()
        }],
        /**
         * Rotate Z
         * @see https://tailwindcss.com/docs/rotate
         */
        "rotate-z": [{
          "rotate-z": scaleRotate()
        }],
        /**
         * Scale
         * @see https://tailwindcss.com/docs/scale
         */
        scale: [{
          scale: scaleScale()
        }],
        /**
         * Scale X
         * @see https://tailwindcss.com/docs/scale
         */
        "scale-x": [{
          "scale-x": scaleScale()
        }],
        /**
         * Scale Y
         * @see https://tailwindcss.com/docs/scale
         */
        "scale-y": [{
          "scale-y": scaleScale()
        }],
        /**
         * Scale Z
         * @see https://tailwindcss.com/docs/scale
         */
        "scale-z": [{
          "scale-z": scaleScale()
        }],
        /**
         * Scale 3D
         * @see https://tailwindcss.com/docs/scale
         */
        "scale-3d": ["scale-3d"],
        /**
         * Skew
         * @see https://tailwindcss.com/docs/skew
         */
        skew: [{
          skew: scaleSkew()
        }],
        /**
         * Skew X
         * @see https://tailwindcss.com/docs/skew
         */
        "skew-x": [{
          "skew-x": scaleSkew()
        }],
        /**
         * Skew Y
         * @see https://tailwindcss.com/docs/skew
         */
        "skew-y": [{
          "skew-y": scaleSkew()
        }],
        /**
         * Transform
         * @see https://tailwindcss.com/docs/transform
         */
        transform: [{
          transform: [isArbitraryVariable, isArbitraryValue, "", "none", "gpu", "cpu"]
        }],
        /**
         * Transform Origin
         * @see https://tailwindcss.com/docs/transform-origin
         */
        "transform-origin": [{
          origin: scalePositionWithArbitrary()
        }],
        /**
         * Transform Style
         * @see https://tailwindcss.com/docs/transform-style
         */
        "transform-style": [{
          transform: ["3d", "flat"]
        }],
        /**
         * Translate
         * @see https://tailwindcss.com/docs/translate
         */
        translate: [{
          translate: scaleTranslate()
        }],
        /**
         * Translate X
         * @see https://tailwindcss.com/docs/translate
         */
        "translate-x": [{
          "translate-x": scaleTranslate()
        }],
        /**
         * Translate Y
         * @see https://tailwindcss.com/docs/translate
         */
        "translate-y": [{
          "translate-y": scaleTranslate()
        }],
        /**
         * Translate Z
         * @see https://tailwindcss.com/docs/translate
         */
        "translate-z": [{
          "translate-z": scaleTranslate()
        }],
        /**
         * Translate None
         * @see https://tailwindcss.com/docs/translate
         */
        "translate-none": ["translate-none"],
        /**
         * Zoom
         * @see https://tailwindcss.com/docs/zoom
         */
        zoom: [{
          zoom: [isInteger, isArbitraryVariable, isArbitraryValue]
        }],
        // ---------------------
        // --- Interactivity ---
        // ---------------------
        /**
         * Accent Color
         * @see https://tailwindcss.com/docs/accent-color
         */
        accent: [{
          accent: scaleColor()
        }],
        /**
         * Appearance
         * @see https://tailwindcss.com/docs/appearance
         */
        appearance: [{
          appearance: ["none", "auto"]
        }],
        /**
         * Caret Color
         * @see https://tailwindcss.com/docs/just-in-time-mode#caret-color-utilities
         */
        "caret-color": [{
          caret: scaleColor()
        }],
        /**
         * Color Scheme
         * @see https://tailwindcss.com/docs/color-scheme
         */
        "color-scheme": [{
          scheme: ["normal", "dark", "light", "light-dark", "only-dark", "only-light"]
        }],
        /**
         * Cursor
         * @see https://tailwindcss.com/docs/cursor
         */
        cursor: [{
          cursor: ["auto", "default", "pointer", "wait", "text", "move", "help", "not-allowed", "none", "context-menu", "progress", "cell", "crosshair", "vertical-text", "alias", "copy", "no-drop", "grab", "grabbing", "all-scroll", "col-resize", "row-resize", "n-resize", "e-resize", "s-resize", "w-resize", "ne-resize", "nw-resize", "se-resize", "sw-resize", "ew-resize", "ns-resize", "nesw-resize", "nwse-resize", "zoom-in", "zoom-out", isArbitraryVariable, isArbitraryValue]
        }],
        /**
         * Field Sizing
         * @see https://tailwindcss.com/docs/field-sizing
         */
        "field-sizing": [{
          "field-sizing": ["fixed", "content"]
        }],
        /**
         * Pointer Events
         * @see https://tailwindcss.com/docs/pointer-events
         */
        "pointer-events": [{
          "pointer-events": ["auto", "none"]
        }],
        /**
         * Resize
         * @see https://tailwindcss.com/docs/resize
         */
        resize: [{
          resize: ["none", "", "y", "x"]
        }],
        /**
         * Scroll Behavior
         * @see https://tailwindcss.com/docs/scroll-behavior
         */
        "scroll-behavior": [{
          scroll: ["auto", "smooth"]
        }],
        /**
         * Scrollbar Thumb Color
         * @see https://tailwindcss.com/docs/scrollbar-color
         */
        "scrollbar-thumb-color": [{
          "scrollbar-thumb": scaleColor()
        }],
        /**
         * Scrollbar Track Color
         * @see https://tailwindcss.com/docs/scrollbar-color
         */
        "scrollbar-track-color": [{
          "scrollbar-track": scaleColor()
        }],
        /**
         * Scrollbar Gutter
         * @see https://tailwindcss.com/docs/scrollbar-gutter
         */
        "scrollbar-gutter": [{
          "scrollbar-gutter": ["auto", "stable", "both"]
        }],
        /**
         * Scrollbar Width
         * @see https://tailwindcss.com/docs/scrollbar-width
         */
        "scrollbar-w": [{
          scrollbar: ["auto", "thin", "none"]
        }],
        /**
         * Scroll Margin
         * @see https://tailwindcss.com/docs/scroll-margin
         */
        "scroll-m": [{
          "scroll-m": scaleUnambiguousSpacing()
        }],
        /**
         * Scroll Margin Inline
         * @see https://tailwindcss.com/docs/scroll-margin
         */
        "scroll-mx": [{
          "scroll-mx": scaleUnambiguousSpacing()
        }],
        /**
         * Scroll Margin Block
         * @see https://tailwindcss.com/docs/scroll-margin
         */
        "scroll-my": [{
          "scroll-my": scaleUnambiguousSpacing()
        }],
        /**
         * Scroll Margin Inline Start
         * @see https://tailwindcss.com/docs/scroll-margin
         */
        "scroll-ms": [{
          "scroll-ms": scaleUnambiguousSpacing()
        }],
        /**
         * Scroll Margin Inline End
         * @see https://tailwindcss.com/docs/scroll-margin
         */
        "scroll-me": [{
          "scroll-me": scaleUnambiguousSpacing()
        }],
        /**
         * Scroll Margin Block Start
         * @see https://tailwindcss.com/docs/scroll-margin
         */
        "scroll-mbs": [{
          "scroll-mbs": scaleUnambiguousSpacing()
        }],
        /**
         * Scroll Margin Block End
         * @see https://tailwindcss.com/docs/scroll-margin
         */
        "scroll-mbe": [{
          "scroll-mbe": scaleUnambiguousSpacing()
        }],
        /**
         * Scroll Margin Top
         * @see https://tailwindcss.com/docs/scroll-margin
         */
        "scroll-mt": [{
          "scroll-mt": scaleUnambiguousSpacing()
        }],
        /**
         * Scroll Margin Right
         * @see https://tailwindcss.com/docs/scroll-margin
         */
        "scroll-mr": [{
          "scroll-mr": scaleUnambiguousSpacing()
        }],
        /**
         * Scroll Margin Bottom
         * @see https://tailwindcss.com/docs/scroll-margin
         */
        "scroll-mb": [{
          "scroll-mb": scaleUnambiguousSpacing()
        }],
        /**
         * Scroll Margin Left
         * @see https://tailwindcss.com/docs/scroll-margin
         */
        "scroll-ml": [{
          "scroll-ml": scaleUnambiguousSpacing()
        }],
        /**
         * Scroll Padding
         * @see https://tailwindcss.com/docs/scroll-padding
         */
        "scroll-p": [{
          "scroll-p": scaleUnambiguousSpacing()
        }],
        /**
         * Scroll Padding Inline
         * @see https://tailwindcss.com/docs/scroll-padding
         */
        "scroll-px": [{
          "scroll-px": scaleUnambiguousSpacing()
        }],
        /**
         * Scroll Padding Block
         * @see https://tailwindcss.com/docs/scroll-padding
         */
        "scroll-py": [{
          "scroll-py": scaleUnambiguousSpacing()
        }],
        /**
         * Scroll Padding Inline Start
         * @see https://tailwindcss.com/docs/scroll-padding
         */
        "scroll-ps": [{
          "scroll-ps": scaleUnambiguousSpacing()
        }],
        /**
         * Scroll Padding Inline End
         * @see https://tailwindcss.com/docs/scroll-padding
         */
        "scroll-pe": [{
          "scroll-pe": scaleUnambiguousSpacing()
        }],
        /**
         * Scroll Padding Block Start
         * @see https://tailwindcss.com/docs/scroll-padding
         */
        "scroll-pbs": [{
          "scroll-pbs": scaleUnambiguousSpacing()
        }],
        /**
         * Scroll Padding Block End
         * @see https://tailwindcss.com/docs/scroll-padding
         */
        "scroll-pbe": [{
          "scroll-pbe": scaleUnambiguousSpacing()
        }],
        /**
         * Scroll Padding Top
         * @see https://tailwindcss.com/docs/scroll-padding
         */
        "scroll-pt": [{
          "scroll-pt": scaleUnambiguousSpacing()
        }],
        /**
         * Scroll Padding Right
         * @see https://tailwindcss.com/docs/scroll-padding
         */
        "scroll-pr": [{
          "scroll-pr": scaleUnambiguousSpacing()
        }],
        /**
         * Scroll Padding Bottom
         * @see https://tailwindcss.com/docs/scroll-padding
         */
        "scroll-pb": [{
          "scroll-pb": scaleUnambiguousSpacing()
        }],
        /**
         * Scroll Padding Left
         * @see https://tailwindcss.com/docs/scroll-padding
         */
        "scroll-pl": [{
          "scroll-pl": scaleUnambiguousSpacing()
        }],
        /**
         * Scroll Snap Align
         * @see https://tailwindcss.com/docs/scroll-snap-align
         */
        "snap-align": [{
          snap: ["start", "end", "center", "align-none"]
        }],
        /**
         * Scroll Snap Stop
         * @see https://tailwindcss.com/docs/scroll-snap-stop
         */
        "snap-stop": [{
          snap: ["normal", "always"]
        }],
        /**
         * Scroll Snap Type
         * @see https://tailwindcss.com/docs/scroll-snap-type
         */
        "snap-type": [{
          snap: ["none", "x", "y", "both"]
        }],
        /**
         * Scroll Snap Type Strictness
         * @see https://tailwindcss.com/docs/scroll-snap-type
         */
        "snap-strictness": [{
          snap: ["mandatory", "proximity"]
        }],
        /**
         * Touch Action
         * @see https://tailwindcss.com/docs/touch-action
         */
        touch: [{
          touch: ["auto", "none", "manipulation"]
        }],
        /**
         * Touch Action X
         * @see https://tailwindcss.com/docs/touch-action
         */
        "touch-x": [{
          "touch-pan": ["x", "left", "right"]
        }],
        /**
         * Touch Action Y
         * @see https://tailwindcss.com/docs/touch-action
         */
        "touch-y": [{
          "touch-pan": ["y", "up", "down"]
        }],
        /**
         * Touch Action Pinch Zoom
         * @see https://tailwindcss.com/docs/touch-action
         */
        "touch-pz": ["touch-pinch-zoom"],
        /**
         * User Select
         * @see https://tailwindcss.com/docs/user-select
         */
        select: [{
          select: ["none", "text", "all", "auto"]
        }],
        /**
         * Will Change
         * @see https://tailwindcss.com/docs/will-change
         */
        "will-change": [{
          "will-change": ["auto", "scroll", "contents", "transform", isArbitraryVariable, isArbitraryValue]
        }],
        // -----------
        // --- SVG ---
        // -----------
        /**
         * Fill
         * @see https://tailwindcss.com/docs/fill
         */
        fill: [{
          fill: ["none", ...scaleColor()]
        }],
        /**
         * Stroke Width
         * @see https://tailwindcss.com/docs/stroke-width
         */
        "stroke-w": [{
          stroke: [isNumber, isArbitraryVariableLength, isArbitraryLength, isArbitraryNumber]
        }],
        /**
         * Stroke
         * @see https://tailwindcss.com/docs/stroke
         */
        stroke: [{
          stroke: ["none", ...scaleColor()]
        }],
        // ---------------------
        // --- Accessibility ---
        // ---------------------
        /**
         * Forced Color Adjust
         * @see https://tailwindcss.com/docs/forced-color-adjust
         */
        "forced-color-adjust": [{
          "forced-color-adjust": ["auto", "none"]
        }]
      },
      conflictingClassGroups: {
        "container-named": ["container-type"],
        overflow: ["overflow-x", "overflow-y"],
        overscroll: ["overscroll-x", "overscroll-y"],
        inset: ["inset-x", "inset-y", "inset-bs", "inset-be", "start", "end", "top", "right", "bottom", "left"],
        "inset-x": ["start", "end", "right", "left"],
        "inset-y": ["inset-bs", "inset-be", "top", "bottom"],
        flex: ["basis", "grow", "shrink"],
        gap: ["gap-x", "gap-y"],
        p: ["px", "py", "ps", "pe", "pbs", "pbe", "pt", "pr", "pb", "pl"],
        px: ["ps", "pe", "pr", "pl"],
        py: ["pbs", "pbe", "pt", "pb"],
        m: ["mx", "my", "ms", "me", "mbs", "mbe", "mt", "mr", "mb", "ml"],
        mx: ["ms", "me", "mr", "ml"],
        my: ["mbs", "mbe", "mt", "mb"],
        size: ["w", "h"],
        "font-size": ["leading"],
        "fvn-normal": ["fvn-ordinal", "fvn-slashed-zero", "fvn-figure", "fvn-spacing", "fvn-fraction"],
        "fvn-ordinal": ["fvn-normal"],
        "fvn-slashed-zero": ["fvn-normal"],
        "fvn-figure": ["fvn-normal"],
        "fvn-spacing": ["fvn-normal"],
        "fvn-fraction": ["fvn-normal"],
        "line-clamp": ["display", "overflow"],
        rounded: ["rounded-s", "rounded-e", "rounded-t", "rounded-r", "rounded-b", "rounded-l", "rounded-ss", "rounded-se", "rounded-ee", "rounded-es", "rounded-tl", "rounded-tr", "rounded-br", "rounded-bl"],
        "rounded-s": ["rounded-ss", "rounded-es"],
        "rounded-e": ["rounded-se", "rounded-ee"],
        "rounded-t": ["rounded-tl", "rounded-tr"],
        "rounded-r": ["rounded-tr", "rounded-br"],
        "rounded-b": ["rounded-br", "rounded-bl"],
        "rounded-l": ["rounded-tl", "rounded-bl"],
        "border-spacing": ["border-spacing-x", "border-spacing-y"],
        "border-w": ["border-w-x", "border-w-y", "border-w-s", "border-w-e", "border-w-bs", "border-w-be", "border-w-t", "border-w-r", "border-w-b", "border-w-l"],
        "border-w-x": ["border-w-s", "border-w-e", "border-w-r", "border-w-l"],
        "border-w-y": ["border-w-bs", "border-w-be", "border-w-t", "border-w-b"],
        "border-color": ["border-color-x", "border-color-y", "border-color-s", "border-color-e", "border-color-bs", "border-color-be", "border-color-t", "border-color-r", "border-color-b", "border-color-l"],
        "border-color-x": ["border-color-s", "border-color-e", "border-color-r", "border-color-l"],
        "border-color-y": ["border-color-bs", "border-color-be", "border-color-t", "border-color-b"],
        translate: ["translate-x", "translate-y", "translate-none"],
        "translate-none": ["translate", "translate-x", "translate-y", "translate-z"],
        "scroll-m": ["scroll-mx", "scroll-my", "scroll-ms", "scroll-me", "scroll-mbs", "scroll-mbe", "scroll-mt", "scroll-mr", "scroll-mb", "scroll-ml"],
        "scroll-mx": ["scroll-ms", "scroll-me", "scroll-mr", "scroll-ml"],
        "scroll-my": ["scroll-mbs", "scroll-mbe", "scroll-mt", "scroll-mb"],
        "scroll-p": ["scroll-px", "scroll-py", "scroll-ps", "scroll-pe", "scroll-pbs", "scroll-pbe", "scroll-pt", "scroll-pr", "scroll-pb", "scroll-pl"],
        "scroll-px": ["scroll-ps", "scroll-pe", "scroll-pr", "scroll-pl"],
        "scroll-py": ["scroll-pbs", "scroll-pbe", "scroll-pt", "scroll-pb"],
        touch: ["touch-x", "touch-y", "touch-pz"],
        "touch-x": ["touch"],
        "touch-y": ["touch"],
        "touch-pz": ["touch"]
      },
      conflictingClassGroupModifiers: {
        "font-size": ["leading"]
      },
      postfixLookupClassGroups: ["container-type"],
      orderSensitiveModifiers: ["*", "**", "after", "backdrop", "before", "details-content", "file", "first-letter", "first-line", "marker", "placeholder", "selection"]
    };
  };
  const twMerge = /* @__PURE__ */ createTailwindMerge(getDefaultConfig);
  const Activity = createLucideIcon("activity", [
    [
      "path",
      {
        d: "M22 12h-2.48a2 2 0 0 0-1.93 1.46l-2.35 8.36a.25.25 0 0 1-.48 0L9.24 2.18a.25.25 0 0 0-.48 0l-2.35 8.36A2 2 0 0 1 4.49 12H2",
        key: "169zse"
      }
    ]
  ]);
  const TriangleAlert = createLucideIcon("triangle-alert", [
    [
      "path",
      {
        d: "m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3",
        key: "wmoenq"
      }
    ],
    ["path", { d: "M12 9v4", key: "juzpu7" }],
    ["path", { d: "M12 17h.01", key: "p32p05" }]
  ]);
  const ArrowDownLeft = createLucideIcon("arrow-down-left", [
    ["path", { d: "M17 7 7 17", key: "15tmo1" }],
    ["path", { d: "M17 17H7V7", key: "1org7z" }]
  ]);
  const ArrowUpRight = createLucideIcon("arrow-up-right", [
    ["path", { d: "M7 7h10v10", key: "1tivn9" }],
    ["path", { d: "M7 17 17 7", key: "1vkiza" }]
  ]);
  const ChartColumn = createLucideIcon("chart-column", [
    ["path", { d: "M3 3v16a2 2 0 0 0 2 2h16", key: "c24i48" }],
    ["path", { d: "M18 17V9", key: "2bz60n" }],
    ["path", { d: "M13 17V5", key: "1frdt8" }],
    ["path", { d: "M8 17v-3", key: "17ska0" }]
  ]);
  const Languages = createLucideIcon("languages", [
    ["path", { d: "m5 8 6 6", key: "1wu5hv" }],
    ["path", { d: "m4 14 6-6 2-3", key: "1k1g8d" }],
    ["path", { d: "M2 5h12", key: "or177f" }],
    ["path", { d: "M7 2h1", key: "1t2jsx" }],
    ["path", { d: "m22 22-5-10-5 10", key: "don7ne" }],
    ["path", { d: "M14 18h6", key: "1m8k6r" }]
  ]);
  const RefreshCcw = createLucideIcon("refresh-ccw", [
    ["path", { d: "M21 12a9 9 0 0 0-9-9 9.75 9.75 0 0 0-6.74 2.74L3 8", key: "14sxne" }],
    ["path", { d: "M3 3v5h5", key: "1xhq8a" }],
    ["path", { d: "M3 12a9 9 0 0 0 9 9 9.75 9.75 0 0 0 6.74-2.74L21 16", key: "1hlbsb" }],
    ["path", { d: "M16 16h5v5", key: "ccwih5" }]
  ]);
  const SlidersHorizontal = createLucideIcon("sliders-horizontal", [
    ["path", { d: "M10 5H3", key: "1qgfaw" }],
    ["path", { d: "M12 19H3", key: "yhmn1j" }],
    ["path", { d: "M14 3v4", key: "1sua03" }],
    ["path", { d: "M16 17v4", key: "1q0r14" }],
    ["path", { d: "M21 12h-9", key: "1o4lsq" }],
    ["path", { d: "M21 19h-5", key: "1rlt1p" }],
    ["path", { d: "M21 5h-7", key: "1oszz2" }],
    ["path", { d: "M8 10v4", key: "tgpxqk" }],
    ["path", { d: "M8 12H3", key: "a7s4jb" }]
  ]);
  function cn(...inputs) {
    return twMerge(clsx(inputs));
  }
  const _sfc_main$3 = /* @__PURE__ */ defineComponent({
    __name: "Badge",
    props: {
      variant: {},
      class: { type: [Boolean, null, String, Object, Array] }
    },
    setup(__props) {
      return (_ctx, _cache) => {
        return openBlock(), createElementBlock(
          "span",
          {
            class: normalizeClass(
              unref(cn)(
                "inline-flex items-center rounded-md border px-2 py-0.5 text-[11px] font-medium leading-4",
                !__props.variant || __props.variant === "default" ? "border-transparent bg-primary text-primary-foreground" : __props.variant === "secondary" ? "border-transparent bg-secondary text-secondary-foreground" : "border-border text-foreground",
                _ctx.$props.class
              )
            )
          },
          [
            renderSlot(_ctx.$slots, "default")
          ],
          2
          /* CLASS */
        );
      };
    }
  });
  const _sfc_main$2 = /* @__PURE__ */ defineComponent({
    __name: "Button",
    props: {
      variant: { default: "default" },
      size: { default: "default" },
      class: { type: [Boolean, null, String, Object, Array] }
    },
    setup(__props) {
      return (_ctx, _cache) => {
        return openBlock(), createElementBlock(
          "button",
          {
            class: normalizeClass(
              unref(cn)(
                "inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium transition-colors outline-none focus-visible:ring-2 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50",
                __props.variant === "default" && "bg-primary text-primary-foreground hover:bg-primary/90",
                __props.variant === "outline" && "border border-border bg-background hover:bg-accent hover:text-accent-foreground",
                __props.variant === "ghost" && "hover:bg-accent hover:text-accent-foreground",
                __props.size === "default" && "h-9 px-4 py-2",
                __props.size === "sm" && "h-8 rounded-md px-3 text-xs",
                __props.size === "xs" && "h-7 rounded-md px-2 text-xs",
                __props.size === "icon" && "size-8",
                __props.size === "icon-sm" && "size-7",
                _ctx.$props.class
              )
            )
          },
          [
            renderSlot(_ctx.$slots, "default")
          ],
          2
          /* CLASS */
        );
      };
    }
  });
  const _hoisted_1$1 = { class: "booster-capture-settings" };
  const _hoisted_2$1 = { class: "booster-note" };
  const _hoisted_3$1 = {
    key: 0,
    class: "booster-form-body"
  };
  const _hoisted_4$1 = ["disabled"];
  const _hoisted_5$1 = { value: "default" };
  const _hoisted_6$1 = ["value"];
  const _hoisted_7$1 = ["disabled"];
  const _hoisted_8$1 = {
    key: 0,
    value: "inherit"
  };
  const _hoisted_9$1 = { value: "on" };
  const _hoisted_10$1 = { value: "off" };
  const _hoisted_11$1 = ["disabled"];
  const _hoisted_12$1 = { class: "booster-note" };
  const _hoisted_13$1 = ["disabled"];
  const _hoisted_14$1 = {
    key: 1,
    role: "alert",
    class: "booster-error"
  };
  const _hoisted_15$1 = {
    key: 2,
    role: "status"
  };
  const _hoisted_16$1 = {
    key: 1,
    class: "booster-note"
  };
  const _sfc_main$1 = /* @__PURE__ */ defineComponent({
    __name: "CaptureSettings",
    props: {
      settingsAdapter: {},
      archiveAdapter: {},
      context: {},
      locale: {}
    },
    setup(__props) {
      const props = __props;
      const settings = /* @__PURE__ */ ref();
      const contexts = /* @__PURE__ */ ref([]);
      const projects = /* @__PURE__ */ ref([]), conversations = /* @__PURE__ */ ref([]);
      const selected = /* @__PURE__ */ ref("default"), mode2 = /* @__PURE__ */ ref("off");
      const rule = /* @__PURE__ */ ref({ ...DEFAULT_CAPTURE_RULE });
      const busy = /* @__PURE__ */ ref(false), error = /* @__PURE__ */ ref(false), saved = /* @__PURE__ */ ref(false);
      const t = (key) => translate(props.locale, key);
      let unsubscribe, alive = true;
      const keyFor = (context) => `${context.scope}:${context.id}`;
      const scopes = computed(() => {
        const values = /* @__PURE__ */ new Map();
        for (const id of Object.keys(settings.value?.archive.projects ?? {})) values.set(`project:${id}`, { scope: "project", id, title: projects.value.find((p2) => p2.projectId === id)?.title ?? null });
        for (const id of Object.keys(settings.value?.archive.conversations ?? {})) {
          const c = conversations.value.find((c2) => c2.conversationId === id);
          values.set(`conversation:${id}`, { scope: "conversation", id, title: c?.title ?? null, projectId: c?.projectId ?? null });
        }
        for (const c of contexts.value) values.set(keyFor(c), c);
        if (props.context) values.set(keyFor(props.context), props.context);
        return [...values.values()];
      });
      const target = computed(() => scopes.value.find((c) => keyFor(c) === selected.value));
      function loadRule() {
        const archive = settings.value?.archive;
        if (!archive) return;
        const scope = target.value;
        const own = !scope ? archive.defaultRule : scope.scope === "project" ? archive.projects[scope.id] : archive.conversations[scope.id];
        const effective = own ?? (scope?.scope === "conversation" ? captureRuleFor(archive, scope.id, scope.projectId ?? null) : archive.defaultRule);
        rule.value = { ...effective };
        mode2.value = own ? own.enabled ? "on" : "off" : "inherit";
        saved.value = false;
      }
      watch(selected, loadRule);
      watch(() => props.context, (value) => {
        if (value) {
          selected.value = keyFor(value);
          loadRule();
        }
      });
      onMounted(async () => {
        try {
          const next = await props.settingsAdapter.get();
          if (!alive) return;
          settings.value = snapshotSettings(next);
          unsubscribe = props.settingsAdapter.subscribe((s) => {
            settings.value = snapshotSettings(s);
          });
          if (props.archiveAdapter) {
            const [current, ps, cs] = await Promise.all([props.archiveAdapter.getCurrentContext(), props.archiveAdapter.listProjects(), props.archiveAdapter.listConversations()]);
            if (!alive) return;
            projects.value = ps;
            conversations.value = cs;
            if (current.projectId) contexts.value.push({ scope: "project", id: current.projectId, title: current.projectTitle });
            if (current.conversationId) contexts.value.push({ scope: "conversation", id: current.conversationId, title: current.conversationTitle, projectId: current.projectId });
          }
          selected.value = props.context ? keyFor(props.context) : contexts.value.at(-1) ? keyFor(contexts.value.at(-1)) : "default";
          loadRule();
        } catch {
          error.value = true;
          loadRule();
        }
      });
      onBeforeUnmount(() => {
        alive = false;
        unsubscribe?.();
      });
      async function save() {
        if (busy.value || !settings.value) return;
        busy.value = true;
        error.value = false;
        saved.value = false;
        const scope = target.value;
        const next = { ...rule.value, enabled: mode2.value === "on" };
        try {
          const patch = scope ? scope.scope === "project" ? { projects: { [scope.id]: mode2.value === "inherit" ? null : next } } : { conversations: { [scope.id]: mode2.value === "inherit" ? null : next } } : { defaultRule: next };
          settings.value = snapshotSettings(await props.settingsAdapter.update({ archive: patch }));
          saved.value = true;
        } catch {
          error.value = true;
        } finally {
          busy.value = false;
        }
      }
      return (_ctx, _cache) => {
        return openBlock(), createElementBlock("section", _hoisted_1$1, [
          createBaseVNode(
            "h3",
            null,
            toDisplayString(t("capture.title")),
            1
            /* TEXT */
          ),
          createBaseVNode(
            "p",
            _hoisted_2$1,
            toDisplayString(t("capture.explanation")),
            1
            /* TEXT */
          ),
          settings.value ? (openBlock(), createElementBlock("div", _hoisted_3$1, [
            createBaseVNode("label", null, [
              createTextVNode(
                toDisplayString(t("capture.scope")),
                1
                /* TEXT */
              ),
              withDirectives(createBaseVNode("select", {
                "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => selected.value = $event),
                disabled: busy.value
              }, [
                createBaseVNode(
                  "option",
                  _hoisted_5$1,
                  toDisplayString(t("capture.global")),
                  1
                  /* TEXT */
                ),
                (openBlock(true), createElementBlock(
                  Fragment,
                  null,
                  renderList(scopes.value, (scope) => {
                    return openBlock(), createElementBlock("option", {
                      key: keyFor(scope),
                      value: keyFor(scope)
                    }, toDisplayString(t(scope.scope === "project" ? "capture.project" : "capture.conversation")) + ": " + toDisplayString(scope.title || t(scope.scope === "project" ? "identity.unknownProject" : "identity.untitled")), 9, _hoisted_6$1);
                  }),
                  128
                  /* KEYED_FRAGMENT */
                ))
              ], 8, _hoisted_4$1), [
                [vModelSelect, selected.value]
              ])
            ]),
            target.value ? (openBlock(), createBlock(_sfc_main$4, {
              key: 0,
              label: target.value.title || t(target.value.scope === "project" ? "identity.unknownProject" : "identity.untitled"),
              identifier: target.value.id,
              locale: __props.locale
            }, null, 8, ["label", "identifier", "locale"])) : createCommentVNode("v-if", true),
            createBaseVNode("label", null, [
              createTextVNode(
                toDisplayString(t("capture.policy")),
                1
                /* TEXT */
              ),
              withDirectives(createBaseVNode("select", {
                "onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => mode2.value = $event),
                disabled: busy.value
              }, [
                target.value ? (openBlock(), createElementBlock(
                  "option",
                  _hoisted_8$1,
                  toDisplayString(t("capture.inherit")),
                  1
                  /* TEXT */
                )) : createCommentVNode("v-if", true),
                createBaseVNode(
                  "option",
                  _hoisted_9$1,
                  toDisplayString(t("capture.on")),
                  1
                  /* TEXT */
                ),
                createBaseVNode(
                  "option",
                  _hoisted_10$1,
                  toDisplayString(t("capture.off")),
                  1
                  /* TEXT */
                )
              ], 8, _hoisted_7$1), [
                [vModelSelect, mode2.value]
              ])
            ]),
            createBaseVNode("fieldset", {
              disabled: busy.value || mode2.value === "inherit",
              class: "booster-checkboxes"
            }, [
              createBaseVNode("label", null, [
                withDirectives(createBaseVNode(
                  "input",
                  {
                    "onUpdate:modelValue": _cache[2] || (_cache[2] = ($event) => rule.value.reasoning = $event),
                    type: "checkbox"
                  },
                  null,
                  512
                  /* NEED_PATCH */
                ), [
                  [vModelCheckbox, rule.value.reasoning]
                ]),
                createTextVNode(
                  toDisplayString(t("capture.reasoning")),
                  1
                  /* TEXT */
                )
              ]),
              createBaseVNode("label", null, [
                withDirectives(createBaseVNode(
                  "input",
                  {
                    "onUpdate:modelValue": _cache[3] || (_cache[3] = ($event) => rule.value.tools = $event),
                    type: "checkbox"
                  },
                  null,
                  512
                  /* NEED_PATCH */
                ), [
                  [vModelCheckbox, rule.value.tools]
                ]),
                createTextVNode(
                  toDisplayString(t("capture.tools")),
                  1
                  /* TEXT */
                )
              ]),
              createBaseVNode("label", null, [
                withDirectives(createBaseVNode(
                  "input",
                  {
                    "onUpdate:modelValue": _cache[4] || (_cache[4] = ($event) => rule.value.internal = $event),
                    type: "checkbox"
                  },
                  null,
                  512
                  /* NEED_PATCH */
                ), [
                  [vModelCheckbox, rule.value.internal]
                ]),
                createTextVNode(
                  toDisplayString(t("capture.internal")),
                  1
                  /* TEXT */
                )
              ])
            ], 8, _hoisted_11$1),
            createBaseVNode(
              "p",
              _hoisted_12$1,
              toDisplayString(t("capture.scopeHint")),
              1
              /* TEXT */
            ),
            createBaseVNode("button", {
              type: "button",
              class: "booster-action-primary",
              disabled: busy.value,
              onClick: save
            }, toDisplayString(t(busy.value ? "control.saving" : "capture.apply")), 9, _hoisted_13$1),
            error.value ? (openBlock(), createElementBlock(
              "p",
              _hoisted_14$1,
              toDisplayString(t("common.saveError")),
              1
              /* TEXT */
            )) : createCommentVNode("v-if", true),
            saved.value ? (openBlock(), createElementBlock(
              "p",
              _hoisted_15$1,
              toDisplayString(t("capture.saved")),
              1
              /* TEXT */
            )) : createCommentVNode("v-if", true)
          ])) : (openBlock(), createElementBlock(
            "p",
            _hoisted_16$1,
            toDisplayString(t(error.value ? "common.saveError" : "control.loading")),
            1
            /* TEXT */
          ))
        ]);
      };
    }
  });
  const _hoisted_1 = ["lang"];
  const _hoisted_2 = {
    key: 0,
    class: "booster-control-header"
  };
  const _hoisted_3 = { class: "booster-header-copy" };
  const _hoisted_4 = { class: "flex items-center gap-2" };
  const _hoisted_5 = {
    key: 0,
    class: "booster-header-actions"
  };
  const _hoisted_6 = { class: "booster-header-toggle-label" };
  const _hoisted_7 = ["aria-pressed"];
  const _hoisted_8 = {
    key: 1,
    class: "booster-loading"
  };
  const _hoisted_9 = {
    key: 2,
    class: "booster-settings-layout"
  };
  const _hoisted_10 = { class: "booster-settings-nav" };
  const _hoisted_11 = { class: "booster-settings-content" };
  const _hoisted_12 = { class: "booster-setting-card" };
  const _hoisted_13 = { class: "booster-setting-copy" };
  const _hoisted_14 = ["value"];
  const _hoisted_15 = { value: "latest" };
  const _hoisted_16 = { value: "first" };
  const _hoisted_17 = {
    key: 0,
    class: "booster-danger-zone"
  };
  const _hoisted_18 = { class: "booster-setting-copy" };
  const _hoisted_19 = { class: "flex items-center gap-2" };
  const _hoisted_20 = { class: "booster-setting-copy" };
  const _hoisted_21 = { class: "flex items-center gap-2" };
  const _hoisted_22 = ["disabled"];
  const _hoisted_23 = { class: "booster-setting-copy" };
  const _hoisted_24 = { class: "flex items-center gap-2" };
  const _hoisted_25 = ["disabled"];
  const _hoisted_26 = { class: "booster-setting-copy" };
  const _hoisted_27 = { class: "flex items-center gap-2" };
  const _hoisted_28 = { class: "booster-alert-setting-actions" };
  const _hoisted_29 = ["disabled"];
  const _hoisted_30 = { class: "booster-alert-threshold" };
  const _hoisted_31 = ["value", "disabled"];
  const _hoisted_32 = { class: "booster-setting-copy" };
  const _hoisted_33 = { class: "flex items-center gap-2" };
  const _hoisted_34 = ["disabled"];
  const _hoisted_35 = { class: "booster-setting-copy" };
  const _hoisted_36 = { class: "flex items-center gap-2" };
  const _hoisted_37 = ["disabled"];
  const _hoisted_38 = { class: "booster-setting-copy" };
  const _hoisted_39 = { class: "flex items-center gap-2" };
  const _hoisted_40 = { class: "booster-alert-setting-actions" };
  const _hoisted_41 = ["disabled"];
  const _hoisted_42 = { class: "booster-alert-threshold" };
  const _hoisted_43 = ["value", "disabled"];
  const _hoisted_44 = { class: "booster-setting-copy" };
  const _hoisted_45 = { class: "flex items-center gap-2" };
  const _hoisted_46 = { class: "booster-range-grid" };
  const _hoisted_47 = ["value", "disabled"];
  const _hoisted_48 = { class: "booster-setting-copy" };
  const _hoisted_49 = { class: "flex items-center gap-2" };
  const _hoisted_50 = { class: "booster-range-grid" };
  const _hoisted_51 = ["value"];
  const _hoisted_52 = ["value"];
  const _hoisted_53 = { class: "booster-setting-copy" };
  const _hoisted_54 = { class: "flex items-center gap-2" };
  const _hoisted_55 = ["disabled"];
  const _hoisted_56 = { class: "booster-setting-copy" };
  const _hoisted_57 = { class: "flex items-center gap-2" };
  const _hoisted_58 = ["disabled"];
  const _hoisted_59 = {
    key: 2,
    class: "booster-analytics-dashboard"
  };
  const _hoisted_60 = { class: "booster-analytics-header" };
  const _hoisted_61 = { class: "booster-analytics-metrics" };
  const _hoisted_62 = { class: "booster-analytics-flow-grid" };
  const _hoisted_63 = { class: "booster-analytics-flow-card" };
  const _hoisted_64 = { class: "booster-analytics-flow-row" };
  const _hoisted_65 = { class: "booster-analytics-flow-row" };
  const _hoisted_66 = { class: "booster-analytics-flow-card" };
  const _hoisted_67 = { class: "booster-analytics-flow-row" };
  const _hoisted_68 = { class: "booster-analytics-flow-row" };
  const _hoisted_69 = { class: "booster-analytics-footer" };
  const _hoisted_70 = { class: "booster-setting-card" };
  const _hoisted_71 = { class: "booster-setting-copy" };
  const _hoisted_72 = { class: "flex items-center gap-2" };
  const _hoisted_73 = ["value", "aria-label"];
  const _hoisted_74 = { value: "auto" };
  const _hoisted_75 = { value: "en" };
  const _hoisted_76 = { value: "ru" };
  const _hoisted_77 = { class: "booster-stack-card" };
  const _hoisted_78 = {
    key: 0,
    class: "booster-telemetry-body"
  };
  const _hoisted_79 = { class: "booster-setting-card booster-setting-card-flat" };
  const _hoisted_80 = { class: "booster-setting-copy" };
  const _hoisted_81 = { class: "booster-field" };
  const _hoisted_82 = ["value", "placeholder"];
  const _hoisted_83 = {
    key: 0,
    class: "booster-field"
  };
  const _hoisted_84 = { class: "flex items-center justify-between gap-2" };
  const _hoisted_85 = {
    key: 0,
    class: "flex gap-2"
  };
  const _hoisted_86 = { class: "booster-telemetry-test-row" };
  const _hoisted_87 = {
    key: 0,
    class: "booster-test-success"
  };
  const _hoisted_88 = ["title"];
  const _hoisted_89 = { class: "booster-control-footer" };
  const _hoisted_90 = { class: "booster-save-state" };
  const _hoisted_91 = { class: "booster-destructive-dialog" };
  const _hoisted_92 = { class: "booster-destructive-icon" };
  const _hoisted_93 = { class: "booster-destructive-warning" };
  const _hoisted_94 = {
    key: 0,
    class: "booster-test-error"
  };
  const _hoisted_95 = { class: "booster-destructive-actions" };
  const _hoisted_96 = ["disabled"];
  const _sfc_main = /* @__PURE__ */ defineComponent({
    __name: "ControlCenterPanel",
    props: {
      settingsAdapter: {},
      archiveAdapter: {},
      captureContext: {},
      diagnosticsAdapter: {},
      persistentDiagnosticsAdapter: {},
      secretAdapter: {},
      telemetryControlAdapter: {},
      targetLabel: {},
      showClose: { type: Boolean, default: false },
      embedded: { type: Boolean }
    },
    emits: ["close"],
    setup(__props, { emit: __emit }) {
      const props = __props;
      const emit2 = __emit;
      const ready = /* @__PURE__ */ ref(false);
      const saving = /* @__PURE__ */ ref(false);
      const saved = /* @__PURE__ */ ref(false);
      const tokenDraft = /* @__PURE__ */ ref("");
      const tokenConfigured = /* @__PURE__ */ ref(false);
      const tokenEditing = /* @__PURE__ */ ref(false);
      const telemetryTestState = /* @__PURE__ */ ref("idle");
      const telemetryTestError = /* @__PURE__ */ ref("");
      const archiveResetOpen = /* @__PURE__ */ ref(false);
      const archiveResetting = /* @__PURE__ */ ref(false);
      const archiveResetError = /* @__PURE__ */ ref("");
      const counters = /* @__PURE__ */ ref({ ...EMPTY_TRANSPORT_COUNTERS });
      const lifetimeCounters = /* @__PURE__ */ ref({ ...EMPTY_TRANSPORT_COUNTERS });
      const settings = /* @__PURE__ */ ref();
      let unsubscribe;
      let unsubscribeDiagnostics;
      let unsubscribeLifetimeDiagnostics;
      let savedTimer;
      let localRevision = 0;
      let pendingWrites = 0;
      const locale = computed(() => resolveLocale(settings.value?.language ?? "auto"));
      const t = (key) => translate(locale.value, key);
      const activeSection = computed(() => settings.value?.ui.activeSection ?? "modules");
      const currentRequestTotal = computed(() => counters.value.requestsSent + counters.value.responsesReceived);
      const lifetimeRequestTotal = computed(() => lifetimeCounters.value.requestsSent + lifetimeCounters.value.responsesReceived);
      const currentMessageTotal = computed(() => counters.value.messagesSent + counters.value.messagesReceived);
      const lifetimeMessageTotal = computed(() => lifetimeCounters.value.messagesSent + lifetimeCounters.value.messagesReceived);
      function bar(value, total) {
        return `${total > 0 ? Math.max(3, Math.round(value / total * 100)) : 0}%`;
      }
      function activityTime(value) {
        return value ? new Date(value).toLocaleTimeString(locale.value, { hour: "2-digit", minute: "2-digit", second: "2-digit" }) : t("control.noActivity");
      }
      function resetCurrentAnalytics() {
        props.diagnosticsAdapter?.resetTransport();
      }
      onMounted(async () => {
        settings.value = snapshotSettings(await props.settingsAdapter.get());
        unsubscribe = props.settingsAdapter.subscribe((next) => {
          if (pendingWrites === 0) settings.value = snapshotSettings(next);
        });
        if (props.diagnosticsAdapter) {
          counters.value = props.diagnosticsAdapter.getTransportCounters();
          unsubscribeDiagnostics = props.diagnosticsAdapter.subscribeTransport((next) => {
            counters.value = next;
          });
        }
        if (props.persistentDiagnosticsAdapter) {
          lifetimeCounters.value = await props.persistentDiagnosticsAdapter.getLifetimeTransportCounters();
          unsubscribeLifetimeDiagnostics = props.persistentDiagnosticsAdapter.subscribeLifetimeTransport(
            (next) => {
              lifetimeCounters.value = next;
            }
          );
        }
        if (props.secretAdapter) {
          tokenConfigured.value = Boolean(await props.secretAdapter.getTelemetryToken());
        }
        ready.value = true;
      });
      onBeforeUnmount(() => {
        unsubscribe?.();
        unsubscribeDiagnostics?.();
        unsubscribeLifetimeDiagnostics?.();
        if (savedTimer) window.clearTimeout(savedTimer);
      });
      async function applyPatch(patch) {
        if (!settings.value) return;
        const revision = ++localRevision;
        pendingWrites += 1;
        settings.value = mergeSettings(settings.value, patch);
        saving.value = true;
        try {
          const persisted = await props.settingsAdapter.update(patch);
          if (revision === localRevision) settings.value = snapshotSettings(persisted);
          saved.value = true;
          if (savedTimer) window.clearTimeout(savedTimer);
          savedTimer = window.setTimeout(() => saved.value = false, 1200);
        } catch (error) {
          console.error("[ChatGPT Booster] Failed to persist settings", error);
          if (revision === localRevision) {
            settings.value = snapshotSettings(await props.settingsAdapter.get());
          }
        } finally {
          pendingWrites -= 1;
          if (pendingWrites === 0) saving.value = false;
        }
      }
      async function setLanguage(event) {
        await applyPatch({
          language: event.target.value
        });
      }
      async function setTelemetryEndpoint(event) {
        await applyPatch({
          telemetry: {
            endpoint: event.target.value.trim()
          }
        });
        telemetryTestState.value = "idle";
        telemetryTestError.value = "";
      }
      async function setSection(section) {
        await applyPatch({ ui: { activeSection: section } });
      }
      async function setHistoryScrollSpeed(event) {
        await applyPatch({
          historyLoader: { speedPxPerSecond: Number(event.target.value) }
        });
      }
      async function setHistoryScrollPause(event) {
        await applyPatch({
          historyLoader: { pauseMs: Number(event.target.value) }
        });
      }
      function alertThresholdLabel(value) {
        const seconds = Math.round(value / 1e3);
        return seconds < 60 ? `${seconds}s` : `${Math.floor(seconds / 60)}m ${seconds % 60}s`;
      }
      async function setLongRunningThreshold(event) {
        await applyPatch({
          alerts: { longRunningThresholdMs: Number(event.target.value) }
        });
      }
      async function setMonitoringInterval(event) {
        await applyPatch({
          monitoring: { intervalMs: Number(event.target.value) }
        });
      }
      function monitoringIntervalLabel(value) {
        return value < 1e3 ? `${Math.round(value)} ms` : `${(value / 1e3).toFixed(value % 1e3 ? 1 : 0)} s`;
      }
      async function toggleTelemetryExpanded() {
        if (!settings.value) return;
        await applyPatch({ ui: { telemetryExpanded: !settings.value.ui.telemetryExpanded } });
      }
      async function saveToken() {
        if (!props.secretAdapter) return;
        await props.secretAdapter.setTelemetryToken(tokenDraft.value.trim());
        tokenConfigured.value = Boolean(tokenDraft.value.trim());
        tokenDraft.value = "";
        tokenEditing.value = false;
        telemetryTestState.value = "idle";
        telemetryTestError.value = "";
        saved.value = true;
      }
      async function clearArchive() {
        if (!props.archiveAdapter || archiveResetting.value) return;
        archiveResetting.value = true;
        archiveResetError.value = "";
        try {
          await props.archiveAdapter.clearAll();
          archiveResetOpen.value = false;
        } catch (error) {
          console.error("[ChatGPT Booster] Failed to clear local archive", error);
          archiveResetError.value = error instanceof Error ? error.message : String(error);
        } finally {
          archiveResetting.value = false;
        }
      }
      async function testTelemetry() {
        if (!props.telemetryControlAdapter) return;
        telemetryTestState.value = "testing";
        telemetryTestError.value = "";
        try {
          await props.telemetryControlAdapter.test();
          telemetryTestState.value = "success";
        } catch (error) {
          telemetryTestState.value = "error";
          telemetryTestError.value = error instanceof Error ? error.message : String(error);
        }
      }
      return (_ctx, _cache) => {
        return openBlock(), createElementBlock("section", {
          class: normalizeClass(["booster-control-center", { "booster-control-embedded": __props.embedded }]),
          lang: locale.value
        }, [
          !__props.embedded ? (openBlock(), createElementBlock("header", _hoisted_2, [
            createBaseVNode("div", _hoisted_3, [
              createBaseVNode("div", _hoisted_4, [
                createBaseVNode(
                  "strong",
                  null,
                  toDisplayString(t("control.title")),
                  1
                  /* TEXT */
                ),
                createVNode(unref(_sfc_main$3), { variant: "outline" }, {
                  default: withCtx(() => [
                    createTextVNode(
                      toDisplayString(__props.targetLabel),
                      1
                      /* TEXT */
                    )
                  ]),
                  _: 1
                  /* STABLE */
                }),
                createVNode(unref(_sfc_main$3), {
                  variant: "outline",
                  title: unref(BOOSTER_VERSION)
                }, {
                  default: withCtx(() => [
                    createTextVNode(
                      toDisplayString(unref(BOOSTER_VERSION)),
                      1
                      /* TEXT */
                    )
                  ]),
                  _: 1
                  /* STABLE */
                }, 8, ["title"])
              ]),
              createBaseVNode(
                "p",
                null,
                toDisplayString(t("control.subtitle")),
                1
                /* TEXT */
              )
            ]),
            settings.value ? (openBlock(), createElementBlock("div", _hoisted_5, [
              createBaseVNode(
                "span",
                _hoisted_6,
                toDisplayString(t("control.booster")),
                1
                /* TEXT */
              ),
              createBaseVNode("button", {
                type: "button",
                class: normalizeClass(["booster-switch", { "booster-switch-on": settings.value.enabled }]),
                "aria-pressed": settings.value.enabled,
                onClick: _cache[0] || (_cache[0] = ($event) => applyPatch({ enabled: !settings.value.enabled }))
              }, [..._cache[22] || (_cache[22] = [
                createBaseVNode(
                  "span",
                  null,
                  null,
                  -1
                  /* CACHED */
                )
              ])], 10, _hoisted_7),
              __props.showClose ? (openBlock(), createBlock(unref(_sfc_main$2), {
                key: 0,
                variant: "ghost",
                size: "icon",
                class: "size-8",
                title: t("common.close"),
                onClick: _cache[1] || (_cache[1] = ($event) => emit2("close"))
              }, {
                default: withCtx(() => [
                  createVNode(unref(X), { class: "size-4" })
                ]),
                _: 1
                /* STABLE */
              }, 8, ["title"])) : createCommentVNode("v-if", true)
            ])) : createCommentVNode("v-if", true)
          ])) : createCommentVNode("v-if", true),
          !ready.value || !settings.value ? (openBlock(), createElementBlock(
            "div",
            _hoisted_8,
            toDisplayString(t("control.loading")),
            1
            /* TEXT */
          )) : (openBlock(), createElementBlock("div", _hoisted_9, [
            createBaseVNode("nav", _hoisted_10, [
              createBaseVNode(
                "button",
                {
                  class: normalizeClass({ active: activeSection.value === "archive" }),
                  onClick: _cache[2] || (_cache[2] = ($event) => setSection("archive"))
                },
                [
                  createVNode(unref(ShieldCheck), { class: "size-4" }),
                  createTextVNode(
                    toDisplayString(t("capture.title")),
                    1
                    /* TEXT */
                  )
                ],
                2
                /* CLASS */
              ),
              createBaseVNode(
                "button",
                {
                  class: normalizeClass({ active: activeSection.value === "modules" }),
                  onClick: _cache[3] || (_cache[3] = ($event) => setSection("modules"))
                },
                [
                  createVNode(unref(Wrench), { class: "size-4" }),
                  createTextVNode(
                    toDisplayString(t("control.modules")),
                    1
                    /* TEXT */
                  )
                ],
                2
                /* CLASS */
              ),
              createBaseVNode(
                "button",
                {
                  class: normalizeClass({ active: activeSection.value === "analytics" }),
                  onClick: _cache[4] || (_cache[4] = ($event) => setSection("analytics"))
                },
                [
                  createVNode(unref(ChartColumn), { class: "size-4" }),
                  createTextVNode(
                    toDisplayString(t("control.analytics")),
                    1
                    /* TEXT */
                  )
                ],
                2
                /* CLASS */
              ),
              createBaseVNode(
                "button",
                {
                  class: normalizeClass({ active: activeSection.value === "other" }),
                  onClick: _cache[5] || (_cache[5] = ($event) => setSection("other"))
                },
                [
                  createVNode(unref(SlidersHorizontal), { class: "size-4" }),
                  createTextVNode(
                    toDisplayString(t("control.other")),
                    1
                    /* TEXT */
                  )
                ],
                2
                /* CLASS */
              )
            ]),
            createBaseVNode("main", _hoisted_11, [
              activeSection.value === "archive" ? (openBlock(), createElementBlock(
                Fragment,
                { key: 0 },
                [
                  createBaseVNode("section", _hoisted_12, [
                    createBaseVNode("div", _hoisted_13, [
                      createBaseVNode(
                        "b",
                        null,
                        toDisplayString(locale.value === "ru" ? "Открывать архив" : "Open archive at"),
                        1
                        /* TEXT */
                      ),
                      createBaseVNode(
                        "span",
                        null,
                        toDisplayString(locale.value === "ru" ? "С начала или с конца сохранённых сообщений" : "Choose the saved history endpoint"),
                        1
                        /* TEXT */
                      )
                    ]),
                    createBaseVNode("select", {
                      class: "booster-select",
                      value: settings.value.ui.archiveStart,
                      onChange: _cache[6] || (_cache[6] = ($event) => applyPatch({ ui: { archiveStart: $event.target.value === "first" ? "first" : "latest" } }))
                    }, [
                      createBaseVNode(
                        "option",
                        _hoisted_15,
                        toDisplayString(locale.value === "ru" ? "Конец истории" : "Latest messages"),
                        1
                        /* TEXT */
                      ),
                      createBaseVNode(
                        "option",
                        _hoisted_16,
                        toDisplayString(locale.value === "ru" ? "Начало сохранённой истории" : "First saved messages"),
                        1
                        /* TEXT */
                      )
                    ], 40, _hoisted_14)
                  ]),
                  createVNode(_sfc_main$1, {
                    "settings-adapter": __props.settingsAdapter,
                    "archive-adapter": __props.archiveAdapter,
                    context: __props.captureContext,
                    locale: locale.value
                  }, null, 8, ["settings-adapter", "archive-adapter", "context", "locale"]),
                  __props.archiveAdapter ? (openBlock(), createElementBlock("section", _hoisted_17, [
                    createBaseVNode("div", _hoisted_18, [
                      createBaseVNode("div", _hoisted_19, [
                        createVNode(unref(TriangleAlert), { class: "size-4" }),
                        createBaseVNode(
                          "b",
                          null,
                          toDisplayString(t("archiveReset.title")),
                          1
                          /* TEXT */
                        )
                      ]),
                      createBaseVNode(
                        "span",
                        null,
                        toDisplayString(t("archiveReset.description")),
                        1
                        /* TEXT */
                      )
                    ]),
                    createBaseVNode(
                      "button",
                      {
                        type: "button",
                        class: "booster-destructive-button",
                        onClick: _cache[7] || (_cache[7] = ($event) => {
                          archiveResetError.value = "";
                          archiveResetOpen.value = true;
                        })
                      },
                      toDisplayString(t("archiveReset.action")),
                      1
                      /* TEXT */
                    )
                  ])) : createCommentVNode("v-if", true)
                ],
                64
                /* STABLE_FRAGMENT */
              )) : activeSection.value === "modules" ? (openBlock(), createElementBlock(
                Fragment,
                { key: 1 },
                [
                  createBaseVNode(
                    "section",
                    {
                      class: normalizeClass(["booster-setting-card", { "booster-setting-disabled": !settings.value.enabled }])
                    },
                    [
                      createBaseVNode("div", _hoisted_20, [
                        createBaseVNode("div", _hoisted_21, [
                          createVNode(unref(Clock3), { class: "size-4" }),
                          createBaseVNode(
                            "b",
                            null,
                            toDisplayString(t("control.messageMetadata")),
                            1
                            /* TEXT */
                          ),
                          createVNode(unref(_sfc_main$3), {
                            variant: settings.value.features.messageMetadata && settings.value.enabled ? "default" : "secondary"
                          }, {
                            default: withCtx(() => [
                              createTextVNode(
                                toDisplayString(settings.value.features.messageMetadata && settings.value.enabled ? t("common.on") : t("common.off")),
                                1
                                /* TEXT */
                              )
                            ]),
                            _: 1
                            /* STABLE */
                          }, 8, ["variant"])
                        ]),
                        createBaseVNode(
                          "span",
                          null,
                          toDisplayString(t("control.messageMetadataDescription")),
                          1
                          /* TEXT */
                        )
                      ]),
                      createBaseVNode("button", {
                        type: "button",
                        class: normalizeClass(["booster-switch", { "booster-switch-on": settings.value.features.messageMetadata }]),
                        disabled: !settings.value.enabled,
                        onClick: _cache[8] || (_cache[8] = ($event) => applyPatch({ features: { messageMetadata: !settings.value.features.messageMetadata } }))
                      }, [..._cache[23] || (_cache[23] = [
                        createBaseVNode(
                          "span",
                          null,
                          null,
                          -1
                          /* CACHED */
                        )
                      ])], 10, _hoisted_22)
                    ],
                    2
                    /* CLASS */
                  ),
                  createBaseVNode(
                    "section",
                    {
                      class: normalizeClass(["booster-setting-card", { "booster-setting-disabled": !settings.value.enabled }])
                    },
                    [
                      createBaseVNode("div", _hoisted_23, [
                        createBaseVNode("div", _hoisted_24, [
                          createVNode(unref(Activity), { class: "size-4" }),
                          createBaseVNode(
                            "b",
                            null,
                            toDisplayString(t("control.activityIndicator")),
                            1
                            /* TEXT */
                          ),
                          createVNode(unref(_sfc_main$3), {
                            variant: settings.value.features.activityIndicator && settings.value.enabled ? "default" : "secondary"
                          }, {
                            default: withCtx(() => [
                              createTextVNode(
                                toDisplayString(settings.value.features.activityIndicator && settings.value.enabled ? t("common.on") : t("common.off")),
                                1
                                /* TEXT */
                              )
                            ]),
                            _: 1
                            /* STABLE */
                          }, 8, ["variant"])
                        ]),
                        createBaseVNode(
                          "span",
                          null,
                          toDisplayString(t("control.activityIndicatorDescription")),
                          1
                          /* TEXT */
                        )
                      ]),
                      createBaseVNode("button", {
                        type: "button",
                        class: normalizeClass(["booster-switch", { "booster-switch-on": settings.value.features.activityIndicator }]),
                        disabled: !settings.value.enabled,
                        onClick: _cache[9] || (_cache[9] = ($event) => applyPatch({ features: { activityIndicator: !settings.value.features.activityIndicator } }))
                      }, [..._cache[24] || (_cache[24] = [
                        createBaseVNode(
                          "span",
                          null,
                          null,
                          -1
                          /* CACHED */
                        )
                      ])], 10, _hoisted_25)
                    ],
                    2
                    /* CLASS */
                  ),
                  createBaseVNode(
                    "section",
                    {
                      class: normalizeClass(["booster-setting-card booster-setting-card-stack", { "booster-setting-disabled": !settings.value.enabled }])
                    },
                    [
                      createBaseVNode("div", _hoisted_26, [
                        createBaseVNode("div", _hoisted_27, [
                          createVNode(unref(Clock3), { class: "size-4" }),
                          createBaseVNode(
                            "b",
                            null,
                            toDisplayString(t("control.requestTimer")),
                            1
                            /* TEXT */
                          ),
                          createVNode(unref(_sfc_main$3), {
                            variant: settings.value.features.requestTimer && settings.value.enabled ? "default" : "secondary"
                          }, {
                            default: withCtx(() => [
                              createTextVNode(
                                toDisplayString(settings.value.features.requestTimer && settings.value.enabled ? t("common.on") : t("common.off")),
                                1
                                /* TEXT */
                              )
                            ]),
                            _: 1
                            /* STABLE */
                          }, 8, ["variant"])
                        ]),
                        createBaseVNode(
                          "span",
                          null,
                          toDisplayString(t("control.requestTimerDescription")),
                          1
                          /* TEXT */
                        )
                      ]),
                      createBaseVNode("div", _hoisted_28, [
                        createBaseVNode("button", {
                          type: "button",
                          class: normalizeClass(["booster-switch", { "booster-switch-on": settings.value.features.requestTimer }]),
                          disabled: !settings.value.enabled,
                          onClick: _cache[10] || (_cache[10] = ($event) => applyPatch({ features: { requestTimer: !settings.value.features.requestTimer } }))
                        }, [..._cache[25] || (_cache[25] = [
                          createBaseVNode(
                            "span",
                            null,
                            null,
                            -1
                            /* CACHED */
                          )
                        ])], 10, _hoisted_29),
                        createBaseVNode("label", _hoisted_30, [
                          createBaseVNode("span", null, [
                            createTextVNode(
                              toDisplayString(t("control.monitoringInterval")) + " ",
                              1
                              /* TEXT */
                            ),
                            createBaseVNode(
                              "b",
                              null,
                              toDisplayString(Math.round(settings.value.monitoring.intervalMs)) + " ms",
                              1
                              /* TEXT */
                            )
                          ]),
                          createBaseVNode("input", {
                            type: "range",
                            min: "100",
                            max: "2000",
                            step: "100",
                            value: settings.value.monitoring.intervalMs,
                            disabled: !settings.value.enabled,
                            onChange: setMonitoringInterval
                          }, null, 40, _hoisted_31)
                        ])
                      ])
                    ],
                    2
                    /* CLASS */
                  ),
                  createBaseVNode(
                    "section",
                    {
                      class: normalizeClass(["booster-setting-card", { "booster-setting-disabled": !settings.value.enabled }])
                    },
                    [
                      createBaseVNode("div", _hoisted_32, [
                        createBaseVNode("div", _hoisted_33, [
                          createVNode(unref(Wrench), { class: "size-4" }),
                          createBaseVNode(
                            "b",
                            null,
                            toDisplayString(t("control.toolInspector")),
                            1
                            /* TEXT */
                          ),
                          createVNode(unref(_sfc_main$3), {
                            variant: settings.value.features.toolInspector && settings.value.enabled ? "default" : "secondary"
                          }, {
                            default: withCtx(() => [
                              createTextVNode(
                                toDisplayString(settings.value.features.toolInspector && settings.value.enabled ? t("common.on") : t("common.off")),
                                1
                                /* TEXT */
                              )
                            ]),
                            _: 1
                            /* STABLE */
                          }, 8, ["variant"])
                        ]),
                        createBaseVNode(
                          "span",
                          null,
                          toDisplayString(t("control.toolInspectorDescription")),
                          1
                          /* TEXT */
                        )
                      ]),
                      createBaseVNode("button", {
                        type: "button",
                        class: normalizeClass(["booster-switch", { "booster-switch-on": settings.value.features.toolInspector }]),
                        disabled: !settings.value.enabled,
                        onClick: _cache[11] || (_cache[11] = ($event) => applyPatch({ features: { toolInspector: !settings.value.features.toolInspector } }))
                      }, [..._cache[26] || (_cache[26] = [
                        createBaseVNode(
                          "span",
                          null,
                          null,
                          -1
                          /* CACHED */
                        )
                      ])], 10, _hoisted_34)
                    ],
                    2
                    /* CLASS */
                  ),
                  createBaseVNode(
                    "section",
                    {
                      class: normalizeClass(["booster-setting-card", { "booster-setting-disabled": !settings.value.enabled }])
                    },
                    [
                      createBaseVNode("div", _hoisted_35, [
                        createBaseVNode("div", _hoisted_36, [
                          createVNode(unref(Activity), { class: "size-4" }),
                          createBaseVNode(
                            "b",
                            null,
                            toDisplayString(t("control.responseCompleteSound")),
                            1
                            /* TEXT */
                          ),
                          createVNode(unref(_sfc_main$3), {
                            variant: settings.value.alerts.responseCompleteSound && settings.value.enabled ? "default" : "secondary"
                          }, {
                            default: withCtx(() => [
                              createTextVNode(
                                toDisplayString(settings.value.alerts.responseCompleteSound && settings.value.enabled ? t("common.on") : t("common.off")),
                                1
                                /* TEXT */
                              )
                            ]),
                            _: 1
                            /* STABLE */
                          }, 8, ["variant"])
                        ]),
                        createBaseVNode(
                          "span",
                          null,
                          toDisplayString(t("control.responseCompleteSoundDescription")),
                          1
                          /* TEXT */
                        )
                      ]),
                      createBaseVNode("button", {
                        type: "button",
                        class: normalizeClass(["booster-switch", { "booster-switch-on": settings.value.alerts.responseCompleteSound }]),
                        disabled: !settings.value.enabled,
                        onClick: _cache[12] || (_cache[12] = ($event) => applyPatch({ alerts: { responseCompleteSound: !settings.value.alerts.responseCompleteSound } }))
                      }, [..._cache[27] || (_cache[27] = [
                        createBaseVNode(
                          "span",
                          null,
                          null,
                          -1
                          /* CACHED */
                        )
                      ])], 10, _hoisted_37)
                    ],
                    2
                    /* CLASS */
                  ),
                  createBaseVNode(
                    "section",
                    {
                      class: normalizeClass(["booster-setting-card booster-setting-card-stack", { "booster-setting-disabled": !settings.value.enabled }])
                    },
                    [
                      createBaseVNode("div", _hoisted_38, [
                        createBaseVNode("div", _hoisted_39, [
                          createVNode(unref(TriangleAlert), { class: "size-4" }),
                          createBaseVNode(
                            "b",
                            null,
                            toDisplayString(t("control.longRunningSound")),
                            1
                            /* TEXT */
                          ),
                          createVNode(unref(_sfc_main$3), {
                            variant: settings.value.alerts.longRunningSound && settings.value.enabled ? "default" : "secondary"
                          }, {
                            default: withCtx(() => [
                              createTextVNode(
                                toDisplayString(settings.value.alerts.longRunningSound && settings.value.enabled ? t("common.on") : t("common.off")),
                                1
                                /* TEXT */
                              )
                            ]),
                            _: 1
                            /* STABLE */
                          }, 8, ["variant"])
                        ]),
                        createBaseVNode(
                          "span",
                          null,
                          toDisplayString(t("control.longRunningSoundDescription")),
                          1
                          /* TEXT */
                        )
                      ]),
                      createBaseVNode("div", _hoisted_40, [
                        createBaseVNode("button", {
                          type: "button",
                          class: normalizeClass(["booster-switch", { "booster-switch-on": settings.value.alerts.longRunningSound }]),
                          disabled: !settings.value.enabled,
                          onClick: _cache[13] || (_cache[13] = ($event) => applyPatch({ alerts: { longRunningSound: !settings.value.alerts.longRunningSound } }))
                        }, [..._cache[28] || (_cache[28] = [
                          createBaseVNode(
                            "span",
                            null,
                            null,
                            -1
                            /* CACHED */
                          )
                        ])], 10, _hoisted_41),
                        createBaseVNode("label", _hoisted_42, [
                          createBaseVNode("span", null, [
                            createTextVNode(
                              toDisplayString(t("control.longRunningThreshold")) + " ",
                              1
                              /* TEXT */
                            ),
                            createBaseVNode(
                              "b",
                              null,
                              toDisplayString(alertThresholdLabel(settings.value.alerts.longRunningThresholdMs)),
                              1
                              /* TEXT */
                            )
                          ]),
                          createBaseVNode("input", {
                            type: "range",
                            min: "15000",
                            max: "1800000",
                            step: "15000",
                            value: settings.value.alerts.longRunningThresholdMs,
                            disabled: !settings.value.enabled || !settings.value.alerts.longRunningSound,
                            onChange: setLongRunningThreshold
                          }, null, 40, _hoisted_43)
                        ])
                      ])
                    ],
                    2
                    /* CLASS */
                  ),
                  createBaseVNode(
                    "section",
                    {
                      class: normalizeClass(["booster-setting-card booster-setting-card-stack", { "booster-setting-disabled": !settings.value.enabled }])
                    },
                    [
                      createBaseVNode("div", _hoisted_44, [
                        createBaseVNode("div", _hoisted_45, [
                          createVNode(unref(RefreshCcw), { class: "size-4" }),
                          createBaseVNode(
                            "b",
                            null,
                            toDisplayString(t("control.monitoringInterval")),
                            1
                            /* TEXT */
                          )
                        ]),
                        createBaseVNode(
                          "span",
                          null,
                          toDisplayString(t("control.monitoringIntervalDescription")),
                          1
                          /* TEXT */
                        )
                      ]),
                      createBaseVNode("div", _hoisted_46, [
                        createBaseVNode("label", null, [
                          createBaseVNode("span", null, [
                            createTextVNode(
                              toDisplayString(t("control.monitoringInterval")) + " ",
                              1
                              /* TEXT */
                            ),
                            createBaseVNode(
                              "b",
                              null,
                              toDisplayString(monitoringIntervalLabel(settings.value.monitoring.intervalMs)),
                              1
                              /* TEXT */
                            )
                          ]),
                          createBaseVNode("input", {
                            type: "range",
                            min: "100",
                            max: "10000",
                            step: "100",
                            value: settings.value.monitoring.intervalMs,
                            disabled: !settings.value.enabled,
                            onChange: setMonitoringInterval
                          }, null, 40, _hoisted_47)
                        ])
                      ])
                    ],
                    2
                    /* CLASS */
                  ),
                  createBaseVNode(
                    "section",
                    {
                      class: normalizeClass(["booster-setting-card booster-setting-card-stack", { "booster-setting-disabled": !settings.value.enabled }])
                    },
                    [
                      createBaseVNode("div", _hoisted_48, [
                        createBaseVNode("div", _hoisted_49, [
                          createVNode(unref(SlidersHorizontal), { class: "size-4" }),
                          createBaseVNode(
                            "b",
                            null,
                            toDisplayString(t("control.historyScroll")),
                            1
                            /* TEXT */
                          )
                        ]),
                        createBaseVNode(
                          "span",
                          null,
                          toDisplayString(t("control.historyScrollDescription")),
                          1
                          /* TEXT */
                        )
                      ]),
                      createBaseVNode("div", _hoisted_50, [
                        createBaseVNode("label", null, [
                          createBaseVNode("span", null, [
                            createTextVNode(
                              toDisplayString(t("control.historyScrollSpeed")) + " ",
                              1
                              /* TEXT */
                            ),
                            createBaseVNode(
                              "b",
                              null,
                              toDisplayString(Math.round(settings.value.historyLoader.speedPxPerSecond)) + " px/s",
                              1
                              /* TEXT */
                            )
                          ]),
                          createBaseVNode("input", {
                            type: "range",
                            min: "600",
                            max: "6000",
                            step: "100",
                            value: settings.value.historyLoader.speedPxPerSecond,
                            onChange: setHistoryScrollSpeed
                          }, null, 40, _hoisted_51)
                        ]),
                        createBaseVNode("label", null, [
                          createBaseVNode("span", null, [
                            createTextVNode(
                              toDisplayString(t("control.historyScrollPause")) + " ",
                              1
                              /* TEXT */
                            ),
                            createBaseVNode(
                              "b",
                              null,
                              toDisplayString(Math.round(settings.value.historyLoader.pauseMs)) + " ms",
                              1
                              /* TEXT */
                            )
                          ]),
                          createBaseVNode("input", {
                            type: "range",
                            min: "20",
                            max: "1200",
                            step: "10",
                            value: settings.value.historyLoader.pauseMs,
                            onChange: setHistoryScrollPause
                          }, null, 40, _hoisted_52)
                        ])
                      ])
                    ],
                    2
                    /* CLASS */
                  ),
                  createBaseVNode(
                    "section",
                    {
                      class: normalizeClass(["booster-setting-card", { "booster-setting-disabled": !settings.value.enabled }])
                    },
                    [
                      createBaseVNode("div", _hoisted_53, [
                        createBaseVNode("div", _hoisted_54, [
                          createVNode(unref(Activity), { class: "size-4" }),
                          createBaseVNode(
                            "b",
                            null,
                            toDisplayString(t("control.observer")),
                            1
                            /* TEXT */
                          ),
                          createVNode(unref(_sfc_main$3), {
                            variant: settings.value.observer.enabled && settings.value.enabled ? "default" : "secondary"
                          }, {
                            default: withCtx(() => [
                              createTextVNode(
                                toDisplayString(settings.value.observer.enabled && settings.value.enabled ? t("common.on") : t("common.off")),
                                1
                                /* TEXT */
                              )
                            ]),
                            _: 1
                            /* STABLE */
                          }, 8, ["variant"])
                        ]),
                        createBaseVNode(
                          "span",
                          null,
                          toDisplayString(t("control.observerDescription")),
                          1
                          /* TEXT */
                        )
                      ]),
                      createBaseVNode("button", {
                        type: "button",
                        class: normalizeClass(["booster-switch", { "booster-switch-on": settings.value.observer.enabled }]),
                        disabled: !settings.value.enabled,
                        onClick: _cache[14] || (_cache[14] = ($event) => applyPatch({ observer: { enabled: !settings.value.observer.enabled } }))
                      }, [..._cache[29] || (_cache[29] = [
                        createBaseVNode(
                          "span",
                          null,
                          null,
                          -1
                          /* CACHED */
                        )
                      ])], 10, _hoisted_55)
                    ],
                    2
                    /* CLASS */
                  ),
                  createBaseVNode(
                    "section",
                    {
                      class: normalizeClass(["booster-setting-card", { "booster-setting-disabled": !settings.value.observer.enabled }])
                    },
                    [
                      createBaseVNode("div", _hoisted_56, [
                        createBaseVNode("div", _hoisted_57, [
                          createVNode(unref(ShieldCheck), { class: "size-4" }),
                          createBaseVNode(
                            "b",
                            null,
                            toDisplayString(t("control.captureBodies")),
                            1
                            /* TEXT */
                          )
                        ]),
                        createBaseVNode(
                          "span",
                          null,
                          toDisplayString(t("control.captureBodiesDescription")),
                          1
                          /* TEXT */
                        )
                      ]),
                      createBaseVNode("button", {
                        type: "button",
                        class: normalizeClass(["booster-switch", { "booster-switch-on": settings.value.observer.captureBodies }]),
                        disabled: !settings.value.observer.enabled,
                        onClick: _cache[15] || (_cache[15] = ($event) => applyPatch({ observer: { captureBodies: !settings.value.observer.captureBodies } }))
                      }, [..._cache[30] || (_cache[30] = [
                        createBaseVNode(
                          "span",
                          null,
                          null,
                          -1
                          /* CACHED */
                        )
                      ])], 10, _hoisted_58)
                    ],
                    2
                    /* CLASS */
                  )
                ],
                64
                /* STABLE_FRAGMENT */
              )) : activeSection.value === "analytics" ? (openBlock(), createElementBlock("section", _hoisted_59, [
                createBaseVNode("header", _hoisted_60, [
                  createBaseVNode("div", null, [
                    createBaseVNode(
                      "strong",
                      null,
                      toDisplayString(t("control.analyticsOverview")),
                      1
                      /* TEXT */
                    ),
                    createBaseVNode(
                      "span",
                      null,
                      toDisplayString(t("control.analyticsDescription")),
                      1
                      /* TEXT */
                    )
                  ]),
                  __props.diagnosticsAdapter ? (openBlock(), createElementBlock("button", {
                    key: 0,
                    type: "button",
                    class: "booster-action-secondary booster-analytics-reset",
                    onClick: resetCurrentAnalytics
                  }, [
                    createVNode(unref(RefreshCcw), { class: "size-3.5" }),
                    createTextVNode(
                      toDisplayString(t("control.resetCurrent")),
                      1
                      /* TEXT */
                    )
                  ])) : createCommentVNode("v-if", true)
                ]),
                createBaseVNode("div", _hoisted_61, [
                  createBaseVNode("article", null, [
                    createBaseVNode(
                      "span",
                      null,
                      toDisplayString(t("control.requestTraffic")),
                      1
                      /* TEXT */
                    ),
                    createBaseVNode(
                      "strong",
                      null,
                      toDisplayString(currentRequestTotal.value),
                      1
                      /* TEXT */
                    ),
                    createBaseVNode(
                      "small",
                      null,
                      toDisplayString(lifetimeRequestTotal.value) + " · " + toDisplayString(t("control.allTime").toLocaleLowerCase()),
                      1
                      /* TEXT */
                    )
                  ]),
                  createBaseVNode("article", null, [
                    createBaseVNode(
                      "span",
                      null,
                      toDisplayString(t("control.messageTraffic")),
                      1
                      /* TEXT */
                    ),
                    createBaseVNode(
                      "strong",
                      null,
                      toDisplayString(currentMessageTotal.value),
                      1
                      /* TEXT */
                    ),
                    createBaseVNode(
                      "small",
                      null,
                      toDisplayString(lifetimeMessageTotal.value) + " · " + toDisplayString(t("control.allTime").toLocaleLowerCase()),
                      1
                      /* TEXT */
                    )
                  ]),
                  createBaseVNode(
                    "article",
                    {
                      class: normalizeClass({ warning: counters.value.errors > 0 })
                    },
                    [
                      createBaseVNode(
                        "span",
                        null,
                        toDisplayString(t("control.errors")),
                        1
                        /* TEXT */
                      ),
                      createBaseVNode(
                        "strong",
                        null,
                        toDisplayString(counters.value.errors),
                        1
                        /* TEXT */
                      ),
                      createBaseVNode(
                        "small",
                        null,
                        toDisplayString(lifetimeCounters.value.errors) + " · " + toDisplayString(t("control.allTime").toLocaleLowerCase()),
                        1
                        /* TEXT */
                      )
                    ],
                    2
                    /* CLASS */
                  )
                ]),
                createBaseVNode("div", _hoisted_62, [
                  createBaseVNode("article", _hoisted_63, [
                    createBaseVNode("header", null, [
                      createBaseVNode("span", null, [
                        createVNode(unref(ArrowUpRight), { class: "size-4" }),
                        createTextVNode(
                          toDisplayString(t("control.outbound")),
                          1
                          /* TEXT */
                        )
                      ]),
                      createBaseVNode(
                        "b",
                        null,
                        toDisplayString(counters.value.requestsSent + counters.value.messagesSent),
                        1
                        /* TEXT */
                      )
                    ]),
                    createBaseVNode("div", _hoisted_64, [
                      createBaseVNode(
                        "span",
                        null,
                        toDisplayString(t("control.requestsSent")),
                        1
                        /* TEXT */
                      ),
                      createBaseVNode("div", null, [
                        createBaseVNode(
                          "i",
                          {
                            style: normalizeStyle({ width: bar(counters.value.requestsSent, counters.value.requestsSent + counters.value.messagesSent) })
                          },
                          null,
                          4
                          /* STYLE */
                        )
                      ]),
                      createBaseVNode(
                        "b",
                        null,
                        toDisplayString(counters.value.requestsSent),
                        1
                        /* TEXT */
                      )
                    ]),
                    createBaseVNode("div", _hoisted_65, [
                      createBaseVNode(
                        "span",
                        null,
                        toDisplayString(t("control.messagesSent")),
                        1
                        /* TEXT */
                      ),
                      createBaseVNode("div", null, [
                        createBaseVNode(
                          "i",
                          {
                            style: normalizeStyle({ width: bar(counters.value.messagesSent, counters.value.requestsSent + counters.value.messagesSent) })
                          },
                          null,
                          4
                          /* STYLE */
                        )
                      ]),
                      createBaseVNode(
                        "b",
                        null,
                        toDisplayString(counters.value.messagesSent),
                        1
                        /* TEXT */
                      )
                    ])
                  ]),
                  createBaseVNode("article", _hoisted_66, [
                    createBaseVNode("header", null, [
                      createBaseVNode("span", null, [
                        createVNode(unref(ArrowDownLeft), { class: "size-4" }),
                        createTextVNode(
                          toDisplayString(t("control.inbound")),
                          1
                          /* TEXT */
                        )
                      ]),
                      createBaseVNode(
                        "b",
                        null,
                        toDisplayString(counters.value.responsesReceived + counters.value.messagesReceived),
                        1
                        /* TEXT */
                      )
                    ]),
                    createBaseVNode("div", _hoisted_67, [
                      createBaseVNode(
                        "span",
                        null,
                        toDisplayString(t("control.responsesReceived")),
                        1
                        /* TEXT */
                      ),
                      createBaseVNode("div", null, [
                        createBaseVNode(
                          "i",
                          {
                            style: normalizeStyle({ width: bar(counters.value.responsesReceived, counters.value.responsesReceived + counters.value.messagesReceived) })
                          },
                          null,
                          4
                          /* STYLE */
                        )
                      ]),
                      createBaseVNode(
                        "b",
                        null,
                        toDisplayString(counters.value.responsesReceived),
                        1
                        /* TEXT */
                      )
                    ]),
                    createBaseVNode("div", _hoisted_68, [
                      createBaseVNode(
                        "span",
                        null,
                        toDisplayString(t("control.messagesReceived")),
                        1
                        /* TEXT */
                      ),
                      createBaseVNode("div", null, [
                        createBaseVNode(
                          "i",
                          {
                            style: normalizeStyle({ width: bar(counters.value.messagesReceived, counters.value.responsesReceived + counters.value.messagesReceived) })
                          },
                          null,
                          4
                          /* STYLE */
                        )
                      ]),
                      createBaseVNode(
                        "b",
                        null,
                        toDisplayString(counters.value.messagesReceived),
                        1
                        /* TEXT */
                      )
                    ])
                  ])
                ]),
                createBaseVNode("footer", _hoisted_69, [
                  createBaseVNode("span", null, [
                    createVNode(unref(Activity), { class: "size-4" }),
                    createTextVNode(
                      toDisplayString(t("control.lastActivity")) + " ",
                      1
                      /* TEXT */
                    ),
                    createBaseVNode(
                      "b",
                      null,
                      toDisplayString(activityTime(counters.value.lastEventAt)),
                      1
                      /* TEXT */
                    )
                  ]),
                  createBaseVNode(
                    "span",
                    {
                      class: normalizeClass({ warning: counters.value.errors > 0 })
                    },
                    [
                      createVNode(unref(TriangleAlert), { class: "size-4" }),
                      createTextVNode(
                        toDisplayString(t("control.errors")) + " ",
                        1
                        /* TEXT */
                      ),
                      createBaseVNode(
                        "b",
                        null,
                        toDisplayString(counters.value.errors),
                        1
                        /* TEXT */
                      )
                    ],
                    2
                    /* CLASS */
                  )
                ])
              ])) : (openBlock(), createElementBlock(
                Fragment,
                { key: 3 },
                [
                  createBaseVNode("section", _hoisted_70, [
                    createBaseVNode("div", _hoisted_71, [
                      createBaseVNode("div", _hoisted_72, [
                        createVNode(unref(Languages), { class: "size-4" }),
                        createBaseVNode(
                          "b",
                          null,
                          toDisplayString(t("control.language")),
                          1
                          /* TEXT */
                        )
                      ]),
                      createBaseVNode(
                        "span",
                        null,
                        toDisplayString(t("control.languageDescription")),
                        1
                        /* TEXT */
                      )
                    ]),
                    createBaseVNode("select", {
                      class: "booster-select",
                      value: settings.value.language,
                      "aria-label": t("control.language"),
                      onChange: setLanguage
                    }, [
                      createBaseVNode(
                        "option",
                        _hoisted_74,
                        toDisplayString(t("common.auto")),
                        1
                        /* TEXT */
                      ),
                      createBaseVNode(
                        "option",
                        _hoisted_75,
                        toDisplayString(t("language.english")),
                        1
                        /* TEXT */
                      ),
                      createBaseVNode(
                        "option",
                        _hoisted_76,
                        toDisplayString(t("language.russian")),
                        1
                        /* TEXT */
                      )
                    ], 40, _hoisted_73)
                  ]),
                  createBaseVNode("section", _hoisted_77, [
                    createBaseVNode("button", {
                      class: "booster-disclosure",
                      type: "button",
                      onClick: toggleTelemetryExpanded
                    }, [
                      createBaseVNode("span", null, [
                        createBaseVNode(
                          "b",
                          null,
                          toDisplayString(t("control.telemetry")),
                          1
                          /* TEXT */
                        ),
                        createBaseVNode(
                          "small",
                          null,
                          toDisplayString(t("control.telemetryDescription")),
                          1
                          /* TEXT */
                        )
                      ]),
                      createVNode(unref(ChevronDown), {
                        class: normalizeClass(["size-4 transition-transform", { "rotate-180": settings.value.ui.telemetryExpanded }])
                      }, null, 8, ["class"])
                    ]),
                    settings.value.ui.telemetryExpanded ? (openBlock(), createElementBlock("div", _hoisted_78, [
                      createBaseVNode("section", _hoisted_79, [
                        createBaseVNode("div", _hoisted_80, [
                          createBaseVNode(
                            "b",
                            null,
                            toDisplayString(t("control.telemetry")),
                            1
                            /* TEXT */
                          )
                        ]),
                        createBaseVNode(
                          "button",
                          {
                            type: "button",
                            class: normalizeClass(["booster-switch", { "booster-switch-on": settings.value.telemetry.enabled }]),
                            onClick: _cache[16] || (_cache[16] = ($event) => applyPatch({ telemetry: { enabled: !settings.value.telemetry.enabled } }))
                          },
                          [..._cache[31] || (_cache[31] = [
                            createBaseVNode(
                              "span",
                              null,
                              null,
                              -1
                              /* CACHED */
                            )
                          ])],
                          2
                          /* CLASS */
                        )
                      ]),
                      createBaseVNode("label", _hoisted_81, [
                        createBaseVNode(
                          "span",
                          null,
                          toDisplayString(t("control.telemetryEndpoint")),
                          1
                          /* TEXT */
                        ),
                        createBaseVNode("input", {
                          value: settings.value.telemetry.endpoint,
                          class: "booster-input",
                          placeholder: t("control.telemetryEndpointPlaceholder"),
                          onChange: setTelemetryEndpoint
                        }, null, 40, _hoisted_82)
                      ]),
                      __props.secretAdapter ? (openBlock(), createElementBlock("div", _hoisted_83, [
                        createBaseVNode("span", _hoisted_84, [
                          createTextVNode(
                            toDisplayString(t("control.telemetryToken")) + " ",
                            1
                            /* TEXT */
                          ),
                          createVNode(unref(_sfc_main$3), {
                            variant: tokenConfigured.value ? "default" : "secondary"
                          }, {
                            default: withCtx(() => [
                              createTextVNode(
                                toDisplayString(tokenConfigured.value ? t("control.tokenConfigured") : t("control.tokenMissing")),
                                1
                                /* TEXT */
                              )
                            ]),
                            _: 1
                            /* STABLE */
                          }, 8, ["variant"])
                        ]),
                        !tokenConfigured.value || tokenEditing.value ? (openBlock(), createElementBlock("div", _hoisted_85, [
                          withDirectives(createBaseVNode(
                            "input",
                            {
                              "onUpdate:modelValue": _cache[17] || (_cache[17] = ($event) => tokenDraft.value = $event),
                              class: "booster-input",
                              type: "password",
                              autocomplete: "off"
                            },
                            null,
                            512
                            /* NEED_PATCH */
                          ), [
                            [vModelText, tokenDraft.value]
                          ]),
                          createVNode(unref(_sfc_main$2), {
                            variant: "outline",
                            size: "sm",
                            disabled: !tokenDraft.value.trim(),
                            onClick: saveToken
                          }, {
                            default: withCtx(() => [
                              createTextVNode(
                                toDisplayString(t("control.saveToken")),
                                1
                                /* TEXT */
                              )
                            ]),
                            _: 1
                            /* STABLE */
                          }, 8, ["disabled"]),
                          tokenConfigured.value ? (openBlock(), createBlock(unref(_sfc_main$2), {
                            key: 0,
                            variant: "ghost",
                            size: "sm",
                            onClick: _cache[18] || (_cache[18] = ($event) => {
                              tokenEditing.value = false;
                              tokenDraft.value = "";
                            })
                          }, {
                            default: withCtx(() => [
                              createTextVNode(
                                toDisplayString(t("control.cancel")),
                                1
                                /* TEXT */
                              )
                            ]),
                            _: 1
                            /* STABLE */
                          })) : createCommentVNode("v-if", true)
                        ])) : (openBlock(), createBlock(unref(_sfc_main$2), {
                          key: 1,
                          variant: "outline",
                          size: "sm",
                          class: "self-start",
                          onClick: _cache[19] || (_cache[19] = ($event) => tokenEditing.value = true)
                        }, {
                          default: withCtx(() => [
                            createTextVNode(
                              toDisplayString(t("control.changeToken")),
                              1
                              /* TEXT */
                            )
                          ]),
                          _: 1
                          /* STABLE */
                        }))
                      ])) : createCommentVNode("v-if", true),
                      createBaseVNode("div", _hoisted_86, [
                        createVNode(unref(_sfc_main$2), {
                          variant: "outline",
                          size: "sm",
                          disabled: telemetryTestState.value === "testing" || !settings.value.telemetry.endpoint || !tokenConfigured.value,
                          onClick: testTelemetry
                        }, {
                          default: withCtx(() => [
                            createTextVNode(
                              toDisplayString(telemetryTestState.value === "testing" ? t("control.testingTelemetry") : t("control.testTelemetry")),
                              1
                              /* TEXT */
                            )
                          ]),
                          _: 1
                          /* STABLE */
                        }, 8, ["disabled"]),
                        telemetryTestState.value === "success" ? (openBlock(), createElementBlock(
                          "span",
                          _hoisted_87,
                          toDisplayString(t("control.telemetryTestSuccess")),
                          1
                          /* TEXT */
                        )) : createCommentVNode("v-if", true),
                        telemetryTestState.value === "error" ? (openBlock(), createElementBlock("span", {
                          key: 1,
                          class: "booster-test-error",
                          title: telemetryTestError.value
                        }, toDisplayString(t("control.telemetryTestFailed")) + ": " + toDisplayString(telemetryTestError.value), 9, _hoisted_88)) : createCommentVNode("v-if", true)
                      ])
                    ])) : createCommentVNode("v-if", true)
                  ])
                ],
                64
                /* STABLE_FRAGMENT */
              )),
              createBaseVNode("footer", _hoisted_89, [
                createBaseVNode("span", _hoisted_90, [
                  saved.value ? (openBlock(), createBlock(unref(Check), {
                    key: 0,
                    class: "size-3.5"
                  })) : createCommentVNode("v-if", true),
                  createTextVNode(
                    " " + toDisplayString(saving.value ? t("control.saving") : saved.value ? t("control.saved") : t("control.live")),
                    1
                    /* TEXT */
                  )
                ])
              ])
            ])
          ])),
          archiveResetOpen.value ? (openBlock(), createBlock(_sfc_main$5, {
            key: 3,
            label: t("archiveReset.confirmTitle"),
            onClose: _cache[21] || (_cache[21] = ($event) => !archiveResetting.value && (archiveResetOpen.value = false))
          }, {
            default: withCtx(() => [
              createBaseVNode("div", _hoisted_91, [
                createBaseVNode("div", _hoisted_92, [
                  createVNode(unref(TriangleAlert), { class: "size-6" })
                ]),
                createBaseVNode("div", null, [
                  createBaseVNode(
                    "strong",
                    null,
                    toDisplayString(t("archiveReset.confirmTitle")),
                    1
                    /* TEXT */
                  ),
                  createBaseVNode(
                    "p",
                    null,
                    toDisplayString(t("archiveReset.confirmDescription")),
                    1
                    /* TEXT */
                  ),
                  createBaseVNode(
                    "p",
                    _hoisted_93,
                    toDisplayString(t("archiveReset.irreversible")),
                    1
                    /* TEXT */
                  ),
                  archiveResetError.value ? (openBlock(), createElementBlock(
                    "p",
                    _hoisted_94,
                    toDisplayString(archiveResetError.value),
                    1
                    /* TEXT */
                  )) : createCommentVNode("v-if", true)
                ]),
                createBaseVNode("div", _hoisted_95, [
                  createVNode(unref(_sfc_main$2), {
                    variant: "outline",
                    disabled: archiveResetting.value,
                    onClick: _cache[20] || (_cache[20] = ($event) => archiveResetOpen.value = false)
                  }, {
                    default: withCtx(() => [
                      createTextVNode(
                        toDisplayString(t("archiveReset.cancel")),
                        1
                        /* TEXT */
                      )
                    ]),
                    _: 1
                    /* STABLE */
                  }, 8, ["disabled"]),
                  createBaseVNode("button", {
                    type: "button",
                    class: "booster-destructive-button",
                    disabled: archiveResetting.value,
                    onClick: clearArchive
                  }, toDisplayString(archiveResetting.value ? t("archiveReset.clearing") : t("archiveReset.confirm")), 9, _hoisted_96)
                ])
              ])
            ]),
            _: 1
            /* STABLE */
          }, 8, ["label"])) : createCommentVNode("v-if", true)
        ], 10, _hoisted_1);
      };
    }
  });
  function createIsolatedMount(host2) {
    const shadow = host2.attachShadow({ mode: "open" });
    installBoosterShadowStyles(shadow);
    const mountPoint = document.createElement("div");
    shadow.append(mountPoint);
    return mountPoint;
  }
  function mountControlCenter(host2, options) {
    const mountPoint = createIsolatedMount(host2);
    const app = createApp(_sfc_main, {
      ...options,
      showClose: false
    });
    app.mount(mountPoint);
    return {
      unmount() {
        app.unmount();
        host2.replaceChildren();
      }
    };
  }
  const ANALYTICS_KEY = "analyticsTransportLifetime";
  const chromeAnalytics = {
    async getLifetimeTransportCounters() {
      const response = await chrome.runtime.sendMessage({
        type: "chatgpt-booster:analytics-get"
      });
      if (!response?.ok || !response.counters) {
        return { ...EMPTY_TRANSPORT_COUNTERS };
      }
      return response.counters;
    },
    async recordTransport(event) {
      const response = await chrome.runtime.sendMessage({
        type: "chatgpt-booster:analytics-record",
        event
      });
      if (!response?.ok) throw new Error(response?.error ?? "Analytics persistence failed");
    },
    async recordTransportBatch(events) {
      if (!events.length) return;
      const response = await chrome.runtime.sendMessage({
        type: "chatgpt-booster:analytics-record-batch",
        events
      });
      if (!response?.ok) throw new Error(response?.error ?? "Analytics persistence failed");
    },
    subscribeLifetimeTransport(listener) {
      const onChanged = (changes, areaName) => {
        if (areaName !== "local" || !changes[ANALYTICS_KEY]) return;
        listener({
          ...EMPTY_TRANSPORT_COUNTERS,
          ...changes[ANALYTICS_KEY].newValue
        });
      };
      chrome.storage.onChanged.addListener(onChanged);
      return () => chrome.storage.onChanged.removeListener(onChanged);
    }
  };
  const STORAGE_KEY = "settings";
  async function sendSettingsMessage(message) {
    const response = await chrome.runtime.sendMessage(message);
    if (!response?.ok || !response.settings) {
      throw new Error(response?.error ?? "Settings persistence failed");
    }
    return normalizeSettings(response.settings);
  }
  const chromeSettings = {
    async get() {
      const data = await chrome.storage.local.get(STORAGE_KEY);
      return normalizeSettings(data[STORAGE_KEY]);
    },
    async set(settings) {
      await sendSettingsMessage({
        type: "chatgpt-booster:settings-set",
        settings
      });
    },
    async update(patch) {
      return await sendSettingsMessage({
        type: "chatgpt-booster:settings-update",
        patch
      });
    },
    subscribe(listener) {
      const onChanged = (changes, areaName) => {
        if (areaName !== "local" || !changes[STORAGE_KEY]) return;
        listener(
          normalizeSettings(changes[STORAGE_KEY].newValue)
        );
      };
      chrome.storage.onChanged.addListener(onChanged);
      return () => chrome.storage.onChanged.removeListener(onChanged);
    }
  };
  const SECRET_PATTERN = /(Bearer\s+)[A-Za-z0-9._~+/-]+=*/gi;
  const JSON_SECRET_VALUE = /("(?:authorization|cookie|token|secret|password|passwd|api[-_]?key|session|credential|verify|turnstile|proof|challenge)[^"]*"\s*:\s*")[^"]*(")/gi;
  const JWT_LIKE = /\beyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\b/g;
  const QUERY_SECRET = /([?&](?:token|access_token|api_key|key|session|secret|auth|verify|turnstile|proof|challenge)=)[^&#]*/gi;
  const FLUSH_INTERVAL_MS = 2e3;
  const MAX_BATCH_SIZE = 50;
  function sanitizeText(value) {
    return value.replace(SECRET_PATTERN, "$1[REDACTED]").replace(QUERY_SECRET, "$1[REDACTED]").replace(JSON_SECRET_VALUE, "$1[REDACTED]$2").replace(JWT_LIKE, "[REDACTED_JWT]").slice(0, 8192);
  }
  function stringAttribute(value) {
    if (typeof value === "boolean") return { boolValue: value };
    if (typeof value === "number" && Number.isInteger(value)) return { intValue: String(value) };
    return { stringValue: sanitizeText(String(value)) };
  }
  function logRecord(event) {
    const attributes = Object.entries(event.attributes ?? {}).filter(([, value]) => value !== void 0 && value !== null).map(([key, value]) => ({
      key,
      value: stringAttribute(value)
    }));
    const severityNumber = event.severity === "ERROR" ? 17 : event.severity === "WARN" ? 13 : 9;
    const timestampNanos = String(BigInt(event.timestamp) * 1000000n);
    return {
      timeUnixNano: timestampNanos,
      observedTimeUnixNano: timestampNanos,
      severityNumber,
      severityText: event.severity ?? "INFO",
      body: { stringValue: sanitizeText(event.body ?? event.name) },
      attributes: [{ key: "event.name", value: { stringValue: event.name } }, ...attributes]
    };
  }
  function buildOtlpLogBatchPayload(events, serviceVersion) {
    const scopes = /* @__PURE__ */ new Map();
    for (const event of events) {
      const bucket = scopes.get(event.scope) ?? [];
      bucket.push(event);
      scopes.set(event.scope, bucket);
    }
    return {
      resourceLogs: [
        {
          resource: {
            attributes: [
              { key: "service.name", value: { stringValue: "chatgpt-booster-extension" } },
              { key: "service.namespace", value: { stringValue: "koba" } },
              { key: "service.version", value: { stringValue: serviceVersion } }
            ]
          },
          scopeLogs: [...scopes.entries()].map(([scope, scopeEvents]) => ({
            scope: {
              name: `chatgpt-booster.${scope}`,
              version: serviceVersion
            },
            logRecords: scopeEvents.map(logRecord)
          }))
        }
      ]
    };
  }
  class OtlpTelemetryClient {
    #sender;
    #serviceVersion;
    #getSettings;
    #getToken;
    #queue = [];
    #flushTimer;
    #flushPromise;
    constructor(options) {
      this.#sender = options.sender;
      this.#serviceVersion = options.serviceVersion;
      this.#getSettings = options.getSettings;
      this.#getToken = options.getToken;
    }
    async emit(event, options = {}) {
      if (options.force) {
        const settings = await this.#getSettings();
        if (!settings.endpoint.trim()) return;
        await this.#sendBatch([event], settings);
        return;
      }
      this.#queue.push(event);
      if (this.#queue.length >= MAX_BATCH_SIZE) {
        await this.flush();
        return;
      }
      this.#scheduleFlush();
    }
    async flush() {
      if (this.#flushTimer) {
        clearTimeout(this.#flushTimer);
        this.#flushTimer = void 0;
      }
      if (this.#queue.length === 0) return;
      if (this.#flushPromise) return await this.#flushPromise;
      const batch2 = this.#queue.splice(0, MAX_BATCH_SIZE);
      this.#flushPromise = (async () => {
        const settings = await this.#getSettings();
        if (!settings.enabled || !settings.endpoint.trim()) return;
        await this.#sendBatch(batch2, settings);
      })();
      try {
        await this.#flushPromise;
      } finally {
        this.#flushPromise = void 0;
        if (this.#queue.length > 0) this.#scheduleFlush();
      }
    }
    async test() {
      const settings = await this.#getSettings();
      if (!settings.endpoint.trim()) throw new Error("Telemetry endpoint is not configured");
      await this.emit(
        {
          scope: "runtime",
          name: "telemetry.test",
          timestamp: Date.now(),
          severity: "INFO",
          attributes: {
            "telemetry.test": true
          },
          body: "ChatGPT Booster telemetry test"
        },
        { force: true }
      );
    }
    #scheduleFlush() {
      if (this.#flushTimer) return;
      this.#flushTimer = setTimeout(() => {
        void this.flush().catch((error) => {
          console.warn("[ChatGPT Booster] Telemetry batch flush failed", error);
        });
      }, FLUSH_INTERVAL_MS);
    }
    async #sendBatch(events, settings) {
      const endpoint = settings.endpoint.trim().replace(/\/$/, "");
      const token = await this.#getToken();
      const headers = {
        "content-type": "application/json"
      };
      if (token) headers.authorization = `Bearer ${token}`;
      await this.#sender({
        url: `${endpoint}/v1/logs`,
        headers,
        body: JSON.stringify(buildOtlpLogBatchPayload(events, this.#serviceVersion))
      });
    }
  }
  const TOKEN_KEY = "telemetryToken";
  const chromeSecrets = {
    async getTelemetryToken() {
      const stored = await chrome.storage.local.get(TOKEN_KEY);
      return typeof stored[TOKEN_KEY] === "string" ? stored[TOKEN_KEY] : "";
    },
    async setTelemetryToken(token) {
      await chrome.storage.local.set({ [TOKEN_KEY]: token });
    }
  };
  function createChromeTelemetry(settings) {
    return new OtlpTelemetryClient({
      serviceVersion: BOOSTER_VERSION,
      getSettings: async () => (await settings.get()).telemetry,
      // The background worker owns the token and adds Authorization.
      getToken: async () => "",
      sender: async ({ url, body }) => {
        const response = await chrome.runtime.sendMessage({
          type: "chatgpt-booster:telemetry-post",
          url,
          body
        });
        if (!response?.ok) throw new Error(response?.error ?? "Telemetry background request failed");
      }
    });
  }
  function createChromeTelemetryControl(telemetry2, settings) {
    return {
      async test() {
        if (settings) {
          const endpoint = (await settings.get()).telemetry.endpoint.trim();
          if (!endpoint) throw new Error("Configure a telemetry endpoint first");
          const parsed = new URL(endpoint);
          if (parsed.protocol !== "https:") throw new Error("Telemetry endpoint must use HTTPS");
          const origin = `${parsed.origin}/*`;
          if (chrome.permissions?.contains && chrome.permissions.request) {
            if (!await chrome.permissions.contains({ origins: [origin] })) {
              const granted = await chrome.permissions.request({ origins: [origin] });
              if (!granted) throw new Error("Telemetry host permission was not granted");
            }
          } else {
            const state = await chrome.runtime.sendMessage({
              type: "chatgpt-booster:telemetry-permission-check",
              origin: parsed.origin
            });
            if (!state?.granted)
              throw new Error("Allow this telemetry endpoint in the ChatGPT Booster extension popup first");
          }
        }
        await telemetry2.test();
      }
    };
  }
  document.body.style.margin = "0";
  document.body.style.minWidth = "620px";
  const host = document.getElementById("app");
  if (!host) throw new Error("Popup mount point is missing");
  const telemetry = createChromeTelemetry(chromeSettings);
  mountControlCenter(host, {
    settingsAdapter: chromeSettings,
    persistentDiagnosticsAdapter: chromeAnalytics,
    secretAdapter: chromeSecrets,
    telemetryControlAdapter: createChromeTelemetryControl(telemetry, chromeSettings),
    targetLabel: "Extension"
  });
})();
